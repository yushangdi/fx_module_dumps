
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/resnetv2_101x1_bitm/resnetv2_101x1_bitm_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, tangents_1):
        view_default = torch.ops.aten.view.default(primals_306, [1, 64, 147]);  primals_306 = None
        empty = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default, None, None, None, None, True, 0.0, 1e-08)
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        view_default_1 = torch.ops.aten.view.default(getitem, [64, 3, 7, 7]);  getitem = None
        convolution_default = torch.ops.aten.convolution.default(primals_307, view_default_1, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(convolution_default, [1, 1, 1, 1], 0.0);  convolution_default = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default, [3, 3], [2, 2])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        native_group_norm_default = torch.ops.aten.native_group_norm.default(getitem_3, primals_10, primals_9, 64, 64, 12544, 32, 1e-05);  primals_9 = None
        getitem_5 = native_group_norm_default[0]
        getitem_6 = native_group_norm_default[1]
        getitem_7 = native_group_norm_default[2];  native_group_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        view_default_2 = torch.ops.aten.view.default(primals_8, [1, 256, 64]);  primals_8 = None
        empty_1 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_2, None, None, None, None, True, 0.0, 1e-08)
        getitem_8 = native_batch_norm_default_1[0]
        getitem_9 = native_batch_norm_default_1[1]
        getitem_10 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(getitem_8, [256, 64, 1, 1]);  getitem_8 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, view_default_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_4 = torch.ops.aten.view.default(primals_5, [1, 64, 64]);  primals_5 = None
        empty_2 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_4, None, None, None, None, True, 0.0, 1e-08)
        getitem_11 = native_batch_norm_default_2[0]
        getitem_12 = native_batch_norm_default_2[1]
        getitem_13 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(getitem_11, [64, 64, 1, 1]);  getitem_11 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default, view_default_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_1 = torch.ops.aten.native_group_norm.default(convolution_default_2, primals_12, primals_11, 64, 64, 12544, 32, 1e-05);  primals_11 = None
        getitem_14 = native_group_norm_default_1[0]
        getitem_15 = native_group_norm_default_1[1]
        getitem_16 = native_group_norm_default_1[2];  native_group_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        view_default_6 = torch.ops.aten.view.default(primals_6, [1, 64, 576]);  primals_6 = None
        empty_3 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_6, None, None, None, None, True, 0.0, 1e-08)
        getitem_17 = native_batch_norm_default_3[0]
        getitem_18 = native_batch_norm_default_3[1]
        getitem_19 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        view_default_7 = torch.ops.aten.view.default(getitem_17, [64, 64, 3, 3]);  getitem_17 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_1, view_default_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_2 = torch.ops.aten.native_group_norm.default(convolution_default_3, primals_14, primals_13, 64, 64, 12544, 32, 1e-05);  primals_13 = None
        getitem_20 = native_group_norm_default_2[0]
        getitem_21 = native_group_norm_default_2[1]
        getitem_22 = native_group_norm_default_2[2];  native_group_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        view_default_8 = torch.ops.aten.view.default(primals_7, [1, 256, 64]);  primals_7 = None
        empty_4 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_8, None, None, None, None, True, 0.0, 1e-08)
        getitem_23 = native_batch_norm_default_4[0]
        getitem_24 = native_batch_norm_default_4[1]
        getitem_25 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        view_default_9 = torch.ops.aten.view.default(getitem_23, [256, 64, 1, 1]);  getitem_23 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_2, view_default_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(convolution_default_4, convolution_default_1);  convolution_default_4 = convolution_default_1 = None
        native_group_norm_default_3 = torch.ops.aten.native_group_norm.default(add_tensor, primals_19, primals_18, 64, 256, 12544, 32, 1e-05);  primals_18 = None
        getitem_26 = native_group_norm_default_3[0]
        getitem_27 = native_group_norm_default_3[1]
        getitem_28 = native_group_norm_default_3[2];  native_group_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        view_default_10 = torch.ops.aten.view.default(primals_15, [1, 64, 256]);  primals_15 = None
        empty_5 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_10, None, None, None, None, True, 0.0, 1e-08)
        getitem_29 = native_batch_norm_default_5[0]
        getitem_30 = native_batch_norm_default_5[1]
        getitem_31 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        view_default_11 = torch.ops.aten.view.default(getitem_29, [64, 256, 1, 1]);  getitem_29 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_3, view_default_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_4 = torch.ops.aten.native_group_norm.default(convolution_default_5, primals_21, primals_20, 64, 64, 12544, 32, 1e-05);  primals_20 = None
        getitem_32 = native_group_norm_default_4[0]
        getitem_33 = native_group_norm_default_4[1]
        getitem_34 = native_group_norm_default_4[2];  native_group_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        view_default_12 = torch.ops.aten.view.default(primals_16, [1, 64, 576]);  primals_16 = None
        empty_6 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_12, None, None, None, None, True, 0.0, 1e-08)
        getitem_35 = native_batch_norm_default_6[0]
        getitem_36 = native_batch_norm_default_6[1]
        getitem_37 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        view_default_13 = torch.ops.aten.view.default(getitem_35, [64, 64, 3, 3]);  getitem_35 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, view_default_13, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_5 = torch.ops.aten.native_group_norm.default(convolution_default_6, primals_23, primals_22, 64, 64, 12544, 32, 1e-05);  primals_22 = None
        getitem_38 = native_group_norm_default_5[0]
        getitem_39 = native_group_norm_default_5[1]
        getitem_40 = native_group_norm_default_5[2];  native_group_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        view_default_14 = torch.ops.aten.view.default(primals_17, [1, 256, 64]);  primals_17 = None
        empty_7 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_14, None, None, None, None, True, 0.0, 1e-08)
        getitem_41 = native_batch_norm_default_7[0]
        getitem_42 = native_batch_norm_default_7[1]
        getitem_43 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        view_default_15 = torch.ops.aten.view.default(getitem_41, [256, 64, 1, 1]);  getitem_41 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, view_default_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(convolution_default_7, add_tensor);  convolution_default_7 = None
        native_group_norm_default_6 = torch.ops.aten.native_group_norm.default(add_tensor_1, primals_28, primals_27, 64, 256, 12544, 32, 1e-05);  primals_27 = None
        getitem_44 = native_group_norm_default_6[0]
        getitem_45 = native_group_norm_default_6[1]
        getitem_46 = native_group_norm_default_6[2];  native_group_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        view_default_16 = torch.ops.aten.view.default(primals_24, [1, 64, 256]);  primals_24 = None
        empty_8 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_16, None, None, None, None, True, 0.0, 1e-08)
        getitem_47 = native_batch_norm_default_8[0]
        getitem_48 = native_batch_norm_default_8[1]
        getitem_49 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        view_default_17 = torch.ops.aten.view.default(getitem_47, [64, 256, 1, 1]);  getitem_47 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, view_default_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_7 = torch.ops.aten.native_group_norm.default(convolution_default_8, primals_30, primals_29, 64, 64, 12544, 32, 1e-05);  primals_29 = None
        getitem_50 = native_group_norm_default_7[0]
        getitem_51 = native_group_norm_default_7[1]
        getitem_52 = native_group_norm_default_7[2];  native_group_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        view_default_18 = torch.ops.aten.view.default(primals_25, [1, 64, 576]);  primals_25 = None
        empty_9 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_18, None, None, None, None, True, 0.0, 1e-08)
        getitem_53 = native_batch_norm_default_9[0]
        getitem_54 = native_batch_norm_default_9[1]
        getitem_55 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        view_default_19 = torch.ops.aten.view.default(getitem_53, [64, 64, 3, 3]);  getitem_53 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, view_default_19, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_8 = torch.ops.aten.native_group_norm.default(convolution_default_9, primals_32, primals_31, 64, 64, 12544, 32, 1e-05);  primals_31 = None
        getitem_56 = native_group_norm_default_8[0]
        getitem_57 = native_group_norm_default_8[1]
        getitem_58 = native_group_norm_default_8[2];  native_group_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        view_default_20 = torch.ops.aten.view.default(primals_26, [1, 256, 64]);  primals_26 = None
        empty_10 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_20, None, None, None, None, True, 0.0, 1e-08)
        getitem_59 = native_batch_norm_default_10[0]
        getitem_60 = native_batch_norm_default_10[1]
        getitem_61 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        view_default_21 = torch.ops.aten.view.default(getitem_59, [256, 64, 1, 1]);  getitem_59 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, view_default_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(convolution_default_10, add_tensor_1);  convolution_default_10 = None
        native_group_norm_default_9 = torch.ops.aten.native_group_norm.default(add_tensor_2, primals_38, primals_37, 64, 256, 12544, 32, 1e-05);  primals_37 = None
        getitem_62 = native_group_norm_default_9[0]
        getitem_63 = native_group_norm_default_9[1]
        getitem_64 = native_group_norm_default_9[2];  native_group_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        view_default_22 = torch.ops.aten.view.default(primals_36, [1, 512, 256]);  primals_36 = None
        empty_11 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_22, None, None, None, None, True, 0.0, 1e-08)
        getitem_65 = native_batch_norm_default_11[0]
        getitem_66 = native_batch_norm_default_11[1]
        getitem_67 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        view_default_23 = torch.ops.aten.view.default(getitem_65, [512, 256, 1, 1]);  getitem_65 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, view_default_23, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_24 = torch.ops.aten.view.default(primals_33, [1, 128, 256]);  primals_33 = None
        empty_12 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_24, None, None, None, None, True, 0.0, 1e-08)
        getitem_68 = native_batch_norm_default_12[0]
        getitem_69 = native_batch_norm_default_12[1]
        getitem_70 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        view_default_25 = torch.ops.aten.view.default(getitem_68, [128, 256, 1, 1]);  getitem_68 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_9, view_default_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_10 = torch.ops.aten.native_group_norm.default(convolution_default_12, primals_40, primals_39, 64, 128, 12544, 32, 1e-05);  primals_39 = None
        getitem_71 = native_group_norm_default_10[0]
        getitem_72 = native_group_norm_default_10[1]
        getitem_73 = native_group_norm_default_10[2];  native_group_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        view_default_26 = torch.ops.aten.view.default(primals_34, [1, 128, 1152]);  primals_34 = None
        empty_13 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_26, None, None, None, None, True, 0.0, 1e-08)
        getitem_74 = native_batch_norm_default_13[0]
        getitem_75 = native_batch_norm_default_13[1]
        getitem_76 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        view_default_27 = torch.ops.aten.view.default(getitem_74, [128, 128, 3, 3]);  getitem_74 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_10, view_default_27, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_11 = torch.ops.aten.native_group_norm.default(convolution_default_13, primals_42, primals_41, 64, 128, 3136, 32, 1e-05);  primals_41 = None
        getitem_77 = native_group_norm_default_11[0]
        getitem_78 = native_group_norm_default_11[1]
        getitem_79 = native_group_norm_default_11[2];  native_group_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        view_default_28 = torch.ops.aten.view.default(primals_35, [1, 512, 128]);  primals_35 = None
        empty_14 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_28, None, None, None, None, True, 0.0, 1e-08)
        getitem_80 = native_batch_norm_default_14[0]
        getitem_81 = native_batch_norm_default_14[1]
        getitem_82 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        view_default_29 = torch.ops.aten.view.default(getitem_80, [512, 128, 1, 1]);  getitem_80 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_11, view_default_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(convolution_default_14, convolution_default_11);  convolution_default_14 = convolution_default_11 = None
        native_group_norm_default_12 = torch.ops.aten.native_group_norm.default(add_tensor_3, primals_47, primals_46, 64, 512, 3136, 32, 1e-05);  primals_46 = None
        getitem_83 = native_group_norm_default_12[0]
        getitem_84 = native_group_norm_default_12[1]
        getitem_85 = native_group_norm_default_12[2];  native_group_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        view_default_30 = torch.ops.aten.view.default(primals_43, [1, 128, 512]);  primals_43 = None
        empty_15 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_30, None, None, None, None, True, 0.0, 1e-08)
        getitem_86 = native_batch_norm_default_15[0]
        getitem_87 = native_batch_norm_default_15[1]
        getitem_88 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        view_default_31 = torch.ops.aten.view.default(getitem_86, [128, 512, 1, 1]);  getitem_86 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_12, view_default_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_13 = torch.ops.aten.native_group_norm.default(convolution_default_15, primals_49, primals_48, 64, 128, 3136, 32, 1e-05);  primals_48 = None
        getitem_89 = native_group_norm_default_13[0]
        getitem_90 = native_group_norm_default_13[1]
        getitem_91 = native_group_norm_default_13[2];  native_group_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        view_default_32 = torch.ops.aten.view.default(primals_44, [1, 128, 1152]);  primals_44 = None
        empty_16 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_32, None, None, None, None, True, 0.0, 1e-08)
        getitem_92 = native_batch_norm_default_16[0]
        getitem_93 = native_batch_norm_default_16[1]
        getitem_94 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        view_default_33 = torch.ops.aten.view.default(getitem_92, [128, 128, 3, 3]);  getitem_92 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, view_default_33, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_14 = torch.ops.aten.native_group_norm.default(convolution_default_16, primals_51, primals_50, 64, 128, 3136, 32, 1e-05);  primals_50 = None
        getitem_95 = native_group_norm_default_14[0]
        getitem_96 = native_group_norm_default_14[1]
        getitem_97 = native_group_norm_default_14[2];  native_group_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        view_default_34 = torch.ops.aten.view.default(primals_45, [1, 512, 128]);  primals_45 = None
        empty_17 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(view_default_34, None, None, None, None, True, 0.0, 1e-08)
        getitem_98 = native_batch_norm_default_17[0]
        getitem_99 = native_batch_norm_default_17[1]
        getitem_100 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        view_default_35 = torch.ops.aten.view.default(getitem_98, [512, 128, 1, 1]);  getitem_98 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_14, view_default_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(convolution_default_17, add_tensor_3);  convolution_default_17 = None
        native_group_norm_default_15 = torch.ops.aten.native_group_norm.default(add_tensor_4, primals_56, primals_55, 64, 512, 3136, 32, 1e-05);  primals_55 = None
        getitem_101 = native_group_norm_default_15[0]
        getitem_102 = native_group_norm_default_15[1]
        getitem_103 = native_group_norm_default_15[2];  native_group_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        view_default_36 = torch.ops.aten.view.default(primals_52, [1, 128, 512]);  primals_52 = None
        empty_18 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(view_default_36, None, None, None, None, True, 0.0, 1e-08)
        getitem_104 = native_batch_norm_default_18[0]
        getitem_105 = native_batch_norm_default_18[1]
        getitem_106 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        view_default_37 = torch.ops.aten.view.default(getitem_104, [128, 512, 1, 1]);  getitem_104 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_15, view_default_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_16 = torch.ops.aten.native_group_norm.default(convolution_default_18, primals_58, primals_57, 64, 128, 3136, 32, 1e-05);  primals_57 = None
        getitem_107 = native_group_norm_default_16[0]
        getitem_108 = native_group_norm_default_16[1]
        getitem_109 = native_group_norm_default_16[2];  native_group_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        view_default_38 = torch.ops.aten.view.default(primals_53, [1, 128, 1152]);  primals_53 = None
        empty_19 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(view_default_38, None, None, None, None, True, 0.0, 1e-08)
        getitem_110 = native_batch_norm_default_19[0]
        getitem_111 = native_batch_norm_default_19[1]
        getitem_112 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        view_default_39 = torch.ops.aten.view.default(getitem_110, [128, 128, 3, 3]);  getitem_110 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_16, view_default_39, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_17 = torch.ops.aten.native_group_norm.default(convolution_default_19, primals_60, primals_59, 64, 128, 3136, 32, 1e-05);  primals_59 = None
        getitem_113 = native_group_norm_default_17[0]
        getitem_114 = native_group_norm_default_17[1]
        getitem_115 = native_group_norm_default_17[2];  native_group_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        view_default_40 = torch.ops.aten.view.default(primals_54, [1, 512, 128]);  primals_54 = None
        empty_20 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(view_default_40, None, None, None, None, True, 0.0, 1e-08)
        getitem_116 = native_batch_norm_default_20[0]
        getitem_117 = native_batch_norm_default_20[1]
        getitem_118 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        view_default_41 = torch.ops.aten.view.default(getitem_116, [512, 128, 1, 1]);  getitem_116 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_17, view_default_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(convolution_default_20, add_tensor_4);  convolution_default_20 = None
        native_group_norm_default_18 = torch.ops.aten.native_group_norm.default(add_tensor_5, primals_65, primals_64, 64, 512, 3136, 32, 1e-05);  primals_64 = None
        getitem_119 = native_group_norm_default_18[0]
        getitem_120 = native_group_norm_default_18[1]
        getitem_121 = native_group_norm_default_18[2];  native_group_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        view_default_42 = torch.ops.aten.view.default(primals_61, [1, 128, 512]);  primals_61 = None
        empty_21 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(view_default_42, None, None, None, None, True, 0.0, 1e-08)
        getitem_122 = native_batch_norm_default_21[0]
        getitem_123 = native_batch_norm_default_21[1]
        getitem_124 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        view_default_43 = torch.ops.aten.view.default(getitem_122, [128, 512, 1, 1]);  getitem_122 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_18, view_default_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_19 = torch.ops.aten.native_group_norm.default(convolution_default_21, primals_67, primals_66, 64, 128, 3136, 32, 1e-05);  primals_66 = None
        getitem_125 = native_group_norm_default_19[0]
        getitem_126 = native_group_norm_default_19[1]
        getitem_127 = native_group_norm_default_19[2];  native_group_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        view_default_44 = torch.ops.aten.view.default(primals_62, [1, 128, 1152]);  primals_62 = None
        empty_22 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(view_default_44, None, None, None, None, True, 0.0, 1e-08)
        getitem_128 = native_batch_norm_default_22[0]
        getitem_129 = native_batch_norm_default_22[1]
        getitem_130 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        view_default_45 = torch.ops.aten.view.default(getitem_128, [128, 128, 3, 3]);  getitem_128 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_19, view_default_45, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_20 = torch.ops.aten.native_group_norm.default(convolution_default_22, primals_69, primals_68, 64, 128, 3136, 32, 1e-05);  primals_68 = None
        getitem_131 = native_group_norm_default_20[0]
        getitem_132 = native_group_norm_default_20[1]
        getitem_133 = native_group_norm_default_20[2];  native_group_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        view_default_46 = torch.ops.aten.view.default(primals_63, [1, 512, 128]);  primals_63 = None
        empty_23 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(view_default_46, None, None, None, None, True, 0.0, 1e-08)
        getitem_134 = native_batch_norm_default_23[0]
        getitem_135 = native_batch_norm_default_23[1]
        getitem_136 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        view_default_47 = torch.ops.aten.view.default(getitem_134, [512, 128, 1, 1]);  getitem_134 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_20, view_default_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(convolution_default_23, add_tensor_5);  convolution_default_23 = None
        native_group_norm_default_21 = torch.ops.aten.native_group_norm.default(add_tensor_6, primals_75, primals_74, 64, 512, 3136, 32, 1e-05);  primals_74 = None
        getitem_137 = native_group_norm_default_21[0]
        getitem_138 = native_group_norm_default_21[1]
        getitem_139 = native_group_norm_default_21[2];  native_group_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_137);  getitem_137 = None
        view_default_48 = torch.ops.aten.view.default(primals_73, [1, 1024, 512]);  primals_73 = None
        empty_24 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(view_default_48, None, None, None, None, True, 0.0, 1e-08)
        getitem_140 = native_batch_norm_default_24[0]
        getitem_141 = native_batch_norm_default_24[1]
        getitem_142 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        view_default_49 = torch.ops.aten.view.default(getitem_140, [1024, 512, 1, 1]);  getitem_140 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_21, view_default_49, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_50 = torch.ops.aten.view.default(primals_70, [1, 256, 512]);  primals_70 = None
        empty_25 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(view_default_50, None, None, None, None, True, 0.0, 1e-08)
        getitem_143 = native_batch_norm_default_25[0]
        getitem_144 = native_batch_norm_default_25[1]
        getitem_145 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        view_default_51 = torch.ops.aten.view.default(getitem_143, [256, 512, 1, 1]);  getitem_143 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_21, view_default_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_22 = torch.ops.aten.native_group_norm.default(convolution_default_25, primals_77, primals_76, 64, 256, 3136, 32, 1e-05);  primals_76 = None
        getitem_146 = native_group_norm_default_22[0]
        getitem_147 = native_group_norm_default_22[1]
        getitem_148 = native_group_norm_default_22[2];  native_group_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        view_default_52 = torch.ops.aten.view.default(primals_71, [1, 256, 2304]);  primals_71 = None
        empty_26 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(view_default_52, None, None, None, None, True, 0.0, 1e-08)
        getitem_149 = native_batch_norm_default_26[0]
        getitem_150 = native_batch_norm_default_26[1]
        getitem_151 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        view_default_53 = torch.ops.aten.view.default(getitem_149, [256, 256, 3, 3]);  getitem_149 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_22, view_default_53, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_23 = torch.ops.aten.native_group_norm.default(convolution_default_26, primals_79, primals_78, 64, 256, 784, 32, 1e-05);  primals_78 = None
        getitem_152 = native_group_norm_default_23[0]
        getitem_153 = native_group_norm_default_23[1]
        getitem_154 = native_group_norm_default_23[2];  native_group_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        view_default_54 = torch.ops.aten.view.default(primals_72, [1, 1024, 256]);  primals_72 = None
        empty_27 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(view_default_54, None, None, None, None, True, 0.0, 1e-08)
        getitem_155 = native_batch_norm_default_27[0]
        getitem_156 = native_batch_norm_default_27[1]
        getitem_157 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        view_default_55 = torch.ops.aten.view.default(getitem_155, [1024, 256, 1, 1]);  getitem_155 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_23, view_default_55, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(convolution_default_27, convolution_default_24);  convolution_default_27 = convolution_default_24 = None
        native_group_norm_default_24 = torch.ops.aten.native_group_norm.default(add_tensor_7, primals_174, primals_173, 64, 1024, 784, 32, 1e-05);  primals_173 = None
        getitem_158 = native_group_norm_default_24[0]
        getitem_159 = native_group_norm_default_24[1]
        getitem_160 = native_group_norm_default_24[2];  native_group_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        view_default_56 = torch.ops.aten.view.default(primals_170, [1, 256, 1024]);  primals_170 = None
        empty_28 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(view_default_56, None, None, None, None, True, 0.0, 1e-08)
        getitem_161 = native_batch_norm_default_28[0]
        getitem_162 = native_batch_norm_default_28[1]
        getitem_163 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        view_default_57 = torch.ops.aten.view.default(getitem_161, [256, 1024, 1, 1]);  getitem_161 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_24, view_default_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_25 = torch.ops.aten.native_group_norm.default(convolution_default_28, primals_176, primals_175, 64, 256, 784, 32, 1e-05);  primals_175 = None
        getitem_164 = native_group_norm_default_25[0]
        getitem_165 = native_group_norm_default_25[1]
        getitem_166 = native_group_norm_default_25[2];  native_group_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        view_default_58 = torch.ops.aten.view.default(primals_171, [1, 256, 2304]);  primals_171 = None
        empty_29 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(view_default_58, None, None, None, None, True, 0.0, 1e-08)
        getitem_167 = native_batch_norm_default_29[0]
        getitem_168 = native_batch_norm_default_29[1]
        getitem_169 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        view_default_59 = torch.ops.aten.view.default(getitem_167, [256, 256, 3, 3]);  getitem_167 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_25, view_default_59, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_26 = torch.ops.aten.native_group_norm.default(convolution_default_29, primals_178, primals_177, 64, 256, 784, 32, 1e-05);  primals_177 = None
        getitem_170 = native_group_norm_default_26[0]
        getitem_171 = native_group_norm_default_26[1]
        getitem_172 = native_group_norm_default_26[2];  native_group_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        view_default_60 = torch.ops.aten.view.default(primals_172, [1, 1024, 256]);  primals_172 = None
        empty_30 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(view_default_60, None, None, None, None, True, 0.0, 1e-08)
        getitem_173 = native_batch_norm_default_30[0]
        getitem_174 = native_batch_norm_default_30[1]
        getitem_175 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        view_default_61 = torch.ops.aten.view.default(getitem_173, [1024, 256, 1, 1]);  getitem_173 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_26, view_default_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(convolution_default_30, add_tensor_7);  convolution_default_30 = None
        native_group_norm_default_27 = torch.ops.aten.native_group_norm.default(add_tensor_8, primals_210, primals_209, 64, 1024, 784, 32, 1e-05);  primals_209 = None
        getitem_176 = native_group_norm_default_27[0]
        getitem_177 = native_group_norm_default_27[1]
        getitem_178 = native_group_norm_default_27[2];  native_group_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        view_default_62 = torch.ops.aten.view.default(primals_206, [1, 256, 1024]);  primals_206 = None
        empty_31 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(view_default_62, None, None, None, None, True, 0.0, 1e-08)
        getitem_179 = native_batch_norm_default_31[0]
        getitem_180 = native_batch_norm_default_31[1]
        getitem_181 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        view_default_63 = torch.ops.aten.view.default(getitem_179, [256, 1024, 1, 1]);  getitem_179 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_27, view_default_63, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_28 = torch.ops.aten.native_group_norm.default(convolution_default_31, primals_212, primals_211, 64, 256, 784, 32, 1e-05);  primals_211 = None
        getitem_182 = native_group_norm_default_28[0]
        getitem_183 = native_group_norm_default_28[1]
        getitem_184 = native_group_norm_default_28[2];  native_group_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        view_default_64 = torch.ops.aten.view.default(primals_207, [1, 256, 2304]);  primals_207 = None
        empty_32 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(view_default_64, None, None, None, None, True, 0.0, 1e-08)
        getitem_185 = native_batch_norm_default_32[0]
        getitem_186 = native_batch_norm_default_32[1]
        getitem_187 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        view_default_65 = torch.ops.aten.view.default(getitem_185, [256, 256, 3, 3]);  getitem_185 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_28, view_default_65, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_29 = torch.ops.aten.native_group_norm.default(convolution_default_32, primals_214, primals_213, 64, 256, 784, 32, 1e-05);  primals_213 = None
        getitem_188 = native_group_norm_default_29[0]
        getitem_189 = native_group_norm_default_29[1]
        getitem_190 = native_group_norm_default_29[2];  native_group_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        view_default_66 = torch.ops.aten.view.default(primals_208, [1, 1024, 256]);  primals_208 = None
        empty_33 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(view_default_66, None, None, None, None, True, 0.0, 1e-08)
        getitem_191 = native_batch_norm_default_33[0]
        getitem_192 = native_batch_norm_default_33[1]
        getitem_193 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        view_default_67 = torch.ops.aten.view.default(getitem_191, [1024, 256, 1, 1]);  getitem_191 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_29, view_default_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(convolution_default_33, add_tensor_8);  convolution_default_33 = None
        native_group_norm_default_30 = torch.ops.aten.native_group_norm.default(add_tensor_9, primals_219, primals_218, 64, 1024, 784, 32, 1e-05);  primals_218 = None
        getitem_194 = native_group_norm_default_30[0]
        getitem_195 = native_group_norm_default_30[1]
        getitem_196 = native_group_norm_default_30[2];  native_group_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        view_default_68 = torch.ops.aten.view.default(primals_215, [1, 256, 1024]);  primals_215 = None
        empty_34 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(view_default_68, None, None, None, None, True, 0.0, 1e-08)
        getitem_197 = native_batch_norm_default_34[0]
        getitem_198 = native_batch_norm_default_34[1]
        getitem_199 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        view_default_69 = torch.ops.aten.view.default(getitem_197, [256, 1024, 1, 1]);  getitem_197 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_30, view_default_69, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_31 = torch.ops.aten.native_group_norm.default(convolution_default_34, primals_221, primals_220, 64, 256, 784, 32, 1e-05);  primals_220 = None
        getitem_200 = native_group_norm_default_31[0]
        getitem_201 = native_group_norm_default_31[1]
        getitem_202 = native_group_norm_default_31[2];  native_group_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        view_default_70 = torch.ops.aten.view.default(primals_216, [1, 256, 2304]);  primals_216 = None
        empty_35 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(view_default_70, None, None, None, None, True, 0.0, 1e-08)
        getitem_203 = native_batch_norm_default_35[0]
        getitem_204 = native_batch_norm_default_35[1]
        getitem_205 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        view_default_71 = torch.ops.aten.view.default(getitem_203, [256, 256, 3, 3]);  getitem_203 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_31, view_default_71, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_32 = torch.ops.aten.native_group_norm.default(convolution_default_35, primals_223, primals_222, 64, 256, 784, 32, 1e-05);  primals_222 = None
        getitem_206 = native_group_norm_default_32[0]
        getitem_207 = native_group_norm_default_32[1]
        getitem_208 = native_group_norm_default_32[2];  native_group_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        view_default_72 = torch.ops.aten.view.default(primals_217, [1, 1024, 256]);  primals_217 = None
        empty_36 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(view_default_72, None, None, None, None, True, 0.0, 1e-08)
        getitem_209 = native_batch_norm_default_36[0]
        getitem_210 = native_batch_norm_default_36[1]
        getitem_211 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        view_default_73 = torch.ops.aten.view.default(getitem_209, [1024, 256, 1, 1]);  getitem_209 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_32, view_default_73, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(convolution_default_36, add_tensor_9);  convolution_default_36 = None
        native_group_norm_default_33 = torch.ops.aten.native_group_norm.default(add_tensor_10, primals_228, primals_227, 64, 1024, 784, 32, 1e-05);  primals_227 = None
        getitem_212 = native_group_norm_default_33[0]
        getitem_213 = native_group_norm_default_33[1]
        getitem_214 = native_group_norm_default_33[2];  native_group_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        view_default_74 = torch.ops.aten.view.default(primals_224, [1, 256, 1024]);  primals_224 = None
        empty_37 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(view_default_74, None, None, None, None, True, 0.0, 1e-08)
        getitem_215 = native_batch_norm_default_37[0]
        getitem_216 = native_batch_norm_default_37[1]
        getitem_217 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        view_default_75 = torch.ops.aten.view.default(getitem_215, [256, 1024, 1, 1]);  getitem_215 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_33, view_default_75, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_34 = torch.ops.aten.native_group_norm.default(convolution_default_37, primals_230, primals_229, 64, 256, 784, 32, 1e-05);  primals_229 = None
        getitem_218 = native_group_norm_default_34[0]
        getitem_219 = native_group_norm_default_34[1]
        getitem_220 = native_group_norm_default_34[2];  native_group_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        view_default_76 = torch.ops.aten.view.default(primals_225, [1, 256, 2304]);  primals_225 = None
        empty_38 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(view_default_76, None, None, None, None, True, 0.0, 1e-08)
        getitem_221 = native_batch_norm_default_38[0]
        getitem_222 = native_batch_norm_default_38[1]
        getitem_223 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        view_default_77 = torch.ops.aten.view.default(getitem_221, [256, 256, 3, 3]);  getitem_221 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_34, view_default_77, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_35 = torch.ops.aten.native_group_norm.default(convolution_default_38, primals_232, primals_231, 64, 256, 784, 32, 1e-05);  primals_231 = None
        getitem_224 = native_group_norm_default_35[0]
        getitem_225 = native_group_norm_default_35[1]
        getitem_226 = native_group_norm_default_35[2];  native_group_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        view_default_78 = torch.ops.aten.view.default(primals_226, [1, 1024, 256]);  primals_226 = None
        empty_39 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(view_default_78, None, None, None, None, True, 0.0, 1e-08)
        getitem_227 = native_batch_norm_default_39[0]
        getitem_228 = native_batch_norm_default_39[1]
        getitem_229 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        view_default_79 = torch.ops.aten.view.default(getitem_227, [1024, 256, 1, 1]);  getitem_227 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_35, view_default_79, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(convolution_default_39, add_tensor_10);  convolution_default_39 = None
        native_group_norm_default_36 = torch.ops.aten.native_group_norm.default(add_tensor_11, primals_237, primals_236, 64, 1024, 784, 32, 1e-05);  primals_236 = None
        getitem_230 = native_group_norm_default_36[0]
        getitem_231 = native_group_norm_default_36[1]
        getitem_232 = native_group_norm_default_36[2];  native_group_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        view_default_80 = torch.ops.aten.view.default(primals_233, [1, 256, 1024]);  primals_233 = None
        empty_40 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(view_default_80, None, None, None, None, True, 0.0, 1e-08)
        getitem_233 = native_batch_norm_default_40[0]
        getitem_234 = native_batch_norm_default_40[1]
        getitem_235 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        view_default_81 = torch.ops.aten.view.default(getitem_233, [256, 1024, 1, 1]);  getitem_233 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_36, view_default_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_37 = torch.ops.aten.native_group_norm.default(convolution_default_40, primals_239, primals_238, 64, 256, 784, 32, 1e-05);  primals_238 = None
        getitem_236 = native_group_norm_default_37[0]
        getitem_237 = native_group_norm_default_37[1]
        getitem_238 = native_group_norm_default_37[2];  native_group_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        view_default_82 = torch.ops.aten.view.default(primals_234, [1, 256, 2304]);  primals_234 = None
        empty_41 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(view_default_82, None, None, None, None, True, 0.0, 1e-08)
        getitem_239 = native_batch_norm_default_41[0]
        getitem_240 = native_batch_norm_default_41[1]
        getitem_241 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        view_default_83 = torch.ops.aten.view.default(getitem_239, [256, 256, 3, 3]);  getitem_239 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_37, view_default_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_38 = torch.ops.aten.native_group_norm.default(convolution_default_41, primals_241, primals_240, 64, 256, 784, 32, 1e-05);  primals_240 = None
        getitem_242 = native_group_norm_default_38[0]
        getitem_243 = native_group_norm_default_38[1]
        getitem_244 = native_group_norm_default_38[2];  native_group_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        view_default_84 = torch.ops.aten.view.default(primals_235, [1, 1024, 256]);  primals_235 = None
        empty_42 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(view_default_84, None, None, None, None, True, 0.0, 1e-08)
        getitem_245 = native_batch_norm_default_42[0]
        getitem_246 = native_batch_norm_default_42[1]
        getitem_247 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        view_default_85 = torch.ops.aten.view.default(getitem_245, [1024, 256, 1, 1]);  getitem_245 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_38, view_default_85, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(convolution_default_42, add_tensor_11);  convolution_default_42 = None
        native_group_norm_default_39 = torch.ops.aten.native_group_norm.default(add_tensor_12, primals_246, primals_245, 64, 1024, 784, 32, 1e-05);  primals_245 = None
        getitem_248 = native_group_norm_default_39[0]
        getitem_249 = native_group_norm_default_39[1]
        getitem_250 = native_group_norm_default_39[2];  native_group_norm_default_39 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        view_default_86 = torch.ops.aten.view.default(primals_242, [1, 256, 1024]);  primals_242 = None
        empty_43 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(view_default_86, None, None, None, None, True, 0.0, 1e-08)
        getitem_251 = native_batch_norm_default_43[0]
        getitem_252 = native_batch_norm_default_43[1]
        getitem_253 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        view_default_87 = torch.ops.aten.view.default(getitem_251, [256, 1024, 1, 1]);  getitem_251 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_39, view_default_87, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_40 = torch.ops.aten.native_group_norm.default(convolution_default_43, primals_248, primals_247, 64, 256, 784, 32, 1e-05);  primals_247 = None
        getitem_254 = native_group_norm_default_40[0]
        getitem_255 = native_group_norm_default_40[1]
        getitem_256 = native_group_norm_default_40[2];  native_group_norm_default_40 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        view_default_88 = torch.ops.aten.view.default(primals_243, [1, 256, 2304]);  primals_243 = None
        empty_44 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(view_default_88, None, None, None, None, True, 0.0, 1e-08)
        getitem_257 = native_batch_norm_default_44[0]
        getitem_258 = native_batch_norm_default_44[1]
        getitem_259 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        view_default_89 = torch.ops.aten.view.default(getitem_257, [256, 256, 3, 3]);  getitem_257 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_40, view_default_89, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_41 = torch.ops.aten.native_group_norm.default(convolution_default_44, primals_250, primals_249, 64, 256, 784, 32, 1e-05);  primals_249 = None
        getitem_260 = native_group_norm_default_41[0]
        getitem_261 = native_group_norm_default_41[1]
        getitem_262 = native_group_norm_default_41[2];  native_group_norm_default_41 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        view_default_90 = torch.ops.aten.view.default(primals_244, [1, 1024, 256]);  primals_244 = None
        empty_45 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(view_default_90, None, None, None, None, True, 0.0, 1e-08)
        getitem_263 = native_batch_norm_default_45[0]
        getitem_264 = native_batch_norm_default_45[1]
        getitem_265 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        view_default_91 = torch.ops.aten.view.default(getitem_263, [1024, 256, 1, 1]);  getitem_263 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_41, view_default_91, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(convolution_default_45, add_tensor_12);  convolution_default_45 = None
        native_group_norm_default_42 = torch.ops.aten.native_group_norm.default(add_tensor_13, primals_255, primals_254, 64, 1024, 784, 32, 1e-05);  primals_254 = None
        getitem_266 = native_group_norm_default_42[0]
        getitem_267 = native_group_norm_default_42[1]
        getitem_268 = native_group_norm_default_42[2];  native_group_norm_default_42 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        view_default_92 = torch.ops.aten.view.default(primals_251, [1, 256, 1024]);  primals_251 = None
        empty_46 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(view_default_92, None, None, None, None, True, 0.0, 1e-08)
        getitem_269 = native_batch_norm_default_46[0]
        getitem_270 = native_batch_norm_default_46[1]
        getitem_271 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        view_default_93 = torch.ops.aten.view.default(getitem_269, [256, 1024, 1, 1]);  getitem_269 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_42, view_default_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_43 = torch.ops.aten.native_group_norm.default(convolution_default_46, primals_257, primals_256, 64, 256, 784, 32, 1e-05);  primals_256 = None
        getitem_272 = native_group_norm_default_43[0]
        getitem_273 = native_group_norm_default_43[1]
        getitem_274 = native_group_norm_default_43[2];  native_group_norm_default_43 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        view_default_94 = torch.ops.aten.view.default(primals_252, [1, 256, 2304]);  primals_252 = None
        empty_47 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(view_default_94, None, None, None, None, True, 0.0, 1e-08)
        getitem_275 = native_batch_norm_default_47[0]
        getitem_276 = native_batch_norm_default_47[1]
        getitem_277 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        view_default_95 = torch.ops.aten.view.default(getitem_275, [256, 256, 3, 3]);  getitem_275 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_43, view_default_95, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_44 = torch.ops.aten.native_group_norm.default(convolution_default_47, primals_259, primals_258, 64, 256, 784, 32, 1e-05);  primals_258 = None
        getitem_278 = native_group_norm_default_44[0]
        getitem_279 = native_group_norm_default_44[1]
        getitem_280 = native_group_norm_default_44[2];  native_group_norm_default_44 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        view_default_96 = torch.ops.aten.view.default(primals_253, [1, 1024, 256]);  primals_253 = None
        empty_48 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(view_default_96, None, None, None, None, True, 0.0, 1e-08)
        getitem_281 = native_batch_norm_default_48[0]
        getitem_282 = native_batch_norm_default_48[1]
        getitem_283 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        view_default_97 = torch.ops.aten.view.default(getitem_281, [1024, 256, 1, 1]);  getitem_281 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_44, view_default_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(convolution_default_48, add_tensor_13);  convolution_default_48 = None
        native_group_norm_default_45 = torch.ops.aten.native_group_norm.default(add_tensor_14, primals_264, primals_263, 64, 1024, 784, 32, 1e-05);  primals_263 = None
        getitem_284 = native_group_norm_default_45[0]
        getitem_285 = native_group_norm_default_45[1]
        getitem_286 = native_group_norm_default_45[2];  native_group_norm_default_45 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        view_default_98 = torch.ops.aten.view.default(primals_260, [1, 256, 1024]);  primals_260 = None
        empty_49 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(view_default_98, None, None, None, None, True, 0.0, 1e-08)
        getitem_287 = native_batch_norm_default_49[0]
        getitem_288 = native_batch_norm_default_49[1]
        getitem_289 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        view_default_99 = torch.ops.aten.view.default(getitem_287, [256, 1024, 1, 1]);  getitem_287 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_45, view_default_99, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_46 = torch.ops.aten.native_group_norm.default(convolution_default_49, primals_266, primals_265, 64, 256, 784, 32, 1e-05);  primals_265 = None
        getitem_290 = native_group_norm_default_46[0]
        getitem_291 = native_group_norm_default_46[1]
        getitem_292 = native_group_norm_default_46[2];  native_group_norm_default_46 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        view_default_100 = torch.ops.aten.view.default(primals_261, [1, 256, 2304]);  primals_261 = None
        empty_50 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(view_default_100, None, None, None, None, True, 0.0, 1e-08)
        getitem_293 = native_batch_norm_default_50[0]
        getitem_294 = native_batch_norm_default_50[1]
        getitem_295 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        view_default_101 = torch.ops.aten.view.default(getitem_293, [256, 256, 3, 3]);  getitem_293 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_46, view_default_101, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_47 = torch.ops.aten.native_group_norm.default(convolution_default_50, primals_268, primals_267, 64, 256, 784, 32, 1e-05);  primals_267 = None
        getitem_296 = native_group_norm_default_47[0]
        getitem_297 = native_group_norm_default_47[1]
        getitem_298 = native_group_norm_default_47[2];  native_group_norm_default_47 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        view_default_102 = torch.ops.aten.view.default(primals_262, [1, 1024, 256]);  primals_262 = None
        empty_51 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(view_default_102, None, None, None, None, True, 0.0, 1e-08)
        getitem_299 = native_batch_norm_default_51[0]
        getitem_300 = native_batch_norm_default_51[1]
        getitem_301 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        view_default_103 = torch.ops.aten.view.default(getitem_299, [1024, 256, 1, 1]);  getitem_299 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_47, view_default_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(convolution_default_51, add_tensor_14);  convolution_default_51 = None
        native_group_norm_default_48 = torch.ops.aten.native_group_norm.default(add_tensor_15, primals_273, primals_272, 64, 1024, 784, 32, 1e-05);  primals_272 = None
        getitem_302 = native_group_norm_default_48[0]
        getitem_303 = native_group_norm_default_48[1]
        getitem_304 = native_group_norm_default_48[2];  native_group_norm_default_48 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        view_default_104 = torch.ops.aten.view.default(primals_269, [1, 256, 1024]);  primals_269 = None
        empty_52 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(view_default_104, None, None, None, None, True, 0.0, 1e-08)
        getitem_305 = native_batch_norm_default_52[0]
        getitem_306 = native_batch_norm_default_52[1]
        getitem_307 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        view_default_105 = torch.ops.aten.view.default(getitem_305, [256, 1024, 1, 1]);  getitem_305 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_48, view_default_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_49 = torch.ops.aten.native_group_norm.default(convolution_default_52, primals_275, primals_274, 64, 256, 784, 32, 1e-05);  primals_274 = None
        getitem_308 = native_group_norm_default_49[0]
        getitem_309 = native_group_norm_default_49[1]
        getitem_310 = native_group_norm_default_49[2];  native_group_norm_default_49 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        view_default_106 = torch.ops.aten.view.default(primals_270, [1, 256, 2304]);  primals_270 = None
        empty_53 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(view_default_106, None, None, None, None, True, 0.0, 1e-08)
        getitem_311 = native_batch_norm_default_53[0]
        getitem_312 = native_batch_norm_default_53[1]
        getitem_313 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        view_default_107 = torch.ops.aten.view.default(getitem_311, [256, 256, 3, 3]);  getitem_311 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_49, view_default_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_50 = torch.ops.aten.native_group_norm.default(convolution_default_53, primals_277, primals_276, 64, 256, 784, 32, 1e-05);  primals_276 = None
        getitem_314 = native_group_norm_default_50[0]
        getitem_315 = native_group_norm_default_50[1]
        getitem_316 = native_group_norm_default_50[2];  native_group_norm_default_50 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_314);  getitem_314 = None
        view_default_108 = torch.ops.aten.view.default(primals_271, [1, 1024, 256]);  primals_271 = None
        empty_54 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(view_default_108, None, None, None, None, True, 0.0, 1e-08)
        getitem_317 = native_batch_norm_default_54[0]
        getitem_318 = native_batch_norm_default_54[1]
        getitem_319 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        view_default_109 = torch.ops.aten.view.default(getitem_317, [1024, 256, 1, 1]);  getitem_317 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_50, view_default_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(convolution_default_54, add_tensor_15);  convolution_default_54 = None
        native_group_norm_default_51 = torch.ops.aten.native_group_norm.default(add_tensor_16, primals_84, primals_83, 64, 1024, 784, 32, 1e-05);  primals_83 = None
        getitem_320 = native_group_norm_default_51[0]
        getitem_321 = native_group_norm_default_51[1]
        getitem_322 = native_group_norm_default_51[2];  native_group_norm_default_51 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_320);  getitem_320 = None
        view_default_110 = torch.ops.aten.view.default(primals_80, [1, 256, 1024]);  primals_80 = None
        empty_55 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(view_default_110, None, None, None, None, True, 0.0, 1e-08)
        getitem_323 = native_batch_norm_default_55[0]
        getitem_324 = native_batch_norm_default_55[1]
        getitem_325 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        view_default_111 = torch.ops.aten.view.default(getitem_323, [256, 1024, 1, 1]);  getitem_323 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_51, view_default_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_52 = torch.ops.aten.native_group_norm.default(convolution_default_55, primals_86, primals_85, 64, 256, 784, 32, 1e-05);  primals_85 = None
        getitem_326 = native_group_norm_default_52[0]
        getitem_327 = native_group_norm_default_52[1]
        getitem_328 = native_group_norm_default_52[2];  native_group_norm_default_52 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_326);  getitem_326 = None
        view_default_112 = torch.ops.aten.view.default(primals_81, [1, 256, 2304]);  primals_81 = None
        empty_56 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(view_default_112, None, None, None, None, True, 0.0, 1e-08)
        getitem_329 = native_batch_norm_default_56[0]
        getitem_330 = native_batch_norm_default_56[1]
        getitem_331 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        view_default_113 = torch.ops.aten.view.default(getitem_329, [256, 256, 3, 3]);  getitem_329 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_52, view_default_113, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_53 = torch.ops.aten.native_group_norm.default(convolution_default_56, primals_88, primals_87, 64, 256, 784, 32, 1e-05);  primals_87 = None
        getitem_332 = native_group_norm_default_53[0]
        getitem_333 = native_group_norm_default_53[1]
        getitem_334 = native_group_norm_default_53[2];  native_group_norm_default_53 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_332);  getitem_332 = None
        view_default_114 = torch.ops.aten.view.default(primals_82, [1, 1024, 256]);  primals_82 = None
        empty_57 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(view_default_114, None, None, None, None, True, 0.0, 1e-08)
        getitem_335 = native_batch_norm_default_57[0]
        getitem_336 = native_batch_norm_default_57[1]
        getitem_337 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        view_default_115 = torch.ops.aten.view.default(getitem_335, [1024, 256, 1, 1]);  getitem_335 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_53, view_default_115, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(convolution_default_57, add_tensor_16);  convolution_default_57 = None
        native_group_norm_default_54 = torch.ops.aten.native_group_norm.default(add_tensor_17, primals_93, primals_92, 64, 1024, 784, 32, 1e-05);  primals_92 = None
        getitem_338 = native_group_norm_default_54[0]
        getitem_339 = native_group_norm_default_54[1]
        getitem_340 = native_group_norm_default_54[2];  native_group_norm_default_54 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_338);  getitem_338 = None
        view_default_116 = torch.ops.aten.view.default(primals_89, [1, 256, 1024]);  primals_89 = None
        empty_58 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(view_default_116, None, None, None, None, True, 0.0, 1e-08)
        getitem_341 = native_batch_norm_default_58[0]
        getitem_342 = native_batch_norm_default_58[1]
        getitem_343 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        view_default_117 = torch.ops.aten.view.default(getitem_341, [256, 1024, 1, 1]);  getitem_341 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_54, view_default_117, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_55 = torch.ops.aten.native_group_norm.default(convolution_default_58, primals_95, primals_94, 64, 256, 784, 32, 1e-05);  primals_94 = None
        getitem_344 = native_group_norm_default_55[0]
        getitem_345 = native_group_norm_default_55[1]
        getitem_346 = native_group_norm_default_55[2];  native_group_norm_default_55 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        view_default_118 = torch.ops.aten.view.default(primals_90, [1, 256, 2304]);  primals_90 = None
        empty_59 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(view_default_118, None, None, None, None, True, 0.0, 1e-08)
        getitem_347 = native_batch_norm_default_59[0]
        getitem_348 = native_batch_norm_default_59[1]
        getitem_349 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        view_default_119 = torch.ops.aten.view.default(getitem_347, [256, 256, 3, 3]);  getitem_347 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_55, view_default_119, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_56 = torch.ops.aten.native_group_norm.default(convolution_default_59, primals_97, primals_96, 64, 256, 784, 32, 1e-05);  primals_96 = None
        getitem_350 = native_group_norm_default_56[0]
        getitem_351 = native_group_norm_default_56[1]
        getitem_352 = native_group_norm_default_56[2];  native_group_norm_default_56 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_350);  getitem_350 = None
        view_default_120 = torch.ops.aten.view.default(primals_91, [1, 1024, 256]);  primals_91 = None
        empty_60 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(view_default_120, None, None, None, None, True, 0.0, 1e-08)
        getitem_353 = native_batch_norm_default_60[0]
        getitem_354 = native_batch_norm_default_60[1]
        getitem_355 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        view_default_121 = torch.ops.aten.view.default(getitem_353, [1024, 256, 1, 1]);  getitem_353 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_56, view_default_121, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(convolution_default_60, add_tensor_17);  convolution_default_60 = None
        native_group_norm_default_57 = torch.ops.aten.native_group_norm.default(add_tensor_18, primals_102, primals_101, 64, 1024, 784, 32, 1e-05);  primals_101 = None
        getitem_356 = native_group_norm_default_57[0]
        getitem_357 = native_group_norm_default_57[1]
        getitem_358 = native_group_norm_default_57[2];  native_group_norm_default_57 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        view_default_122 = torch.ops.aten.view.default(primals_98, [1, 256, 1024]);  primals_98 = None
        empty_61 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(view_default_122, None, None, None, None, True, 0.0, 1e-08)
        getitem_359 = native_batch_norm_default_61[0]
        getitem_360 = native_batch_norm_default_61[1]
        getitem_361 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        view_default_123 = torch.ops.aten.view.default(getitem_359, [256, 1024, 1, 1]);  getitem_359 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_57, view_default_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_58 = torch.ops.aten.native_group_norm.default(convolution_default_61, primals_104, primals_103, 64, 256, 784, 32, 1e-05);  primals_103 = None
        getitem_362 = native_group_norm_default_58[0]
        getitem_363 = native_group_norm_default_58[1]
        getitem_364 = native_group_norm_default_58[2];  native_group_norm_default_58 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_362);  getitem_362 = None
        view_default_124 = torch.ops.aten.view.default(primals_99, [1, 256, 2304]);  primals_99 = None
        empty_62 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(view_default_124, None, None, None, None, True, 0.0, 1e-08)
        getitem_365 = native_batch_norm_default_62[0]
        getitem_366 = native_batch_norm_default_62[1]
        getitem_367 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        view_default_125 = torch.ops.aten.view.default(getitem_365, [256, 256, 3, 3]);  getitem_365 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_58, view_default_125, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_59 = torch.ops.aten.native_group_norm.default(convolution_default_62, primals_106, primals_105, 64, 256, 784, 32, 1e-05);  primals_105 = None
        getitem_368 = native_group_norm_default_59[0]
        getitem_369 = native_group_norm_default_59[1]
        getitem_370 = native_group_norm_default_59[2];  native_group_norm_default_59 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_368);  getitem_368 = None
        view_default_126 = torch.ops.aten.view.default(primals_100, [1, 1024, 256]);  primals_100 = None
        empty_63 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(view_default_126, None, None, None, None, True, 0.0, 1e-08)
        getitem_371 = native_batch_norm_default_63[0]
        getitem_372 = native_batch_norm_default_63[1]
        getitem_373 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        view_default_127 = torch.ops.aten.view.default(getitem_371, [1024, 256, 1, 1]);  getitem_371 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_59, view_default_127, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(convolution_default_63, add_tensor_18);  convolution_default_63 = None
        native_group_norm_default_60 = torch.ops.aten.native_group_norm.default(add_tensor_19, primals_111, primals_110, 64, 1024, 784, 32, 1e-05);  primals_110 = None
        getitem_374 = native_group_norm_default_60[0]
        getitem_375 = native_group_norm_default_60[1]
        getitem_376 = native_group_norm_default_60[2];  native_group_norm_default_60 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_374);  getitem_374 = None
        view_default_128 = torch.ops.aten.view.default(primals_107, [1, 256, 1024]);  primals_107 = None
        empty_64 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(view_default_128, None, None, None, None, True, 0.0, 1e-08)
        getitem_377 = native_batch_norm_default_64[0]
        getitem_378 = native_batch_norm_default_64[1]
        getitem_379 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        view_default_129 = torch.ops.aten.view.default(getitem_377, [256, 1024, 1, 1]);  getitem_377 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_60, view_default_129, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_61 = torch.ops.aten.native_group_norm.default(convolution_default_64, primals_113, primals_112, 64, 256, 784, 32, 1e-05);  primals_112 = None
        getitem_380 = native_group_norm_default_61[0]
        getitem_381 = native_group_norm_default_61[1]
        getitem_382 = native_group_norm_default_61[2];  native_group_norm_default_61 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_380);  getitem_380 = None
        view_default_130 = torch.ops.aten.view.default(primals_108, [1, 256, 2304]);  primals_108 = None
        empty_65 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(view_default_130, None, None, None, None, True, 0.0, 1e-08)
        getitem_383 = native_batch_norm_default_65[0]
        getitem_384 = native_batch_norm_default_65[1]
        getitem_385 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        view_default_131 = torch.ops.aten.view.default(getitem_383, [256, 256, 3, 3]);  getitem_383 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_61, view_default_131, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_62 = torch.ops.aten.native_group_norm.default(convolution_default_65, primals_115, primals_114, 64, 256, 784, 32, 1e-05);  primals_114 = None
        getitem_386 = native_group_norm_default_62[0]
        getitem_387 = native_group_norm_default_62[1]
        getitem_388 = native_group_norm_default_62[2];  native_group_norm_default_62 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_386);  getitem_386 = None
        view_default_132 = torch.ops.aten.view.default(primals_109, [1, 1024, 256]);  primals_109 = None
        empty_66 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(view_default_132, None, None, None, None, True, 0.0, 1e-08)
        getitem_389 = native_batch_norm_default_66[0]
        getitem_390 = native_batch_norm_default_66[1]
        getitem_391 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        view_default_133 = torch.ops.aten.view.default(getitem_389, [1024, 256, 1, 1]);  getitem_389 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_62, view_default_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(convolution_default_66, add_tensor_19);  convolution_default_66 = None
        native_group_norm_default_63 = torch.ops.aten.native_group_norm.default(add_tensor_20, primals_120, primals_119, 64, 1024, 784, 32, 1e-05);  primals_119 = None
        getitem_392 = native_group_norm_default_63[0]
        getitem_393 = native_group_norm_default_63[1]
        getitem_394 = native_group_norm_default_63[2];  native_group_norm_default_63 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_392);  getitem_392 = None
        view_default_134 = torch.ops.aten.view.default(primals_116, [1, 256, 1024]);  primals_116 = None
        empty_67 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(view_default_134, None, None, None, None, True, 0.0, 1e-08)
        getitem_395 = native_batch_norm_default_67[0]
        getitem_396 = native_batch_norm_default_67[1]
        getitem_397 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        view_default_135 = torch.ops.aten.view.default(getitem_395, [256, 1024, 1, 1]);  getitem_395 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_63, view_default_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_64 = torch.ops.aten.native_group_norm.default(convolution_default_67, primals_122, primals_121, 64, 256, 784, 32, 1e-05);  primals_121 = None
        getitem_398 = native_group_norm_default_64[0]
        getitem_399 = native_group_norm_default_64[1]
        getitem_400 = native_group_norm_default_64[2];  native_group_norm_default_64 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_398);  getitem_398 = None
        view_default_136 = torch.ops.aten.view.default(primals_117, [1, 256, 2304]);  primals_117 = None
        empty_68 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(view_default_136, None, None, None, None, True, 0.0, 1e-08)
        getitem_401 = native_batch_norm_default_68[0]
        getitem_402 = native_batch_norm_default_68[1]
        getitem_403 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        view_default_137 = torch.ops.aten.view.default(getitem_401, [256, 256, 3, 3]);  getitem_401 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_64, view_default_137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_65 = torch.ops.aten.native_group_norm.default(convolution_default_68, primals_124, primals_123, 64, 256, 784, 32, 1e-05);  primals_123 = None
        getitem_404 = native_group_norm_default_65[0]
        getitem_405 = native_group_norm_default_65[1]
        getitem_406 = native_group_norm_default_65[2];  native_group_norm_default_65 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_404);  getitem_404 = None
        view_default_138 = torch.ops.aten.view.default(primals_118, [1, 1024, 256]);  primals_118 = None
        empty_69 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(view_default_138, None, None, None, None, True, 0.0, 1e-08)
        getitem_407 = native_batch_norm_default_69[0]
        getitem_408 = native_batch_norm_default_69[1]
        getitem_409 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        view_default_139 = torch.ops.aten.view.default(getitem_407, [1024, 256, 1, 1]);  getitem_407 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_65, view_default_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(convolution_default_69, add_tensor_20);  convolution_default_69 = None
        native_group_norm_default_66 = torch.ops.aten.native_group_norm.default(add_tensor_21, primals_129, primals_128, 64, 1024, 784, 32, 1e-05);  primals_128 = None
        getitem_410 = native_group_norm_default_66[0]
        getitem_411 = native_group_norm_default_66[1]
        getitem_412 = native_group_norm_default_66[2];  native_group_norm_default_66 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_410);  getitem_410 = None
        view_default_140 = torch.ops.aten.view.default(primals_125, [1, 256, 1024]);  primals_125 = None
        empty_70 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(view_default_140, None, None, None, None, True, 0.0, 1e-08)
        getitem_413 = native_batch_norm_default_70[0]
        getitem_414 = native_batch_norm_default_70[1]
        getitem_415 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        view_default_141 = torch.ops.aten.view.default(getitem_413, [256, 1024, 1, 1]);  getitem_413 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_66, view_default_141, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_67 = torch.ops.aten.native_group_norm.default(convolution_default_70, primals_131, primals_130, 64, 256, 784, 32, 1e-05);  primals_130 = None
        getitem_416 = native_group_norm_default_67[0]
        getitem_417 = native_group_norm_default_67[1]
        getitem_418 = native_group_norm_default_67[2];  native_group_norm_default_67 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_416);  getitem_416 = None
        view_default_142 = torch.ops.aten.view.default(primals_126, [1, 256, 2304]);  primals_126 = None
        empty_71 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(view_default_142, None, None, None, None, True, 0.0, 1e-08)
        getitem_419 = native_batch_norm_default_71[0]
        getitem_420 = native_batch_norm_default_71[1]
        getitem_421 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        view_default_143 = torch.ops.aten.view.default(getitem_419, [256, 256, 3, 3]);  getitem_419 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_67, view_default_143, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_68 = torch.ops.aten.native_group_norm.default(convolution_default_71, primals_133, primals_132, 64, 256, 784, 32, 1e-05);  primals_132 = None
        getitem_422 = native_group_norm_default_68[0]
        getitem_423 = native_group_norm_default_68[1]
        getitem_424 = native_group_norm_default_68[2];  native_group_norm_default_68 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_422);  getitem_422 = None
        view_default_144 = torch.ops.aten.view.default(primals_127, [1, 1024, 256]);  primals_127 = None
        empty_72 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(view_default_144, None, None, None, None, True, 0.0, 1e-08)
        getitem_425 = native_batch_norm_default_72[0]
        getitem_426 = native_batch_norm_default_72[1]
        getitem_427 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        view_default_145 = torch.ops.aten.view.default(getitem_425, [1024, 256, 1, 1]);  getitem_425 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_68, view_default_145, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(convolution_default_72, add_tensor_21);  convolution_default_72 = None
        native_group_norm_default_69 = torch.ops.aten.native_group_norm.default(add_tensor_22, primals_138, primals_137, 64, 1024, 784, 32, 1e-05);  primals_137 = None
        getitem_428 = native_group_norm_default_69[0]
        getitem_429 = native_group_norm_default_69[1]
        getitem_430 = native_group_norm_default_69[2];  native_group_norm_default_69 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_428);  getitem_428 = None
        view_default_146 = torch.ops.aten.view.default(primals_134, [1, 256, 1024]);  primals_134 = None
        empty_73 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(view_default_146, None, None, None, None, True, 0.0, 1e-08)
        getitem_431 = native_batch_norm_default_73[0]
        getitem_432 = native_batch_norm_default_73[1]
        getitem_433 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        view_default_147 = torch.ops.aten.view.default(getitem_431, [256, 1024, 1, 1]);  getitem_431 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_69, view_default_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_70 = torch.ops.aten.native_group_norm.default(convolution_default_73, primals_140, primals_139, 64, 256, 784, 32, 1e-05);  primals_139 = None
        getitem_434 = native_group_norm_default_70[0]
        getitem_435 = native_group_norm_default_70[1]
        getitem_436 = native_group_norm_default_70[2];  native_group_norm_default_70 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_434);  getitem_434 = None
        view_default_148 = torch.ops.aten.view.default(primals_135, [1, 256, 2304]);  primals_135 = None
        empty_74 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(view_default_148, None, None, None, None, True, 0.0, 1e-08)
        getitem_437 = native_batch_norm_default_74[0]
        getitem_438 = native_batch_norm_default_74[1]
        getitem_439 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        view_default_149 = torch.ops.aten.view.default(getitem_437, [256, 256, 3, 3]);  getitem_437 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_70, view_default_149, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_71 = torch.ops.aten.native_group_norm.default(convolution_default_74, primals_142, primals_141, 64, 256, 784, 32, 1e-05);  primals_141 = None
        getitem_440 = native_group_norm_default_71[0]
        getitem_441 = native_group_norm_default_71[1]
        getitem_442 = native_group_norm_default_71[2];  native_group_norm_default_71 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_440);  getitem_440 = None
        view_default_150 = torch.ops.aten.view.default(primals_136, [1, 1024, 256]);  primals_136 = None
        empty_75 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(view_default_150, None, None, None, None, True, 0.0, 1e-08)
        getitem_443 = native_batch_norm_default_75[0]
        getitem_444 = native_batch_norm_default_75[1]
        getitem_445 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        view_default_151 = torch.ops.aten.view.default(getitem_443, [1024, 256, 1, 1]);  getitem_443 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_71, view_default_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(convolution_default_75, add_tensor_22);  convolution_default_75 = None
        native_group_norm_default_72 = torch.ops.aten.native_group_norm.default(add_tensor_23, primals_147, primals_146, 64, 1024, 784, 32, 1e-05);  primals_146 = None
        getitem_446 = native_group_norm_default_72[0]
        getitem_447 = native_group_norm_default_72[1]
        getitem_448 = native_group_norm_default_72[2];  native_group_norm_default_72 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_446);  getitem_446 = None
        view_default_152 = torch.ops.aten.view.default(primals_143, [1, 256, 1024]);  primals_143 = None
        empty_76 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(view_default_152, None, None, None, None, True, 0.0, 1e-08)
        getitem_449 = native_batch_norm_default_76[0]
        getitem_450 = native_batch_norm_default_76[1]
        getitem_451 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        view_default_153 = torch.ops.aten.view.default(getitem_449, [256, 1024, 1, 1]);  getitem_449 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_72, view_default_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_73 = torch.ops.aten.native_group_norm.default(convolution_default_76, primals_149, primals_148, 64, 256, 784, 32, 1e-05);  primals_148 = None
        getitem_452 = native_group_norm_default_73[0]
        getitem_453 = native_group_norm_default_73[1]
        getitem_454 = native_group_norm_default_73[2];  native_group_norm_default_73 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_452);  getitem_452 = None
        view_default_154 = torch.ops.aten.view.default(primals_144, [1, 256, 2304]);  primals_144 = None
        empty_77 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(view_default_154, None, None, None, None, True, 0.0, 1e-08)
        getitem_455 = native_batch_norm_default_77[0]
        getitem_456 = native_batch_norm_default_77[1]
        getitem_457 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        view_default_155 = torch.ops.aten.view.default(getitem_455, [256, 256, 3, 3]);  getitem_455 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_73, view_default_155, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_74 = torch.ops.aten.native_group_norm.default(convolution_default_77, primals_151, primals_150, 64, 256, 784, 32, 1e-05);  primals_150 = None
        getitem_458 = native_group_norm_default_74[0]
        getitem_459 = native_group_norm_default_74[1]
        getitem_460 = native_group_norm_default_74[2];  native_group_norm_default_74 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_458);  getitem_458 = None
        view_default_156 = torch.ops.aten.view.default(primals_145, [1, 1024, 256]);  primals_145 = None
        empty_78 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(view_default_156, None, None, None, None, True, 0.0, 1e-08)
        getitem_461 = native_batch_norm_default_78[0]
        getitem_462 = native_batch_norm_default_78[1]
        getitem_463 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        view_default_157 = torch.ops.aten.view.default(getitem_461, [1024, 256, 1, 1]);  getitem_461 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_74, view_default_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(convolution_default_78, add_tensor_23);  convolution_default_78 = None
        native_group_norm_default_75 = torch.ops.aten.native_group_norm.default(add_tensor_24, primals_156, primals_155, 64, 1024, 784, 32, 1e-05);  primals_155 = None
        getitem_464 = native_group_norm_default_75[0]
        getitem_465 = native_group_norm_default_75[1]
        getitem_466 = native_group_norm_default_75[2];  native_group_norm_default_75 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_464);  getitem_464 = None
        view_default_158 = torch.ops.aten.view.default(primals_152, [1, 256, 1024]);  primals_152 = None
        empty_79 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(view_default_158, None, None, None, None, True, 0.0, 1e-08)
        getitem_467 = native_batch_norm_default_79[0]
        getitem_468 = native_batch_norm_default_79[1]
        getitem_469 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        view_default_159 = torch.ops.aten.view.default(getitem_467, [256, 1024, 1, 1]);  getitem_467 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_75, view_default_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_76 = torch.ops.aten.native_group_norm.default(convolution_default_79, primals_158, primals_157, 64, 256, 784, 32, 1e-05);  primals_157 = None
        getitem_470 = native_group_norm_default_76[0]
        getitem_471 = native_group_norm_default_76[1]
        getitem_472 = native_group_norm_default_76[2];  native_group_norm_default_76 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_470);  getitem_470 = None
        view_default_160 = torch.ops.aten.view.default(primals_153, [1, 256, 2304]);  primals_153 = None
        empty_80 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(view_default_160, None, None, None, None, True, 0.0, 1e-08)
        getitem_473 = native_batch_norm_default_80[0]
        getitem_474 = native_batch_norm_default_80[1]
        getitem_475 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        view_default_161 = torch.ops.aten.view.default(getitem_473, [256, 256, 3, 3]);  getitem_473 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_76, view_default_161, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_77 = torch.ops.aten.native_group_norm.default(convolution_default_80, primals_160, primals_159, 64, 256, 784, 32, 1e-05);  primals_159 = None
        getitem_476 = native_group_norm_default_77[0]
        getitem_477 = native_group_norm_default_77[1]
        getitem_478 = native_group_norm_default_77[2];  native_group_norm_default_77 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_476);  getitem_476 = None
        view_default_162 = torch.ops.aten.view.default(primals_154, [1, 1024, 256]);  primals_154 = None
        empty_81 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(view_default_162, None, None, None, None, True, 0.0, 1e-08)
        getitem_479 = native_batch_norm_default_81[0]
        getitem_480 = native_batch_norm_default_81[1]
        getitem_481 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        view_default_163 = torch.ops.aten.view.default(getitem_479, [1024, 256, 1, 1]);  getitem_479 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_77, view_default_163, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_25 = torch.ops.aten.add.Tensor(convolution_default_81, add_tensor_24);  convolution_default_81 = None
        native_group_norm_default_78 = torch.ops.aten.native_group_norm.default(add_tensor_25, primals_165, primals_164, 64, 1024, 784, 32, 1e-05);  primals_164 = None
        getitem_482 = native_group_norm_default_78[0]
        getitem_483 = native_group_norm_default_78[1]
        getitem_484 = native_group_norm_default_78[2];  native_group_norm_default_78 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_482);  getitem_482 = None
        view_default_164 = torch.ops.aten.view.default(primals_161, [1, 256, 1024]);  primals_161 = None
        empty_82 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(view_default_164, None, None, None, None, True, 0.0, 1e-08)
        getitem_485 = native_batch_norm_default_82[0]
        getitem_486 = native_batch_norm_default_82[1]
        getitem_487 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        view_default_165 = torch.ops.aten.view.default(getitem_485, [256, 1024, 1, 1]);  getitem_485 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_78, view_default_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_79 = torch.ops.aten.native_group_norm.default(convolution_default_82, primals_167, primals_166, 64, 256, 784, 32, 1e-05);  primals_166 = None
        getitem_488 = native_group_norm_default_79[0]
        getitem_489 = native_group_norm_default_79[1]
        getitem_490 = native_group_norm_default_79[2];  native_group_norm_default_79 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_488);  getitem_488 = None
        view_default_166 = torch.ops.aten.view.default(primals_162, [1, 256, 2304]);  primals_162 = None
        empty_83 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(view_default_166, None, None, None, None, True, 0.0, 1e-08)
        getitem_491 = native_batch_norm_default_83[0]
        getitem_492 = native_batch_norm_default_83[1]
        getitem_493 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        view_default_167 = torch.ops.aten.view.default(getitem_491, [256, 256, 3, 3]);  getitem_491 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_79, view_default_167, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_80 = torch.ops.aten.native_group_norm.default(convolution_default_83, primals_169, primals_168, 64, 256, 784, 32, 1e-05);  primals_168 = None
        getitem_494 = native_group_norm_default_80[0]
        getitem_495 = native_group_norm_default_80[1]
        getitem_496 = native_group_norm_default_80[2];  native_group_norm_default_80 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_494);  getitem_494 = None
        view_default_168 = torch.ops.aten.view.default(primals_163, [1, 1024, 256]);  primals_163 = None
        empty_84 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(view_default_168, None, None, None, None, True, 0.0, 1e-08)
        getitem_497 = native_batch_norm_default_84[0]
        getitem_498 = native_batch_norm_default_84[1]
        getitem_499 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        view_default_169 = torch.ops.aten.view.default(getitem_497, [1024, 256, 1, 1]);  getitem_497 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_80, view_default_169, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(convolution_default_84, add_tensor_25);  convolution_default_84 = None
        native_group_norm_default_81 = torch.ops.aten.native_group_norm.default(add_tensor_26, primals_183, primals_182, 64, 1024, 784, 32, 1e-05);  primals_182 = None
        getitem_500 = native_group_norm_default_81[0]
        getitem_501 = native_group_norm_default_81[1]
        getitem_502 = native_group_norm_default_81[2];  native_group_norm_default_81 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_500);  getitem_500 = None
        view_default_170 = torch.ops.aten.view.default(primals_179, [1, 256, 1024]);  primals_179 = None
        empty_85 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(view_default_170, None, None, None, None, True, 0.0, 1e-08)
        getitem_503 = native_batch_norm_default_85[0]
        getitem_504 = native_batch_norm_default_85[1]
        getitem_505 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        view_default_171 = torch.ops.aten.view.default(getitem_503, [256, 1024, 1, 1]);  getitem_503 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_81, view_default_171, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_82 = torch.ops.aten.native_group_norm.default(convolution_default_85, primals_185, primals_184, 64, 256, 784, 32, 1e-05);  primals_184 = None
        getitem_506 = native_group_norm_default_82[0]
        getitem_507 = native_group_norm_default_82[1]
        getitem_508 = native_group_norm_default_82[2];  native_group_norm_default_82 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_506);  getitem_506 = None
        view_default_172 = torch.ops.aten.view.default(primals_180, [1, 256, 2304]);  primals_180 = None
        empty_86 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(view_default_172, None, None, None, None, True, 0.0, 1e-08)
        getitem_509 = native_batch_norm_default_86[0]
        getitem_510 = native_batch_norm_default_86[1]
        getitem_511 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        view_default_173 = torch.ops.aten.view.default(getitem_509, [256, 256, 3, 3]);  getitem_509 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_82, view_default_173, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_83 = torch.ops.aten.native_group_norm.default(convolution_default_86, primals_187, primals_186, 64, 256, 784, 32, 1e-05);  primals_186 = None
        getitem_512 = native_group_norm_default_83[0]
        getitem_513 = native_group_norm_default_83[1]
        getitem_514 = native_group_norm_default_83[2];  native_group_norm_default_83 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_512);  getitem_512 = None
        view_default_174 = torch.ops.aten.view.default(primals_181, [1, 1024, 256]);  primals_181 = None
        empty_87 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(view_default_174, None, None, None, None, True, 0.0, 1e-08)
        getitem_515 = native_batch_norm_default_87[0]
        getitem_516 = native_batch_norm_default_87[1]
        getitem_517 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        view_default_175 = torch.ops.aten.view.default(getitem_515, [1024, 256, 1, 1]);  getitem_515 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_83, view_default_175, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(convolution_default_87, add_tensor_26);  convolution_default_87 = None
        native_group_norm_default_84 = torch.ops.aten.native_group_norm.default(add_tensor_27, primals_192, primals_191, 64, 1024, 784, 32, 1e-05);  primals_191 = None
        getitem_518 = native_group_norm_default_84[0]
        getitem_519 = native_group_norm_default_84[1]
        getitem_520 = native_group_norm_default_84[2];  native_group_norm_default_84 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_518);  getitem_518 = None
        view_default_176 = torch.ops.aten.view.default(primals_188, [1, 256, 1024]);  primals_188 = None
        empty_88 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(view_default_176, None, None, None, None, True, 0.0, 1e-08)
        getitem_521 = native_batch_norm_default_88[0]
        getitem_522 = native_batch_norm_default_88[1]
        getitem_523 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        view_default_177 = torch.ops.aten.view.default(getitem_521, [256, 1024, 1, 1]);  getitem_521 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_84, view_default_177, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_85 = torch.ops.aten.native_group_norm.default(convolution_default_88, primals_194, primals_193, 64, 256, 784, 32, 1e-05);  primals_193 = None
        getitem_524 = native_group_norm_default_85[0]
        getitem_525 = native_group_norm_default_85[1]
        getitem_526 = native_group_norm_default_85[2];  native_group_norm_default_85 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_524);  getitem_524 = None
        view_default_178 = torch.ops.aten.view.default(primals_189, [1, 256, 2304]);  primals_189 = None
        empty_89 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(view_default_178, None, None, None, None, True, 0.0, 1e-08)
        getitem_527 = native_batch_norm_default_89[0]
        getitem_528 = native_batch_norm_default_89[1]
        getitem_529 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        view_default_179 = torch.ops.aten.view.default(getitem_527, [256, 256, 3, 3]);  getitem_527 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_85, view_default_179, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_86 = torch.ops.aten.native_group_norm.default(convolution_default_89, primals_196, primals_195, 64, 256, 784, 32, 1e-05);  primals_195 = None
        getitem_530 = native_group_norm_default_86[0]
        getitem_531 = native_group_norm_default_86[1]
        getitem_532 = native_group_norm_default_86[2];  native_group_norm_default_86 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_530);  getitem_530 = None
        view_default_180 = torch.ops.aten.view.default(primals_190, [1, 1024, 256]);  primals_190 = None
        empty_90 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(view_default_180, None, None, None, None, True, 0.0, 1e-08)
        getitem_533 = native_batch_norm_default_90[0]
        getitem_534 = native_batch_norm_default_90[1]
        getitem_535 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        view_default_181 = torch.ops.aten.view.default(getitem_533, [1024, 256, 1, 1]);  getitem_533 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_86, view_default_181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(convolution_default_90, add_tensor_27);  convolution_default_90 = None
        native_group_norm_default_87 = torch.ops.aten.native_group_norm.default(add_tensor_28, primals_201, primals_200, 64, 1024, 784, 32, 1e-05);  primals_200 = None
        getitem_536 = native_group_norm_default_87[0]
        getitem_537 = native_group_norm_default_87[1]
        getitem_538 = native_group_norm_default_87[2];  native_group_norm_default_87 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_536);  getitem_536 = None
        view_default_182 = torch.ops.aten.view.default(primals_197, [1, 256, 1024]);  primals_197 = None
        empty_91 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(view_default_182, None, None, None, None, True, 0.0, 1e-08)
        getitem_539 = native_batch_norm_default_91[0]
        getitem_540 = native_batch_norm_default_91[1]
        getitem_541 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        view_default_183 = torch.ops.aten.view.default(getitem_539, [256, 1024, 1, 1]);  getitem_539 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_87, view_default_183, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_88 = torch.ops.aten.native_group_norm.default(convolution_default_91, primals_203, primals_202, 64, 256, 784, 32, 1e-05);  primals_202 = None
        getitem_542 = native_group_norm_default_88[0]
        getitem_543 = native_group_norm_default_88[1]
        getitem_544 = native_group_norm_default_88[2];  native_group_norm_default_88 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_542);  getitem_542 = None
        view_default_184 = torch.ops.aten.view.default(primals_198, [1, 256, 2304]);  primals_198 = None
        empty_92 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(view_default_184, None, None, None, None, True, 0.0, 1e-08)
        getitem_545 = native_batch_norm_default_92[0]
        getitem_546 = native_batch_norm_default_92[1]
        getitem_547 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        view_default_185 = torch.ops.aten.view.default(getitem_545, [256, 256, 3, 3]);  getitem_545 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_88, view_default_185, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_89 = torch.ops.aten.native_group_norm.default(convolution_default_92, primals_205, primals_204, 64, 256, 784, 32, 1e-05);  primals_204 = None
        getitem_548 = native_group_norm_default_89[0]
        getitem_549 = native_group_norm_default_89[1]
        getitem_550 = native_group_norm_default_89[2];  native_group_norm_default_89 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_548);  getitem_548 = None
        view_default_186 = torch.ops.aten.view.default(primals_199, [1, 1024, 256]);  primals_199 = None
        empty_93 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(view_default_186, None, None, None, None, True, 0.0, 1e-08)
        getitem_551 = native_batch_norm_default_93[0]
        getitem_552 = native_batch_norm_default_93[1]
        getitem_553 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        view_default_187 = torch.ops.aten.view.default(getitem_551, [1024, 256, 1, 1]);  getitem_551 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_89, view_default_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_29 = torch.ops.aten.add.Tensor(convolution_default_93, add_tensor_28);  convolution_default_93 = None
        native_group_norm_default_90 = torch.ops.aten.native_group_norm.default(add_tensor_29, primals_283, primals_282, 64, 1024, 784, 32, 1e-05);  primals_282 = None
        getitem_554 = native_group_norm_default_90[0]
        getitem_555 = native_group_norm_default_90[1]
        getitem_556 = native_group_norm_default_90[2];  native_group_norm_default_90 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_554);  getitem_554 = None
        view_default_188 = torch.ops.aten.view.default(primals_281, [1, 2048, 1024]);  primals_281 = None
        empty_94 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(view_default_188, None, None, None, None, True, 0.0, 1e-08)
        getitem_557 = native_batch_norm_default_94[0]
        getitem_558 = native_batch_norm_default_94[1]
        getitem_559 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        view_default_189 = torch.ops.aten.view.default(getitem_557, [2048, 1024, 1, 1]);  getitem_557 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_90, view_default_189, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_190 = torch.ops.aten.view.default(primals_278, [1, 512, 1024]);  primals_278 = None
        empty_95 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(view_default_190, None, None, None, None, True, 0.0, 1e-08)
        getitem_560 = native_batch_norm_default_95[0]
        getitem_561 = native_batch_norm_default_95[1]
        getitem_562 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        view_default_191 = torch.ops.aten.view.default(getitem_560, [512, 1024, 1, 1]);  getitem_560 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_90, view_default_191, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_91 = torch.ops.aten.native_group_norm.default(convolution_default_95, primals_285, primals_284, 64, 512, 784, 32, 1e-05);  primals_284 = None
        getitem_563 = native_group_norm_default_91[0]
        getitem_564 = native_group_norm_default_91[1]
        getitem_565 = native_group_norm_default_91[2];  native_group_norm_default_91 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_563);  getitem_563 = None
        view_default_192 = torch.ops.aten.view.default(primals_279, [1, 512, 4608]);  primals_279 = None
        empty_96 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(view_default_192, None, None, None, None, True, 0.0, 1e-08)
        getitem_566 = native_batch_norm_default_96[0]
        getitem_567 = native_batch_norm_default_96[1]
        getitem_568 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        view_default_193 = torch.ops.aten.view.default(getitem_566, [512, 512, 3, 3]);  getitem_566 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_91, view_default_193, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_92 = torch.ops.aten.native_group_norm.default(convolution_default_96, primals_287, primals_286, 64, 512, 196, 32, 1e-05);  primals_286 = None
        getitem_569 = native_group_norm_default_92[0]
        getitem_570 = native_group_norm_default_92[1]
        getitem_571 = native_group_norm_default_92[2];  native_group_norm_default_92 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_569);  getitem_569 = None
        view_default_194 = torch.ops.aten.view.default(primals_280, [1, 2048, 512]);  primals_280 = None
        empty_97 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(view_default_194, None, None, None, None, True, 0.0, 1e-08)
        getitem_572 = native_batch_norm_default_97[0]
        getitem_573 = native_batch_norm_default_97[1]
        getitem_574 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        view_default_195 = torch.ops.aten.view.default(getitem_572, [2048, 512, 1, 1]);  getitem_572 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_92, view_default_195, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_30 = torch.ops.aten.add.Tensor(convolution_default_97, convolution_default_94);  convolution_default_97 = convolution_default_94 = None
        native_group_norm_default_93 = torch.ops.aten.native_group_norm.default(add_tensor_30, primals_292, primals_291, 64, 2048, 196, 32, 1e-05);  primals_291 = None
        getitem_575 = native_group_norm_default_93[0]
        getitem_576 = native_group_norm_default_93[1]
        getitem_577 = native_group_norm_default_93[2];  native_group_norm_default_93 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_575);  getitem_575 = None
        view_default_196 = torch.ops.aten.view.default(primals_288, [1, 512, 2048]);  primals_288 = None
        empty_98 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(view_default_196, None, None, None, None, True, 0.0, 1e-08)
        getitem_578 = native_batch_norm_default_98[0]
        getitem_579 = native_batch_norm_default_98[1]
        getitem_580 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        view_default_197 = torch.ops.aten.view.default(getitem_578, [512, 2048, 1, 1]);  getitem_578 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_93, view_default_197, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_94 = torch.ops.aten.native_group_norm.default(convolution_default_98, primals_294, primals_293, 64, 512, 196, 32, 1e-05);  primals_293 = None
        getitem_581 = native_group_norm_default_94[0]
        getitem_582 = native_group_norm_default_94[1]
        getitem_583 = native_group_norm_default_94[2];  native_group_norm_default_94 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_581);  getitem_581 = None
        view_default_198 = torch.ops.aten.view.default(primals_289, [1, 512, 4608]);  primals_289 = None
        empty_99 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(view_default_198, None, None, None, None, True, 0.0, 1e-08)
        getitem_584 = native_batch_norm_default_99[0]
        getitem_585 = native_batch_norm_default_99[1]
        getitem_586 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        view_default_199 = torch.ops.aten.view.default(getitem_584, [512, 512, 3, 3]);  getitem_584 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_94, view_default_199, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_95 = torch.ops.aten.native_group_norm.default(convolution_default_99, primals_296, primals_295, 64, 512, 196, 32, 1e-05);  primals_295 = None
        getitem_587 = native_group_norm_default_95[0]
        getitem_588 = native_group_norm_default_95[1]
        getitem_589 = native_group_norm_default_95[2];  native_group_norm_default_95 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_587);  getitem_587 = None
        view_default_200 = torch.ops.aten.view.default(primals_290, [1, 2048, 512]);  primals_290 = None
        empty_100 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(view_default_200, None, None, None, None, True, 0.0, 1e-08)
        getitem_590 = native_batch_norm_default_100[0]
        getitem_591 = native_batch_norm_default_100[1]
        getitem_592 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        view_default_201 = torch.ops.aten.view.default(getitem_590, [2048, 512, 1, 1]);  getitem_590 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_95, view_default_201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(convolution_default_100, add_tensor_30);  convolution_default_100 = None
        native_group_norm_default_96 = torch.ops.aten.native_group_norm.default(add_tensor_31, primals_301, primals_300, 64, 2048, 196, 32, 1e-05);  primals_300 = None
        getitem_593 = native_group_norm_default_96[0]
        getitem_594 = native_group_norm_default_96[1]
        getitem_595 = native_group_norm_default_96[2];  native_group_norm_default_96 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_593);  getitem_593 = None
        view_default_202 = torch.ops.aten.view.default(primals_297, [1, 512, 2048]);  primals_297 = None
        empty_101 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(view_default_202, None, None, None, None, True, 0.0, 1e-08)
        getitem_596 = native_batch_norm_default_101[0]
        getitem_597 = native_batch_norm_default_101[1]
        getitem_598 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        view_default_203 = torch.ops.aten.view.default(getitem_596, [512, 2048, 1, 1]);  getitem_596 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_96, view_default_203, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_97 = torch.ops.aten.native_group_norm.default(convolution_default_101, primals_303, primals_302, 64, 512, 196, 32, 1e-05);  primals_302 = None
        getitem_599 = native_group_norm_default_97[0]
        getitem_600 = native_group_norm_default_97[1]
        getitem_601 = native_group_norm_default_97[2];  native_group_norm_default_97 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_599);  getitem_599 = None
        view_default_204 = torch.ops.aten.view.default(primals_298, [1, 512, 4608]);  primals_298 = None
        empty_102 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(view_default_204, None, None, None, None, True, 0.0, 1e-08)
        getitem_602 = native_batch_norm_default_102[0]
        getitem_603 = native_batch_norm_default_102[1]
        getitem_604 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        view_default_205 = torch.ops.aten.view.default(getitem_602, [512, 512, 3, 3]);  getitem_602 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_97, view_default_205, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_98 = torch.ops.aten.native_group_norm.default(convolution_default_102, primals_305, primals_304, 64, 512, 196, 32, 1e-05);  primals_304 = None
        getitem_605 = native_group_norm_default_98[0]
        getitem_606 = native_group_norm_default_98[1]
        getitem_607 = native_group_norm_default_98[2];  native_group_norm_default_98 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_605);  getitem_605 = None
        view_default_206 = torch.ops.aten.view.default(primals_299, [1, 2048, 512]);  primals_299 = None
        empty_103 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(view_default_206, None, None, None, None, True, 0.0, 1e-08)
        getitem_608 = native_batch_norm_default_103[0]
        getitem_609 = native_batch_norm_default_103[1]
        getitem_610 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        view_default_207 = torch.ops.aten.view.default(getitem_608, [2048, 512, 1, 1]);  getitem_608 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_98, view_default_207, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_32 = torch.ops.aten.add.Tensor(convolution_default_103, add_tensor_31);  convolution_default_103 = None
        native_group_norm_default_99 = torch.ops.aten.native_group_norm.default(add_tensor_32, primals_4, primals_3, 64, 2048, 196, 32, 1e-05);  primals_3 = None
        getitem_611 = native_group_norm_default_99[0]
        getitem_612 = native_group_norm_default_99[1]
        getitem_613 = native_group_norm_default_99[2];  native_group_norm_default_99 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_611);  getitem_611 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_99, [-1, -2], True)
        convolution_default_104 = torch.ops.aten.convolution.default(mean_dim, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        view_default_208 = torch.ops.aten.view.default(convolution_default_104, [64, 1000]);  convolution_default_104 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(view_default_208, tangents_1)
        view_default_209 = torch.ops.aten.view.default(tangents_1, [64, 1000, 1, 1]);  tangents_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(view_default_209, mean_dim, primals_2, [1000], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_209 = mean_dim = primals_2 = None
        getitem_614 = convolution_backward_default[0]
        getitem_615 = convolution_backward_default[1]
        getitem_616 = convolution_backward_default[2];  convolution_backward_default = None
        expand_default = torch.ops.aten.expand.default(getitem_614, [64, 2048, 14, 14]);  getitem_614 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 196);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_group_norm_backward_default = torch.ops.aten.native_group_norm_backward.default(to_dtype_2, add_tensor_32, getitem_612, getitem_613, primals_4, 64, 2048, 196, 32, [True, True, True]);  to_dtype_2 = add_tensor_32 = getitem_612 = getitem_613 = primals_4 = None
        getitem_617 = native_group_norm_backward_default[0]
        getitem_618 = native_group_norm_backward_default[1]
        getitem_619 = native_group_norm_backward_default[2];  native_group_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_617, relu__default_98, view_default_207, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_207 = None
        getitem_620 = convolution_backward_default_1[0]
        getitem_621 = convolution_backward_default_1[1]
        getitem_622 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        view_default_210 = torch.ops.aten.view.default(getitem_621, [1, 2048, 512]);  getitem_621 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(view_default_210, view_default_206, None, None, None, getitem_609, getitem_610, True, 1e-08, [True, False, False]);  view_default_210 = view_default_206 = getitem_609 = getitem_610 = None
        getitem_623 = native_batch_norm_backward_default[0]
        getitem_624 = native_batch_norm_backward_default[1]
        getitem_625 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        view_default_211 = torch.ops.aten.view.default(getitem_623, [2048, 512, 1, 1]);  getitem_623 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_620, torch.float32);  getitem_620 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_group_norm_backward_default_1 = torch.ops.aten.native_group_norm_backward.default(to_dtype_5, convolution_default_102, getitem_606, getitem_607, primals_305, 64, 512, 196, 32, [True, True, True]);  to_dtype_5 = convolution_default_102 = getitem_606 = getitem_607 = primals_305 = None
        getitem_626 = native_group_norm_backward_default_1[0]
        getitem_627 = native_group_norm_backward_default_1[1]
        getitem_628 = native_group_norm_backward_default_1[2];  native_group_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_626, relu__default_97, view_default_205, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_626 = view_default_205 = None
        getitem_629 = convolution_backward_default_2[0]
        getitem_630 = convolution_backward_default_2[1]
        getitem_631 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        view_default_212 = torch.ops.aten.view.default(getitem_630, [1, 512, 4608]);  getitem_630 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(view_default_212, view_default_204, None, None, None, getitem_603, getitem_604, True, 1e-08, [True, False, False]);  view_default_212 = view_default_204 = getitem_603 = getitem_604 = None
        getitem_632 = native_batch_norm_backward_default_1[0]
        getitem_633 = native_batch_norm_backward_default_1[1]
        getitem_634 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        view_default_213 = torch.ops.aten.view.default(getitem_632, [512, 512, 3, 3]);  getitem_632 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_629, torch.float32);  getitem_629 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_group_norm_backward_default_2 = torch.ops.aten.native_group_norm_backward.default(to_dtype_8, convolution_default_101, getitem_600, getitem_601, primals_303, 64, 512, 196, 32, [True, True, True]);  to_dtype_8 = convolution_default_101 = getitem_600 = getitem_601 = primals_303 = None
        getitem_635 = native_group_norm_backward_default_2[0]
        getitem_636 = native_group_norm_backward_default_2[1]
        getitem_637 = native_group_norm_backward_default_2[2];  native_group_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_635, relu__default_96, view_default_203, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_635 = view_default_203 = None
        getitem_638 = convolution_backward_default_3[0]
        getitem_639 = convolution_backward_default_3[1]
        getitem_640 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        view_default_214 = torch.ops.aten.view.default(getitem_639, [1, 512, 2048]);  getitem_639 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(view_default_214, view_default_202, None, None, None, getitem_597, getitem_598, True, 1e-08, [True, False, False]);  view_default_214 = view_default_202 = getitem_597 = getitem_598 = None
        getitem_641 = native_batch_norm_backward_default_2[0]
        getitem_642 = native_batch_norm_backward_default_2[1]
        getitem_643 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        view_default_215 = torch.ops.aten.view.default(getitem_641, [512, 2048, 1, 1]);  getitem_641 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_638, torch.float32);  getitem_638 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_group_norm_backward_default_3 = torch.ops.aten.native_group_norm_backward.default(to_dtype_11, add_tensor_31, getitem_594, getitem_595, primals_301, 64, 2048, 196, 32, [True, True, True]);  to_dtype_11 = add_tensor_31 = getitem_594 = getitem_595 = primals_301 = None
        getitem_644 = native_group_norm_backward_default_3[0]
        getitem_645 = native_group_norm_backward_default_3[1]
        getitem_646 = native_group_norm_backward_default_3[2];  native_group_norm_backward_default_3 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(getitem_617, getitem_644);  getitem_617 = getitem_644 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(add_tensor_33, relu__default_95, view_default_201, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_201 = None
        getitem_647 = convolution_backward_default_4[0]
        getitem_648 = convolution_backward_default_4[1]
        getitem_649 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        view_default_216 = torch.ops.aten.view.default(getitem_648, [1, 2048, 512]);  getitem_648 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(view_default_216, view_default_200, None, None, None, getitem_591, getitem_592, True, 1e-08, [True, False, False]);  view_default_216 = view_default_200 = getitem_591 = getitem_592 = None
        getitem_650 = native_batch_norm_backward_default_3[0]
        getitem_651 = native_batch_norm_backward_default_3[1]
        getitem_652 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        view_default_217 = torch.ops.aten.view.default(getitem_650, [2048, 512, 1, 1]);  getitem_650 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_647, torch.float32);  getitem_647 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_group_norm_backward_default_4 = torch.ops.aten.native_group_norm_backward.default(to_dtype_14, convolution_default_99, getitem_588, getitem_589, primals_296, 64, 512, 196, 32, [True, True, True]);  to_dtype_14 = convolution_default_99 = getitem_588 = getitem_589 = primals_296 = None
        getitem_653 = native_group_norm_backward_default_4[0]
        getitem_654 = native_group_norm_backward_default_4[1]
        getitem_655 = native_group_norm_backward_default_4[2];  native_group_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_653, relu__default_94, view_default_199, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_653 = view_default_199 = None
        getitem_656 = convolution_backward_default_5[0]
        getitem_657 = convolution_backward_default_5[1]
        getitem_658 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        view_default_218 = torch.ops.aten.view.default(getitem_657, [1, 512, 4608]);  getitem_657 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(view_default_218, view_default_198, None, None, None, getitem_585, getitem_586, True, 1e-08, [True, False, False]);  view_default_218 = view_default_198 = getitem_585 = getitem_586 = None
        getitem_659 = native_batch_norm_backward_default_4[0]
        getitem_660 = native_batch_norm_backward_default_4[1]
        getitem_661 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        view_default_219 = torch.ops.aten.view.default(getitem_659, [512, 512, 3, 3]);  getitem_659 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_656, torch.float32);  getitem_656 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_group_norm_backward_default_5 = torch.ops.aten.native_group_norm_backward.default(to_dtype_17, convolution_default_98, getitem_582, getitem_583, primals_294, 64, 512, 196, 32, [True, True, True]);  to_dtype_17 = convolution_default_98 = getitem_582 = getitem_583 = primals_294 = None
        getitem_662 = native_group_norm_backward_default_5[0]
        getitem_663 = native_group_norm_backward_default_5[1]
        getitem_664 = native_group_norm_backward_default_5[2];  native_group_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_662, relu__default_93, view_default_197, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_662 = view_default_197 = None
        getitem_665 = convolution_backward_default_6[0]
        getitem_666 = convolution_backward_default_6[1]
        getitem_667 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        view_default_220 = torch.ops.aten.view.default(getitem_666, [1, 512, 2048]);  getitem_666 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(view_default_220, view_default_196, None, None, None, getitem_579, getitem_580, True, 1e-08, [True, False, False]);  view_default_220 = view_default_196 = getitem_579 = getitem_580 = None
        getitem_668 = native_batch_norm_backward_default_5[0]
        getitem_669 = native_batch_norm_backward_default_5[1]
        getitem_670 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        view_default_221 = torch.ops.aten.view.default(getitem_668, [512, 2048, 1, 1]);  getitem_668 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_665, torch.float32);  getitem_665 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_group_norm_backward_default_6 = torch.ops.aten.native_group_norm_backward.default(to_dtype_20, add_tensor_30, getitem_576, getitem_577, primals_292, 64, 2048, 196, 32, [True, True, True]);  to_dtype_20 = add_tensor_30 = getitem_576 = getitem_577 = primals_292 = None
        getitem_671 = native_group_norm_backward_default_6[0]
        getitem_672 = native_group_norm_backward_default_6[1]
        getitem_673 = native_group_norm_backward_default_6[2];  native_group_norm_backward_default_6 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_671);  add_tensor_33 = getitem_671 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(add_tensor_34, relu__default_92, view_default_195, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_195 = None
        getitem_674 = convolution_backward_default_7[0]
        getitem_675 = convolution_backward_default_7[1]
        getitem_676 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        view_default_222 = torch.ops.aten.view.default(getitem_675, [1, 2048, 512]);  getitem_675 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(view_default_222, view_default_194, None, None, None, getitem_573, getitem_574, True, 1e-08, [True, False, False]);  view_default_222 = view_default_194 = getitem_573 = getitem_574 = None
        getitem_677 = native_batch_norm_backward_default_6[0]
        getitem_678 = native_batch_norm_backward_default_6[1]
        getitem_679 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        view_default_223 = torch.ops.aten.view.default(getitem_677, [2048, 512, 1, 1]);  getitem_677 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_674, torch.float32);  getitem_674 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_group_norm_backward_default_7 = torch.ops.aten.native_group_norm_backward.default(to_dtype_23, convolution_default_96, getitem_570, getitem_571, primals_287, 64, 512, 196, 32, [True, True, True]);  to_dtype_23 = convolution_default_96 = getitem_570 = getitem_571 = primals_287 = None
        getitem_680 = native_group_norm_backward_default_7[0]
        getitem_681 = native_group_norm_backward_default_7[1]
        getitem_682 = native_group_norm_backward_default_7[2];  native_group_norm_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_680, relu__default_91, view_default_193, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_680 = view_default_193 = None
        getitem_683 = convolution_backward_default_8[0]
        getitem_684 = convolution_backward_default_8[1]
        getitem_685 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        view_default_224 = torch.ops.aten.view.default(getitem_684, [1, 512, 4608]);  getitem_684 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(view_default_224, view_default_192, None, None, None, getitem_567, getitem_568, True, 1e-08, [True, False, False]);  view_default_224 = view_default_192 = getitem_567 = getitem_568 = None
        getitem_686 = native_batch_norm_backward_default_7[0]
        getitem_687 = native_batch_norm_backward_default_7[1]
        getitem_688 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        view_default_225 = torch.ops.aten.view.default(getitem_686, [512, 512, 3, 3]);  getitem_686 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_683, torch.float32);  getitem_683 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_24);  le_scalar_8 = new_zeros_default_8 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_group_norm_backward_default_8 = torch.ops.aten.native_group_norm_backward.default(to_dtype_26, convolution_default_95, getitem_564, getitem_565, primals_285, 64, 512, 784, 32, [True, True, True]);  to_dtype_26 = convolution_default_95 = getitem_564 = getitem_565 = primals_285 = None
        getitem_689 = native_group_norm_backward_default_8[0]
        getitem_690 = native_group_norm_backward_default_8[1]
        getitem_691 = native_group_norm_backward_default_8[2];  native_group_norm_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_689, relu__default_90, view_default_191, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_689 = view_default_191 = None
        getitem_692 = convolution_backward_default_9[0]
        getitem_693 = convolution_backward_default_9[1]
        getitem_694 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        view_default_226 = torch.ops.aten.view.default(getitem_693, [1, 512, 1024]);  getitem_693 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(view_default_226, view_default_190, None, None, None, getitem_561, getitem_562, True, 1e-08, [True, False, False]);  view_default_226 = view_default_190 = getitem_561 = getitem_562 = None
        getitem_695 = native_batch_norm_backward_default_8[0]
        getitem_696 = native_batch_norm_backward_default_8[1]
        getitem_697 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        view_default_227 = torch.ops.aten.view.default(getitem_695, [512, 1024, 1, 1]);  getitem_695 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(add_tensor_34, relu__default_90, view_default_189, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_34 = view_default_189 = None
        getitem_698 = convolution_backward_default_10[0]
        getitem_699 = convolution_backward_default_10[1]
        getitem_700 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_692, getitem_698);  getitem_692 = getitem_698 = None
        view_default_228 = torch.ops.aten.view.default(getitem_699, [1, 2048, 1024]);  getitem_699 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(view_default_228, view_default_188, None, None, None, getitem_558, getitem_559, True, 1e-08, [True, False, False]);  view_default_228 = view_default_188 = getitem_558 = getitem_559 = None
        getitem_701 = native_batch_norm_backward_default_9[0]
        getitem_702 = native_batch_norm_backward_default_9[1]
        getitem_703 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        view_default_229 = torch.ops.aten.view.default(getitem_701, [2048, 1024, 1, 1]);  getitem_701 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_27);  le_scalar_9 = new_zeros_default_9 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_group_norm_backward_default_9 = torch.ops.aten.native_group_norm_backward.default(to_dtype_29, add_tensor_29, getitem_555, getitem_556, primals_283, 64, 1024, 784, 32, [True, True, True]);  to_dtype_29 = add_tensor_29 = getitem_555 = getitem_556 = primals_283 = None
        getitem_704 = native_group_norm_backward_default_9[0]
        getitem_705 = native_group_norm_backward_default_9[1]
        getitem_706 = native_group_norm_backward_default_9[2];  native_group_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_704, relu__default_89, view_default_187, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_187 = None
        getitem_707 = convolution_backward_default_11[0]
        getitem_708 = convolution_backward_default_11[1]
        getitem_709 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        view_default_230 = torch.ops.aten.view.default(getitem_708, [1, 1024, 256]);  getitem_708 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(view_default_230, view_default_186, None, None, None, getitem_552, getitem_553, True, 1e-08, [True, False, False]);  view_default_230 = view_default_186 = getitem_552 = getitem_553 = None
        getitem_710 = native_batch_norm_backward_default_10[0]
        getitem_711 = native_batch_norm_backward_default_10[1]
        getitem_712 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        view_default_231 = torch.ops.aten.view.default(getitem_710, [1024, 256, 1, 1]);  getitem_710 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_707, torch.float32);  getitem_707 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_30);  le_scalar_10 = new_zeros_default_10 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_group_norm_backward_default_10 = torch.ops.aten.native_group_norm_backward.default(to_dtype_32, convolution_default_92, getitem_549, getitem_550, primals_205, 64, 256, 784, 32, [True, True, True]);  to_dtype_32 = convolution_default_92 = getitem_549 = getitem_550 = primals_205 = None
        getitem_713 = native_group_norm_backward_default_10[0]
        getitem_714 = native_group_norm_backward_default_10[1]
        getitem_715 = native_group_norm_backward_default_10[2];  native_group_norm_backward_default_10 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_713, relu__default_88, view_default_185, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_713 = view_default_185 = None
        getitem_716 = convolution_backward_default_12[0]
        getitem_717 = convolution_backward_default_12[1]
        getitem_718 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        view_default_232 = torch.ops.aten.view.default(getitem_717, [1, 256, 2304]);  getitem_717 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(view_default_232, view_default_184, None, None, None, getitem_546, getitem_547, True, 1e-08, [True, False, False]);  view_default_232 = view_default_184 = getitem_546 = getitem_547 = None
        getitem_719 = native_batch_norm_backward_default_11[0]
        getitem_720 = native_batch_norm_backward_default_11[1]
        getitem_721 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        view_default_233 = torch.ops.aten.view.default(getitem_719, [256, 256, 3, 3]);  getitem_719 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_716, torch.float32);  getitem_716 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_33);  le_scalar_11 = new_zeros_default_11 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_group_norm_backward_default_11 = torch.ops.aten.native_group_norm_backward.default(to_dtype_35, convolution_default_91, getitem_543, getitem_544, primals_203, 64, 256, 784, 32, [True, True, True]);  to_dtype_35 = convolution_default_91 = getitem_543 = getitem_544 = primals_203 = None
        getitem_722 = native_group_norm_backward_default_11[0]
        getitem_723 = native_group_norm_backward_default_11[1]
        getitem_724 = native_group_norm_backward_default_11[2];  native_group_norm_backward_default_11 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_722, relu__default_87, view_default_183, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_722 = view_default_183 = None
        getitem_725 = convolution_backward_default_13[0]
        getitem_726 = convolution_backward_default_13[1]
        getitem_727 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        view_default_234 = torch.ops.aten.view.default(getitem_726, [1, 256, 1024]);  getitem_726 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(view_default_234, view_default_182, None, None, None, getitem_540, getitem_541, True, 1e-08, [True, False, False]);  view_default_234 = view_default_182 = getitem_540 = getitem_541 = None
        getitem_728 = native_batch_norm_backward_default_12[0]
        getitem_729 = native_batch_norm_backward_default_12[1]
        getitem_730 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        view_default_235 = torch.ops.aten.view.default(getitem_728, [256, 1024, 1, 1]);  getitem_728 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_725, torch.float32);  getitem_725 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_12, to_dtype_36);  le_scalar_12 = new_zeros_default_12 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_group_norm_backward_default_12 = torch.ops.aten.native_group_norm_backward.default(to_dtype_38, add_tensor_28, getitem_537, getitem_538, primals_201, 64, 1024, 784, 32, [True, True, True]);  to_dtype_38 = add_tensor_28 = getitem_537 = getitem_538 = primals_201 = None
        getitem_731 = native_group_norm_backward_default_12[0]
        getitem_732 = native_group_norm_backward_default_12[1]
        getitem_733 = native_group_norm_backward_default_12[2];  native_group_norm_backward_default_12 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_704, getitem_731);  getitem_704 = getitem_731 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(add_tensor_36, relu__default_86, view_default_181, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_181 = None
        getitem_734 = convolution_backward_default_14[0]
        getitem_735 = convolution_backward_default_14[1]
        getitem_736 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        view_default_236 = torch.ops.aten.view.default(getitem_735, [1, 1024, 256]);  getitem_735 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(view_default_236, view_default_180, None, None, None, getitem_534, getitem_535, True, 1e-08, [True, False, False]);  view_default_236 = view_default_180 = getitem_534 = getitem_535 = None
        getitem_737 = native_batch_norm_backward_default_13[0]
        getitem_738 = native_batch_norm_backward_default_13[1]
        getitem_739 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        view_default_237 = torch.ops.aten.view.default(getitem_737, [1024, 256, 1, 1]);  getitem_737 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_734, torch.float32);  getitem_734 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_13, to_dtype_39);  le_scalar_13 = new_zeros_default_13 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_group_norm_backward_default_13 = torch.ops.aten.native_group_norm_backward.default(to_dtype_41, convolution_default_89, getitem_531, getitem_532, primals_196, 64, 256, 784, 32, [True, True, True]);  to_dtype_41 = convolution_default_89 = getitem_531 = getitem_532 = primals_196 = None
        getitem_740 = native_group_norm_backward_default_13[0]
        getitem_741 = native_group_norm_backward_default_13[1]
        getitem_742 = native_group_norm_backward_default_13[2];  native_group_norm_backward_default_13 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_740, relu__default_85, view_default_179, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_740 = view_default_179 = None
        getitem_743 = convolution_backward_default_15[0]
        getitem_744 = convolution_backward_default_15[1]
        getitem_745 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        view_default_238 = torch.ops.aten.view.default(getitem_744, [1, 256, 2304]);  getitem_744 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(view_default_238, view_default_178, None, None, None, getitem_528, getitem_529, True, 1e-08, [True, False, False]);  view_default_238 = view_default_178 = getitem_528 = getitem_529 = None
        getitem_746 = native_batch_norm_backward_default_14[0]
        getitem_747 = native_batch_norm_backward_default_14[1]
        getitem_748 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        view_default_239 = torch.ops.aten.view.default(getitem_746, [256, 256, 3, 3]);  getitem_746 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_743, torch.float32);  getitem_743 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_14, to_dtype_42);  le_scalar_14 = new_zeros_default_14 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_group_norm_backward_default_14 = torch.ops.aten.native_group_norm_backward.default(to_dtype_44, convolution_default_88, getitem_525, getitem_526, primals_194, 64, 256, 784, 32, [True, True, True]);  to_dtype_44 = convolution_default_88 = getitem_525 = getitem_526 = primals_194 = None
        getitem_749 = native_group_norm_backward_default_14[0]
        getitem_750 = native_group_norm_backward_default_14[1]
        getitem_751 = native_group_norm_backward_default_14[2];  native_group_norm_backward_default_14 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_749, relu__default_84, view_default_177, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_749 = view_default_177 = None
        getitem_752 = convolution_backward_default_16[0]
        getitem_753 = convolution_backward_default_16[1]
        getitem_754 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        view_default_240 = torch.ops.aten.view.default(getitem_753, [1, 256, 1024]);  getitem_753 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(view_default_240, view_default_176, None, None, None, getitem_522, getitem_523, True, 1e-08, [True, False, False]);  view_default_240 = view_default_176 = getitem_522 = getitem_523 = None
        getitem_755 = native_batch_norm_backward_default_15[0]
        getitem_756 = native_batch_norm_backward_default_15[1]
        getitem_757 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        view_default_241 = torch.ops.aten.view.default(getitem_755, [256, 1024, 1, 1]);  getitem_755 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_752, torch.float32);  getitem_752 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_15, to_dtype_45);  le_scalar_15 = new_zeros_default_15 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_group_norm_backward_default_15 = torch.ops.aten.native_group_norm_backward.default(to_dtype_47, add_tensor_27, getitem_519, getitem_520, primals_192, 64, 1024, 784, 32, [True, True, True]);  to_dtype_47 = add_tensor_27 = getitem_519 = getitem_520 = primals_192 = None
        getitem_758 = native_group_norm_backward_default_15[0]
        getitem_759 = native_group_norm_backward_default_15[1]
        getitem_760 = native_group_norm_backward_default_15[2];  native_group_norm_backward_default_15 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_36, getitem_758);  add_tensor_36 = getitem_758 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(add_tensor_37, relu__default_83, view_default_175, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_175 = None
        getitem_761 = convolution_backward_default_17[0]
        getitem_762 = convolution_backward_default_17[1]
        getitem_763 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        view_default_242 = torch.ops.aten.view.default(getitem_762, [1, 1024, 256]);  getitem_762 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(view_default_242, view_default_174, None, None, None, getitem_516, getitem_517, True, 1e-08, [True, False, False]);  view_default_242 = view_default_174 = getitem_516 = getitem_517 = None
        getitem_764 = native_batch_norm_backward_default_16[0]
        getitem_765 = native_batch_norm_backward_default_16[1]
        getitem_766 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        view_default_243 = torch.ops.aten.view.default(getitem_764, [1024, 256, 1, 1]);  getitem_764 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_761, torch.float32);  getitem_761 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_16, to_dtype_48);  le_scalar_16 = new_zeros_default_16 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_group_norm_backward_default_16 = torch.ops.aten.native_group_norm_backward.default(to_dtype_50, convolution_default_86, getitem_513, getitem_514, primals_187, 64, 256, 784, 32, [True, True, True]);  to_dtype_50 = convolution_default_86 = getitem_513 = getitem_514 = primals_187 = None
        getitem_767 = native_group_norm_backward_default_16[0]
        getitem_768 = native_group_norm_backward_default_16[1]
        getitem_769 = native_group_norm_backward_default_16[2];  native_group_norm_backward_default_16 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_767, relu__default_82, view_default_173, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_767 = view_default_173 = None
        getitem_770 = convolution_backward_default_18[0]
        getitem_771 = convolution_backward_default_18[1]
        getitem_772 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        view_default_244 = torch.ops.aten.view.default(getitem_771, [1, 256, 2304]);  getitem_771 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(view_default_244, view_default_172, None, None, None, getitem_510, getitem_511, True, 1e-08, [True, False, False]);  view_default_244 = view_default_172 = getitem_510 = getitem_511 = None
        getitem_773 = native_batch_norm_backward_default_17[0]
        getitem_774 = native_batch_norm_backward_default_17[1]
        getitem_775 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        view_default_245 = torch.ops.aten.view.default(getitem_773, [256, 256, 3, 3]);  getitem_773 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_770, torch.float32);  getitem_770 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_17, to_dtype_51);  le_scalar_17 = new_zeros_default_17 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_group_norm_backward_default_17 = torch.ops.aten.native_group_norm_backward.default(to_dtype_53, convolution_default_85, getitem_507, getitem_508, primals_185, 64, 256, 784, 32, [True, True, True]);  to_dtype_53 = convolution_default_85 = getitem_507 = getitem_508 = primals_185 = None
        getitem_776 = native_group_norm_backward_default_17[0]
        getitem_777 = native_group_norm_backward_default_17[1]
        getitem_778 = native_group_norm_backward_default_17[2];  native_group_norm_backward_default_17 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_776, relu__default_81, view_default_171, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_776 = view_default_171 = None
        getitem_779 = convolution_backward_default_19[0]
        getitem_780 = convolution_backward_default_19[1]
        getitem_781 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        view_default_246 = torch.ops.aten.view.default(getitem_780, [1, 256, 1024]);  getitem_780 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(view_default_246, view_default_170, None, None, None, getitem_504, getitem_505, True, 1e-08, [True, False, False]);  view_default_246 = view_default_170 = getitem_504 = getitem_505 = None
        getitem_782 = native_batch_norm_backward_default_18[0]
        getitem_783 = native_batch_norm_backward_default_18[1]
        getitem_784 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        view_default_247 = torch.ops.aten.view.default(getitem_782, [256, 1024, 1, 1]);  getitem_782 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_779, torch.float32);  getitem_779 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_18, to_dtype_54);  le_scalar_18 = new_zeros_default_18 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_group_norm_backward_default_18 = torch.ops.aten.native_group_norm_backward.default(to_dtype_56, add_tensor_26, getitem_501, getitem_502, primals_183, 64, 1024, 784, 32, [True, True, True]);  to_dtype_56 = add_tensor_26 = getitem_501 = getitem_502 = primals_183 = None
        getitem_785 = native_group_norm_backward_default_18[0]
        getitem_786 = native_group_norm_backward_default_18[1]
        getitem_787 = native_group_norm_backward_default_18[2];  native_group_norm_backward_default_18 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(add_tensor_37, getitem_785);  add_tensor_37 = getitem_785 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(add_tensor_38, relu__default_80, view_default_169, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_169 = None
        getitem_788 = convolution_backward_default_20[0]
        getitem_789 = convolution_backward_default_20[1]
        getitem_790 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        view_default_248 = torch.ops.aten.view.default(getitem_789, [1, 1024, 256]);  getitem_789 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(view_default_248, view_default_168, None, None, None, getitem_498, getitem_499, True, 1e-08, [True, False, False]);  view_default_248 = view_default_168 = getitem_498 = getitem_499 = None
        getitem_791 = native_batch_norm_backward_default_19[0]
        getitem_792 = native_batch_norm_backward_default_19[1]
        getitem_793 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        view_default_249 = torch.ops.aten.view.default(getitem_791, [1024, 256, 1, 1]);  getitem_791 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_788, torch.float32);  getitem_788 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_19, to_dtype_57);  le_scalar_19 = new_zeros_default_19 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_group_norm_backward_default_19 = torch.ops.aten.native_group_norm_backward.default(to_dtype_59, convolution_default_83, getitem_495, getitem_496, primals_169, 64, 256, 784, 32, [True, True, True]);  to_dtype_59 = convolution_default_83 = getitem_495 = getitem_496 = primals_169 = None
        getitem_794 = native_group_norm_backward_default_19[0]
        getitem_795 = native_group_norm_backward_default_19[1]
        getitem_796 = native_group_norm_backward_default_19[2];  native_group_norm_backward_default_19 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_794, relu__default_79, view_default_167, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_794 = view_default_167 = None
        getitem_797 = convolution_backward_default_21[0]
        getitem_798 = convolution_backward_default_21[1]
        getitem_799 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        view_default_250 = torch.ops.aten.view.default(getitem_798, [1, 256, 2304]);  getitem_798 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(view_default_250, view_default_166, None, None, None, getitem_492, getitem_493, True, 1e-08, [True, False, False]);  view_default_250 = view_default_166 = getitem_492 = getitem_493 = None
        getitem_800 = native_batch_norm_backward_default_20[0]
        getitem_801 = native_batch_norm_backward_default_20[1]
        getitem_802 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        view_default_251 = torch.ops.aten.view.default(getitem_800, [256, 256, 3, 3]);  getitem_800 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_797, torch.float32);  getitem_797 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_20, to_dtype_60);  le_scalar_20 = new_zeros_default_20 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_group_norm_backward_default_20 = torch.ops.aten.native_group_norm_backward.default(to_dtype_62, convolution_default_82, getitem_489, getitem_490, primals_167, 64, 256, 784, 32, [True, True, True]);  to_dtype_62 = convolution_default_82 = getitem_489 = getitem_490 = primals_167 = None
        getitem_803 = native_group_norm_backward_default_20[0]
        getitem_804 = native_group_norm_backward_default_20[1]
        getitem_805 = native_group_norm_backward_default_20[2];  native_group_norm_backward_default_20 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_803, relu__default_78, view_default_165, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_803 = view_default_165 = None
        getitem_806 = convolution_backward_default_22[0]
        getitem_807 = convolution_backward_default_22[1]
        getitem_808 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        view_default_252 = torch.ops.aten.view.default(getitem_807, [1, 256, 1024]);  getitem_807 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(view_default_252, view_default_164, None, None, None, getitem_486, getitem_487, True, 1e-08, [True, False, False]);  view_default_252 = view_default_164 = getitem_486 = getitem_487 = None
        getitem_809 = native_batch_norm_backward_default_21[0]
        getitem_810 = native_batch_norm_backward_default_21[1]
        getitem_811 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        view_default_253 = torch.ops.aten.view.default(getitem_809, [256, 1024, 1, 1]);  getitem_809 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_806, torch.float32);  getitem_806 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_21, to_dtype_63);  le_scalar_21 = new_zeros_default_21 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_group_norm_backward_default_21 = torch.ops.aten.native_group_norm_backward.default(to_dtype_65, add_tensor_25, getitem_483, getitem_484, primals_165, 64, 1024, 784, 32, [True, True, True]);  to_dtype_65 = add_tensor_25 = getitem_483 = getitem_484 = primals_165 = None
        getitem_812 = native_group_norm_backward_default_21[0]
        getitem_813 = native_group_norm_backward_default_21[1]
        getitem_814 = native_group_norm_backward_default_21[2];  native_group_norm_backward_default_21 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_38, getitem_812);  add_tensor_38 = getitem_812 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(add_tensor_39, relu__default_77, view_default_163, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_163 = None
        getitem_815 = convolution_backward_default_23[0]
        getitem_816 = convolution_backward_default_23[1]
        getitem_817 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        view_default_254 = torch.ops.aten.view.default(getitem_816, [1, 1024, 256]);  getitem_816 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(view_default_254, view_default_162, None, None, None, getitem_480, getitem_481, True, 1e-08, [True, False, False]);  view_default_254 = view_default_162 = getitem_480 = getitem_481 = None
        getitem_818 = native_batch_norm_backward_default_22[0]
        getitem_819 = native_batch_norm_backward_default_22[1]
        getitem_820 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        view_default_255 = torch.ops.aten.view.default(getitem_818, [1024, 256, 1, 1]);  getitem_818 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_815, torch.float32);  getitem_815 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_22, to_dtype_66);  le_scalar_22 = new_zeros_default_22 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_group_norm_backward_default_22 = torch.ops.aten.native_group_norm_backward.default(to_dtype_68, convolution_default_80, getitem_477, getitem_478, primals_160, 64, 256, 784, 32, [True, True, True]);  to_dtype_68 = convolution_default_80 = getitem_477 = getitem_478 = primals_160 = None
        getitem_821 = native_group_norm_backward_default_22[0]
        getitem_822 = native_group_norm_backward_default_22[1]
        getitem_823 = native_group_norm_backward_default_22[2];  native_group_norm_backward_default_22 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_821, relu__default_76, view_default_161, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_821 = view_default_161 = None
        getitem_824 = convolution_backward_default_24[0]
        getitem_825 = convolution_backward_default_24[1]
        getitem_826 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        view_default_256 = torch.ops.aten.view.default(getitem_825, [1, 256, 2304]);  getitem_825 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(view_default_256, view_default_160, None, None, None, getitem_474, getitem_475, True, 1e-08, [True, False, False]);  view_default_256 = view_default_160 = getitem_474 = getitem_475 = None
        getitem_827 = native_batch_norm_backward_default_23[0]
        getitem_828 = native_batch_norm_backward_default_23[1]
        getitem_829 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        view_default_257 = torch.ops.aten.view.default(getitem_827, [256, 256, 3, 3]);  getitem_827 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_824, torch.float32);  getitem_824 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_23, to_dtype_69);  le_scalar_23 = new_zeros_default_23 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_group_norm_backward_default_23 = torch.ops.aten.native_group_norm_backward.default(to_dtype_71, convolution_default_79, getitem_471, getitem_472, primals_158, 64, 256, 784, 32, [True, True, True]);  to_dtype_71 = convolution_default_79 = getitem_471 = getitem_472 = primals_158 = None
        getitem_830 = native_group_norm_backward_default_23[0]
        getitem_831 = native_group_norm_backward_default_23[1]
        getitem_832 = native_group_norm_backward_default_23[2];  native_group_norm_backward_default_23 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_830, relu__default_75, view_default_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_830 = view_default_159 = None
        getitem_833 = convolution_backward_default_25[0]
        getitem_834 = convolution_backward_default_25[1]
        getitem_835 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        view_default_258 = torch.ops.aten.view.default(getitem_834, [1, 256, 1024]);  getitem_834 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(view_default_258, view_default_158, None, None, None, getitem_468, getitem_469, True, 1e-08, [True, False, False]);  view_default_258 = view_default_158 = getitem_468 = getitem_469 = None
        getitem_836 = native_batch_norm_backward_default_24[0]
        getitem_837 = native_batch_norm_backward_default_24[1]
        getitem_838 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        view_default_259 = torch.ops.aten.view.default(getitem_836, [256, 1024, 1, 1]);  getitem_836 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_833, torch.float32);  getitem_833 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_24, to_dtype_72);  le_scalar_24 = new_zeros_default_24 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_group_norm_backward_default_24 = torch.ops.aten.native_group_norm_backward.default(to_dtype_74, add_tensor_24, getitem_465, getitem_466, primals_156, 64, 1024, 784, 32, [True, True, True]);  to_dtype_74 = add_tensor_24 = getitem_465 = getitem_466 = primals_156 = None
        getitem_839 = native_group_norm_backward_default_24[0]
        getitem_840 = native_group_norm_backward_default_24[1]
        getitem_841 = native_group_norm_backward_default_24[2];  native_group_norm_backward_default_24 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, getitem_839);  add_tensor_39 = getitem_839 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(add_tensor_40, relu__default_74, view_default_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_157 = None
        getitem_842 = convolution_backward_default_26[0]
        getitem_843 = convolution_backward_default_26[1]
        getitem_844 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        view_default_260 = torch.ops.aten.view.default(getitem_843, [1, 1024, 256]);  getitem_843 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(view_default_260, view_default_156, None, None, None, getitem_462, getitem_463, True, 1e-08, [True, False, False]);  view_default_260 = view_default_156 = getitem_462 = getitem_463 = None
        getitem_845 = native_batch_norm_backward_default_25[0]
        getitem_846 = native_batch_norm_backward_default_25[1]
        getitem_847 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        view_default_261 = torch.ops.aten.view.default(getitem_845, [1024, 256, 1, 1]);  getitem_845 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_842, torch.float32);  getitem_842 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_25, to_dtype_75);  le_scalar_25 = new_zeros_default_25 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_group_norm_backward_default_25 = torch.ops.aten.native_group_norm_backward.default(to_dtype_77, convolution_default_77, getitem_459, getitem_460, primals_151, 64, 256, 784, 32, [True, True, True]);  to_dtype_77 = convolution_default_77 = getitem_459 = getitem_460 = primals_151 = None
        getitem_848 = native_group_norm_backward_default_25[0]
        getitem_849 = native_group_norm_backward_default_25[1]
        getitem_850 = native_group_norm_backward_default_25[2];  native_group_norm_backward_default_25 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_848, relu__default_73, view_default_155, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_848 = view_default_155 = None
        getitem_851 = convolution_backward_default_27[0]
        getitem_852 = convolution_backward_default_27[1]
        getitem_853 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        view_default_262 = torch.ops.aten.view.default(getitem_852, [1, 256, 2304]);  getitem_852 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(view_default_262, view_default_154, None, None, None, getitem_456, getitem_457, True, 1e-08, [True, False, False]);  view_default_262 = view_default_154 = getitem_456 = getitem_457 = None
        getitem_854 = native_batch_norm_backward_default_26[0]
        getitem_855 = native_batch_norm_backward_default_26[1]
        getitem_856 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        view_default_263 = torch.ops.aten.view.default(getitem_854, [256, 256, 3, 3]);  getitem_854 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_851, torch.float32);  getitem_851 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_26, to_dtype_78);  le_scalar_26 = new_zeros_default_26 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_group_norm_backward_default_26 = torch.ops.aten.native_group_norm_backward.default(to_dtype_80, convolution_default_76, getitem_453, getitem_454, primals_149, 64, 256, 784, 32, [True, True, True]);  to_dtype_80 = convolution_default_76 = getitem_453 = getitem_454 = primals_149 = None
        getitem_857 = native_group_norm_backward_default_26[0]
        getitem_858 = native_group_norm_backward_default_26[1]
        getitem_859 = native_group_norm_backward_default_26[2];  native_group_norm_backward_default_26 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_857, relu__default_72, view_default_153, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_857 = view_default_153 = None
        getitem_860 = convolution_backward_default_28[0]
        getitem_861 = convolution_backward_default_28[1]
        getitem_862 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        view_default_264 = torch.ops.aten.view.default(getitem_861, [1, 256, 1024]);  getitem_861 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(view_default_264, view_default_152, None, None, None, getitem_450, getitem_451, True, 1e-08, [True, False, False]);  view_default_264 = view_default_152 = getitem_450 = getitem_451 = None
        getitem_863 = native_batch_norm_backward_default_27[0]
        getitem_864 = native_batch_norm_backward_default_27[1]
        getitem_865 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        view_default_265 = torch.ops.aten.view.default(getitem_863, [256, 1024, 1, 1]);  getitem_863 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_860, torch.float32);  getitem_860 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_27, to_dtype_81);  le_scalar_27 = new_zeros_default_27 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_group_norm_backward_default_27 = torch.ops.aten.native_group_norm_backward.default(to_dtype_83, add_tensor_23, getitem_447, getitem_448, primals_147, 64, 1024, 784, 32, [True, True, True]);  to_dtype_83 = add_tensor_23 = getitem_447 = getitem_448 = primals_147 = None
        getitem_866 = native_group_norm_backward_default_27[0]
        getitem_867 = native_group_norm_backward_default_27[1]
        getitem_868 = native_group_norm_backward_default_27[2];  native_group_norm_backward_default_27 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, getitem_866);  add_tensor_40 = getitem_866 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(add_tensor_41, relu__default_71, view_default_151, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_151 = None
        getitem_869 = convolution_backward_default_29[0]
        getitem_870 = convolution_backward_default_29[1]
        getitem_871 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        view_default_266 = torch.ops.aten.view.default(getitem_870, [1, 1024, 256]);  getitem_870 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(view_default_266, view_default_150, None, None, None, getitem_444, getitem_445, True, 1e-08, [True, False, False]);  view_default_266 = view_default_150 = getitem_444 = getitem_445 = None
        getitem_872 = native_batch_norm_backward_default_28[0]
        getitem_873 = native_batch_norm_backward_default_28[1]
        getitem_874 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        view_default_267 = torch.ops.aten.view.default(getitem_872, [1024, 256, 1, 1]);  getitem_872 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_869, torch.float32);  getitem_869 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_28, to_dtype_84);  le_scalar_28 = new_zeros_default_28 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_group_norm_backward_default_28 = torch.ops.aten.native_group_norm_backward.default(to_dtype_86, convolution_default_74, getitem_441, getitem_442, primals_142, 64, 256, 784, 32, [True, True, True]);  to_dtype_86 = convolution_default_74 = getitem_441 = getitem_442 = primals_142 = None
        getitem_875 = native_group_norm_backward_default_28[0]
        getitem_876 = native_group_norm_backward_default_28[1]
        getitem_877 = native_group_norm_backward_default_28[2];  native_group_norm_backward_default_28 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_875, relu__default_70, view_default_149, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_875 = view_default_149 = None
        getitem_878 = convolution_backward_default_30[0]
        getitem_879 = convolution_backward_default_30[1]
        getitem_880 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        view_default_268 = torch.ops.aten.view.default(getitem_879, [1, 256, 2304]);  getitem_879 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(view_default_268, view_default_148, None, None, None, getitem_438, getitem_439, True, 1e-08, [True, False, False]);  view_default_268 = view_default_148 = getitem_438 = getitem_439 = None
        getitem_881 = native_batch_norm_backward_default_29[0]
        getitem_882 = native_batch_norm_backward_default_29[1]
        getitem_883 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        view_default_269 = torch.ops.aten.view.default(getitem_881, [256, 256, 3, 3]);  getitem_881 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_878, torch.float32);  getitem_878 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_29, to_dtype_87);  le_scalar_29 = new_zeros_default_29 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_group_norm_backward_default_29 = torch.ops.aten.native_group_norm_backward.default(to_dtype_89, convolution_default_73, getitem_435, getitem_436, primals_140, 64, 256, 784, 32, [True, True, True]);  to_dtype_89 = convolution_default_73 = getitem_435 = getitem_436 = primals_140 = None
        getitem_884 = native_group_norm_backward_default_29[0]
        getitem_885 = native_group_norm_backward_default_29[1]
        getitem_886 = native_group_norm_backward_default_29[2];  native_group_norm_backward_default_29 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_884, relu__default_69, view_default_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_884 = view_default_147 = None
        getitem_887 = convolution_backward_default_31[0]
        getitem_888 = convolution_backward_default_31[1]
        getitem_889 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        view_default_270 = torch.ops.aten.view.default(getitem_888, [1, 256, 1024]);  getitem_888 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(view_default_270, view_default_146, None, None, None, getitem_432, getitem_433, True, 1e-08, [True, False, False]);  view_default_270 = view_default_146 = getitem_432 = getitem_433 = None
        getitem_890 = native_batch_norm_backward_default_30[0]
        getitem_891 = native_batch_norm_backward_default_30[1]
        getitem_892 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        view_default_271 = torch.ops.aten.view.default(getitem_890, [256, 1024, 1, 1]);  getitem_890 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_887, torch.float32);  getitem_887 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_30, to_dtype_90);  le_scalar_30 = new_zeros_default_30 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_group_norm_backward_default_30 = torch.ops.aten.native_group_norm_backward.default(to_dtype_92, add_tensor_22, getitem_429, getitem_430, primals_138, 64, 1024, 784, 32, [True, True, True]);  to_dtype_92 = add_tensor_22 = getitem_429 = getitem_430 = primals_138 = None
        getitem_893 = native_group_norm_backward_default_30[0]
        getitem_894 = native_group_norm_backward_default_30[1]
        getitem_895 = native_group_norm_backward_default_30[2];  native_group_norm_backward_default_30 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, getitem_893);  add_tensor_41 = getitem_893 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(add_tensor_42, relu__default_68, view_default_145, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_145 = None
        getitem_896 = convolution_backward_default_32[0]
        getitem_897 = convolution_backward_default_32[1]
        getitem_898 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        view_default_272 = torch.ops.aten.view.default(getitem_897, [1, 1024, 256]);  getitem_897 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(view_default_272, view_default_144, None, None, None, getitem_426, getitem_427, True, 1e-08, [True, False, False]);  view_default_272 = view_default_144 = getitem_426 = getitem_427 = None
        getitem_899 = native_batch_norm_backward_default_31[0]
        getitem_900 = native_batch_norm_backward_default_31[1]
        getitem_901 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        view_default_273 = torch.ops.aten.view.default(getitem_899, [1024, 256, 1, 1]);  getitem_899 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_896, torch.float32);  getitem_896 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_31, to_dtype_93);  le_scalar_31 = new_zeros_default_31 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_group_norm_backward_default_31 = torch.ops.aten.native_group_norm_backward.default(to_dtype_95, convolution_default_71, getitem_423, getitem_424, primals_133, 64, 256, 784, 32, [True, True, True]);  to_dtype_95 = convolution_default_71 = getitem_423 = getitem_424 = primals_133 = None
        getitem_902 = native_group_norm_backward_default_31[0]
        getitem_903 = native_group_norm_backward_default_31[1]
        getitem_904 = native_group_norm_backward_default_31[2];  native_group_norm_backward_default_31 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_902, relu__default_67, view_default_143, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_902 = view_default_143 = None
        getitem_905 = convolution_backward_default_33[0]
        getitem_906 = convolution_backward_default_33[1]
        getitem_907 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        view_default_274 = torch.ops.aten.view.default(getitem_906, [1, 256, 2304]);  getitem_906 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(view_default_274, view_default_142, None, None, None, getitem_420, getitem_421, True, 1e-08, [True, False, False]);  view_default_274 = view_default_142 = getitem_420 = getitem_421 = None
        getitem_908 = native_batch_norm_backward_default_32[0]
        getitem_909 = native_batch_norm_backward_default_32[1]
        getitem_910 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        view_default_275 = torch.ops.aten.view.default(getitem_908, [256, 256, 3, 3]);  getitem_908 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_905, torch.float32);  getitem_905 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_32, to_dtype_96);  le_scalar_32 = new_zeros_default_32 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_group_norm_backward_default_32 = torch.ops.aten.native_group_norm_backward.default(to_dtype_98, convolution_default_70, getitem_417, getitem_418, primals_131, 64, 256, 784, 32, [True, True, True]);  to_dtype_98 = convolution_default_70 = getitem_417 = getitem_418 = primals_131 = None
        getitem_911 = native_group_norm_backward_default_32[0]
        getitem_912 = native_group_norm_backward_default_32[1]
        getitem_913 = native_group_norm_backward_default_32[2];  native_group_norm_backward_default_32 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_911, relu__default_66, view_default_141, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_911 = view_default_141 = None
        getitem_914 = convolution_backward_default_34[0]
        getitem_915 = convolution_backward_default_34[1]
        getitem_916 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        view_default_276 = torch.ops.aten.view.default(getitem_915, [1, 256, 1024]);  getitem_915 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(view_default_276, view_default_140, None, None, None, getitem_414, getitem_415, True, 1e-08, [True, False, False]);  view_default_276 = view_default_140 = getitem_414 = getitem_415 = None
        getitem_917 = native_batch_norm_backward_default_33[0]
        getitem_918 = native_batch_norm_backward_default_33[1]
        getitem_919 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        view_default_277 = torch.ops.aten.view.default(getitem_917, [256, 1024, 1, 1]);  getitem_917 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_914, torch.float32);  getitem_914 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_33, to_dtype_99);  le_scalar_33 = new_zeros_default_33 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_group_norm_backward_default_33 = torch.ops.aten.native_group_norm_backward.default(to_dtype_101, add_tensor_21, getitem_411, getitem_412, primals_129, 64, 1024, 784, 32, [True, True, True]);  to_dtype_101 = add_tensor_21 = getitem_411 = getitem_412 = primals_129 = None
        getitem_920 = native_group_norm_backward_default_33[0]
        getitem_921 = native_group_norm_backward_default_33[1]
        getitem_922 = native_group_norm_backward_default_33[2];  native_group_norm_backward_default_33 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_42, getitem_920);  add_tensor_42 = getitem_920 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(add_tensor_43, relu__default_65, view_default_139, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_139 = None
        getitem_923 = convolution_backward_default_35[0]
        getitem_924 = convolution_backward_default_35[1]
        getitem_925 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        view_default_278 = torch.ops.aten.view.default(getitem_924, [1, 1024, 256]);  getitem_924 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(view_default_278, view_default_138, None, None, None, getitem_408, getitem_409, True, 1e-08, [True, False, False]);  view_default_278 = view_default_138 = getitem_408 = getitem_409 = None
        getitem_926 = native_batch_norm_backward_default_34[0]
        getitem_927 = native_batch_norm_backward_default_34[1]
        getitem_928 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        view_default_279 = torch.ops.aten.view.default(getitem_926, [1024, 256, 1, 1]);  getitem_926 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_923, torch.float32);  getitem_923 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_34, to_dtype_102);  le_scalar_34 = new_zeros_default_34 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_group_norm_backward_default_34 = torch.ops.aten.native_group_norm_backward.default(to_dtype_104, convolution_default_68, getitem_405, getitem_406, primals_124, 64, 256, 784, 32, [True, True, True]);  to_dtype_104 = convolution_default_68 = getitem_405 = getitem_406 = primals_124 = None
        getitem_929 = native_group_norm_backward_default_34[0]
        getitem_930 = native_group_norm_backward_default_34[1]
        getitem_931 = native_group_norm_backward_default_34[2];  native_group_norm_backward_default_34 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_929, relu__default_64, view_default_137, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_929 = view_default_137 = None
        getitem_932 = convolution_backward_default_36[0]
        getitem_933 = convolution_backward_default_36[1]
        getitem_934 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        view_default_280 = torch.ops.aten.view.default(getitem_933, [1, 256, 2304]);  getitem_933 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(view_default_280, view_default_136, None, None, None, getitem_402, getitem_403, True, 1e-08, [True, False, False]);  view_default_280 = view_default_136 = getitem_402 = getitem_403 = None
        getitem_935 = native_batch_norm_backward_default_35[0]
        getitem_936 = native_batch_norm_backward_default_35[1]
        getitem_937 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        view_default_281 = torch.ops.aten.view.default(getitem_935, [256, 256, 3, 3]);  getitem_935 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_932, torch.float32);  getitem_932 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_35, to_dtype_105);  le_scalar_35 = new_zeros_default_35 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_group_norm_backward_default_35 = torch.ops.aten.native_group_norm_backward.default(to_dtype_107, convolution_default_67, getitem_399, getitem_400, primals_122, 64, 256, 784, 32, [True, True, True]);  to_dtype_107 = convolution_default_67 = getitem_399 = getitem_400 = primals_122 = None
        getitem_938 = native_group_norm_backward_default_35[0]
        getitem_939 = native_group_norm_backward_default_35[1]
        getitem_940 = native_group_norm_backward_default_35[2];  native_group_norm_backward_default_35 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_938, relu__default_63, view_default_135, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_938 = view_default_135 = None
        getitem_941 = convolution_backward_default_37[0]
        getitem_942 = convolution_backward_default_37[1]
        getitem_943 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        view_default_282 = torch.ops.aten.view.default(getitem_942, [1, 256, 1024]);  getitem_942 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(view_default_282, view_default_134, None, None, None, getitem_396, getitem_397, True, 1e-08, [True, False, False]);  view_default_282 = view_default_134 = getitem_396 = getitem_397 = None
        getitem_944 = native_batch_norm_backward_default_36[0]
        getitem_945 = native_batch_norm_backward_default_36[1]
        getitem_946 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        view_default_283 = torch.ops.aten.view.default(getitem_944, [256, 1024, 1, 1]);  getitem_944 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_941, torch.float32);  getitem_941 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_36, to_dtype_108);  le_scalar_36 = new_zeros_default_36 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_group_norm_backward_default_36 = torch.ops.aten.native_group_norm_backward.default(to_dtype_110, add_tensor_20, getitem_393, getitem_394, primals_120, 64, 1024, 784, 32, [True, True, True]);  to_dtype_110 = add_tensor_20 = getitem_393 = getitem_394 = primals_120 = None
        getitem_947 = native_group_norm_backward_default_36[0]
        getitem_948 = native_group_norm_backward_default_36[1]
        getitem_949 = native_group_norm_backward_default_36[2];  native_group_norm_backward_default_36 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(add_tensor_43, getitem_947);  add_tensor_43 = getitem_947 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(add_tensor_44, relu__default_62, view_default_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_133 = None
        getitem_950 = convolution_backward_default_38[0]
        getitem_951 = convolution_backward_default_38[1]
        getitem_952 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        view_default_284 = torch.ops.aten.view.default(getitem_951, [1, 1024, 256]);  getitem_951 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(view_default_284, view_default_132, None, None, None, getitem_390, getitem_391, True, 1e-08, [True, False, False]);  view_default_284 = view_default_132 = getitem_390 = getitem_391 = None
        getitem_953 = native_batch_norm_backward_default_37[0]
        getitem_954 = native_batch_norm_backward_default_37[1]
        getitem_955 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        view_default_285 = torch.ops.aten.view.default(getitem_953, [1024, 256, 1, 1]);  getitem_953 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_950, torch.float32);  getitem_950 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_37, to_dtype_111);  le_scalar_37 = new_zeros_default_37 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_group_norm_backward_default_37 = torch.ops.aten.native_group_norm_backward.default(to_dtype_113, convolution_default_65, getitem_387, getitem_388, primals_115, 64, 256, 784, 32, [True, True, True]);  to_dtype_113 = convolution_default_65 = getitem_387 = getitem_388 = primals_115 = None
        getitem_956 = native_group_norm_backward_default_37[0]
        getitem_957 = native_group_norm_backward_default_37[1]
        getitem_958 = native_group_norm_backward_default_37[2];  native_group_norm_backward_default_37 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_956, relu__default_61, view_default_131, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_956 = view_default_131 = None
        getitem_959 = convolution_backward_default_39[0]
        getitem_960 = convolution_backward_default_39[1]
        getitem_961 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        view_default_286 = torch.ops.aten.view.default(getitem_960, [1, 256, 2304]);  getitem_960 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(view_default_286, view_default_130, None, None, None, getitem_384, getitem_385, True, 1e-08, [True, False, False]);  view_default_286 = view_default_130 = getitem_384 = getitem_385 = None
        getitem_962 = native_batch_norm_backward_default_38[0]
        getitem_963 = native_batch_norm_backward_default_38[1]
        getitem_964 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        view_default_287 = torch.ops.aten.view.default(getitem_962, [256, 256, 3, 3]);  getitem_962 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_959, torch.float32);  getitem_959 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_38, to_dtype_114);  le_scalar_38 = new_zeros_default_38 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_group_norm_backward_default_38 = torch.ops.aten.native_group_norm_backward.default(to_dtype_116, convolution_default_64, getitem_381, getitem_382, primals_113, 64, 256, 784, 32, [True, True, True]);  to_dtype_116 = convolution_default_64 = getitem_381 = getitem_382 = primals_113 = None
        getitem_965 = native_group_norm_backward_default_38[0]
        getitem_966 = native_group_norm_backward_default_38[1]
        getitem_967 = native_group_norm_backward_default_38[2];  native_group_norm_backward_default_38 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_965, relu__default_60, view_default_129, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_965 = view_default_129 = None
        getitem_968 = convolution_backward_default_40[0]
        getitem_969 = convolution_backward_default_40[1]
        getitem_970 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        view_default_288 = torch.ops.aten.view.default(getitem_969, [1, 256, 1024]);  getitem_969 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(view_default_288, view_default_128, None, None, None, getitem_378, getitem_379, True, 1e-08, [True, False, False]);  view_default_288 = view_default_128 = getitem_378 = getitem_379 = None
        getitem_971 = native_batch_norm_backward_default_39[0]
        getitem_972 = native_batch_norm_backward_default_39[1]
        getitem_973 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        view_default_289 = torch.ops.aten.view.default(getitem_971, [256, 1024, 1, 1]);  getitem_971 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_968, torch.float32);  getitem_968 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_39, to_dtype_117);  le_scalar_39 = new_zeros_default_39 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_group_norm_backward_default_39 = torch.ops.aten.native_group_norm_backward.default(to_dtype_119, add_tensor_19, getitem_375, getitem_376, primals_111, 64, 1024, 784, 32, [True, True, True]);  to_dtype_119 = add_tensor_19 = getitem_375 = getitem_376 = primals_111 = None
        getitem_974 = native_group_norm_backward_default_39[0]
        getitem_975 = native_group_norm_backward_default_39[1]
        getitem_976 = native_group_norm_backward_default_39[2];  native_group_norm_backward_default_39 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, getitem_974);  add_tensor_44 = getitem_974 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(add_tensor_45, relu__default_59, view_default_127, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_127 = None
        getitem_977 = convolution_backward_default_41[0]
        getitem_978 = convolution_backward_default_41[1]
        getitem_979 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        view_default_290 = torch.ops.aten.view.default(getitem_978, [1, 1024, 256]);  getitem_978 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(view_default_290, view_default_126, None, None, None, getitem_372, getitem_373, True, 1e-08, [True, False, False]);  view_default_290 = view_default_126 = getitem_372 = getitem_373 = None
        getitem_980 = native_batch_norm_backward_default_40[0]
        getitem_981 = native_batch_norm_backward_default_40[1]
        getitem_982 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        view_default_291 = torch.ops.aten.view.default(getitem_980, [1024, 256, 1, 1]);  getitem_980 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_977, torch.float32);  getitem_977 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_40, to_dtype_120);  le_scalar_40 = new_zeros_default_40 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_group_norm_backward_default_40 = torch.ops.aten.native_group_norm_backward.default(to_dtype_122, convolution_default_62, getitem_369, getitem_370, primals_106, 64, 256, 784, 32, [True, True, True]);  to_dtype_122 = convolution_default_62 = getitem_369 = getitem_370 = primals_106 = None
        getitem_983 = native_group_norm_backward_default_40[0]
        getitem_984 = native_group_norm_backward_default_40[1]
        getitem_985 = native_group_norm_backward_default_40[2];  native_group_norm_backward_default_40 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_983, relu__default_58, view_default_125, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_983 = view_default_125 = None
        getitem_986 = convolution_backward_default_42[0]
        getitem_987 = convolution_backward_default_42[1]
        getitem_988 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        view_default_292 = torch.ops.aten.view.default(getitem_987, [1, 256, 2304]);  getitem_987 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(view_default_292, view_default_124, None, None, None, getitem_366, getitem_367, True, 1e-08, [True, False, False]);  view_default_292 = view_default_124 = getitem_366 = getitem_367 = None
        getitem_989 = native_batch_norm_backward_default_41[0]
        getitem_990 = native_batch_norm_backward_default_41[1]
        getitem_991 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        view_default_293 = torch.ops.aten.view.default(getitem_989, [256, 256, 3, 3]);  getitem_989 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_986, torch.float32);  getitem_986 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_41, to_dtype_123);  le_scalar_41 = new_zeros_default_41 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_group_norm_backward_default_41 = torch.ops.aten.native_group_norm_backward.default(to_dtype_125, convolution_default_61, getitem_363, getitem_364, primals_104, 64, 256, 784, 32, [True, True, True]);  to_dtype_125 = convolution_default_61 = getitem_363 = getitem_364 = primals_104 = None
        getitem_992 = native_group_norm_backward_default_41[0]
        getitem_993 = native_group_norm_backward_default_41[1]
        getitem_994 = native_group_norm_backward_default_41[2];  native_group_norm_backward_default_41 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_992, relu__default_57, view_default_123, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_992 = view_default_123 = None
        getitem_995 = convolution_backward_default_43[0]
        getitem_996 = convolution_backward_default_43[1]
        getitem_997 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        view_default_294 = torch.ops.aten.view.default(getitem_996, [1, 256, 1024]);  getitem_996 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(view_default_294, view_default_122, None, None, None, getitem_360, getitem_361, True, 1e-08, [True, False, False]);  view_default_294 = view_default_122 = getitem_360 = getitem_361 = None
        getitem_998 = native_batch_norm_backward_default_42[0]
        getitem_999 = native_batch_norm_backward_default_42[1]
        getitem_1000 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        view_default_295 = torch.ops.aten.view.default(getitem_998, [256, 1024, 1, 1]);  getitem_998 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_995, torch.float32);  getitem_995 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_42, to_dtype_126);  le_scalar_42 = new_zeros_default_42 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_group_norm_backward_default_42 = torch.ops.aten.native_group_norm_backward.default(to_dtype_128, add_tensor_18, getitem_357, getitem_358, primals_102, 64, 1024, 784, 32, [True, True, True]);  to_dtype_128 = add_tensor_18 = getitem_357 = getitem_358 = primals_102 = None
        getitem_1001 = native_group_norm_backward_default_42[0]
        getitem_1002 = native_group_norm_backward_default_42[1]
        getitem_1003 = native_group_norm_backward_default_42[2];  native_group_norm_backward_default_42 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, getitem_1001);  add_tensor_45 = getitem_1001 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(add_tensor_46, relu__default_56, view_default_121, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_121 = None
        getitem_1004 = convolution_backward_default_44[0]
        getitem_1005 = convolution_backward_default_44[1]
        getitem_1006 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        view_default_296 = torch.ops.aten.view.default(getitem_1005, [1, 1024, 256]);  getitem_1005 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(view_default_296, view_default_120, None, None, None, getitem_354, getitem_355, True, 1e-08, [True, False, False]);  view_default_296 = view_default_120 = getitem_354 = getitem_355 = None
        getitem_1007 = native_batch_norm_backward_default_43[0]
        getitem_1008 = native_batch_norm_backward_default_43[1]
        getitem_1009 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        view_default_297 = torch.ops.aten.view.default(getitem_1007, [1024, 256, 1, 1]);  getitem_1007 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_1004, torch.float32);  getitem_1004 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_43, to_dtype_129);  le_scalar_43 = new_zeros_default_43 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_group_norm_backward_default_43 = torch.ops.aten.native_group_norm_backward.default(to_dtype_131, convolution_default_59, getitem_351, getitem_352, primals_97, 64, 256, 784, 32, [True, True, True]);  to_dtype_131 = convolution_default_59 = getitem_351 = getitem_352 = primals_97 = None
        getitem_1010 = native_group_norm_backward_default_43[0]
        getitem_1011 = native_group_norm_backward_default_43[1]
        getitem_1012 = native_group_norm_backward_default_43[2];  native_group_norm_backward_default_43 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_1010, relu__default_55, view_default_119, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1010 = view_default_119 = None
        getitem_1013 = convolution_backward_default_45[0]
        getitem_1014 = convolution_backward_default_45[1]
        getitem_1015 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        view_default_298 = torch.ops.aten.view.default(getitem_1014, [1, 256, 2304]);  getitem_1014 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(view_default_298, view_default_118, None, None, None, getitem_348, getitem_349, True, 1e-08, [True, False, False]);  view_default_298 = view_default_118 = getitem_348 = getitem_349 = None
        getitem_1016 = native_batch_norm_backward_default_44[0]
        getitem_1017 = native_batch_norm_backward_default_44[1]
        getitem_1018 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        view_default_299 = torch.ops.aten.view.default(getitem_1016, [256, 256, 3, 3]);  getitem_1016 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_1013, torch.float32);  getitem_1013 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_44, to_dtype_132);  le_scalar_44 = new_zeros_default_44 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_group_norm_backward_default_44 = torch.ops.aten.native_group_norm_backward.default(to_dtype_134, convolution_default_58, getitem_345, getitem_346, primals_95, 64, 256, 784, 32, [True, True, True]);  to_dtype_134 = convolution_default_58 = getitem_345 = getitem_346 = primals_95 = None
        getitem_1019 = native_group_norm_backward_default_44[0]
        getitem_1020 = native_group_norm_backward_default_44[1]
        getitem_1021 = native_group_norm_backward_default_44[2];  native_group_norm_backward_default_44 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_1019, relu__default_54, view_default_117, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1019 = view_default_117 = None
        getitem_1022 = convolution_backward_default_46[0]
        getitem_1023 = convolution_backward_default_46[1]
        getitem_1024 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        view_default_300 = torch.ops.aten.view.default(getitem_1023, [1, 256, 1024]);  getitem_1023 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(view_default_300, view_default_116, None, None, None, getitem_342, getitem_343, True, 1e-08, [True, False, False]);  view_default_300 = view_default_116 = getitem_342 = getitem_343 = None
        getitem_1025 = native_batch_norm_backward_default_45[0]
        getitem_1026 = native_batch_norm_backward_default_45[1]
        getitem_1027 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        view_default_301 = torch.ops.aten.view.default(getitem_1025, [256, 1024, 1, 1]);  getitem_1025 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_1022, torch.float32);  getitem_1022 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_45, to_dtype_135);  le_scalar_45 = new_zeros_default_45 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_group_norm_backward_default_45 = torch.ops.aten.native_group_norm_backward.default(to_dtype_137, add_tensor_17, getitem_339, getitem_340, primals_93, 64, 1024, 784, 32, [True, True, True]);  to_dtype_137 = add_tensor_17 = getitem_339 = getitem_340 = primals_93 = None
        getitem_1028 = native_group_norm_backward_default_45[0]
        getitem_1029 = native_group_norm_backward_default_45[1]
        getitem_1030 = native_group_norm_backward_default_45[2];  native_group_norm_backward_default_45 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_46, getitem_1028);  add_tensor_46 = getitem_1028 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(add_tensor_47, relu__default_53, view_default_115, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_115 = None
        getitem_1031 = convolution_backward_default_47[0]
        getitem_1032 = convolution_backward_default_47[1]
        getitem_1033 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        view_default_302 = torch.ops.aten.view.default(getitem_1032, [1, 1024, 256]);  getitem_1032 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(view_default_302, view_default_114, None, None, None, getitem_336, getitem_337, True, 1e-08, [True, False, False]);  view_default_302 = view_default_114 = getitem_336 = getitem_337 = None
        getitem_1034 = native_batch_norm_backward_default_46[0]
        getitem_1035 = native_batch_norm_backward_default_46[1]
        getitem_1036 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        view_default_303 = torch.ops.aten.view.default(getitem_1034, [1024, 256, 1, 1]);  getitem_1034 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_1031, torch.float32);  getitem_1031 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_46, to_dtype_138);  le_scalar_46 = new_zeros_default_46 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_group_norm_backward_default_46 = torch.ops.aten.native_group_norm_backward.default(to_dtype_140, convolution_default_56, getitem_333, getitem_334, primals_88, 64, 256, 784, 32, [True, True, True]);  to_dtype_140 = convolution_default_56 = getitem_333 = getitem_334 = primals_88 = None
        getitem_1037 = native_group_norm_backward_default_46[0]
        getitem_1038 = native_group_norm_backward_default_46[1]
        getitem_1039 = native_group_norm_backward_default_46[2];  native_group_norm_backward_default_46 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_1037, relu__default_52, view_default_113, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1037 = view_default_113 = None
        getitem_1040 = convolution_backward_default_48[0]
        getitem_1041 = convolution_backward_default_48[1]
        getitem_1042 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        view_default_304 = torch.ops.aten.view.default(getitem_1041, [1, 256, 2304]);  getitem_1041 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(view_default_304, view_default_112, None, None, None, getitem_330, getitem_331, True, 1e-08, [True, False, False]);  view_default_304 = view_default_112 = getitem_330 = getitem_331 = None
        getitem_1043 = native_batch_norm_backward_default_47[0]
        getitem_1044 = native_batch_norm_backward_default_47[1]
        getitem_1045 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        view_default_305 = torch.ops.aten.view.default(getitem_1043, [256, 256, 3, 3]);  getitem_1043 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_1040, torch.float32);  getitem_1040 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_47, to_dtype_141);  le_scalar_47 = new_zeros_default_47 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_group_norm_backward_default_47 = torch.ops.aten.native_group_norm_backward.default(to_dtype_143, convolution_default_55, getitem_327, getitem_328, primals_86, 64, 256, 784, 32, [True, True, True]);  to_dtype_143 = convolution_default_55 = getitem_327 = getitem_328 = primals_86 = None
        getitem_1046 = native_group_norm_backward_default_47[0]
        getitem_1047 = native_group_norm_backward_default_47[1]
        getitem_1048 = native_group_norm_backward_default_47[2];  native_group_norm_backward_default_47 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_1046, relu__default_51, view_default_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1046 = view_default_111 = None
        getitem_1049 = convolution_backward_default_49[0]
        getitem_1050 = convolution_backward_default_49[1]
        getitem_1051 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        view_default_306 = torch.ops.aten.view.default(getitem_1050, [1, 256, 1024]);  getitem_1050 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(view_default_306, view_default_110, None, None, None, getitem_324, getitem_325, True, 1e-08, [True, False, False]);  view_default_306 = view_default_110 = getitem_324 = getitem_325 = None
        getitem_1052 = native_batch_norm_backward_default_48[0]
        getitem_1053 = native_batch_norm_backward_default_48[1]
        getitem_1054 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        view_default_307 = torch.ops.aten.view.default(getitem_1052, [256, 1024, 1, 1]);  getitem_1052 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_1049, torch.float32);  getitem_1049 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_48, to_dtype_144);  le_scalar_48 = new_zeros_default_48 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_group_norm_backward_default_48 = torch.ops.aten.native_group_norm_backward.default(to_dtype_146, add_tensor_16, getitem_321, getitem_322, primals_84, 64, 1024, 784, 32, [True, True, True]);  to_dtype_146 = add_tensor_16 = getitem_321 = getitem_322 = primals_84 = None
        getitem_1055 = native_group_norm_backward_default_48[0]
        getitem_1056 = native_group_norm_backward_default_48[1]
        getitem_1057 = native_group_norm_backward_default_48[2];  native_group_norm_backward_default_48 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, getitem_1055);  add_tensor_47 = getitem_1055 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(add_tensor_48, relu__default_50, view_default_109, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_109 = None
        getitem_1058 = convolution_backward_default_50[0]
        getitem_1059 = convolution_backward_default_50[1]
        getitem_1060 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        view_default_308 = torch.ops.aten.view.default(getitem_1059, [1, 1024, 256]);  getitem_1059 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(view_default_308, view_default_108, None, None, None, getitem_318, getitem_319, True, 1e-08, [True, False, False]);  view_default_308 = view_default_108 = getitem_318 = getitem_319 = None
        getitem_1061 = native_batch_norm_backward_default_49[0]
        getitem_1062 = native_batch_norm_backward_default_49[1]
        getitem_1063 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        view_default_309 = torch.ops.aten.view.default(getitem_1061, [1024, 256, 1, 1]);  getitem_1061 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_1058, torch.float32);  getitem_1058 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_49, to_dtype_147);  le_scalar_49 = new_zeros_default_49 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_group_norm_backward_default_49 = torch.ops.aten.native_group_norm_backward.default(to_dtype_149, convolution_default_53, getitem_315, getitem_316, primals_277, 64, 256, 784, 32, [True, True, True]);  to_dtype_149 = convolution_default_53 = getitem_315 = getitem_316 = primals_277 = None
        getitem_1064 = native_group_norm_backward_default_49[0]
        getitem_1065 = native_group_norm_backward_default_49[1]
        getitem_1066 = native_group_norm_backward_default_49[2];  native_group_norm_backward_default_49 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_1064, relu__default_49, view_default_107, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1064 = view_default_107 = None
        getitem_1067 = convolution_backward_default_51[0]
        getitem_1068 = convolution_backward_default_51[1]
        getitem_1069 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        view_default_310 = torch.ops.aten.view.default(getitem_1068, [1, 256, 2304]);  getitem_1068 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(view_default_310, view_default_106, None, None, None, getitem_312, getitem_313, True, 1e-08, [True, False, False]);  view_default_310 = view_default_106 = getitem_312 = getitem_313 = None
        getitem_1070 = native_batch_norm_backward_default_50[0]
        getitem_1071 = native_batch_norm_backward_default_50[1]
        getitem_1072 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        view_default_311 = torch.ops.aten.view.default(getitem_1070, [256, 256, 3, 3]);  getitem_1070 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_1067, torch.float32);  getitem_1067 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_50, to_dtype_150);  le_scalar_50 = new_zeros_default_50 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_group_norm_backward_default_50 = torch.ops.aten.native_group_norm_backward.default(to_dtype_152, convolution_default_52, getitem_309, getitem_310, primals_275, 64, 256, 784, 32, [True, True, True]);  to_dtype_152 = convolution_default_52 = getitem_309 = getitem_310 = primals_275 = None
        getitem_1073 = native_group_norm_backward_default_50[0]
        getitem_1074 = native_group_norm_backward_default_50[1]
        getitem_1075 = native_group_norm_backward_default_50[2];  native_group_norm_backward_default_50 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_1073, relu__default_48, view_default_105, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1073 = view_default_105 = None
        getitem_1076 = convolution_backward_default_52[0]
        getitem_1077 = convolution_backward_default_52[1]
        getitem_1078 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        view_default_312 = torch.ops.aten.view.default(getitem_1077, [1, 256, 1024]);  getitem_1077 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(view_default_312, view_default_104, None, None, None, getitem_306, getitem_307, True, 1e-08, [True, False, False]);  view_default_312 = view_default_104 = getitem_306 = getitem_307 = None
        getitem_1079 = native_batch_norm_backward_default_51[0]
        getitem_1080 = native_batch_norm_backward_default_51[1]
        getitem_1081 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        view_default_313 = torch.ops.aten.view.default(getitem_1079, [256, 1024, 1, 1]);  getitem_1079 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_1076, torch.float32);  getitem_1076 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_51, to_dtype_153);  le_scalar_51 = new_zeros_default_51 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_group_norm_backward_default_51 = torch.ops.aten.native_group_norm_backward.default(to_dtype_155, add_tensor_15, getitem_303, getitem_304, primals_273, 64, 1024, 784, 32, [True, True, True]);  to_dtype_155 = add_tensor_15 = getitem_303 = getitem_304 = primals_273 = None
        getitem_1082 = native_group_norm_backward_default_51[0]
        getitem_1083 = native_group_norm_backward_default_51[1]
        getitem_1084 = native_group_norm_backward_default_51[2];  native_group_norm_backward_default_51 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, getitem_1082);  add_tensor_48 = getitem_1082 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(add_tensor_49, relu__default_47, view_default_103, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_103 = None
        getitem_1085 = convolution_backward_default_53[0]
        getitem_1086 = convolution_backward_default_53[1]
        getitem_1087 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        view_default_314 = torch.ops.aten.view.default(getitem_1086, [1, 1024, 256]);  getitem_1086 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(view_default_314, view_default_102, None, None, None, getitem_300, getitem_301, True, 1e-08, [True, False, False]);  view_default_314 = view_default_102 = getitem_300 = getitem_301 = None
        getitem_1088 = native_batch_norm_backward_default_52[0]
        getitem_1089 = native_batch_norm_backward_default_52[1]
        getitem_1090 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        view_default_315 = torch.ops.aten.view.default(getitem_1088, [1024, 256, 1, 1]);  getitem_1088 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_1085, torch.float32);  getitem_1085 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_52, to_dtype_156);  le_scalar_52 = new_zeros_default_52 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_group_norm_backward_default_52 = torch.ops.aten.native_group_norm_backward.default(to_dtype_158, convolution_default_50, getitem_297, getitem_298, primals_268, 64, 256, 784, 32, [True, True, True]);  to_dtype_158 = convolution_default_50 = getitem_297 = getitem_298 = primals_268 = None
        getitem_1091 = native_group_norm_backward_default_52[0]
        getitem_1092 = native_group_norm_backward_default_52[1]
        getitem_1093 = native_group_norm_backward_default_52[2];  native_group_norm_backward_default_52 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_1091, relu__default_46, view_default_101, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1091 = view_default_101 = None
        getitem_1094 = convolution_backward_default_54[0]
        getitem_1095 = convolution_backward_default_54[1]
        getitem_1096 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        view_default_316 = torch.ops.aten.view.default(getitem_1095, [1, 256, 2304]);  getitem_1095 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(view_default_316, view_default_100, None, None, None, getitem_294, getitem_295, True, 1e-08, [True, False, False]);  view_default_316 = view_default_100 = getitem_294 = getitem_295 = None
        getitem_1097 = native_batch_norm_backward_default_53[0]
        getitem_1098 = native_batch_norm_backward_default_53[1]
        getitem_1099 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        view_default_317 = torch.ops.aten.view.default(getitem_1097, [256, 256, 3, 3]);  getitem_1097 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_1094, torch.float32);  getitem_1094 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_53, to_dtype_159);  le_scalar_53 = new_zeros_default_53 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_group_norm_backward_default_53 = torch.ops.aten.native_group_norm_backward.default(to_dtype_161, convolution_default_49, getitem_291, getitem_292, primals_266, 64, 256, 784, 32, [True, True, True]);  to_dtype_161 = convolution_default_49 = getitem_291 = getitem_292 = primals_266 = None
        getitem_1100 = native_group_norm_backward_default_53[0]
        getitem_1101 = native_group_norm_backward_default_53[1]
        getitem_1102 = native_group_norm_backward_default_53[2];  native_group_norm_backward_default_53 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_1100, relu__default_45, view_default_99, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1100 = view_default_99 = None
        getitem_1103 = convolution_backward_default_55[0]
        getitem_1104 = convolution_backward_default_55[1]
        getitem_1105 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        view_default_318 = torch.ops.aten.view.default(getitem_1104, [1, 256, 1024]);  getitem_1104 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(view_default_318, view_default_98, None, None, None, getitem_288, getitem_289, True, 1e-08, [True, False, False]);  view_default_318 = view_default_98 = getitem_288 = getitem_289 = None
        getitem_1106 = native_batch_norm_backward_default_54[0]
        getitem_1107 = native_batch_norm_backward_default_54[1]
        getitem_1108 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        view_default_319 = torch.ops.aten.view.default(getitem_1106, [256, 1024, 1, 1]);  getitem_1106 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_1103, torch.float32);  getitem_1103 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_54, to_dtype_162);  le_scalar_54 = new_zeros_default_54 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_group_norm_backward_default_54 = torch.ops.aten.native_group_norm_backward.default(to_dtype_164, add_tensor_14, getitem_285, getitem_286, primals_264, 64, 1024, 784, 32, [True, True, True]);  to_dtype_164 = add_tensor_14 = getitem_285 = getitem_286 = primals_264 = None
        getitem_1109 = native_group_norm_backward_default_54[0]
        getitem_1110 = native_group_norm_backward_default_54[1]
        getitem_1111 = native_group_norm_backward_default_54[2];  native_group_norm_backward_default_54 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(add_tensor_49, getitem_1109);  add_tensor_49 = getitem_1109 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(add_tensor_50, relu__default_44, view_default_97, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_97 = None
        getitem_1112 = convolution_backward_default_56[0]
        getitem_1113 = convolution_backward_default_56[1]
        getitem_1114 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        view_default_320 = torch.ops.aten.view.default(getitem_1113, [1, 1024, 256]);  getitem_1113 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(view_default_320, view_default_96, None, None, None, getitem_282, getitem_283, True, 1e-08, [True, False, False]);  view_default_320 = view_default_96 = getitem_282 = getitem_283 = None
        getitem_1115 = native_batch_norm_backward_default_55[0]
        getitem_1116 = native_batch_norm_backward_default_55[1]
        getitem_1117 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        view_default_321 = torch.ops.aten.view.default(getitem_1115, [1024, 256, 1, 1]);  getitem_1115 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_1112, torch.float32);  getitem_1112 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_55, to_dtype_165);  le_scalar_55 = new_zeros_default_55 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_group_norm_backward_default_55 = torch.ops.aten.native_group_norm_backward.default(to_dtype_167, convolution_default_47, getitem_279, getitem_280, primals_259, 64, 256, 784, 32, [True, True, True]);  to_dtype_167 = convolution_default_47 = getitem_279 = getitem_280 = primals_259 = None
        getitem_1118 = native_group_norm_backward_default_55[0]
        getitem_1119 = native_group_norm_backward_default_55[1]
        getitem_1120 = native_group_norm_backward_default_55[2];  native_group_norm_backward_default_55 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_1118, relu__default_43, view_default_95, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1118 = view_default_95 = None
        getitem_1121 = convolution_backward_default_57[0]
        getitem_1122 = convolution_backward_default_57[1]
        getitem_1123 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        view_default_322 = torch.ops.aten.view.default(getitem_1122, [1, 256, 2304]);  getitem_1122 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(view_default_322, view_default_94, None, None, None, getitem_276, getitem_277, True, 1e-08, [True, False, False]);  view_default_322 = view_default_94 = getitem_276 = getitem_277 = None
        getitem_1124 = native_batch_norm_backward_default_56[0]
        getitem_1125 = native_batch_norm_backward_default_56[1]
        getitem_1126 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        view_default_323 = torch.ops.aten.view.default(getitem_1124, [256, 256, 3, 3]);  getitem_1124 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_1121, torch.float32);  getitem_1121 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_56, to_dtype_168);  le_scalar_56 = new_zeros_default_56 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_group_norm_backward_default_56 = torch.ops.aten.native_group_norm_backward.default(to_dtype_170, convolution_default_46, getitem_273, getitem_274, primals_257, 64, 256, 784, 32, [True, True, True]);  to_dtype_170 = convolution_default_46 = getitem_273 = getitem_274 = primals_257 = None
        getitem_1127 = native_group_norm_backward_default_56[0]
        getitem_1128 = native_group_norm_backward_default_56[1]
        getitem_1129 = native_group_norm_backward_default_56[2];  native_group_norm_backward_default_56 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_1127, relu__default_42, view_default_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1127 = view_default_93 = None
        getitem_1130 = convolution_backward_default_58[0]
        getitem_1131 = convolution_backward_default_58[1]
        getitem_1132 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        view_default_324 = torch.ops.aten.view.default(getitem_1131, [1, 256, 1024]);  getitem_1131 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(view_default_324, view_default_92, None, None, None, getitem_270, getitem_271, True, 1e-08, [True, False, False]);  view_default_324 = view_default_92 = getitem_270 = getitem_271 = None
        getitem_1133 = native_batch_norm_backward_default_57[0]
        getitem_1134 = native_batch_norm_backward_default_57[1]
        getitem_1135 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        view_default_325 = torch.ops.aten.view.default(getitem_1133, [256, 1024, 1, 1]);  getitem_1133 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_1130, torch.float32);  getitem_1130 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_57, to_dtype_171);  le_scalar_57 = new_zeros_default_57 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_group_norm_backward_default_57 = torch.ops.aten.native_group_norm_backward.default(to_dtype_173, add_tensor_13, getitem_267, getitem_268, primals_255, 64, 1024, 784, 32, [True, True, True]);  to_dtype_173 = add_tensor_13 = getitem_267 = getitem_268 = primals_255 = None
        getitem_1136 = native_group_norm_backward_default_57[0]
        getitem_1137 = native_group_norm_backward_default_57[1]
        getitem_1138 = native_group_norm_backward_default_57[2];  native_group_norm_backward_default_57 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_50, getitem_1136);  add_tensor_50 = getitem_1136 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(add_tensor_51, relu__default_41, view_default_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_91 = None
        getitem_1139 = convolution_backward_default_59[0]
        getitem_1140 = convolution_backward_default_59[1]
        getitem_1141 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        view_default_326 = torch.ops.aten.view.default(getitem_1140, [1, 1024, 256]);  getitem_1140 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(view_default_326, view_default_90, None, None, None, getitem_264, getitem_265, True, 1e-08, [True, False, False]);  view_default_326 = view_default_90 = getitem_264 = getitem_265 = None
        getitem_1142 = native_batch_norm_backward_default_58[0]
        getitem_1143 = native_batch_norm_backward_default_58[1]
        getitem_1144 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        view_default_327 = torch.ops.aten.view.default(getitem_1142, [1024, 256, 1, 1]);  getitem_1142 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_1139, torch.float32);  getitem_1139 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_58, to_dtype_174);  le_scalar_58 = new_zeros_default_58 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_group_norm_backward_default_58 = torch.ops.aten.native_group_norm_backward.default(to_dtype_176, convolution_default_44, getitem_261, getitem_262, primals_250, 64, 256, 784, 32, [True, True, True]);  to_dtype_176 = convolution_default_44 = getitem_261 = getitem_262 = primals_250 = None
        getitem_1145 = native_group_norm_backward_default_58[0]
        getitem_1146 = native_group_norm_backward_default_58[1]
        getitem_1147 = native_group_norm_backward_default_58[2];  native_group_norm_backward_default_58 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_1145, relu__default_40, view_default_89, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1145 = view_default_89 = None
        getitem_1148 = convolution_backward_default_60[0]
        getitem_1149 = convolution_backward_default_60[1]
        getitem_1150 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        view_default_328 = torch.ops.aten.view.default(getitem_1149, [1, 256, 2304]);  getitem_1149 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(view_default_328, view_default_88, None, None, None, getitem_258, getitem_259, True, 1e-08, [True, False, False]);  view_default_328 = view_default_88 = getitem_258 = getitem_259 = None
        getitem_1151 = native_batch_norm_backward_default_59[0]
        getitem_1152 = native_batch_norm_backward_default_59[1]
        getitem_1153 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        view_default_329 = torch.ops.aten.view.default(getitem_1151, [256, 256, 3, 3]);  getitem_1151 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_1148, torch.float32);  getitem_1148 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_59, to_dtype_177);  le_scalar_59 = new_zeros_default_59 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_group_norm_backward_default_59 = torch.ops.aten.native_group_norm_backward.default(to_dtype_179, convolution_default_43, getitem_255, getitem_256, primals_248, 64, 256, 784, 32, [True, True, True]);  to_dtype_179 = convolution_default_43 = getitem_255 = getitem_256 = primals_248 = None
        getitem_1154 = native_group_norm_backward_default_59[0]
        getitem_1155 = native_group_norm_backward_default_59[1]
        getitem_1156 = native_group_norm_backward_default_59[2];  native_group_norm_backward_default_59 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_1154, relu__default_39, view_default_87, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1154 = view_default_87 = None
        getitem_1157 = convolution_backward_default_61[0]
        getitem_1158 = convolution_backward_default_61[1]
        getitem_1159 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        view_default_330 = torch.ops.aten.view.default(getitem_1158, [1, 256, 1024]);  getitem_1158 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(view_default_330, view_default_86, None, None, None, getitem_252, getitem_253, True, 1e-08, [True, False, False]);  view_default_330 = view_default_86 = getitem_252 = getitem_253 = None
        getitem_1160 = native_batch_norm_backward_default_60[0]
        getitem_1161 = native_batch_norm_backward_default_60[1]
        getitem_1162 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        view_default_331 = torch.ops.aten.view.default(getitem_1160, [256, 1024, 1, 1]);  getitem_1160 = None
        to_dtype_180 = torch.ops.aten.to.dtype(getitem_1157, torch.float32);  getitem_1157 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_60, to_dtype_180);  le_scalar_60 = new_zeros_default_60 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_group_norm_backward_default_60 = torch.ops.aten.native_group_norm_backward.default(to_dtype_182, add_tensor_12, getitem_249, getitem_250, primals_246, 64, 1024, 784, 32, [True, True, True]);  to_dtype_182 = add_tensor_12 = getitem_249 = getitem_250 = primals_246 = None
        getitem_1163 = native_group_norm_backward_default_60[0]
        getitem_1164 = native_group_norm_backward_default_60[1]
        getitem_1165 = native_group_norm_backward_default_60[2];  native_group_norm_backward_default_60 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, getitem_1163);  add_tensor_51 = getitem_1163 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(add_tensor_52, relu__default_38, view_default_85, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_85 = None
        getitem_1166 = convolution_backward_default_62[0]
        getitem_1167 = convolution_backward_default_62[1]
        getitem_1168 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        view_default_332 = torch.ops.aten.view.default(getitem_1167, [1, 1024, 256]);  getitem_1167 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(view_default_332, view_default_84, None, None, None, getitem_246, getitem_247, True, 1e-08, [True, False, False]);  view_default_332 = view_default_84 = getitem_246 = getitem_247 = None
        getitem_1169 = native_batch_norm_backward_default_61[0]
        getitem_1170 = native_batch_norm_backward_default_61[1]
        getitem_1171 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        view_default_333 = torch.ops.aten.view.default(getitem_1169, [1024, 256, 1, 1]);  getitem_1169 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_1166, torch.float32);  getitem_1166 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_61, to_dtype_183);  le_scalar_61 = new_zeros_default_61 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_group_norm_backward_default_61 = torch.ops.aten.native_group_norm_backward.default(to_dtype_185, convolution_default_41, getitem_243, getitem_244, primals_241, 64, 256, 784, 32, [True, True, True]);  to_dtype_185 = convolution_default_41 = getitem_243 = getitem_244 = primals_241 = None
        getitem_1172 = native_group_norm_backward_default_61[0]
        getitem_1173 = native_group_norm_backward_default_61[1]
        getitem_1174 = native_group_norm_backward_default_61[2];  native_group_norm_backward_default_61 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_1172, relu__default_37, view_default_83, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1172 = view_default_83 = None
        getitem_1175 = convolution_backward_default_63[0]
        getitem_1176 = convolution_backward_default_63[1]
        getitem_1177 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        view_default_334 = torch.ops.aten.view.default(getitem_1176, [1, 256, 2304]);  getitem_1176 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(view_default_334, view_default_82, None, None, None, getitem_240, getitem_241, True, 1e-08, [True, False, False]);  view_default_334 = view_default_82 = getitem_240 = getitem_241 = None
        getitem_1178 = native_batch_norm_backward_default_62[0]
        getitem_1179 = native_batch_norm_backward_default_62[1]
        getitem_1180 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        view_default_335 = torch.ops.aten.view.default(getitem_1178, [256, 256, 3, 3]);  getitem_1178 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_1175, torch.float32);  getitem_1175 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_62, to_dtype_186);  le_scalar_62 = new_zeros_default_62 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_group_norm_backward_default_62 = torch.ops.aten.native_group_norm_backward.default(to_dtype_188, convolution_default_40, getitem_237, getitem_238, primals_239, 64, 256, 784, 32, [True, True, True]);  to_dtype_188 = convolution_default_40 = getitem_237 = getitem_238 = primals_239 = None
        getitem_1181 = native_group_norm_backward_default_62[0]
        getitem_1182 = native_group_norm_backward_default_62[1]
        getitem_1183 = native_group_norm_backward_default_62[2];  native_group_norm_backward_default_62 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_1181, relu__default_36, view_default_81, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1181 = view_default_81 = None
        getitem_1184 = convolution_backward_default_64[0]
        getitem_1185 = convolution_backward_default_64[1]
        getitem_1186 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        view_default_336 = torch.ops.aten.view.default(getitem_1185, [1, 256, 1024]);  getitem_1185 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(view_default_336, view_default_80, None, None, None, getitem_234, getitem_235, True, 1e-08, [True, False, False]);  view_default_336 = view_default_80 = getitem_234 = getitem_235 = None
        getitem_1187 = native_batch_norm_backward_default_63[0]
        getitem_1188 = native_batch_norm_backward_default_63[1]
        getitem_1189 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        view_default_337 = torch.ops.aten.view.default(getitem_1187, [256, 1024, 1, 1]);  getitem_1187 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_1184, torch.float32);  getitem_1184 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_63, to_dtype_189);  le_scalar_63 = new_zeros_default_63 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_group_norm_backward_default_63 = torch.ops.aten.native_group_norm_backward.default(to_dtype_191, add_tensor_11, getitem_231, getitem_232, primals_237, 64, 1024, 784, 32, [True, True, True]);  to_dtype_191 = add_tensor_11 = getitem_231 = getitem_232 = primals_237 = None
        getitem_1190 = native_group_norm_backward_default_63[0]
        getitem_1191 = native_group_norm_backward_default_63[1]
        getitem_1192 = native_group_norm_backward_default_63[2];  native_group_norm_backward_default_63 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(add_tensor_52, getitem_1190);  add_tensor_52 = getitem_1190 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(add_tensor_53, relu__default_35, view_default_79, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_79 = None
        getitem_1193 = convolution_backward_default_65[0]
        getitem_1194 = convolution_backward_default_65[1]
        getitem_1195 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        view_default_338 = torch.ops.aten.view.default(getitem_1194, [1, 1024, 256]);  getitem_1194 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(view_default_338, view_default_78, None, None, None, getitem_228, getitem_229, True, 1e-08, [True, False, False]);  view_default_338 = view_default_78 = getitem_228 = getitem_229 = None
        getitem_1196 = native_batch_norm_backward_default_64[0]
        getitem_1197 = native_batch_norm_backward_default_64[1]
        getitem_1198 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        view_default_339 = torch.ops.aten.view.default(getitem_1196, [1024, 256, 1, 1]);  getitem_1196 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_1193, torch.float32);  getitem_1193 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_64, to_dtype_192);  le_scalar_64 = new_zeros_default_64 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_group_norm_backward_default_64 = torch.ops.aten.native_group_norm_backward.default(to_dtype_194, convolution_default_38, getitem_225, getitem_226, primals_232, 64, 256, 784, 32, [True, True, True]);  to_dtype_194 = convolution_default_38 = getitem_225 = getitem_226 = primals_232 = None
        getitem_1199 = native_group_norm_backward_default_64[0]
        getitem_1200 = native_group_norm_backward_default_64[1]
        getitem_1201 = native_group_norm_backward_default_64[2];  native_group_norm_backward_default_64 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_1199, relu__default_34, view_default_77, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1199 = view_default_77 = None
        getitem_1202 = convolution_backward_default_66[0]
        getitem_1203 = convolution_backward_default_66[1]
        getitem_1204 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        view_default_340 = torch.ops.aten.view.default(getitem_1203, [1, 256, 2304]);  getitem_1203 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(view_default_340, view_default_76, None, None, None, getitem_222, getitem_223, True, 1e-08, [True, False, False]);  view_default_340 = view_default_76 = getitem_222 = getitem_223 = None
        getitem_1205 = native_batch_norm_backward_default_65[0]
        getitem_1206 = native_batch_norm_backward_default_65[1]
        getitem_1207 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        view_default_341 = torch.ops.aten.view.default(getitem_1205, [256, 256, 3, 3]);  getitem_1205 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_1202, torch.float32);  getitem_1202 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_65, to_dtype_195);  le_scalar_65 = new_zeros_default_65 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_group_norm_backward_default_65 = torch.ops.aten.native_group_norm_backward.default(to_dtype_197, convolution_default_37, getitem_219, getitem_220, primals_230, 64, 256, 784, 32, [True, True, True]);  to_dtype_197 = convolution_default_37 = getitem_219 = getitem_220 = primals_230 = None
        getitem_1208 = native_group_norm_backward_default_65[0]
        getitem_1209 = native_group_norm_backward_default_65[1]
        getitem_1210 = native_group_norm_backward_default_65[2];  native_group_norm_backward_default_65 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_1208, relu__default_33, view_default_75, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1208 = view_default_75 = None
        getitem_1211 = convolution_backward_default_67[0]
        getitem_1212 = convolution_backward_default_67[1]
        getitem_1213 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        view_default_342 = torch.ops.aten.view.default(getitem_1212, [1, 256, 1024]);  getitem_1212 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(view_default_342, view_default_74, None, None, None, getitem_216, getitem_217, True, 1e-08, [True, False, False]);  view_default_342 = view_default_74 = getitem_216 = getitem_217 = None
        getitem_1214 = native_batch_norm_backward_default_66[0]
        getitem_1215 = native_batch_norm_backward_default_66[1]
        getitem_1216 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        view_default_343 = torch.ops.aten.view.default(getitem_1214, [256, 1024, 1, 1]);  getitem_1214 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_1211, torch.float32);  getitem_1211 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_66, to_dtype_198);  le_scalar_66 = new_zeros_default_66 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_group_norm_backward_default_66 = torch.ops.aten.native_group_norm_backward.default(to_dtype_200, add_tensor_10, getitem_213, getitem_214, primals_228, 64, 1024, 784, 32, [True, True, True]);  to_dtype_200 = add_tensor_10 = getitem_213 = getitem_214 = primals_228 = None
        getitem_1217 = native_group_norm_backward_default_66[0]
        getitem_1218 = native_group_norm_backward_default_66[1]
        getitem_1219 = native_group_norm_backward_default_66[2];  native_group_norm_backward_default_66 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, getitem_1217);  add_tensor_53 = getitem_1217 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(add_tensor_54, relu__default_32, view_default_73, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_73 = None
        getitem_1220 = convolution_backward_default_68[0]
        getitem_1221 = convolution_backward_default_68[1]
        getitem_1222 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        view_default_344 = torch.ops.aten.view.default(getitem_1221, [1, 1024, 256]);  getitem_1221 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(view_default_344, view_default_72, None, None, None, getitem_210, getitem_211, True, 1e-08, [True, False, False]);  view_default_344 = view_default_72 = getitem_210 = getitem_211 = None
        getitem_1223 = native_batch_norm_backward_default_67[0]
        getitem_1224 = native_batch_norm_backward_default_67[1]
        getitem_1225 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        view_default_345 = torch.ops.aten.view.default(getitem_1223, [1024, 256, 1, 1]);  getitem_1223 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_1220, torch.float32);  getitem_1220 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_67, to_dtype_201);  le_scalar_67 = new_zeros_default_67 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_group_norm_backward_default_67 = torch.ops.aten.native_group_norm_backward.default(to_dtype_203, convolution_default_35, getitem_207, getitem_208, primals_223, 64, 256, 784, 32, [True, True, True]);  to_dtype_203 = convolution_default_35 = getitem_207 = getitem_208 = primals_223 = None
        getitem_1226 = native_group_norm_backward_default_67[0]
        getitem_1227 = native_group_norm_backward_default_67[1]
        getitem_1228 = native_group_norm_backward_default_67[2];  native_group_norm_backward_default_67 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_1226, relu__default_31, view_default_71, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1226 = view_default_71 = None
        getitem_1229 = convolution_backward_default_69[0]
        getitem_1230 = convolution_backward_default_69[1]
        getitem_1231 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        view_default_346 = torch.ops.aten.view.default(getitem_1230, [1, 256, 2304]);  getitem_1230 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(view_default_346, view_default_70, None, None, None, getitem_204, getitem_205, True, 1e-08, [True, False, False]);  view_default_346 = view_default_70 = getitem_204 = getitem_205 = None
        getitem_1232 = native_batch_norm_backward_default_68[0]
        getitem_1233 = native_batch_norm_backward_default_68[1]
        getitem_1234 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        view_default_347 = torch.ops.aten.view.default(getitem_1232, [256, 256, 3, 3]);  getitem_1232 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_1229, torch.float32);  getitem_1229 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_68, to_dtype_204);  le_scalar_68 = new_zeros_default_68 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_group_norm_backward_default_68 = torch.ops.aten.native_group_norm_backward.default(to_dtype_206, convolution_default_34, getitem_201, getitem_202, primals_221, 64, 256, 784, 32, [True, True, True]);  to_dtype_206 = convolution_default_34 = getitem_201 = getitem_202 = primals_221 = None
        getitem_1235 = native_group_norm_backward_default_68[0]
        getitem_1236 = native_group_norm_backward_default_68[1]
        getitem_1237 = native_group_norm_backward_default_68[2];  native_group_norm_backward_default_68 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_1235, relu__default_30, view_default_69, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1235 = view_default_69 = None
        getitem_1238 = convolution_backward_default_70[0]
        getitem_1239 = convolution_backward_default_70[1]
        getitem_1240 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        view_default_348 = torch.ops.aten.view.default(getitem_1239, [1, 256, 1024]);  getitem_1239 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(view_default_348, view_default_68, None, None, None, getitem_198, getitem_199, True, 1e-08, [True, False, False]);  view_default_348 = view_default_68 = getitem_198 = getitem_199 = None
        getitem_1241 = native_batch_norm_backward_default_69[0]
        getitem_1242 = native_batch_norm_backward_default_69[1]
        getitem_1243 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        view_default_349 = torch.ops.aten.view.default(getitem_1241, [256, 1024, 1, 1]);  getitem_1241 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_1238, torch.float32);  getitem_1238 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_69, to_dtype_207);  le_scalar_69 = new_zeros_default_69 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_group_norm_backward_default_69 = torch.ops.aten.native_group_norm_backward.default(to_dtype_209, add_tensor_9, getitem_195, getitem_196, primals_219, 64, 1024, 784, 32, [True, True, True]);  to_dtype_209 = add_tensor_9 = getitem_195 = getitem_196 = primals_219 = None
        getitem_1244 = native_group_norm_backward_default_69[0]
        getitem_1245 = native_group_norm_backward_default_69[1]
        getitem_1246 = native_group_norm_backward_default_69[2];  native_group_norm_backward_default_69 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(add_tensor_54, getitem_1244);  add_tensor_54 = getitem_1244 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(add_tensor_55, relu__default_29, view_default_67, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_67 = None
        getitem_1247 = convolution_backward_default_71[0]
        getitem_1248 = convolution_backward_default_71[1]
        getitem_1249 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        view_default_350 = torch.ops.aten.view.default(getitem_1248, [1, 1024, 256]);  getitem_1248 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(view_default_350, view_default_66, None, None, None, getitem_192, getitem_193, True, 1e-08, [True, False, False]);  view_default_350 = view_default_66 = getitem_192 = getitem_193 = None
        getitem_1250 = native_batch_norm_backward_default_70[0]
        getitem_1251 = native_batch_norm_backward_default_70[1]
        getitem_1252 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        view_default_351 = torch.ops.aten.view.default(getitem_1250, [1024, 256, 1, 1]);  getitem_1250 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_1247, torch.float32);  getitem_1247 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_70, to_dtype_210);  le_scalar_70 = new_zeros_default_70 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_group_norm_backward_default_70 = torch.ops.aten.native_group_norm_backward.default(to_dtype_212, convolution_default_32, getitem_189, getitem_190, primals_214, 64, 256, 784, 32, [True, True, True]);  to_dtype_212 = convolution_default_32 = getitem_189 = getitem_190 = primals_214 = None
        getitem_1253 = native_group_norm_backward_default_70[0]
        getitem_1254 = native_group_norm_backward_default_70[1]
        getitem_1255 = native_group_norm_backward_default_70[2];  native_group_norm_backward_default_70 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_1253, relu__default_28, view_default_65, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1253 = view_default_65 = None
        getitem_1256 = convolution_backward_default_72[0]
        getitem_1257 = convolution_backward_default_72[1]
        getitem_1258 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        view_default_352 = torch.ops.aten.view.default(getitem_1257, [1, 256, 2304]);  getitem_1257 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(view_default_352, view_default_64, None, None, None, getitem_186, getitem_187, True, 1e-08, [True, False, False]);  view_default_352 = view_default_64 = getitem_186 = getitem_187 = None
        getitem_1259 = native_batch_norm_backward_default_71[0]
        getitem_1260 = native_batch_norm_backward_default_71[1]
        getitem_1261 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        view_default_353 = torch.ops.aten.view.default(getitem_1259, [256, 256, 3, 3]);  getitem_1259 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_1256, torch.float32);  getitem_1256 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_71, to_dtype_213);  le_scalar_71 = new_zeros_default_71 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_group_norm_backward_default_71 = torch.ops.aten.native_group_norm_backward.default(to_dtype_215, convolution_default_31, getitem_183, getitem_184, primals_212, 64, 256, 784, 32, [True, True, True]);  to_dtype_215 = convolution_default_31 = getitem_183 = getitem_184 = primals_212 = None
        getitem_1262 = native_group_norm_backward_default_71[0]
        getitem_1263 = native_group_norm_backward_default_71[1]
        getitem_1264 = native_group_norm_backward_default_71[2];  native_group_norm_backward_default_71 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_1262, relu__default_27, view_default_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1262 = view_default_63 = None
        getitem_1265 = convolution_backward_default_73[0]
        getitem_1266 = convolution_backward_default_73[1]
        getitem_1267 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        view_default_354 = torch.ops.aten.view.default(getitem_1266, [1, 256, 1024]);  getitem_1266 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(view_default_354, view_default_62, None, None, None, getitem_180, getitem_181, True, 1e-08, [True, False, False]);  view_default_354 = view_default_62 = getitem_180 = getitem_181 = None
        getitem_1268 = native_batch_norm_backward_default_72[0]
        getitem_1269 = native_batch_norm_backward_default_72[1]
        getitem_1270 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        view_default_355 = torch.ops.aten.view.default(getitem_1268, [256, 1024, 1, 1]);  getitem_1268 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_1265, torch.float32);  getitem_1265 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_72, to_dtype_216);  le_scalar_72 = new_zeros_default_72 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_group_norm_backward_default_72 = torch.ops.aten.native_group_norm_backward.default(to_dtype_218, add_tensor_8, getitem_177, getitem_178, primals_210, 64, 1024, 784, 32, [True, True, True]);  to_dtype_218 = add_tensor_8 = getitem_177 = getitem_178 = primals_210 = None
        getitem_1271 = native_group_norm_backward_default_72[0]
        getitem_1272 = native_group_norm_backward_default_72[1]
        getitem_1273 = native_group_norm_backward_default_72[2];  native_group_norm_backward_default_72 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(add_tensor_55, getitem_1271);  add_tensor_55 = getitem_1271 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(add_tensor_56, relu__default_26, view_default_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_61 = None
        getitem_1274 = convolution_backward_default_74[0]
        getitem_1275 = convolution_backward_default_74[1]
        getitem_1276 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        view_default_356 = torch.ops.aten.view.default(getitem_1275, [1, 1024, 256]);  getitem_1275 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(view_default_356, view_default_60, None, None, None, getitem_174, getitem_175, True, 1e-08, [True, False, False]);  view_default_356 = view_default_60 = getitem_174 = getitem_175 = None
        getitem_1277 = native_batch_norm_backward_default_73[0]
        getitem_1278 = native_batch_norm_backward_default_73[1]
        getitem_1279 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        view_default_357 = torch.ops.aten.view.default(getitem_1277, [1024, 256, 1, 1]);  getitem_1277 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_1274, torch.float32);  getitem_1274 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_73, to_dtype_219);  le_scalar_73 = new_zeros_default_73 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_group_norm_backward_default_73 = torch.ops.aten.native_group_norm_backward.default(to_dtype_221, convolution_default_29, getitem_171, getitem_172, primals_178, 64, 256, 784, 32, [True, True, True]);  to_dtype_221 = convolution_default_29 = getitem_171 = getitem_172 = primals_178 = None
        getitem_1280 = native_group_norm_backward_default_73[0]
        getitem_1281 = native_group_norm_backward_default_73[1]
        getitem_1282 = native_group_norm_backward_default_73[2];  native_group_norm_backward_default_73 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_1280, relu__default_25, view_default_59, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1280 = view_default_59 = None
        getitem_1283 = convolution_backward_default_75[0]
        getitem_1284 = convolution_backward_default_75[1]
        getitem_1285 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        view_default_358 = torch.ops.aten.view.default(getitem_1284, [1, 256, 2304]);  getitem_1284 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(view_default_358, view_default_58, None, None, None, getitem_168, getitem_169, True, 1e-08, [True, False, False]);  view_default_358 = view_default_58 = getitem_168 = getitem_169 = None
        getitem_1286 = native_batch_norm_backward_default_74[0]
        getitem_1287 = native_batch_norm_backward_default_74[1]
        getitem_1288 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        view_default_359 = torch.ops.aten.view.default(getitem_1286, [256, 256, 3, 3]);  getitem_1286 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_1283, torch.float32);  getitem_1283 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_74, to_dtype_222);  le_scalar_74 = new_zeros_default_74 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_group_norm_backward_default_74 = torch.ops.aten.native_group_norm_backward.default(to_dtype_224, convolution_default_28, getitem_165, getitem_166, primals_176, 64, 256, 784, 32, [True, True, True]);  to_dtype_224 = convolution_default_28 = getitem_165 = getitem_166 = primals_176 = None
        getitem_1289 = native_group_norm_backward_default_74[0]
        getitem_1290 = native_group_norm_backward_default_74[1]
        getitem_1291 = native_group_norm_backward_default_74[2];  native_group_norm_backward_default_74 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_1289, relu__default_24, view_default_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1289 = view_default_57 = None
        getitem_1292 = convolution_backward_default_76[0]
        getitem_1293 = convolution_backward_default_76[1]
        getitem_1294 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        view_default_360 = torch.ops.aten.view.default(getitem_1293, [1, 256, 1024]);  getitem_1293 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(view_default_360, view_default_56, None, None, None, getitem_162, getitem_163, True, 1e-08, [True, False, False]);  view_default_360 = view_default_56 = getitem_162 = getitem_163 = None
        getitem_1295 = native_batch_norm_backward_default_75[0]
        getitem_1296 = native_batch_norm_backward_default_75[1]
        getitem_1297 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        view_default_361 = torch.ops.aten.view.default(getitem_1295, [256, 1024, 1, 1]);  getitem_1295 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_1292, torch.float32);  getitem_1292 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_75, to_dtype_225);  le_scalar_75 = new_zeros_default_75 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_group_norm_backward_default_75 = torch.ops.aten.native_group_norm_backward.default(to_dtype_227, add_tensor_7, getitem_159, getitem_160, primals_174, 64, 1024, 784, 32, [True, True, True]);  to_dtype_227 = add_tensor_7 = getitem_159 = getitem_160 = primals_174 = None
        getitem_1298 = native_group_norm_backward_default_75[0]
        getitem_1299 = native_group_norm_backward_default_75[1]
        getitem_1300 = native_group_norm_backward_default_75[2];  native_group_norm_backward_default_75 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_56, getitem_1298);  add_tensor_56 = getitem_1298 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(add_tensor_57, relu__default_23, view_default_55, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_55 = None
        getitem_1301 = convolution_backward_default_77[0]
        getitem_1302 = convolution_backward_default_77[1]
        getitem_1303 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        view_default_362 = torch.ops.aten.view.default(getitem_1302, [1, 1024, 256]);  getitem_1302 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(view_default_362, view_default_54, None, None, None, getitem_156, getitem_157, True, 1e-08, [True, False, False]);  view_default_362 = view_default_54 = getitem_156 = getitem_157 = None
        getitem_1304 = native_batch_norm_backward_default_76[0]
        getitem_1305 = native_batch_norm_backward_default_76[1]
        getitem_1306 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        view_default_363 = torch.ops.aten.view.default(getitem_1304, [1024, 256, 1, 1]);  getitem_1304 = None
        to_dtype_228 = torch.ops.aten.to.dtype(getitem_1301, torch.float32);  getitem_1301 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_76, to_dtype_228);  le_scalar_76 = new_zeros_default_76 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_group_norm_backward_default_76 = torch.ops.aten.native_group_norm_backward.default(to_dtype_230, convolution_default_26, getitem_153, getitem_154, primals_79, 64, 256, 784, 32, [True, True, True]);  to_dtype_230 = convolution_default_26 = getitem_153 = getitem_154 = primals_79 = None
        getitem_1307 = native_group_norm_backward_default_76[0]
        getitem_1308 = native_group_norm_backward_default_76[1]
        getitem_1309 = native_group_norm_backward_default_76[2];  native_group_norm_backward_default_76 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_1307, relu__default_22, view_default_53, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1307 = view_default_53 = None
        getitem_1310 = convolution_backward_default_78[0]
        getitem_1311 = convolution_backward_default_78[1]
        getitem_1312 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        view_default_364 = torch.ops.aten.view.default(getitem_1311, [1, 256, 2304]);  getitem_1311 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(view_default_364, view_default_52, None, None, None, getitem_150, getitem_151, True, 1e-08, [True, False, False]);  view_default_364 = view_default_52 = getitem_150 = getitem_151 = None
        getitem_1313 = native_batch_norm_backward_default_77[0]
        getitem_1314 = native_batch_norm_backward_default_77[1]
        getitem_1315 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        view_default_365 = torch.ops.aten.view.default(getitem_1313, [256, 256, 3, 3]);  getitem_1313 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_1310, torch.float32);  getitem_1310 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_77, to_dtype_231);  le_scalar_77 = new_zeros_default_77 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_group_norm_backward_default_77 = torch.ops.aten.native_group_norm_backward.default(to_dtype_233, convolution_default_25, getitem_147, getitem_148, primals_77, 64, 256, 3136, 32, [True, True, True]);  to_dtype_233 = convolution_default_25 = getitem_147 = getitem_148 = primals_77 = None
        getitem_1316 = native_group_norm_backward_default_77[0]
        getitem_1317 = native_group_norm_backward_default_77[1]
        getitem_1318 = native_group_norm_backward_default_77[2];  native_group_norm_backward_default_77 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_1316, relu__default_21, view_default_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1316 = view_default_51 = None
        getitem_1319 = convolution_backward_default_79[0]
        getitem_1320 = convolution_backward_default_79[1]
        getitem_1321 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        view_default_366 = torch.ops.aten.view.default(getitem_1320, [1, 256, 512]);  getitem_1320 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(view_default_366, view_default_50, None, None, None, getitem_144, getitem_145, True, 1e-08, [True, False, False]);  view_default_366 = view_default_50 = getitem_144 = getitem_145 = None
        getitem_1322 = native_batch_norm_backward_default_78[0]
        getitem_1323 = native_batch_norm_backward_default_78[1]
        getitem_1324 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        view_default_367 = torch.ops.aten.view.default(getitem_1322, [256, 512, 1, 1]);  getitem_1322 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(add_tensor_57, relu__default_21, view_default_49, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_57 = view_default_49 = None
        getitem_1325 = convolution_backward_default_80[0]
        getitem_1326 = convolution_backward_default_80[1]
        getitem_1327 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(getitem_1319, getitem_1325);  getitem_1319 = getitem_1325 = None
        view_default_368 = torch.ops.aten.view.default(getitem_1326, [1, 1024, 512]);  getitem_1326 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(view_default_368, view_default_48, None, None, None, getitem_141, getitem_142, True, 1e-08, [True, False, False]);  view_default_368 = view_default_48 = getitem_141 = getitem_142 = None
        getitem_1328 = native_batch_norm_backward_default_79[0]
        getitem_1329 = native_batch_norm_backward_default_79[1]
        getitem_1330 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        view_default_369 = torch.ops.aten.view.default(getitem_1328, [1024, 512, 1, 1]);  getitem_1328 = None
        to_dtype_234 = torch.ops.aten.to.dtype(add_tensor_58, torch.float32);  add_tensor_58 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_78, to_dtype_234);  le_scalar_78 = new_zeros_default_78 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_group_norm_backward_default_78 = torch.ops.aten.native_group_norm_backward.default(to_dtype_236, add_tensor_6, getitem_138, getitem_139, primals_75, 64, 512, 3136, 32, [True, True, True]);  to_dtype_236 = add_tensor_6 = getitem_138 = getitem_139 = primals_75 = None
        getitem_1331 = native_group_norm_backward_default_78[0]
        getitem_1332 = native_group_norm_backward_default_78[1]
        getitem_1333 = native_group_norm_backward_default_78[2];  native_group_norm_backward_default_78 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_1331, relu__default_20, view_default_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_47 = None
        getitem_1334 = convolution_backward_default_81[0]
        getitem_1335 = convolution_backward_default_81[1]
        getitem_1336 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        view_default_370 = torch.ops.aten.view.default(getitem_1335, [1, 512, 128]);  getitem_1335 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(view_default_370, view_default_46, None, None, None, getitem_135, getitem_136, True, 1e-08, [True, False, False]);  view_default_370 = view_default_46 = getitem_135 = getitem_136 = None
        getitem_1337 = native_batch_norm_backward_default_80[0]
        getitem_1338 = native_batch_norm_backward_default_80[1]
        getitem_1339 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        view_default_371 = torch.ops.aten.view.default(getitem_1337, [512, 128, 1, 1]);  getitem_1337 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_1334, torch.float32);  getitem_1334 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_79, to_dtype_237);  le_scalar_79 = new_zeros_default_79 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_group_norm_backward_default_79 = torch.ops.aten.native_group_norm_backward.default(to_dtype_239, convolution_default_22, getitem_132, getitem_133, primals_69, 64, 128, 3136, 32, [True, True, True]);  to_dtype_239 = convolution_default_22 = getitem_132 = getitem_133 = primals_69 = None
        getitem_1340 = native_group_norm_backward_default_79[0]
        getitem_1341 = native_group_norm_backward_default_79[1]
        getitem_1342 = native_group_norm_backward_default_79[2];  native_group_norm_backward_default_79 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_1340, relu__default_19, view_default_45, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1340 = view_default_45 = None
        getitem_1343 = convolution_backward_default_82[0]
        getitem_1344 = convolution_backward_default_82[1]
        getitem_1345 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        view_default_372 = torch.ops.aten.view.default(getitem_1344, [1, 128, 1152]);  getitem_1344 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(view_default_372, view_default_44, None, None, None, getitem_129, getitem_130, True, 1e-08, [True, False, False]);  view_default_372 = view_default_44 = getitem_129 = getitem_130 = None
        getitem_1346 = native_batch_norm_backward_default_81[0]
        getitem_1347 = native_batch_norm_backward_default_81[1]
        getitem_1348 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        view_default_373 = torch.ops.aten.view.default(getitem_1346, [128, 128, 3, 3]);  getitem_1346 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_1343, torch.float32);  getitem_1343 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_80, to_dtype_240);  le_scalar_80 = new_zeros_default_80 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_group_norm_backward_default_80 = torch.ops.aten.native_group_norm_backward.default(to_dtype_242, convolution_default_21, getitem_126, getitem_127, primals_67, 64, 128, 3136, 32, [True, True, True]);  to_dtype_242 = convolution_default_21 = getitem_126 = getitem_127 = primals_67 = None
        getitem_1349 = native_group_norm_backward_default_80[0]
        getitem_1350 = native_group_norm_backward_default_80[1]
        getitem_1351 = native_group_norm_backward_default_80[2];  native_group_norm_backward_default_80 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_1349, relu__default_18, view_default_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1349 = view_default_43 = None
        getitem_1352 = convolution_backward_default_83[0]
        getitem_1353 = convolution_backward_default_83[1]
        getitem_1354 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        view_default_374 = torch.ops.aten.view.default(getitem_1353, [1, 128, 512]);  getitem_1353 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(view_default_374, view_default_42, None, None, None, getitem_123, getitem_124, True, 1e-08, [True, False, False]);  view_default_374 = view_default_42 = getitem_123 = getitem_124 = None
        getitem_1355 = native_batch_norm_backward_default_82[0]
        getitem_1356 = native_batch_norm_backward_default_82[1]
        getitem_1357 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        view_default_375 = torch.ops.aten.view.default(getitem_1355, [128, 512, 1, 1]);  getitem_1355 = None
        to_dtype_243 = torch.ops.aten.to.dtype(getitem_1352, torch.float32);  getitem_1352 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_81, to_dtype_243);  le_scalar_81 = new_zeros_default_81 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_group_norm_backward_default_81 = torch.ops.aten.native_group_norm_backward.default(to_dtype_245, add_tensor_5, getitem_120, getitem_121, primals_65, 64, 512, 3136, 32, [True, True, True]);  to_dtype_245 = add_tensor_5 = getitem_120 = getitem_121 = primals_65 = None
        getitem_1358 = native_group_norm_backward_default_81[0]
        getitem_1359 = native_group_norm_backward_default_81[1]
        getitem_1360 = native_group_norm_backward_default_81[2];  native_group_norm_backward_default_81 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_1331, getitem_1358);  getitem_1331 = getitem_1358 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(add_tensor_59, relu__default_17, view_default_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_41 = None
        getitem_1361 = convolution_backward_default_84[0]
        getitem_1362 = convolution_backward_default_84[1]
        getitem_1363 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        view_default_376 = torch.ops.aten.view.default(getitem_1362, [1, 512, 128]);  getitem_1362 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(view_default_376, view_default_40, None, None, None, getitem_117, getitem_118, True, 1e-08, [True, False, False]);  view_default_376 = view_default_40 = getitem_117 = getitem_118 = None
        getitem_1364 = native_batch_norm_backward_default_83[0]
        getitem_1365 = native_batch_norm_backward_default_83[1]
        getitem_1366 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        view_default_377 = torch.ops.aten.view.default(getitem_1364, [512, 128, 1, 1]);  getitem_1364 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_1361, torch.float32);  getitem_1361 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_82, to_dtype_246);  le_scalar_82 = new_zeros_default_82 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_group_norm_backward_default_82 = torch.ops.aten.native_group_norm_backward.default(to_dtype_248, convolution_default_19, getitem_114, getitem_115, primals_60, 64, 128, 3136, 32, [True, True, True]);  to_dtype_248 = convolution_default_19 = getitem_114 = getitem_115 = primals_60 = None
        getitem_1367 = native_group_norm_backward_default_82[0]
        getitem_1368 = native_group_norm_backward_default_82[1]
        getitem_1369 = native_group_norm_backward_default_82[2];  native_group_norm_backward_default_82 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_1367, relu__default_16, view_default_39, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1367 = view_default_39 = None
        getitem_1370 = convolution_backward_default_85[0]
        getitem_1371 = convolution_backward_default_85[1]
        getitem_1372 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        view_default_378 = torch.ops.aten.view.default(getitem_1371, [1, 128, 1152]);  getitem_1371 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(view_default_378, view_default_38, None, None, None, getitem_111, getitem_112, True, 1e-08, [True, False, False]);  view_default_378 = view_default_38 = getitem_111 = getitem_112 = None
        getitem_1373 = native_batch_norm_backward_default_84[0]
        getitem_1374 = native_batch_norm_backward_default_84[1]
        getitem_1375 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        view_default_379 = torch.ops.aten.view.default(getitem_1373, [128, 128, 3, 3]);  getitem_1373 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_1370, torch.float32);  getitem_1370 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_83, to_dtype_249);  le_scalar_83 = new_zeros_default_83 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_group_norm_backward_default_83 = torch.ops.aten.native_group_norm_backward.default(to_dtype_251, convolution_default_18, getitem_108, getitem_109, primals_58, 64, 128, 3136, 32, [True, True, True]);  to_dtype_251 = convolution_default_18 = getitem_108 = getitem_109 = primals_58 = None
        getitem_1376 = native_group_norm_backward_default_83[0]
        getitem_1377 = native_group_norm_backward_default_83[1]
        getitem_1378 = native_group_norm_backward_default_83[2];  native_group_norm_backward_default_83 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_1376, relu__default_15, view_default_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1376 = view_default_37 = None
        getitem_1379 = convolution_backward_default_86[0]
        getitem_1380 = convolution_backward_default_86[1]
        getitem_1381 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        view_default_380 = torch.ops.aten.view.default(getitem_1380, [1, 128, 512]);  getitem_1380 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(view_default_380, view_default_36, None, None, None, getitem_105, getitem_106, True, 1e-08, [True, False, False]);  view_default_380 = view_default_36 = getitem_105 = getitem_106 = None
        getitem_1382 = native_batch_norm_backward_default_85[0]
        getitem_1383 = native_batch_norm_backward_default_85[1]
        getitem_1384 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        view_default_381 = torch.ops.aten.view.default(getitem_1382, [128, 512, 1, 1]);  getitem_1382 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_1379, torch.float32);  getitem_1379 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_84, to_dtype_252);  le_scalar_84 = new_zeros_default_84 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_group_norm_backward_default_84 = torch.ops.aten.native_group_norm_backward.default(to_dtype_254, add_tensor_4, getitem_102, getitem_103, primals_56, 64, 512, 3136, 32, [True, True, True]);  to_dtype_254 = add_tensor_4 = getitem_102 = getitem_103 = primals_56 = None
        getitem_1385 = native_group_norm_backward_default_84[0]
        getitem_1386 = native_group_norm_backward_default_84[1]
        getitem_1387 = native_group_norm_backward_default_84[2];  native_group_norm_backward_default_84 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, getitem_1385);  add_tensor_59 = getitem_1385 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(add_tensor_60, relu__default_14, view_default_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_35 = None
        getitem_1388 = convolution_backward_default_87[0]
        getitem_1389 = convolution_backward_default_87[1]
        getitem_1390 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        view_default_382 = torch.ops.aten.view.default(getitem_1389, [1, 512, 128]);  getitem_1389 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(view_default_382, view_default_34, None, None, None, getitem_99, getitem_100, True, 1e-08, [True, False, False]);  view_default_382 = view_default_34 = getitem_99 = getitem_100 = None
        getitem_1391 = native_batch_norm_backward_default_86[0]
        getitem_1392 = native_batch_norm_backward_default_86[1]
        getitem_1393 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        view_default_383 = torch.ops.aten.view.default(getitem_1391, [512, 128, 1, 1]);  getitem_1391 = None
        to_dtype_255 = torch.ops.aten.to.dtype(getitem_1388, torch.float32);  getitem_1388 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_85, to_dtype_255);  le_scalar_85 = new_zeros_default_85 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_group_norm_backward_default_85 = torch.ops.aten.native_group_norm_backward.default(to_dtype_257, convolution_default_16, getitem_96, getitem_97, primals_51, 64, 128, 3136, 32, [True, True, True]);  to_dtype_257 = convolution_default_16 = getitem_96 = getitem_97 = primals_51 = None
        getitem_1394 = native_group_norm_backward_default_85[0]
        getitem_1395 = native_group_norm_backward_default_85[1]
        getitem_1396 = native_group_norm_backward_default_85[2];  native_group_norm_backward_default_85 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_1394, relu__default_13, view_default_33, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1394 = view_default_33 = None
        getitem_1397 = convolution_backward_default_88[0]
        getitem_1398 = convolution_backward_default_88[1]
        getitem_1399 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        view_default_384 = torch.ops.aten.view.default(getitem_1398, [1, 128, 1152]);  getitem_1398 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(view_default_384, view_default_32, None, None, None, getitem_93, getitem_94, True, 1e-08, [True, False, False]);  view_default_384 = view_default_32 = getitem_93 = getitem_94 = None
        getitem_1400 = native_batch_norm_backward_default_87[0]
        getitem_1401 = native_batch_norm_backward_default_87[1]
        getitem_1402 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        view_default_385 = torch.ops.aten.view.default(getitem_1400, [128, 128, 3, 3]);  getitem_1400 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_1397, torch.float32);  getitem_1397 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_86, to_dtype_258);  le_scalar_86 = new_zeros_default_86 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_group_norm_backward_default_86 = torch.ops.aten.native_group_norm_backward.default(to_dtype_260, convolution_default_15, getitem_90, getitem_91, primals_49, 64, 128, 3136, 32, [True, True, True]);  to_dtype_260 = convolution_default_15 = getitem_90 = getitem_91 = primals_49 = None
        getitem_1403 = native_group_norm_backward_default_86[0]
        getitem_1404 = native_group_norm_backward_default_86[1]
        getitem_1405 = native_group_norm_backward_default_86[2];  native_group_norm_backward_default_86 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_1403, relu__default_12, view_default_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1403 = view_default_31 = None
        getitem_1406 = convolution_backward_default_89[0]
        getitem_1407 = convolution_backward_default_89[1]
        getitem_1408 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        view_default_386 = torch.ops.aten.view.default(getitem_1407, [1, 128, 512]);  getitem_1407 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(view_default_386, view_default_30, None, None, None, getitem_87, getitem_88, True, 1e-08, [True, False, False]);  view_default_386 = view_default_30 = getitem_87 = getitem_88 = None
        getitem_1409 = native_batch_norm_backward_default_88[0]
        getitem_1410 = native_batch_norm_backward_default_88[1]
        getitem_1411 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        view_default_387 = torch.ops.aten.view.default(getitem_1409, [128, 512, 1, 1]);  getitem_1409 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_1406, torch.float32);  getitem_1406 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_87, to_dtype_261);  le_scalar_87 = new_zeros_default_87 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_group_norm_backward_default_87 = torch.ops.aten.native_group_norm_backward.default(to_dtype_263, add_tensor_3, getitem_84, getitem_85, primals_47, 64, 512, 3136, 32, [True, True, True]);  to_dtype_263 = add_tensor_3 = getitem_84 = getitem_85 = primals_47 = None
        getitem_1412 = native_group_norm_backward_default_87[0]
        getitem_1413 = native_group_norm_backward_default_87[1]
        getitem_1414 = native_group_norm_backward_default_87[2];  native_group_norm_backward_default_87 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_60, getitem_1412);  add_tensor_60 = getitem_1412 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(add_tensor_61, relu__default_11, view_default_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_29 = None
        getitem_1415 = convolution_backward_default_90[0]
        getitem_1416 = convolution_backward_default_90[1]
        getitem_1417 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        view_default_388 = torch.ops.aten.view.default(getitem_1416, [1, 512, 128]);  getitem_1416 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(view_default_388, view_default_28, None, None, None, getitem_81, getitem_82, True, 1e-08, [True, False, False]);  view_default_388 = view_default_28 = getitem_81 = getitem_82 = None
        getitem_1418 = native_batch_norm_backward_default_89[0]
        getitem_1419 = native_batch_norm_backward_default_89[1]
        getitem_1420 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        view_default_389 = torch.ops.aten.view.default(getitem_1418, [512, 128, 1, 1]);  getitem_1418 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_1415, torch.float32);  getitem_1415 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_88, to_dtype_264);  le_scalar_88 = new_zeros_default_88 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_group_norm_backward_default_88 = torch.ops.aten.native_group_norm_backward.default(to_dtype_266, convolution_default_13, getitem_78, getitem_79, primals_42, 64, 128, 3136, 32, [True, True, True]);  to_dtype_266 = convolution_default_13 = getitem_78 = getitem_79 = primals_42 = None
        getitem_1421 = native_group_norm_backward_default_88[0]
        getitem_1422 = native_group_norm_backward_default_88[1]
        getitem_1423 = native_group_norm_backward_default_88[2];  native_group_norm_backward_default_88 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1421, relu__default_10, view_default_27, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1421 = view_default_27 = None
        getitem_1424 = convolution_backward_default_91[0]
        getitem_1425 = convolution_backward_default_91[1]
        getitem_1426 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        view_default_390 = torch.ops.aten.view.default(getitem_1425, [1, 128, 1152]);  getitem_1425 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(view_default_390, view_default_26, None, None, None, getitem_75, getitem_76, True, 1e-08, [True, False, False]);  view_default_390 = view_default_26 = getitem_75 = getitem_76 = None
        getitem_1427 = native_batch_norm_backward_default_90[0]
        getitem_1428 = native_batch_norm_backward_default_90[1]
        getitem_1429 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        view_default_391 = torch.ops.aten.view.default(getitem_1427, [128, 128, 3, 3]);  getitem_1427 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_1424, torch.float32);  getitem_1424 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_89, to_dtype_267);  le_scalar_89 = new_zeros_default_89 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_group_norm_backward_default_89 = torch.ops.aten.native_group_norm_backward.default(to_dtype_269, convolution_default_12, getitem_72, getitem_73, primals_40, 64, 128, 12544, 32, [True, True, True]);  to_dtype_269 = convolution_default_12 = getitem_72 = getitem_73 = primals_40 = None
        getitem_1430 = native_group_norm_backward_default_89[0]
        getitem_1431 = native_group_norm_backward_default_89[1]
        getitem_1432 = native_group_norm_backward_default_89[2];  native_group_norm_backward_default_89 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1430, relu__default_9, view_default_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1430 = view_default_25 = None
        getitem_1433 = convolution_backward_default_92[0]
        getitem_1434 = convolution_backward_default_92[1]
        getitem_1435 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        view_default_392 = torch.ops.aten.view.default(getitem_1434, [1, 128, 256]);  getitem_1434 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(view_default_392, view_default_24, None, None, None, getitem_69, getitem_70, True, 1e-08, [True, False, False]);  view_default_392 = view_default_24 = getitem_69 = getitem_70 = None
        getitem_1436 = native_batch_norm_backward_default_91[0]
        getitem_1437 = native_batch_norm_backward_default_91[1]
        getitem_1438 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        view_default_393 = torch.ops.aten.view.default(getitem_1436, [128, 256, 1, 1]);  getitem_1436 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(add_tensor_61, relu__default_9, view_default_23, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_61 = view_default_23 = None
        getitem_1439 = convolution_backward_default_93[0]
        getitem_1440 = convolution_backward_default_93[1]
        getitem_1441 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_1433, getitem_1439);  getitem_1433 = getitem_1439 = None
        view_default_394 = torch.ops.aten.view.default(getitem_1440, [1, 512, 256]);  getitem_1440 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(view_default_394, view_default_22, None, None, None, getitem_66, getitem_67, True, 1e-08, [True, False, False]);  view_default_394 = view_default_22 = getitem_66 = getitem_67 = None
        getitem_1442 = native_batch_norm_backward_default_92[0]
        getitem_1443 = native_batch_norm_backward_default_92[1]
        getitem_1444 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        view_default_395 = torch.ops.aten.view.default(getitem_1442, [512, 256, 1, 1]);  getitem_1442 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_90, to_dtype_270);  le_scalar_90 = new_zeros_default_90 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_group_norm_backward_default_90 = torch.ops.aten.native_group_norm_backward.default(to_dtype_272, add_tensor_2, getitem_63, getitem_64, primals_38, 64, 256, 12544, 32, [True, True, True]);  to_dtype_272 = add_tensor_2 = getitem_63 = getitem_64 = primals_38 = None
        getitem_1445 = native_group_norm_backward_default_90[0]
        getitem_1446 = native_group_norm_backward_default_90[1]
        getitem_1447 = native_group_norm_backward_default_90[2];  native_group_norm_backward_default_90 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1445, relu__default_8, view_default_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_21 = None
        getitem_1448 = convolution_backward_default_94[0]
        getitem_1449 = convolution_backward_default_94[1]
        getitem_1450 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        view_default_396 = torch.ops.aten.view.default(getitem_1449, [1, 256, 64]);  getitem_1449 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(view_default_396, view_default_20, None, None, None, getitem_60, getitem_61, True, 1e-08, [True, False, False]);  view_default_396 = view_default_20 = getitem_60 = getitem_61 = None
        getitem_1451 = native_batch_norm_backward_default_93[0]
        getitem_1452 = native_batch_norm_backward_default_93[1]
        getitem_1453 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        view_default_397 = torch.ops.aten.view.default(getitem_1451, [256, 64, 1, 1]);  getitem_1451 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_1448, torch.float32);  getitem_1448 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_91, to_dtype_273);  le_scalar_91 = new_zeros_default_91 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_group_norm_backward_default_91 = torch.ops.aten.native_group_norm_backward.default(to_dtype_275, convolution_default_9, getitem_57, getitem_58, primals_32, 64, 64, 12544, 32, [True, True, True]);  to_dtype_275 = convolution_default_9 = getitem_57 = getitem_58 = primals_32 = None
        getitem_1454 = native_group_norm_backward_default_91[0]
        getitem_1455 = native_group_norm_backward_default_91[1]
        getitem_1456 = native_group_norm_backward_default_91[2];  native_group_norm_backward_default_91 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1454, relu__default_7, view_default_19, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1454 = view_default_19 = None
        getitem_1457 = convolution_backward_default_95[0]
        getitem_1458 = convolution_backward_default_95[1]
        getitem_1459 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        view_default_398 = torch.ops.aten.view.default(getitem_1458, [1, 64, 576]);  getitem_1458 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(view_default_398, view_default_18, None, None, None, getitem_54, getitem_55, True, 1e-08, [True, False, False]);  view_default_398 = view_default_18 = getitem_54 = getitem_55 = None
        getitem_1460 = native_batch_norm_backward_default_94[0]
        getitem_1461 = native_batch_norm_backward_default_94[1]
        getitem_1462 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        view_default_399 = torch.ops.aten.view.default(getitem_1460, [64, 64, 3, 3]);  getitem_1460 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_1457, torch.float32);  getitem_1457 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_92, to_dtype_276);  le_scalar_92 = new_zeros_default_92 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_group_norm_backward_default_92 = torch.ops.aten.native_group_norm_backward.default(to_dtype_278, convolution_default_8, getitem_51, getitem_52, primals_30, 64, 64, 12544, 32, [True, True, True]);  to_dtype_278 = convolution_default_8 = getitem_51 = getitem_52 = primals_30 = None
        getitem_1463 = native_group_norm_backward_default_92[0]
        getitem_1464 = native_group_norm_backward_default_92[1]
        getitem_1465 = native_group_norm_backward_default_92[2];  native_group_norm_backward_default_92 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1463, relu__default_6, view_default_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1463 = view_default_17 = None
        getitem_1466 = convolution_backward_default_96[0]
        getitem_1467 = convolution_backward_default_96[1]
        getitem_1468 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        view_default_400 = torch.ops.aten.view.default(getitem_1467, [1, 64, 256]);  getitem_1467 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(view_default_400, view_default_16, None, None, None, getitem_48, getitem_49, True, 1e-08, [True, False, False]);  view_default_400 = view_default_16 = getitem_48 = getitem_49 = None
        getitem_1469 = native_batch_norm_backward_default_95[0]
        getitem_1470 = native_batch_norm_backward_default_95[1]
        getitem_1471 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        view_default_401 = torch.ops.aten.view.default(getitem_1469, [64, 256, 1, 1]);  getitem_1469 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_1466, torch.float32);  getitem_1466 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_93, to_dtype_279);  le_scalar_93 = new_zeros_default_93 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_group_norm_backward_default_93 = torch.ops.aten.native_group_norm_backward.default(to_dtype_281, add_tensor_1, getitem_45, getitem_46, primals_28, 64, 256, 12544, 32, [True, True, True]);  to_dtype_281 = add_tensor_1 = getitem_45 = getitem_46 = primals_28 = None
        getitem_1472 = native_group_norm_backward_default_93[0]
        getitem_1473 = native_group_norm_backward_default_93[1]
        getitem_1474 = native_group_norm_backward_default_93[2];  native_group_norm_backward_default_93 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_1445, getitem_1472);  getitem_1445 = getitem_1472 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(add_tensor_63, relu__default_5, view_default_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_15 = None
        getitem_1475 = convolution_backward_default_97[0]
        getitem_1476 = convolution_backward_default_97[1]
        getitem_1477 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        view_default_402 = torch.ops.aten.view.default(getitem_1476, [1, 256, 64]);  getitem_1476 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(view_default_402, view_default_14, None, None, None, getitem_42, getitem_43, True, 1e-08, [True, False, False]);  view_default_402 = view_default_14 = getitem_42 = getitem_43 = None
        getitem_1478 = native_batch_norm_backward_default_96[0]
        getitem_1479 = native_batch_norm_backward_default_96[1]
        getitem_1480 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        view_default_403 = torch.ops.aten.view.default(getitem_1478, [256, 64, 1, 1]);  getitem_1478 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_1475, torch.float32);  getitem_1475 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_94, to_dtype_282);  le_scalar_94 = new_zeros_default_94 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_group_norm_backward_default_94 = torch.ops.aten.native_group_norm_backward.default(to_dtype_284, convolution_default_6, getitem_39, getitem_40, primals_23, 64, 64, 12544, 32, [True, True, True]);  to_dtype_284 = convolution_default_6 = getitem_39 = getitem_40 = primals_23 = None
        getitem_1481 = native_group_norm_backward_default_94[0]
        getitem_1482 = native_group_norm_backward_default_94[1]
        getitem_1483 = native_group_norm_backward_default_94[2];  native_group_norm_backward_default_94 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1481, relu__default_4, view_default_13, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1481 = view_default_13 = None
        getitem_1484 = convolution_backward_default_98[0]
        getitem_1485 = convolution_backward_default_98[1]
        getitem_1486 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        view_default_404 = torch.ops.aten.view.default(getitem_1485, [1, 64, 576]);  getitem_1485 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(view_default_404, view_default_12, None, None, None, getitem_36, getitem_37, True, 1e-08, [True, False, False]);  view_default_404 = view_default_12 = getitem_36 = getitem_37 = None
        getitem_1487 = native_batch_norm_backward_default_97[0]
        getitem_1488 = native_batch_norm_backward_default_97[1]
        getitem_1489 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        view_default_405 = torch.ops.aten.view.default(getitem_1487, [64, 64, 3, 3]);  getitem_1487 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_1484, torch.float32);  getitem_1484 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_95, to_dtype_285);  le_scalar_95 = new_zeros_default_95 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_group_norm_backward_default_95 = torch.ops.aten.native_group_norm_backward.default(to_dtype_287, convolution_default_5, getitem_33, getitem_34, primals_21, 64, 64, 12544, 32, [True, True, True]);  to_dtype_287 = convolution_default_5 = getitem_33 = getitem_34 = primals_21 = None
        getitem_1490 = native_group_norm_backward_default_95[0]
        getitem_1491 = native_group_norm_backward_default_95[1]
        getitem_1492 = native_group_norm_backward_default_95[2];  native_group_norm_backward_default_95 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1490, relu__default_3, view_default_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1490 = view_default_11 = None
        getitem_1493 = convolution_backward_default_99[0]
        getitem_1494 = convolution_backward_default_99[1]
        getitem_1495 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        view_default_406 = torch.ops.aten.view.default(getitem_1494, [1, 64, 256]);  getitem_1494 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(view_default_406, view_default_10, None, None, None, getitem_30, getitem_31, True, 1e-08, [True, False, False]);  view_default_406 = view_default_10 = getitem_30 = getitem_31 = None
        getitem_1496 = native_batch_norm_backward_default_98[0]
        getitem_1497 = native_batch_norm_backward_default_98[1]
        getitem_1498 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        view_default_407 = torch.ops.aten.view.default(getitem_1496, [64, 256, 1, 1]);  getitem_1496 = None
        to_dtype_288 = torch.ops.aten.to.dtype(getitem_1493, torch.float32);  getitem_1493 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_96, to_dtype_288);  le_scalar_96 = new_zeros_default_96 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_group_norm_backward_default_96 = torch.ops.aten.native_group_norm_backward.default(to_dtype_290, add_tensor, getitem_27, getitem_28, primals_19, 64, 256, 12544, 32, [True, True, True]);  to_dtype_290 = add_tensor = getitem_27 = getitem_28 = primals_19 = None
        getitem_1499 = native_group_norm_backward_default_96[0]
        getitem_1500 = native_group_norm_backward_default_96[1]
        getitem_1501 = native_group_norm_backward_default_96[2];  native_group_norm_backward_default_96 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, getitem_1499);  add_tensor_63 = getitem_1499 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(add_tensor_64, relu__default_2, view_default_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_9 = None
        getitem_1502 = convolution_backward_default_100[0]
        getitem_1503 = convolution_backward_default_100[1]
        getitem_1504 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        view_default_408 = torch.ops.aten.view.default(getitem_1503, [1, 256, 64]);  getitem_1503 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(view_default_408, view_default_8, None, None, None, getitem_24, getitem_25, True, 1e-08, [True, False, False]);  view_default_408 = view_default_8 = getitem_24 = getitem_25 = None
        getitem_1505 = native_batch_norm_backward_default_99[0]
        getitem_1506 = native_batch_norm_backward_default_99[1]
        getitem_1507 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        view_default_409 = torch.ops.aten.view.default(getitem_1505, [256, 64, 1, 1]);  getitem_1505 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_1502, torch.float32);  getitem_1502 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_97, to_dtype_291);  le_scalar_97 = new_zeros_default_97 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_group_norm_backward_default_97 = torch.ops.aten.native_group_norm_backward.default(to_dtype_293, convolution_default_3, getitem_21, getitem_22, primals_14, 64, 64, 12544, 32, [True, True, True]);  to_dtype_293 = convolution_default_3 = getitem_21 = getitem_22 = primals_14 = None
        getitem_1508 = native_group_norm_backward_default_97[0]
        getitem_1509 = native_group_norm_backward_default_97[1]
        getitem_1510 = native_group_norm_backward_default_97[2];  native_group_norm_backward_default_97 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1508, relu__default_1, view_default_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1508 = view_default_7 = None
        getitem_1511 = convolution_backward_default_101[0]
        getitem_1512 = convolution_backward_default_101[1]
        getitem_1513 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        view_default_410 = torch.ops.aten.view.default(getitem_1512, [1, 64, 576]);  getitem_1512 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(view_default_410, view_default_6, None, None, None, getitem_18, getitem_19, True, 1e-08, [True, False, False]);  view_default_410 = view_default_6 = getitem_18 = getitem_19 = None
        getitem_1514 = native_batch_norm_backward_default_100[0]
        getitem_1515 = native_batch_norm_backward_default_100[1]
        getitem_1516 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        view_default_411 = torch.ops.aten.view.default(getitem_1514, [64, 64, 3, 3]);  getitem_1514 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_1511, torch.float32);  getitem_1511 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_98, to_dtype_294);  le_scalar_98 = new_zeros_default_98 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_group_norm_backward_default_98 = torch.ops.aten.native_group_norm_backward.default(to_dtype_296, convolution_default_2, getitem_15, getitem_16, primals_12, 64, 64, 12544, 32, [True, True, True]);  to_dtype_296 = convolution_default_2 = getitem_15 = getitem_16 = primals_12 = None
        getitem_1517 = native_group_norm_backward_default_98[0]
        getitem_1518 = native_group_norm_backward_default_98[1]
        getitem_1519 = native_group_norm_backward_default_98[2];  native_group_norm_backward_default_98 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1517, relu__default, view_default_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1517 = view_default_5 = None
        getitem_1520 = convolution_backward_default_102[0]
        getitem_1521 = convolution_backward_default_102[1]
        getitem_1522 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        view_default_412 = torch.ops.aten.view.default(getitem_1521, [1, 64, 64]);  getitem_1521 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(view_default_412, view_default_4, None, None, None, getitem_12, getitem_13, True, 1e-08, [True, False, False]);  view_default_412 = view_default_4 = getitem_12 = getitem_13 = None
        getitem_1523 = native_batch_norm_backward_default_101[0]
        getitem_1524 = native_batch_norm_backward_default_101[1]
        getitem_1525 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        view_default_413 = torch.ops.aten.view.default(getitem_1523, [64, 64, 1, 1]);  getitem_1523 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(add_tensor_64, relu__default, view_default_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_64 = view_default_3 = None
        getitem_1526 = convolution_backward_default_103[0]
        getitem_1527 = convolution_backward_default_103[1]
        getitem_1528 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_1520, getitem_1526);  getitem_1520 = getitem_1526 = None
        view_default_414 = torch.ops.aten.view.default(getitem_1527, [1, 256, 64]);  getitem_1527 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(view_default_414, view_default_2, None, None, None, getitem_9, getitem_10, True, 1e-08, [True, False, False]);  view_default_414 = view_default_2 = getitem_9 = getitem_10 = None
        getitem_1529 = native_batch_norm_backward_default_102[0]
        getitem_1530 = native_batch_norm_backward_default_102[1]
        getitem_1531 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        view_default_415 = torch.ops.aten.view.default(getitem_1529, [256, 64, 1, 1]);  getitem_1529 = None
        to_dtype_297 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_99, to_dtype_297);  le_scalar_99 = new_zeros_default_99 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_group_norm_backward_default_99 = torch.ops.aten.native_group_norm_backward.default(to_dtype_299, getitem_3, getitem_6, getitem_7, primals_10, 64, 64, 12544, 32, [True, True, True]);  to_dtype_299 = getitem_3 = getitem_6 = getitem_7 = primals_10 = None
        getitem_1532 = native_group_norm_backward_default_99[0]
        getitem_1533 = native_group_norm_backward_default_99[1]
        getitem_1534 = native_group_norm_backward_default_99[2];  native_group_norm_backward_default_99 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_1532, constant_pad_nd_default, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_4);  getitem_1532 = constant_pad_nd_default = getitem_4 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(constant_pad_nd_default_1, primals_307, view_default_1, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  constant_pad_nd_default_1 = primals_307 = view_default_1 = None
        getitem_1535 = convolution_backward_default_104[0]
        getitem_1536 = convolution_backward_default_104[1]
        getitem_1537 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        view_default_416 = torch.ops.aten.view.default(getitem_1536, [1, 64, 147]);  getitem_1536 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(view_default_416, view_default, None, None, None, getitem_1, getitem_2, True, 1e-08, [True, False, False]);  view_default_416 = view_default = getitem_1 = getitem_2 = None
        getitem_1538 = native_batch_norm_backward_default_103[0]
        getitem_1539 = native_batch_norm_backward_default_103[1]
        getitem_1540 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        view_default_417 = torch.ops.aten.view.default(getitem_1538, [64, 3, 7, 7]);  getitem_1538 = None
        return [view_default_208, getitem_616, getitem_615, getitem_619, getitem_618, view_default_413, view_default_411, view_default_409, view_default_415, getitem_1534, getitem_1533, getitem_1519, getitem_1518, getitem_1510, getitem_1509, view_default_407, view_default_405, view_default_403, getitem_1501, getitem_1500, getitem_1492, getitem_1491, getitem_1483, getitem_1482, view_default_401, view_default_399, view_default_397, getitem_1474, getitem_1473, getitem_1465, getitem_1464, getitem_1456, getitem_1455, view_default_393, view_default_391, view_default_389, view_default_395, getitem_1447, getitem_1446, getitem_1432, getitem_1431, getitem_1423, getitem_1422, view_default_387, view_default_385, view_default_383, getitem_1414, getitem_1413, getitem_1405, getitem_1404, getitem_1396, getitem_1395, view_default_381, view_default_379, view_default_377, getitem_1387, getitem_1386, getitem_1378, getitem_1377, getitem_1369, getitem_1368, view_default_375, view_default_373, view_default_371, getitem_1360, getitem_1359, getitem_1351, getitem_1350, getitem_1342, getitem_1341, view_default_367, view_default_365, view_default_363, view_default_369, getitem_1333, getitem_1332, getitem_1318, getitem_1317, getitem_1309, getitem_1308, view_default_307, view_default_305, view_default_303, getitem_1057, getitem_1056, getitem_1048, getitem_1047, getitem_1039, getitem_1038, view_default_301, view_default_299, view_default_297, getitem_1030, getitem_1029, getitem_1021, getitem_1020, getitem_1012, getitem_1011, view_default_295, view_default_293, view_default_291, getitem_1003, getitem_1002, getitem_994, getitem_993, getitem_985, getitem_984, view_default_289, view_default_287, view_default_285, getitem_976, getitem_975, getitem_967, getitem_966, getitem_958, getitem_957, view_default_283, view_default_281, view_default_279, getitem_949, getitem_948, getitem_940, getitem_939, getitem_931, getitem_930, view_default_277, view_default_275, view_default_273, getitem_922, getitem_921, getitem_913, getitem_912, getitem_904, getitem_903, view_default_271, view_default_269, view_default_267, getitem_895, getitem_894, getitem_886, getitem_885, getitem_877, getitem_876, view_default_265, view_default_263, view_default_261, getitem_868, getitem_867, getitem_859, getitem_858, getitem_850, getitem_849, view_default_259, view_default_257, view_default_255, getitem_841, getitem_840, getitem_832, getitem_831, getitem_823, getitem_822, view_default_253, view_default_251, view_default_249, getitem_814, getitem_813, getitem_805, getitem_804, getitem_796, getitem_795, view_default_361, view_default_359, view_default_357, getitem_1300, getitem_1299, getitem_1291, getitem_1290, getitem_1282, getitem_1281, view_default_247, view_default_245, view_default_243, getitem_787, getitem_786, getitem_778, getitem_777, getitem_769, getitem_768, view_default_241, view_default_239, view_default_237, getitem_760, getitem_759, getitem_751, getitem_750, getitem_742, getitem_741, view_default_235, view_default_233, view_default_231, getitem_733, getitem_732, getitem_724, getitem_723, getitem_715, getitem_714, view_default_355, view_default_353, view_default_351, getitem_1273, getitem_1272, getitem_1264, getitem_1263, getitem_1255, getitem_1254, view_default_349, view_default_347, view_default_345, getitem_1246, getitem_1245, getitem_1237, getitem_1236, getitem_1228, getitem_1227, view_default_343, view_default_341, view_default_339, getitem_1219, getitem_1218, getitem_1210, getitem_1209, getitem_1201, getitem_1200, view_default_337, view_default_335, view_default_333, getitem_1192, getitem_1191, getitem_1183, getitem_1182, getitem_1174, getitem_1173, view_default_331, view_default_329, view_default_327, getitem_1165, getitem_1164, getitem_1156, getitem_1155, getitem_1147, getitem_1146, view_default_325, view_default_323, view_default_321, getitem_1138, getitem_1137, getitem_1129, getitem_1128, getitem_1120, getitem_1119, view_default_319, view_default_317, view_default_315, getitem_1111, getitem_1110, getitem_1102, getitem_1101, getitem_1093, getitem_1092, view_default_313, view_default_311, view_default_309, getitem_1084, getitem_1083, getitem_1075, getitem_1074, getitem_1066, getitem_1065, view_default_227, view_default_225, view_default_223, view_default_229, getitem_706, getitem_705, getitem_691, getitem_690, getitem_682, getitem_681, view_default_221, view_default_219, view_default_217, getitem_673, getitem_672, getitem_664, getitem_663, getitem_655, getitem_654, view_default_215, view_default_213, view_default_211, getitem_646, getitem_645, getitem_637, getitem_636, getitem_628, getitem_627, view_default_417, None]
        
