
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/RobertaForMaskedLM_roberta/RobertaForMaskedLM_roberta_backward_1/state_dict.pt'))

    
    
    def forward(self, t_default_94, _softmax_default_4, view_default_73, t_default_24, getitem_91, getitem_23, view_default_268, add_tensor_13, getitem_92, t_default_93, view_default_269, _unsafe_view_default_78, t_default_25, view_default_70, t_default_26, view_default_266, view_default_319, t_default_111, add_tensor_11, getitem_110, _unsafe_view_default_48, t_default_100, getitem_20, _unsafe_view_default_93, t_default_23, view_default_162, view_default_68, view_default_285, getitem_19, view_default_64, view_default_321, getitem_98, view_default_66, _unsafe_view_default_46, _unsafe_view_default_45, add_tensor_28, t_default_101, getitem_97, view_default_286, view_default_320, t_default_56, t_default_22, view_default_317, t_default_112, view_default_287, getitem_22, getitem_109, view_default_65, add_tensor_50, t_default_99, view_default_26, view_default_264, _unsafe_view_default_76, _unsafe_view_default_75, view_default_22, _unsafe_view_default_8, t_default_92, t_default_8, add_tensor_46, _unsafe_view_default_6, _unsafe_view_default_5, add_tensor_4, view_default_260, primals_226, view_default_332, primals_221, _unsafe_view_default_11, _unsafe_view_default_13, view_default_376, getitem_14, view_default_379, view_default_383, view_default_45, t_default_134, view_default_47, t_default_133, t_default_116, t_default_15, view_default_328, add_tensor_67, add_tensor_58, primals_222, _softmax_default_22, primals_225, primals_237, getitem_13, view_default_311, _unsafe_view_default_90, view_default_315, view_default_277, add_tensor_55, t_default_110, _unsafe_view_default_91, view_default_325, _unsafe_view_default_36, getitem_61, view_default_323, t_default_114, t_default_64, _unsafe_view_default_38, view_default_132, t_default_113, _softmax_default_19, view_default_181, getitem_113, getitem_62, _unsafe_view_default_53, view_default_130, add_tensor_56, t_default_45, _unsafe_view_default_51, view_default_183, t_default_63, getitem_112, t_default_115, _softmax_default_9, _unsafe_view_default_25, getitem_53, add_tensor_16, t_default_54, getitem_116, t_default_32, _unsafe_view_default_96, getitem_115, t_default_55, t_default_117, t_default_118, _softmax_default_5, _unsafe_view_default_35, _unsafe_view_default_98, t_default_31, view_default_153, _unsafe_view_default_95, getitem_52, view_default_90, view_default_155, view_default_334, view_default_87, view_default_158, view_default_94, view_default_336, view_default_150, t_default_53, getitem_50, t_default_52, view_default_151, view_default_149, getitem_49, add_tensor_26, _unsafe_view_default_118, getitem_104, _unsafe_view_default_116, t_default_106, add_tensor_70, view_default_303, t_default_107, view_default_402, add_tensor_53, getitem_103, view_default_304, _unsafe_view_default_115, t_default_105, view_default_400, view_default_300, view_default_302, t_default_3, primals_190, _unsafe_view_default_103, t_default_124, t_default_123, _unsafe_view_default_68, t_default_58, view_default_14, _unsafe_view_default_10, t_default_14, getitem_55, primals_193, getitem_56, primals_194, add_tensor_7, view_default_167, view_default_15, primals_189, view_default_230, view_default_13, _unsafe_view_default_66, getitem_1, view_default_232, getitem_122, getitem_121, getitem_2, view_default_353, view_default_351, view_default_43, view_default_164, add_tensor_40, view_default_166, t_default_4, view_default_354, t_default_57, _unsafe_view_default_65, view_default_39, getitem_100, view_default_289, t_default_102, _softmax_default_1, t_default_9, view_default_291, getitem_8, getitem_101, t_default_7, view_default_17, _softmax_default_17, view_default_30, t_default_50, _softmax_default_8, getitem_7, getitem_5, view_default_31, t_default_10, view_default_138, getitem_4, view_default_28, view_default_19, t_default_49, t_default_103, getitem_142, t_default_5, getitem_143, add_tensor_2, t_default_6, view_default_294, t_default_48, view_default_141, view_default_252, t_default_87, getitem_133, primals_381, getitem_134, primals_370, view_default_389, t_default_136, t_default_88, primals_369, view_default_249, view_default_391, view_default_251, getitem_85, getitem_136, primals_382, getitem_86, t_default_137, view_default_388, _unsafe_view_default_73, add_tensor_68, t_default_65, view_default_185, view_default_198, primals_302, primals_305, getitem_65, add_tensor_32, _unsafe_view_default_58, view_default_187, t_default_66, _unsafe_view_default_55, view_default_184, primals_301, primals_306, getitem_64, t_default_69, _unsafe_view_default_56, view_default_9, t_default_70, getitem_95, view_default_272, primals_321, t_default_97, t_default_2, add_tensor_35, t_default_96, add_tensor_1, view_default_201, _softmax_default_16, _unsafe_view_default_1, getitem_67, primals_318, t_default_95, _unsafe_view_default, view_default_204, getitem_68, t_default_71, primals_317, primals_322, _unsafe_view_default_3, view_default_274, view_default_202, add_tensor_47, view_default_270, getitem_94, view_default_11, view_default_200, t_default_104, add_tensor_38, _unsafe_view_default_110, _unsafe_view_default_88, _unsafe_view_default_85, t_default_75, _unsafe_view_default_111, add_tensor_52, getitem_74, view_default_387, getitem_73, view_default_217, view_default_385, t_default_135, _unsafe_view_default_113, t_default_76, _unsafe_view_default_86, view_default_218, view_default_298, view_default_221, view_default_219, t_default_77, primals_141, view_default_104, primals_126, view_default_238, view_default_111, primals_125, _unsafe_view_default_30, t_default_38, getitem_83, view_default_240, primals_129, view_default_107, _softmax_default_14, t_default_85, primals_178, getitem_82, primals_174, t_default_84, primals_177, _softmax_default_6, t_default_37, add_tensor_19, primals_130, primals_173, primals_142, primals_353, t_default_30, _unsafe_view_default_108, primals_354, view_default_83, _unsafe_view_default_105, view_default_366, add_tensor_64, view_default_362, primals_365, _softmax_default_3, add_tensor_14, getitem_29, t_default_128, view_default_82, t_default_29, view_default_53, getitem_28, t_default_20, view_default_56, t_default_19, primals_366, _unsafe_view_default_106, view_default_85, t_default_28, primals_238, view_default_236, primals_253, primals_242, t_default_130, view_default_234, getitem_128, view_default_370, primals_254, t_default_83, t_default_82, t_default_81, getitem_127, view_default_368, t_default_129, getitem_80, view_default_235, getitem_79, add_tensor_41, primals_241, view_default_349, add_tensor_61, t_default_142, primals_1, view_default_355, view_default_128, t_default_126, primals_109, add_tensor_62, primals_110, _softmax_default_7, _softmax_default_18, t_default_127, add_tensor_71, primals_113, view_default_337, view_default_406, t_default_44, add_tensor_22, getitem_106, t_default_109, _softmax_default_21, view_default_359, view_default_308, primals_114, view_default_124, getitem_125, _unsafe_view_default_100, view_default_121, getitem_140, getitem_107, _unsafe_view_default_101, t_default_43, view_default_345, t_default_141, t_default_108, view_default_404, getitem_139, view_default_306, getitem_124, t_default_122, t_default_125, view_default_357, t_default_143, view_default_405, t_default_89, getitem_88, view_default_192, view_default_196, _softmax_default_15, t_default_33, _unsafe_view_default_28, view_default_96, getitem_31, getitem_32, primals_274, view_default_189, primals_285, t_default_68, primals_286, _softmax_default_11, add_tensor_44, t_default_90, view_default_257, view_default_255, primals_289, view_default_253, _unsafe_view_default_26, getitem_89, view_default_98, primals_290, t_default_67, add_tensor_34, t_default_91, t_default_78, view_default_223, t_default_79, primals_49, primals_29, primals_269, getitem_76, primals_81, primals_50, primals_77, primals_30, t_default_80, primals_34, primals_46, primals_273, primals_45, primals_33, primals_257, getitem_77, view_default_226, primals_258, primals_82, _softmax_default_13, primals_270, primals_78, _unsafe_view_default_16, _unsafe_view_default_60, _unsafe_view_default_63, add_tensor_10, _unsafe_view_default_18, _unsafe_view_default_15, view_default_215, _unsafe_view_default_61, view_default_62, add_tensor_37, t_default_21, view_default_213, view_default_60, primals_61, getitem_25, _unsafe_view_default_20, view_default_81, primals_66, primals_65, view_default_79, view_default_77, primals_62, t_default_27, _unsafe_view_default_21, getitem_26, _unsafe_view_default_23, getitem_131, primals_338, view_default_372, t_default_131, primals_337, primals_349, t_default_132, primals_350, view_default_371, add_tensor_65, view_default_374, getitem_130, t_default_35, primals_206, t_default, getitem_11, t_default_12, view_default_36, _unsafe_view_default_41, view_default_99, t_default_13, primals_205, add_tensor_5, view_default, view_default_100, primals_209, view_default_147, t_default_1, view_default_2, getitem_35, view_default_5, _softmax_default, add_tensor_25, t_default_34, view_default_32, _unsafe_view_default_40, _unsafe_view_default_43, getitem_34, t_default_51, t_default_11, _softmax_default_2, view_default_34, view_default_102, getitem_10, primals_210, add_tensor_17, view_default_145, t_default_18, getitem_71, t_default_17, t_default_62, view_default_206, view_default_49, _softmax_default_12, _unsafe_view_default_71, _unsafe_view_default_50, t_default_72, view_default_48, getitem_16, t_default_61, view_default_243, view_default_179, view_default_209, view_default_51, add_tensor_8, t_default_73, getitem_17, add_tensor_43, view_default_175, t_default_74, getitem_70, t_default_16, view_default_247, add_tensor_31, t_default_86, _unsafe_view_default_70, primals_97, getitem_137, view_default_396, view_default_342, _softmax_default_23, t_default_138, primals_98, primals_93, primals_94, getitem_119, view_default_340, t_default_120, _softmax_default_20, view_default_393, t_default_139, t_default_121, t_default_36, t_default_119, view_default_338, t_default_140, add_tensor_59, getitem_118, primals_18, view_default_116, getitem_47, t_default_47, t_default_40, t_default_39, view_default_113, t_default_42, add_tensor_20, t_default_46, getitem_38, view_default_136, getitem_40, getitem_37, _unsafe_view_default_33, view_default_115, getitem_41, getitem_43, primals_14, getitem_44, getitem_46, view_default_134, view_default_117, add_tensor_23, primals_17, _unsafe_view_default_31, t_default_41, primals_2, primals_13, view_default_119, view_default_133, primals_334, _unsafe_view_default_81, t_default_60, _unsafe_view_default_80, getitem_58, primals_157, primals_158, _softmax_default_10, view_default_281, primals_146, add_tensor_29, view_default_172, primals_161, view_default_283, getitem_59, t_default_98, add_tensor_49, primals_145, primals_162, view_default_170, primals_333, view_default_168, _unsafe_view_default_83, t_default_59, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_71, [1024], getitem_142, getitem_143, primals_254, primals_253, [True, True, True]);  tangents_1 = add_tensor_71 = getitem_142 = getitem_143 = primals_254 = primals_253 = None
        getitem_144 = native_layer_norm_backward_default[0]
        getitem_145 = native_layer_norm_backward_default[1]
        getitem_146 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_408 = torch.ops.aten.view.default(getitem_144, [8192, 1024])
        t_default_144 = torch.ops.aten.t.default(t_default_143);  t_default_143 = None
        mm_default = torch.ops.aten.mm.default(view_default_408, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_408)
        mm_default_1 = torch.ops.aten.mm.default(t_default_145, view_default_406);  t_default_145 = view_default_406 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_408, [0], True);  view_default_408 = None
        view_default_409 = torch.ops.aten.view.default(sum_dim_int_list, [1024]);  sum_dim_int_list = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_410 = torch.ops.aten.view.default(mm_default, [64, 128, 4096]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_410, torch.float32);  view_default_410 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_405, torch.float32);  view_default_405 = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor);  mul_tensor = None
        add_tensor_72 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(add_tensor_72, 0.5);  add_tensor_72 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor_2, -0.5);  mul_tensor_2 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_3);  mul_tensor_3 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_4);  to_dtype_1 = mul_tensor_4 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_1, mul_tensor_5);  mul_tensor_1 = mul_tensor_5 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_73);  to_dtype = add_tensor_73 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_6, torch.float32);  mul_tensor_6 = None
        view_default_411 = torch.ops.aten.view.default(to_dtype_2, [8192, 4096]);  to_dtype_2 = None
        t_default_148 = torch.ops.aten.t.default(t_default_142);  t_default_142 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_411, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(view_default_411)
        mm_default_3 = torch.ops.aten.mm.default(t_default_149, view_default_404);  t_default_149 = view_default_404 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_411, [0], True);  view_default_411 = None
        view_default_412 = torch.ops.aten.view.default(sum_dim_int_list_1, [4096]);  sum_dim_int_list_1 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_413 = torch.ops.aten.view.default(mm_default_2, [64, 128, 1024]);  mm_default_2 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(getitem_144, view_default_413);  getitem_144 = view_default_413 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_74, add_tensor_70, [1024], getitem_139, getitem_140, primals_242, primals_241, [True, True, True]);  add_tensor_74 = add_tensor_70 = getitem_139 = getitem_140 = primals_242 = primals_241 = None
        getitem_147 = native_layer_norm_backward_default_1[0]
        getitem_148 = native_layer_norm_backward_default_1[1]
        getitem_149 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_414 = torch.ops.aten.view.default(getitem_147, [8192, 1024])
        t_default_152 = torch.ops.aten.t.default(t_default_141);  t_default_141 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_414, t_default_152);  t_default_152 = None
        t_default_153 = torch.ops.aten.t.default(view_default_414)
        mm_default_5 = torch.ops.aten.mm.default(t_default_153, view_default_402);  t_default_153 = view_default_402 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_414, [0], True);  view_default_414 = None
        view_default_415 = torch.ops.aten.view.default(sum_dim_int_list_2, [1024]);  sum_dim_int_list_2 = None
        t_default_155 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_416 = torch.ops.aten.view.default(mm_default_4, [64, 128, 1024]);  mm_default_4 = None
        view_default_417 = torch.ops.aten.view.default(view_default_416, [64, 128, 16, 64]);  view_default_416 = None
        permute_default_96 = torch.ops.aten.permute.default(view_default_417, [0, 2, 1, 3]);  view_default_417 = None
        clone_default_96 = torch.ops.aten.clone.default(permute_default_96, memory_format = torch.contiguous_format);  permute_default_96 = None
        _unsafe_view_default_120 = torch.ops.aten._unsafe_view.default(clone_default_96, [1024, 128, 64]);  clone_default_96 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_400, 1, 2);  view_default_400 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_24, _unsafe_view_default_120);  transpose_int_24 = None
        transpose_int_25 = torch.ops.aten.transpose.int(_unsafe_view_default_118, 1, 2);  _unsafe_view_default_118 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_120, transpose_int_25);  _unsafe_view_default_120 = transpose_int_25 = None
        view_default_418 = torch.ops.aten.view.default(bmm_default_48, [64, 16, 128, 64]);  bmm_default_48 = None
        view_default_419 = torch.ops.aten.view.default(bmm_default_49, [64, 16, 128, 128]);  bmm_default_49 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_419, _softmax_default_23, -1, torch.float32);  view_default_419 = _softmax_default_23 = None
        div_tensor_24 = torch.ops.aten.div.Tensor(_softmax_backward_data_default, 8.0);  _softmax_backward_data_default = None
        view_default_420 = torch.ops.aten.view.default(div_tensor_24, [1024, 128, 128]);  div_tensor_24 = None
        transpose_int_26 = torch.ops.aten.transpose.int(_unsafe_view_default_115, 1, 2);  _unsafe_view_default_115 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_26, view_default_420);  transpose_int_26 = None
        transpose_int_27 = torch.ops.aten.transpose.int(_unsafe_view_default_116, 1, 2);  _unsafe_view_default_116 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_420, transpose_int_27);  view_default_420 = transpose_int_27 = None
        view_default_421 = torch.ops.aten.view.default(bmm_default_50, [64, 16, 64, 128]);  bmm_default_50 = None
        view_default_422 = torch.ops.aten.view.default(bmm_default_51, [64, 16, 128, 64]);  bmm_default_51 = None
        transpose_int_28 = torch.ops.aten.transpose.int(view_default_421, -1, -2);  view_default_421 = None
        permute_default_97 = torch.ops.aten.permute.default(view_default_422, [0, 2, 1, 3]);  view_default_422 = None
        clone_default_97 = torch.ops.aten.clone.default(permute_default_97, memory_format = torch.contiguous_format);  permute_default_97 = None
        _unsafe_view_default_121 = torch.ops.aten._unsafe_view.default(clone_default_97, [64, 128, 1024]);  clone_default_97 = None
        permute_default_98 = torch.ops.aten.permute.default(view_default_418, [0, 2, 1, 3]);  view_default_418 = None
        clone_default_98 = torch.ops.aten.clone.default(permute_default_98, memory_format = torch.contiguous_format);  permute_default_98 = None
        _unsafe_view_default_122 = torch.ops.aten._unsafe_view.default(clone_default_98, [64, 128, 1024]);  clone_default_98 = None
        view_default_423 = torch.ops.aten.view.default(_unsafe_view_default_122, [8192, 1024]);  _unsafe_view_default_122 = None
        t_default_156 = torch.ops.aten.t.default(t_default_140);  t_default_140 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_423, t_default_156);  t_default_156 = None
        t_default_157 = torch.ops.aten.t.default(view_default_423)
        mm_default_7 = torch.ops.aten.mm.default(t_default_157, view_default_396);  t_default_157 = view_default_396 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_423, [0], True);  view_default_423 = None
        view_default_424 = torch.ops.aten.view.default(sum_dim_int_list_3, [1024]);  sum_dim_int_list_3 = None
        t_default_159 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        view_default_425 = torch.ops.aten.view.default(mm_default_6, [64, 128, 1024]);  mm_default_6 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(getitem_147, view_default_425);  getitem_147 = view_default_425 = None
        permute_default_99 = torch.ops.aten.permute.default(transpose_int_28, [0, 2, 1, 3]);  transpose_int_28 = None
        view_default_426 = torch.ops.aten.view.default(permute_default_99, [64, 128, 1024]);  permute_default_99 = None
        clone_default_99 = torch.ops.aten.clone.default(view_default_426, memory_format = torch.contiguous_format);  view_default_426 = None
        _unsafe_view_default_123 = torch.ops.aten._unsafe_view.default(clone_default_99, [8192, 1024]);  clone_default_99 = None
        t_default_160 = torch.ops.aten.t.default(t_default_139);  t_default_139 = None
        mm_default_8 = torch.ops.aten.mm.default(_unsafe_view_default_123, t_default_160);  t_default_160 = None
        t_default_161 = torch.ops.aten.t.default(_unsafe_view_default_123)
        mm_default_9 = torch.ops.aten.mm.default(t_default_161, view_default_393);  t_default_161 = view_default_393 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_123, [0], True);  _unsafe_view_default_123 = None
        view_default_427 = torch.ops.aten.view.default(sum_dim_int_list_4, [1024]);  sum_dim_int_list_4 = None
        t_default_163 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        view_default_428 = torch.ops.aten.view.default(mm_default_8, [64, 128, 1024]);  mm_default_8 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(add_tensor_75, view_default_428);  add_tensor_75 = view_default_428 = None
        view_default_429 = torch.ops.aten.view.default(_unsafe_view_default_121, [8192, 1024]);  _unsafe_view_default_121 = None
        t_default_164 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_429, t_default_164);  t_default_164 = None
        t_default_165 = torch.ops.aten.t.default(view_default_429)
        mm_default_11 = torch.ops.aten.mm.default(t_default_165, view_default_391);  t_default_165 = view_default_391 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_429, [0], True);  view_default_429 = None
        view_default_430 = torch.ops.aten.view.default(sum_dim_int_list_5, [1024]);  sum_dim_int_list_5 = None
        t_default_167 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_431 = torch.ops.aten.view.default(mm_default_10, [64, 128, 1024]);  mm_default_10 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_76, view_default_431);  add_tensor_76 = view_default_431 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_77, add_tensor_68, [1024], getitem_136, getitem_137, primals_238, primals_237, [True, True, True]);  add_tensor_77 = add_tensor_68 = getitem_136 = getitem_137 = primals_238 = primals_237 = None
        getitem_150 = native_layer_norm_backward_default_2[0]
        getitem_151 = native_layer_norm_backward_default_2[1]
        getitem_152 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_432 = torch.ops.aten.view.default(getitem_150, [8192, 1024])
        t_default_168 = torch.ops.aten.t.default(t_default_137);  t_default_137 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_432, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_432)
        mm_default_13 = torch.ops.aten.mm.default(t_default_169, view_default_389);  t_default_169 = view_default_389 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_432, [0], True);  view_default_432 = None
        view_default_433 = torch.ops.aten.view.default(sum_dim_int_list_6, [1024]);  sum_dim_int_list_6 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_434 = torch.ops.aten.view.default(mm_default_12, [64, 128, 4096]);  mm_default_12 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_434, torch.float32);  view_default_434 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_388, torch.float32);  view_default_388 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_7);  mul_tensor_7 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(add_tensor_78, 0.5);  add_tensor_78 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(mul_tensor_9, -0.5);  mul_tensor_9 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_10);  mul_tensor_10 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_11);  to_dtype_4 = mul_tensor_11 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(mul_tensor_8, mul_tensor_12);  mul_tensor_8 = mul_tensor_12 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_79);  to_dtype_3 = add_tensor_79 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_13, torch.float32);  mul_tensor_13 = None
        view_default_435 = torch.ops.aten.view.default(to_dtype_5, [8192, 4096]);  to_dtype_5 = None
        t_default_172 = torch.ops.aten.t.default(t_default_136);  t_default_136 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_435, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(view_default_435)
        mm_default_15 = torch.ops.aten.mm.default(t_default_173, view_default_387);  t_default_173 = view_default_387 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_435, [0], True);  view_default_435 = None
        view_default_436 = torch.ops.aten.view.default(sum_dim_int_list_7, [4096]);  sum_dim_int_list_7 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_437 = torch.ops.aten.view.default(mm_default_14, [64, 128, 1024]);  mm_default_14 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_150, view_default_437);  getitem_150 = view_default_437 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_80, add_tensor_67, [1024], getitem_133, getitem_134, primals_226, primals_225, [True, True, True]);  add_tensor_80 = add_tensor_67 = getitem_133 = getitem_134 = primals_226 = primals_225 = None
        getitem_153 = native_layer_norm_backward_default_3[0]
        getitem_154 = native_layer_norm_backward_default_3[1]
        getitem_155 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        view_default_438 = torch.ops.aten.view.default(getitem_153, [8192, 1024])
        t_default_176 = torch.ops.aten.t.default(t_default_135);  t_default_135 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_438, t_default_176);  t_default_176 = None
        t_default_177 = torch.ops.aten.t.default(view_default_438)
        mm_default_17 = torch.ops.aten.mm.default(t_default_177, view_default_385);  t_default_177 = view_default_385 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_438, [0], True);  view_default_438 = None
        view_default_439 = torch.ops.aten.view.default(sum_dim_int_list_8, [1024]);  sum_dim_int_list_8 = None
        t_default_179 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        view_default_440 = torch.ops.aten.view.default(mm_default_16, [64, 128, 1024]);  mm_default_16 = None
        view_default_441 = torch.ops.aten.view.default(view_default_440, [64, 128, 16, 64]);  view_default_440 = None
        permute_default_100 = torch.ops.aten.permute.default(view_default_441, [0, 2, 1, 3]);  view_default_441 = None
        clone_default_100 = torch.ops.aten.clone.default(permute_default_100, memory_format = torch.contiguous_format);  permute_default_100 = None
        _unsafe_view_default_124 = torch.ops.aten._unsafe_view.default(clone_default_100, [1024, 128, 64]);  clone_default_100 = None
        transpose_int_29 = torch.ops.aten.transpose.int(view_default_383, 1, 2);  view_default_383 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_29, _unsafe_view_default_124);  transpose_int_29 = None
        transpose_int_30 = torch.ops.aten.transpose.int(_unsafe_view_default_113, 1, 2);  _unsafe_view_default_113 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_124, transpose_int_30);  _unsafe_view_default_124 = transpose_int_30 = None
        view_default_442 = torch.ops.aten.view.default(bmm_default_52, [64, 16, 128, 64]);  bmm_default_52 = None
        view_default_443 = torch.ops.aten.view.default(bmm_default_53, [64, 16, 128, 128]);  bmm_default_53 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_443, _softmax_default_22, -1, torch.float32);  view_default_443 = _softmax_default_22 = None
        div_tensor_25 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_1, 8.0);  _softmax_backward_data_default_1 = None
        view_default_444 = torch.ops.aten.view.default(div_tensor_25, [1024, 128, 128]);  div_tensor_25 = None
        transpose_int_31 = torch.ops.aten.transpose.int(_unsafe_view_default_110, 1, 2);  _unsafe_view_default_110 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_31, view_default_444);  transpose_int_31 = None
        transpose_int_32 = torch.ops.aten.transpose.int(_unsafe_view_default_111, 1, 2);  _unsafe_view_default_111 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_444, transpose_int_32);  view_default_444 = transpose_int_32 = None
        view_default_445 = torch.ops.aten.view.default(bmm_default_54, [64, 16, 64, 128]);  bmm_default_54 = None
        view_default_446 = torch.ops.aten.view.default(bmm_default_55, [64, 16, 128, 64]);  bmm_default_55 = None
        transpose_int_33 = torch.ops.aten.transpose.int(view_default_445, -1, -2);  view_default_445 = None
        permute_default_101 = torch.ops.aten.permute.default(view_default_446, [0, 2, 1, 3]);  view_default_446 = None
        clone_default_101 = torch.ops.aten.clone.default(permute_default_101, memory_format = torch.contiguous_format);  permute_default_101 = None
        _unsafe_view_default_125 = torch.ops.aten._unsafe_view.default(clone_default_101, [64, 128, 1024]);  clone_default_101 = None
        permute_default_102 = torch.ops.aten.permute.default(view_default_442, [0, 2, 1, 3]);  view_default_442 = None
        clone_default_102 = torch.ops.aten.clone.default(permute_default_102, memory_format = torch.contiguous_format);  permute_default_102 = None
        _unsafe_view_default_126 = torch.ops.aten._unsafe_view.default(clone_default_102, [64, 128, 1024]);  clone_default_102 = None
        view_default_447 = torch.ops.aten.view.default(_unsafe_view_default_126, [8192, 1024]);  _unsafe_view_default_126 = None
        t_default_180 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_447, t_default_180);  t_default_180 = None
        t_default_181 = torch.ops.aten.t.default(view_default_447)
        mm_default_19 = torch.ops.aten.mm.default(t_default_181, view_default_379);  t_default_181 = view_default_379 = None
        t_default_182 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_447, [0], True);  view_default_447 = None
        view_default_448 = torch.ops.aten.view.default(sum_dim_int_list_9, [1024]);  sum_dim_int_list_9 = None
        t_default_183 = torch.ops.aten.t.default(t_default_182);  t_default_182 = None
        view_default_449 = torch.ops.aten.view.default(mm_default_18, [64, 128, 1024]);  mm_default_18 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(getitem_153, view_default_449);  getitem_153 = view_default_449 = None
        permute_default_103 = torch.ops.aten.permute.default(transpose_int_33, [0, 2, 1, 3]);  transpose_int_33 = None
        view_default_450 = torch.ops.aten.view.default(permute_default_103, [64, 128, 1024]);  permute_default_103 = None
        clone_default_103 = torch.ops.aten.clone.default(view_default_450, memory_format = torch.contiguous_format);  view_default_450 = None
        _unsafe_view_default_127 = torch.ops.aten._unsafe_view.default(clone_default_103, [8192, 1024]);  clone_default_103 = None
        t_default_184 = torch.ops.aten.t.default(t_default_133);  t_default_133 = None
        mm_default_20 = torch.ops.aten.mm.default(_unsafe_view_default_127, t_default_184);  t_default_184 = None
        t_default_185 = torch.ops.aten.t.default(_unsafe_view_default_127)
        mm_default_21 = torch.ops.aten.mm.default(t_default_185, view_default_376);  t_default_185 = view_default_376 = None
        t_default_186 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_127, [0], True);  _unsafe_view_default_127 = None
        view_default_451 = torch.ops.aten.view.default(sum_dim_int_list_10, [1024]);  sum_dim_int_list_10 = None
        t_default_187 = torch.ops.aten.t.default(t_default_186);  t_default_186 = None
        view_default_452 = torch.ops.aten.view.default(mm_default_20, [64, 128, 1024]);  mm_default_20 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(add_tensor_81, view_default_452);  add_tensor_81 = view_default_452 = None
        view_default_453 = torch.ops.aten.view.default(_unsafe_view_default_125, [8192, 1024]);  _unsafe_view_default_125 = None
        t_default_188 = torch.ops.aten.t.default(t_default_132);  t_default_132 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_453, t_default_188);  t_default_188 = None
        t_default_189 = torch.ops.aten.t.default(view_default_453)
        mm_default_23 = torch.ops.aten.mm.default(t_default_189, view_default_374);  t_default_189 = view_default_374 = None
        t_default_190 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_453, [0], True);  view_default_453 = None
        view_default_454 = torch.ops.aten.view.default(sum_dim_int_list_11, [1024]);  sum_dim_int_list_11 = None
        t_default_191 = torch.ops.aten.t.default(t_default_190);  t_default_190 = None
        view_default_455 = torch.ops.aten.view.default(mm_default_22, [64, 128, 1024]);  mm_default_22 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_82, view_default_455);  add_tensor_82 = view_default_455 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_83, add_tensor_65, [1024], getitem_130, getitem_131, primals_222, primals_221, [True, True, True]);  add_tensor_83 = add_tensor_65 = getitem_130 = getitem_131 = primals_222 = primals_221 = None
        getitem_156 = native_layer_norm_backward_default_4[0]
        getitem_157 = native_layer_norm_backward_default_4[1]
        getitem_158 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_456 = torch.ops.aten.view.default(getitem_156, [8192, 1024])
        t_default_192 = torch.ops.aten.t.default(t_default_131);  t_default_131 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_456, t_default_192);  t_default_192 = None
        t_default_193 = torch.ops.aten.t.default(view_default_456)
        mm_default_25 = torch.ops.aten.mm.default(t_default_193, view_default_372);  t_default_193 = view_default_372 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_456, [0], True);  view_default_456 = None
        view_default_457 = torch.ops.aten.view.default(sum_dim_int_list_12, [1024]);  sum_dim_int_list_12 = None
        t_default_195 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_458 = torch.ops.aten.view.default(mm_default_24, [64, 128, 4096]);  mm_default_24 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_458, torch.float32);  view_default_458 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_371, torch.float32);  view_default_371 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_14);  mul_tensor_14 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(add_tensor_84, 0.5);  add_tensor_84 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_17 = torch.ops.aten.mul.Tensor(mul_tensor_16, -0.5);  mul_tensor_16 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_17);  mul_tensor_17 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_18);  to_dtype_7 = mul_tensor_18 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(mul_tensor_15, mul_tensor_19);  mul_tensor_15 = mul_tensor_19 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_85);  to_dtype_6 = add_tensor_85 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_20, torch.float32);  mul_tensor_20 = None
        view_default_459 = torch.ops.aten.view.default(to_dtype_8, [8192, 4096]);  to_dtype_8 = None
        t_default_196 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_459, t_default_196);  t_default_196 = None
        t_default_197 = torch.ops.aten.t.default(view_default_459)
        mm_default_27 = torch.ops.aten.mm.default(t_default_197, view_default_370);  t_default_197 = view_default_370 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_459, [0], True);  view_default_459 = None
        view_default_460 = torch.ops.aten.view.default(sum_dim_int_list_13, [4096]);  sum_dim_int_list_13 = None
        t_default_199 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        view_default_461 = torch.ops.aten.view.default(mm_default_26, [64, 128, 1024]);  mm_default_26 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(getitem_156, view_default_461);  getitem_156 = view_default_461 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_86, add_tensor_64, [1024], getitem_127, getitem_128, primals_210, primals_209, [True, True, True]);  add_tensor_86 = add_tensor_64 = getitem_127 = getitem_128 = primals_210 = primals_209 = None
        getitem_159 = native_layer_norm_backward_default_5[0]
        getitem_160 = native_layer_norm_backward_default_5[1]
        getitem_161 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_462 = torch.ops.aten.view.default(getitem_159, [8192, 1024])
        t_default_200 = torch.ops.aten.t.default(t_default_129);  t_default_129 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_462, t_default_200);  t_default_200 = None
        t_default_201 = torch.ops.aten.t.default(view_default_462)
        mm_default_29 = torch.ops.aten.mm.default(t_default_201, view_default_368);  t_default_201 = view_default_368 = None
        t_default_202 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_462, [0], True);  view_default_462 = None
        view_default_463 = torch.ops.aten.view.default(sum_dim_int_list_14, [1024]);  sum_dim_int_list_14 = None
        t_default_203 = torch.ops.aten.t.default(t_default_202);  t_default_202 = None
        view_default_464 = torch.ops.aten.view.default(mm_default_28, [64, 128, 1024]);  mm_default_28 = None
        view_default_465 = torch.ops.aten.view.default(view_default_464, [64, 128, 16, 64]);  view_default_464 = None
        permute_default_104 = torch.ops.aten.permute.default(view_default_465, [0, 2, 1, 3]);  view_default_465 = None
        clone_default_104 = torch.ops.aten.clone.default(permute_default_104, memory_format = torch.contiguous_format);  permute_default_104 = None
        _unsafe_view_default_128 = torch.ops.aten._unsafe_view.default(clone_default_104, [1024, 128, 64]);  clone_default_104 = None
        transpose_int_34 = torch.ops.aten.transpose.int(view_default_366, 1, 2);  view_default_366 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_34, _unsafe_view_default_128);  transpose_int_34 = None
        transpose_int_35 = torch.ops.aten.transpose.int(_unsafe_view_default_108, 1, 2);  _unsafe_view_default_108 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_128, transpose_int_35);  _unsafe_view_default_128 = transpose_int_35 = None
        view_default_466 = torch.ops.aten.view.default(bmm_default_56, [64, 16, 128, 64]);  bmm_default_56 = None
        view_default_467 = torch.ops.aten.view.default(bmm_default_57, [64, 16, 128, 128]);  bmm_default_57 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_467, _softmax_default_21, -1, torch.float32);  view_default_467 = _softmax_default_21 = None
        div_tensor_26 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_2, 8.0);  _softmax_backward_data_default_2 = None
        view_default_468 = torch.ops.aten.view.default(div_tensor_26, [1024, 128, 128]);  div_tensor_26 = None
        transpose_int_36 = torch.ops.aten.transpose.int(_unsafe_view_default_105, 1, 2);  _unsafe_view_default_105 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_36, view_default_468);  transpose_int_36 = None
        transpose_int_37 = torch.ops.aten.transpose.int(_unsafe_view_default_106, 1, 2);  _unsafe_view_default_106 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_468, transpose_int_37);  view_default_468 = transpose_int_37 = None
        view_default_469 = torch.ops.aten.view.default(bmm_default_58, [64, 16, 64, 128]);  bmm_default_58 = None
        view_default_470 = torch.ops.aten.view.default(bmm_default_59, [64, 16, 128, 64]);  bmm_default_59 = None
        transpose_int_38 = torch.ops.aten.transpose.int(view_default_469, -1, -2);  view_default_469 = None
        permute_default_105 = torch.ops.aten.permute.default(view_default_470, [0, 2, 1, 3]);  view_default_470 = None
        clone_default_105 = torch.ops.aten.clone.default(permute_default_105, memory_format = torch.contiguous_format);  permute_default_105 = None
        _unsafe_view_default_129 = torch.ops.aten._unsafe_view.default(clone_default_105, [64, 128, 1024]);  clone_default_105 = None
        permute_default_106 = torch.ops.aten.permute.default(view_default_466, [0, 2, 1, 3]);  view_default_466 = None
        clone_default_106 = torch.ops.aten.clone.default(permute_default_106, memory_format = torch.contiguous_format);  permute_default_106 = None
        _unsafe_view_default_130 = torch.ops.aten._unsafe_view.default(clone_default_106, [64, 128, 1024]);  clone_default_106 = None
        view_default_471 = torch.ops.aten.view.default(_unsafe_view_default_130, [8192, 1024]);  _unsafe_view_default_130 = None
        t_default_204 = torch.ops.aten.t.default(t_default_128);  t_default_128 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_471, t_default_204);  t_default_204 = None
        t_default_205 = torch.ops.aten.t.default(view_default_471)
        mm_default_31 = torch.ops.aten.mm.default(t_default_205, view_default_362);  t_default_205 = view_default_362 = None
        t_default_206 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_471, [0], True);  view_default_471 = None
        view_default_472 = torch.ops.aten.view.default(sum_dim_int_list_15, [1024]);  sum_dim_int_list_15 = None
        t_default_207 = torch.ops.aten.t.default(t_default_206);  t_default_206 = None
        view_default_473 = torch.ops.aten.view.default(mm_default_30, [64, 128, 1024]);  mm_default_30 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(getitem_159, view_default_473);  getitem_159 = view_default_473 = None
        permute_default_107 = torch.ops.aten.permute.default(transpose_int_38, [0, 2, 1, 3]);  transpose_int_38 = None
        view_default_474 = torch.ops.aten.view.default(permute_default_107, [64, 128, 1024]);  permute_default_107 = None
        clone_default_107 = torch.ops.aten.clone.default(view_default_474, memory_format = torch.contiguous_format);  view_default_474 = None
        _unsafe_view_default_131 = torch.ops.aten._unsafe_view.default(clone_default_107, [8192, 1024]);  clone_default_107 = None
        t_default_208 = torch.ops.aten.t.default(t_default_127);  t_default_127 = None
        mm_default_32 = torch.ops.aten.mm.default(_unsafe_view_default_131, t_default_208);  t_default_208 = None
        t_default_209 = torch.ops.aten.t.default(_unsafe_view_default_131)
        mm_default_33 = torch.ops.aten.mm.default(t_default_209, view_default_359);  t_default_209 = view_default_359 = None
        t_default_210 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_131, [0], True);  _unsafe_view_default_131 = None
        view_default_475 = torch.ops.aten.view.default(sum_dim_int_list_16, [1024]);  sum_dim_int_list_16 = None
        t_default_211 = torch.ops.aten.t.default(t_default_210);  t_default_210 = None
        view_default_476 = torch.ops.aten.view.default(mm_default_32, [64, 128, 1024]);  mm_default_32 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(add_tensor_87, view_default_476);  add_tensor_87 = view_default_476 = None
        view_default_477 = torch.ops.aten.view.default(_unsafe_view_default_129, [8192, 1024]);  _unsafe_view_default_129 = None
        t_default_212 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_477, t_default_212);  t_default_212 = None
        t_default_213 = torch.ops.aten.t.default(view_default_477)
        mm_default_35 = torch.ops.aten.mm.default(t_default_213, view_default_357);  t_default_213 = view_default_357 = None
        t_default_214 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_477, [0], True);  view_default_477 = None
        view_default_478 = torch.ops.aten.view.default(sum_dim_int_list_17, [1024]);  sum_dim_int_list_17 = None
        t_default_215 = torch.ops.aten.t.default(t_default_214);  t_default_214 = None
        view_default_479 = torch.ops.aten.view.default(mm_default_34, [64, 128, 1024]);  mm_default_34 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(add_tensor_88, view_default_479);  add_tensor_88 = view_default_479 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_89, add_tensor_62, [1024], getitem_124, getitem_125, primals_206, primals_205, [True, True, True]);  add_tensor_89 = add_tensor_62 = getitem_124 = getitem_125 = primals_206 = primals_205 = None
        getitem_162 = native_layer_norm_backward_default_6[0]
        getitem_163 = native_layer_norm_backward_default_6[1]
        getitem_164 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_480 = torch.ops.aten.view.default(getitem_162, [8192, 1024])
        t_default_216 = torch.ops.aten.t.default(t_default_125);  t_default_125 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_480, t_default_216);  t_default_216 = None
        t_default_217 = torch.ops.aten.t.default(view_default_480)
        mm_default_37 = torch.ops.aten.mm.default(t_default_217, view_default_355);  t_default_217 = view_default_355 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_480, [0], True);  view_default_480 = None
        view_default_481 = torch.ops.aten.view.default(sum_dim_int_list_18, [1024]);  sum_dim_int_list_18 = None
        t_default_219 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        view_default_482 = torch.ops.aten.view.default(mm_default_36, [64, 128, 4096]);  mm_default_36 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_482, torch.float32);  view_default_482 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_354, torch.float32);  view_default_354 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_21);  mul_tensor_21 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(add_tensor_90, 0.5);  add_tensor_90 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_24 = torch.ops.aten.mul.Tensor(mul_tensor_23, -0.5);  mul_tensor_23 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_24);  mul_tensor_24 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_25);  to_dtype_10 = mul_tensor_25 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_22, mul_tensor_26);  mul_tensor_22 = mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_91);  to_dtype_9 = add_tensor_91 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        view_default_483 = torch.ops.aten.view.default(to_dtype_11, [8192, 4096]);  to_dtype_11 = None
        t_default_220 = torch.ops.aten.t.default(t_default_124);  t_default_124 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_483, t_default_220);  t_default_220 = None
        t_default_221 = torch.ops.aten.t.default(view_default_483)
        mm_default_39 = torch.ops.aten.mm.default(t_default_221, view_default_353);  t_default_221 = view_default_353 = None
        t_default_222 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_483, [0], True);  view_default_483 = None
        view_default_484 = torch.ops.aten.view.default(sum_dim_int_list_19, [4096]);  sum_dim_int_list_19 = None
        t_default_223 = torch.ops.aten.t.default(t_default_222);  t_default_222 = None
        view_default_485 = torch.ops.aten.view.default(mm_default_38, [64, 128, 1024]);  mm_default_38 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_162, view_default_485);  getitem_162 = view_default_485 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_92, add_tensor_61, [1024], getitem_121, getitem_122, primals_194, primals_193, [True, True, True]);  add_tensor_92 = add_tensor_61 = getitem_121 = getitem_122 = primals_194 = primals_193 = None
        getitem_165 = native_layer_norm_backward_default_7[0]
        getitem_166 = native_layer_norm_backward_default_7[1]
        getitem_167 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_486 = torch.ops.aten.view.default(getitem_165, [8192, 1024])
        t_default_224 = torch.ops.aten.t.default(t_default_123);  t_default_123 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_486, t_default_224);  t_default_224 = None
        t_default_225 = torch.ops.aten.t.default(view_default_486)
        mm_default_41 = torch.ops.aten.mm.default(t_default_225, view_default_351);  t_default_225 = view_default_351 = None
        t_default_226 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_486, [0], True);  view_default_486 = None
        view_default_487 = torch.ops.aten.view.default(sum_dim_int_list_20, [1024]);  sum_dim_int_list_20 = None
        t_default_227 = torch.ops.aten.t.default(t_default_226);  t_default_226 = None
        view_default_488 = torch.ops.aten.view.default(mm_default_40, [64, 128, 1024]);  mm_default_40 = None
        view_default_489 = torch.ops.aten.view.default(view_default_488, [64, 128, 16, 64]);  view_default_488 = None
        permute_default_108 = torch.ops.aten.permute.default(view_default_489, [0, 2, 1, 3]);  view_default_489 = None
        clone_default_108 = torch.ops.aten.clone.default(permute_default_108, memory_format = torch.contiguous_format);  permute_default_108 = None
        _unsafe_view_default_132 = torch.ops.aten._unsafe_view.default(clone_default_108, [1024, 128, 64]);  clone_default_108 = None
        transpose_int_39 = torch.ops.aten.transpose.int(view_default_349, 1, 2);  view_default_349 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_39, _unsafe_view_default_132);  transpose_int_39 = None
        transpose_int_40 = torch.ops.aten.transpose.int(_unsafe_view_default_103, 1, 2);  _unsafe_view_default_103 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_132, transpose_int_40);  _unsafe_view_default_132 = transpose_int_40 = None
        view_default_490 = torch.ops.aten.view.default(bmm_default_60, [64, 16, 128, 64]);  bmm_default_60 = None
        view_default_491 = torch.ops.aten.view.default(bmm_default_61, [64, 16, 128, 128]);  bmm_default_61 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_491, _softmax_default_20, -1, torch.float32);  view_default_491 = _softmax_default_20 = None
        div_tensor_27 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_3, 8.0);  _softmax_backward_data_default_3 = None
        view_default_492 = torch.ops.aten.view.default(div_tensor_27, [1024, 128, 128]);  div_tensor_27 = None
        transpose_int_41 = torch.ops.aten.transpose.int(_unsafe_view_default_100, 1, 2);  _unsafe_view_default_100 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_41, view_default_492);  transpose_int_41 = None
        transpose_int_42 = torch.ops.aten.transpose.int(_unsafe_view_default_101, 1, 2);  _unsafe_view_default_101 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_492, transpose_int_42);  view_default_492 = transpose_int_42 = None
        view_default_493 = torch.ops.aten.view.default(bmm_default_62, [64, 16, 64, 128]);  bmm_default_62 = None
        view_default_494 = torch.ops.aten.view.default(bmm_default_63, [64, 16, 128, 64]);  bmm_default_63 = None
        transpose_int_43 = torch.ops.aten.transpose.int(view_default_493, -1, -2);  view_default_493 = None
        permute_default_109 = torch.ops.aten.permute.default(view_default_494, [0, 2, 1, 3]);  view_default_494 = None
        clone_default_109 = torch.ops.aten.clone.default(permute_default_109, memory_format = torch.contiguous_format);  permute_default_109 = None
        _unsafe_view_default_133 = torch.ops.aten._unsafe_view.default(clone_default_109, [64, 128, 1024]);  clone_default_109 = None
        permute_default_110 = torch.ops.aten.permute.default(view_default_490, [0, 2, 1, 3]);  view_default_490 = None
        clone_default_110 = torch.ops.aten.clone.default(permute_default_110, memory_format = torch.contiguous_format);  permute_default_110 = None
        _unsafe_view_default_134 = torch.ops.aten._unsafe_view.default(clone_default_110, [64, 128, 1024]);  clone_default_110 = None
        view_default_495 = torch.ops.aten.view.default(_unsafe_view_default_134, [8192, 1024]);  _unsafe_view_default_134 = None
        t_default_228 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_495, t_default_228);  t_default_228 = None
        t_default_229 = torch.ops.aten.t.default(view_default_495)
        mm_default_43 = torch.ops.aten.mm.default(t_default_229, view_default_345);  t_default_229 = view_default_345 = None
        t_default_230 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_495, [0], True);  view_default_495 = None
        view_default_496 = torch.ops.aten.view.default(sum_dim_int_list_21, [1024]);  sum_dim_int_list_21 = None
        t_default_231 = torch.ops.aten.t.default(t_default_230);  t_default_230 = None
        view_default_497 = torch.ops.aten.view.default(mm_default_42, [64, 128, 1024]);  mm_default_42 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(getitem_165, view_default_497);  getitem_165 = view_default_497 = None
        permute_default_111 = torch.ops.aten.permute.default(transpose_int_43, [0, 2, 1, 3]);  transpose_int_43 = None
        view_default_498 = torch.ops.aten.view.default(permute_default_111, [64, 128, 1024]);  permute_default_111 = None
        clone_default_111 = torch.ops.aten.clone.default(view_default_498, memory_format = torch.contiguous_format);  view_default_498 = None
        _unsafe_view_default_135 = torch.ops.aten._unsafe_view.default(clone_default_111, [8192, 1024]);  clone_default_111 = None
        t_default_232 = torch.ops.aten.t.default(t_default_121);  t_default_121 = None
        mm_default_44 = torch.ops.aten.mm.default(_unsafe_view_default_135, t_default_232);  t_default_232 = None
        t_default_233 = torch.ops.aten.t.default(_unsafe_view_default_135)
        mm_default_45 = torch.ops.aten.mm.default(t_default_233, view_default_342);  t_default_233 = view_default_342 = None
        t_default_234 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_135, [0], True);  _unsafe_view_default_135 = None
        view_default_499 = torch.ops.aten.view.default(sum_dim_int_list_22, [1024]);  sum_dim_int_list_22 = None
        t_default_235 = torch.ops.aten.t.default(t_default_234);  t_default_234 = None
        view_default_500 = torch.ops.aten.view.default(mm_default_44, [64, 128, 1024]);  mm_default_44 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(add_tensor_93, view_default_500);  add_tensor_93 = view_default_500 = None
        view_default_501 = torch.ops.aten.view.default(_unsafe_view_default_133, [8192, 1024]);  _unsafe_view_default_133 = None
        t_default_236 = torch.ops.aten.t.default(t_default_120);  t_default_120 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_501, t_default_236);  t_default_236 = None
        t_default_237 = torch.ops.aten.t.default(view_default_501)
        mm_default_47 = torch.ops.aten.mm.default(t_default_237, view_default_340);  t_default_237 = view_default_340 = None
        t_default_238 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_501, [0], True);  view_default_501 = None
        view_default_502 = torch.ops.aten.view.default(sum_dim_int_list_23, [1024]);  sum_dim_int_list_23 = None
        t_default_239 = torch.ops.aten.t.default(t_default_238);  t_default_238 = None
        view_default_503 = torch.ops.aten.view.default(mm_default_46, [64, 128, 1024]);  mm_default_46 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_94, view_default_503);  add_tensor_94 = view_default_503 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_95, add_tensor_59, [1024], getitem_118, getitem_119, primals_174, primals_173, [True, True, True]);  add_tensor_95 = add_tensor_59 = getitem_118 = getitem_119 = primals_174 = primals_173 = None
        getitem_168 = native_layer_norm_backward_default_8[0]
        getitem_169 = native_layer_norm_backward_default_8[1]
        getitem_170 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_504 = torch.ops.aten.view.default(getitem_168, [8192, 1024])
        t_default_240 = torch.ops.aten.t.default(t_default_119);  t_default_119 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_504, t_default_240);  t_default_240 = None
        t_default_241 = torch.ops.aten.t.default(view_default_504)
        mm_default_49 = torch.ops.aten.mm.default(t_default_241, view_default_338);  t_default_241 = view_default_338 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_504, [0], True);  view_default_504 = None
        view_default_505 = torch.ops.aten.view.default(sum_dim_int_list_24, [1024]);  sum_dim_int_list_24 = None
        t_default_243 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        view_default_506 = torch.ops.aten.view.default(mm_default_48, [64, 128, 4096]);  mm_default_48 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_506, torch.float32);  view_default_506 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_337, torch.float32);  view_default_337 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_28);  mul_tensor_28 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(add_tensor_96, 0.5);  add_tensor_96 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_30, -0.5);  mul_tensor_30 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_31);  mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_32);  to_dtype_13 = mul_tensor_32 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_29, mul_tensor_33);  mul_tensor_29 = mul_tensor_33 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_97);  to_dtype_12 = add_tensor_97 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_34, torch.float32);  mul_tensor_34 = None
        view_default_507 = torch.ops.aten.view.default(to_dtype_14, [8192, 4096]);  to_dtype_14 = None
        t_default_244 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_507, t_default_244);  t_default_244 = None
        t_default_245 = torch.ops.aten.t.default(view_default_507)
        mm_default_51 = torch.ops.aten.mm.default(t_default_245, view_default_336);  t_default_245 = view_default_336 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_507, [0], True);  view_default_507 = None
        view_default_508 = torch.ops.aten.view.default(sum_dim_int_list_25, [4096]);  sum_dim_int_list_25 = None
        t_default_247 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_509 = torch.ops.aten.view.default(mm_default_50, [64, 128, 1024]);  mm_default_50 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_168, view_default_509);  getitem_168 = view_default_509 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_98, add_tensor_58, [1024], getitem_115, getitem_116, primals_162, primals_161, [True, True, True]);  add_tensor_98 = add_tensor_58 = getitem_115 = getitem_116 = primals_162 = primals_161 = None
        getitem_171 = native_layer_norm_backward_default_9[0]
        getitem_172 = native_layer_norm_backward_default_9[1]
        getitem_173 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        view_default_510 = torch.ops.aten.view.default(getitem_171, [8192, 1024])
        t_default_248 = torch.ops.aten.t.default(t_default_117);  t_default_117 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_510, t_default_248);  t_default_248 = None
        t_default_249 = torch.ops.aten.t.default(view_default_510)
        mm_default_53 = torch.ops.aten.mm.default(t_default_249, view_default_334);  t_default_249 = view_default_334 = None
        t_default_250 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_510, [0], True);  view_default_510 = None
        view_default_511 = torch.ops.aten.view.default(sum_dim_int_list_26, [1024]);  sum_dim_int_list_26 = None
        t_default_251 = torch.ops.aten.t.default(t_default_250);  t_default_250 = None
        view_default_512 = torch.ops.aten.view.default(mm_default_52, [64, 128, 1024]);  mm_default_52 = None
        view_default_513 = torch.ops.aten.view.default(view_default_512, [64, 128, 16, 64]);  view_default_512 = None
        permute_default_112 = torch.ops.aten.permute.default(view_default_513, [0, 2, 1, 3]);  view_default_513 = None
        clone_default_112 = torch.ops.aten.clone.default(permute_default_112, memory_format = torch.contiguous_format);  permute_default_112 = None
        _unsafe_view_default_136 = torch.ops.aten._unsafe_view.default(clone_default_112, [1024, 128, 64]);  clone_default_112 = None
        transpose_int_44 = torch.ops.aten.transpose.int(view_default_332, 1, 2);  view_default_332 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_44, _unsafe_view_default_136);  transpose_int_44 = None
        transpose_int_45 = torch.ops.aten.transpose.int(_unsafe_view_default_98, 1, 2);  _unsafe_view_default_98 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_136, transpose_int_45);  _unsafe_view_default_136 = transpose_int_45 = None
        view_default_514 = torch.ops.aten.view.default(bmm_default_64, [64, 16, 128, 64]);  bmm_default_64 = None
        view_default_515 = torch.ops.aten.view.default(bmm_default_65, [64, 16, 128, 128]);  bmm_default_65 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_515, _softmax_default_19, -1, torch.float32);  view_default_515 = _softmax_default_19 = None
        div_tensor_28 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_4, 8.0);  _softmax_backward_data_default_4 = None
        view_default_516 = torch.ops.aten.view.default(div_tensor_28, [1024, 128, 128]);  div_tensor_28 = None
        transpose_int_46 = torch.ops.aten.transpose.int(_unsafe_view_default_95, 1, 2);  _unsafe_view_default_95 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_46, view_default_516);  transpose_int_46 = None
        transpose_int_47 = torch.ops.aten.transpose.int(_unsafe_view_default_96, 1, 2);  _unsafe_view_default_96 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_516, transpose_int_47);  view_default_516 = transpose_int_47 = None
        view_default_517 = torch.ops.aten.view.default(bmm_default_66, [64, 16, 64, 128]);  bmm_default_66 = None
        view_default_518 = torch.ops.aten.view.default(bmm_default_67, [64, 16, 128, 64]);  bmm_default_67 = None
        transpose_int_48 = torch.ops.aten.transpose.int(view_default_517, -1, -2);  view_default_517 = None
        permute_default_113 = torch.ops.aten.permute.default(view_default_518, [0, 2, 1, 3]);  view_default_518 = None
        clone_default_113 = torch.ops.aten.clone.default(permute_default_113, memory_format = torch.contiguous_format);  permute_default_113 = None
        _unsafe_view_default_137 = torch.ops.aten._unsafe_view.default(clone_default_113, [64, 128, 1024]);  clone_default_113 = None
        permute_default_114 = torch.ops.aten.permute.default(view_default_514, [0, 2, 1, 3]);  view_default_514 = None
        clone_default_114 = torch.ops.aten.clone.default(permute_default_114, memory_format = torch.contiguous_format);  permute_default_114 = None
        _unsafe_view_default_138 = torch.ops.aten._unsafe_view.default(clone_default_114, [64, 128, 1024]);  clone_default_114 = None
        view_default_519 = torch.ops.aten.view.default(_unsafe_view_default_138, [8192, 1024]);  _unsafe_view_default_138 = None
        t_default_252 = torch.ops.aten.t.default(t_default_116);  t_default_116 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_519, t_default_252);  t_default_252 = None
        t_default_253 = torch.ops.aten.t.default(view_default_519)
        mm_default_55 = torch.ops.aten.mm.default(t_default_253, view_default_328);  t_default_253 = view_default_328 = None
        t_default_254 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_519, [0], True);  view_default_519 = None
        view_default_520 = torch.ops.aten.view.default(sum_dim_int_list_27, [1024]);  sum_dim_int_list_27 = None
        t_default_255 = torch.ops.aten.t.default(t_default_254);  t_default_254 = None
        view_default_521 = torch.ops.aten.view.default(mm_default_54, [64, 128, 1024]);  mm_default_54 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(getitem_171, view_default_521);  getitem_171 = view_default_521 = None
        permute_default_115 = torch.ops.aten.permute.default(transpose_int_48, [0, 2, 1, 3]);  transpose_int_48 = None
        view_default_522 = torch.ops.aten.view.default(permute_default_115, [64, 128, 1024]);  permute_default_115 = None
        clone_default_115 = torch.ops.aten.clone.default(view_default_522, memory_format = torch.contiguous_format);  view_default_522 = None
        _unsafe_view_default_139 = torch.ops.aten._unsafe_view.default(clone_default_115, [8192, 1024]);  clone_default_115 = None
        t_default_256 = torch.ops.aten.t.default(t_default_115);  t_default_115 = None
        mm_default_56 = torch.ops.aten.mm.default(_unsafe_view_default_139, t_default_256);  t_default_256 = None
        t_default_257 = torch.ops.aten.t.default(_unsafe_view_default_139)
        mm_default_57 = torch.ops.aten.mm.default(t_default_257, view_default_325);  t_default_257 = view_default_325 = None
        t_default_258 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_139, [0], True);  _unsafe_view_default_139 = None
        view_default_523 = torch.ops.aten.view.default(sum_dim_int_list_28, [1024]);  sum_dim_int_list_28 = None
        t_default_259 = torch.ops.aten.t.default(t_default_258);  t_default_258 = None
        view_default_524 = torch.ops.aten.view.default(mm_default_56, [64, 128, 1024]);  mm_default_56 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_99, view_default_524);  add_tensor_99 = view_default_524 = None
        view_default_525 = torch.ops.aten.view.default(_unsafe_view_default_137, [8192, 1024]);  _unsafe_view_default_137 = None
        t_default_260 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_525, t_default_260);  t_default_260 = None
        t_default_261 = torch.ops.aten.t.default(view_default_525)
        mm_default_59 = torch.ops.aten.mm.default(t_default_261, view_default_323);  t_default_261 = view_default_323 = None
        t_default_262 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_525, [0], True);  view_default_525 = None
        view_default_526 = torch.ops.aten.view.default(sum_dim_int_list_29, [1024]);  sum_dim_int_list_29 = None
        t_default_263 = torch.ops.aten.t.default(t_default_262);  t_default_262 = None
        view_default_527 = torch.ops.aten.view.default(mm_default_58, [64, 128, 1024]);  mm_default_58 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_100, view_default_527);  add_tensor_100 = view_default_527 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_101, add_tensor_56, [1024], getitem_112, getitem_113, primals_158, primals_157, [True, True, True]);  add_tensor_101 = add_tensor_56 = getitem_112 = getitem_113 = primals_158 = primals_157 = None
        getitem_174 = native_layer_norm_backward_default_10[0]
        getitem_175 = native_layer_norm_backward_default_10[1]
        getitem_176 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_528 = torch.ops.aten.view.default(getitem_174, [8192, 1024])
        t_default_264 = torch.ops.aten.t.default(t_default_113);  t_default_113 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_528, t_default_264);  t_default_264 = None
        t_default_265 = torch.ops.aten.t.default(view_default_528)
        mm_default_61 = torch.ops.aten.mm.default(t_default_265, view_default_321);  t_default_265 = view_default_321 = None
        t_default_266 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_528, [0], True);  view_default_528 = None
        view_default_529 = torch.ops.aten.view.default(sum_dim_int_list_30, [1024]);  sum_dim_int_list_30 = None
        t_default_267 = torch.ops.aten.t.default(t_default_266);  t_default_266 = None
        view_default_530 = torch.ops.aten.view.default(mm_default_60, [64, 128, 4096]);  mm_default_60 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_530, torch.float32);  view_default_530 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_320, torch.float32);  view_default_320 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_35);  mul_tensor_35 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(add_tensor_102, 0.5);  add_tensor_102 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(mul_tensor_37, -0.5);  mul_tensor_37 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_38);  mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_39);  to_dtype_16 = mul_tensor_39 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(mul_tensor_36, mul_tensor_40);  mul_tensor_36 = mul_tensor_40 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_103);  to_dtype_15 = add_tensor_103 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_41, torch.float32);  mul_tensor_41 = None
        view_default_531 = torch.ops.aten.view.default(to_dtype_17, [8192, 4096]);  to_dtype_17 = None
        t_default_268 = torch.ops.aten.t.default(t_default_112);  t_default_112 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_531, t_default_268);  t_default_268 = None
        t_default_269 = torch.ops.aten.t.default(view_default_531)
        mm_default_63 = torch.ops.aten.mm.default(t_default_269, view_default_319);  t_default_269 = view_default_319 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_531, [0], True);  view_default_531 = None
        view_default_532 = torch.ops.aten.view.default(sum_dim_int_list_31, [4096]);  sum_dim_int_list_31 = None
        t_default_271 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_533 = torch.ops.aten.view.default(mm_default_62, [64, 128, 1024]);  mm_default_62 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(getitem_174, view_default_533);  getitem_174 = view_default_533 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_104, add_tensor_55, [1024], getitem_109, getitem_110, primals_146, primals_145, [True, True, True]);  add_tensor_104 = add_tensor_55 = getitem_109 = getitem_110 = primals_146 = primals_145 = None
        getitem_177 = native_layer_norm_backward_default_11[0]
        getitem_178 = native_layer_norm_backward_default_11[1]
        getitem_179 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_534 = torch.ops.aten.view.default(getitem_177, [8192, 1024])
        t_default_272 = torch.ops.aten.t.default(t_default_111);  t_default_111 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_534, t_default_272);  t_default_272 = None
        t_default_273 = torch.ops.aten.t.default(view_default_534)
        mm_default_65 = torch.ops.aten.mm.default(t_default_273, view_default_317);  t_default_273 = view_default_317 = None
        t_default_274 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_534, [0], True);  view_default_534 = None
        view_default_535 = torch.ops.aten.view.default(sum_dim_int_list_32, [1024]);  sum_dim_int_list_32 = None
        t_default_275 = torch.ops.aten.t.default(t_default_274);  t_default_274 = None
        view_default_536 = torch.ops.aten.view.default(mm_default_64, [64, 128, 1024]);  mm_default_64 = None
        view_default_537 = torch.ops.aten.view.default(view_default_536, [64, 128, 16, 64]);  view_default_536 = None
        permute_default_116 = torch.ops.aten.permute.default(view_default_537, [0, 2, 1, 3]);  view_default_537 = None
        clone_default_116 = torch.ops.aten.clone.default(permute_default_116, memory_format = torch.contiguous_format);  permute_default_116 = None
        _unsafe_view_default_140 = torch.ops.aten._unsafe_view.default(clone_default_116, [1024, 128, 64]);  clone_default_116 = None
        transpose_int_49 = torch.ops.aten.transpose.int(view_default_315, 1, 2);  view_default_315 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_49, _unsafe_view_default_140);  transpose_int_49 = None
        transpose_int_50 = torch.ops.aten.transpose.int(_unsafe_view_default_93, 1, 2);  _unsafe_view_default_93 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_140, transpose_int_50);  _unsafe_view_default_140 = transpose_int_50 = None
        view_default_538 = torch.ops.aten.view.default(bmm_default_68, [64, 16, 128, 64]);  bmm_default_68 = None
        view_default_539 = torch.ops.aten.view.default(bmm_default_69, [64, 16, 128, 128]);  bmm_default_69 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_539, _softmax_default_18, -1, torch.float32);  view_default_539 = _softmax_default_18 = None
        div_tensor_29 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_5, 8.0);  _softmax_backward_data_default_5 = None
        view_default_540 = torch.ops.aten.view.default(div_tensor_29, [1024, 128, 128]);  div_tensor_29 = None
        transpose_int_51 = torch.ops.aten.transpose.int(_unsafe_view_default_90, 1, 2);  _unsafe_view_default_90 = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_51, view_default_540);  transpose_int_51 = None
        transpose_int_52 = torch.ops.aten.transpose.int(_unsafe_view_default_91, 1, 2);  _unsafe_view_default_91 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_540, transpose_int_52);  view_default_540 = transpose_int_52 = None
        view_default_541 = torch.ops.aten.view.default(bmm_default_70, [64, 16, 64, 128]);  bmm_default_70 = None
        view_default_542 = torch.ops.aten.view.default(bmm_default_71, [64, 16, 128, 64]);  bmm_default_71 = None
        transpose_int_53 = torch.ops.aten.transpose.int(view_default_541, -1, -2);  view_default_541 = None
        permute_default_117 = torch.ops.aten.permute.default(view_default_542, [0, 2, 1, 3]);  view_default_542 = None
        clone_default_117 = torch.ops.aten.clone.default(permute_default_117, memory_format = torch.contiguous_format);  permute_default_117 = None
        _unsafe_view_default_141 = torch.ops.aten._unsafe_view.default(clone_default_117, [64, 128, 1024]);  clone_default_117 = None
        permute_default_118 = torch.ops.aten.permute.default(view_default_538, [0, 2, 1, 3]);  view_default_538 = None
        clone_default_118 = torch.ops.aten.clone.default(permute_default_118, memory_format = torch.contiguous_format);  permute_default_118 = None
        _unsafe_view_default_142 = torch.ops.aten._unsafe_view.default(clone_default_118, [64, 128, 1024]);  clone_default_118 = None
        view_default_543 = torch.ops.aten.view.default(_unsafe_view_default_142, [8192, 1024]);  _unsafe_view_default_142 = None
        t_default_276 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_543, t_default_276);  t_default_276 = None
        t_default_277 = torch.ops.aten.t.default(view_default_543)
        mm_default_67 = torch.ops.aten.mm.default(t_default_277, view_default_311);  t_default_277 = view_default_311 = None
        t_default_278 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_543, [0], True);  view_default_543 = None
        view_default_544 = torch.ops.aten.view.default(sum_dim_int_list_33, [1024]);  sum_dim_int_list_33 = None
        t_default_279 = torch.ops.aten.t.default(t_default_278);  t_default_278 = None
        view_default_545 = torch.ops.aten.view.default(mm_default_66, [64, 128, 1024]);  mm_default_66 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(getitem_177, view_default_545);  getitem_177 = view_default_545 = None
        permute_default_119 = torch.ops.aten.permute.default(transpose_int_53, [0, 2, 1, 3]);  transpose_int_53 = None
        view_default_546 = torch.ops.aten.view.default(permute_default_119, [64, 128, 1024]);  permute_default_119 = None
        clone_default_119 = torch.ops.aten.clone.default(view_default_546, memory_format = torch.contiguous_format);  view_default_546 = None
        _unsafe_view_default_143 = torch.ops.aten._unsafe_view.default(clone_default_119, [8192, 1024]);  clone_default_119 = None
        t_default_280 = torch.ops.aten.t.default(t_default_109);  t_default_109 = None
        mm_default_68 = torch.ops.aten.mm.default(_unsafe_view_default_143, t_default_280);  t_default_280 = None
        t_default_281 = torch.ops.aten.t.default(_unsafe_view_default_143)
        mm_default_69 = torch.ops.aten.mm.default(t_default_281, view_default_308);  t_default_281 = view_default_308 = None
        t_default_282 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_143, [0], True);  _unsafe_view_default_143 = None
        view_default_547 = torch.ops.aten.view.default(sum_dim_int_list_34, [1024]);  sum_dim_int_list_34 = None
        t_default_283 = torch.ops.aten.t.default(t_default_282);  t_default_282 = None
        view_default_548 = torch.ops.aten.view.default(mm_default_68, [64, 128, 1024]);  mm_default_68 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_105, view_default_548);  add_tensor_105 = view_default_548 = None
        view_default_549 = torch.ops.aten.view.default(_unsafe_view_default_141, [8192, 1024]);  _unsafe_view_default_141 = None
        t_default_284 = torch.ops.aten.t.default(t_default_108);  t_default_108 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_549, t_default_284);  t_default_284 = None
        t_default_285 = torch.ops.aten.t.default(view_default_549)
        mm_default_71 = torch.ops.aten.mm.default(t_default_285, view_default_306);  t_default_285 = view_default_306 = None
        t_default_286 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_549, [0], True);  view_default_549 = None
        view_default_550 = torch.ops.aten.view.default(sum_dim_int_list_35, [1024]);  sum_dim_int_list_35 = None
        t_default_287 = torch.ops.aten.t.default(t_default_286);  t_default_286 = None
        view_default_551 = torch.ops.aten.view.default(mm_default_70, [64, 128, 1024]);  mm_default_70 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_106, view_default_551);  add_tensor_106 = view_default_551 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_107, add_tensor_53, [1024], getitem_106, getitem_107, primals_142, primals_141, [True, True, True]);  add_tensor_107 = add_tensor_53 = getitem_106 = getitem_107 = primals_142 = primals_141 = None
        getitem_180 = native_layer_norm_backward_default_12[0]
        getitem_181 = native_layer_norm_backward_default_12[1]
        getitem_182 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        view_default_552 = torch.ops.aten.view.default(getitem_180, [8192, 1024])
        t_default_288 = torch.ops.aten.t.default(t_default_107);  t_default_107 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_552, t_default_288);  t_default_288 = None
        t_default_289 = torch.ops.aten.t.default(view_default_552)
        mm_default_73 = torch.ops.aten.mm.default(t_default_289, view_default_304);  t_default_289 = view_default_304 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_552, [0], True);  view_default_552 = None
        view_default_553 = torch.ops.aten.view.default(sum_dim_int_list_36, [1024]);  sum_dim_int_list_36 = None
        t_default_291 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_554 = torch.ops.aten.view.default(mm_default_72, [64, 128, 4096]);  mm_default_72 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_554, torch.float32);  view_default_554 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_303, torch.float32);  view_default_303 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_42);  mul_tensor_42 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(add_tensor_108, 0.5);  add_tensor_108 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(mul_tensor_44, -0.5);  mul_tensor_44 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_45);  mul_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_46);  to_dtype_19 = mul_tensor_46 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(mul_tensor_43, mul_tensor_47);  mul_tensor_43 = mul_tensor_47 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_109);  to_dtype_18 = add_tensor_109 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_48, torch.float32);  mul_tensor_48 = None
        view_default_555 = torch.ops.aten.view.default(to_dtype_20, [8192, 4096]);  to_dtype_20 = None
        t_default_292 = torch.ops.aten.t.default(t_default_106);  t_default_106 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_555, t_default_292);  t_default_292 = None
        t_default_293 = torch.ops.aten.t.default(view_default_555)
        mm_default_75 = torch.ops.aten.mm.default(t_default_293, view_default_302);  t_default_293 = view_default_302 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_555, [0], True);  view_default_555 = None
        view_default_556 = torch.ops.aten.view.default(sum_dim_int_list_37, [4096]);  sum_dim_int_list_37 = None
        t_default_295 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        view_default_557 = torch.ops.aten.view.default(mm_default_74, [64, 128, 1024]);  mm_default_74 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(getitem_180, view_default_557);  getitem_180 = view_default_557 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_110, add_tensor_52, [1024], getitem_103, getitem_104, primals_130, primals_129, [True, True, True]);  add_tensor_110 = add_tensor_52 = getitem_103 = getitem_104 = primals_130 = primals_129 = None
        getitem_183 = native_layer_norm_backward_default_13[0]
        getitem_184 = native_layer_norm_backward_default_13[1]
        getitem_185 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        view_default_558 = torch.ops.aten.view.default(getitem_183, [8192, 1024])
        t_default_296 = torch.ops.aten.t.default(t_default_105);  t_default_105 = None
        mm_default_76 = torch.ops.aten.mm.default(view_default_558, t_default_296);  t_default_296 = None
        t_default_297 = torch.ops.aten.t.default(view_default_558)
        mm_default_77 = torch.ops.aten.mm.default(t_default_297, view_default_300);  t_default_297 = view_default_300 = None
        t_default_298 = torch.ops.aten.t.default(mm_default_77);  mm_default_77 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(view_default_558, [0], True);  view_default_558 = None
        view_default_559 = torch.ops.aten.view.default(sum_dim_int_list_38, [1024]);  sum_dim_int_list_38 = None
        t_default_299 = torch.ops.aten.t.default(t_default_298);  t_default_298 = None
        view_default_560 = torch.ops.aten.view.default(mm_default_76, [64, 128, 1024]);  mm_default_76 = None
        view_default_561 = torch.ops.aten.view.default(view_default_560, [64, 128, 16, 64]);  view_default_560 = None
        permute_default_120 = torch.ops.aten.permute.default(view_default_561, [0, 2, 1, 3]);  view_default_561 = None
        clone_default_120 = torch.ops.aten.clone.default(permute_default_120, memory_format = torch.contiguous_format);  permute_default_120 = None
        _unsafe_view_default_144 = torch.ops.aten._unsafe_view.default(clone_default_120, [1024, 128, 64]);  clone_default_120 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_298, 1, 2);  view_default_298 = None
        bmm_default_72 = torch.ops.aten.bmm.default(transpose_int_54, _unsafe_view_default_144);  transpose_int_54 = None
        transpose_int_55 = torch.ops.aten.transpose.int(_unsafe_view_default_88, 1, 2);  _unsafe_view_default_88 = None
        bmm_default_73 = torch.ops.aten.bmm.default(_unsafe_view_default_144, transpose_int_55);  _unsafe_view_default_144 = transpose_int_55 = None
        view_default_562 = torch.ops.aten.view.default(bmm_default_72, [64, 16, 128, 64]);  bmm_default_72 = None
        view_default_563 = torch.ops.aten.view.default(bmm_default_73, [64, 16, 128, 128]);  bmm_default_73 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_563, _softmax_default_17, -1, torch.float32);  view_default_563 = _softmax_default_17 = None
        div_tensor_30 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_6, 8.0);  _softmax_backward_data_default_6 = None
        view_default_564 = torch.ops.aten.view.default(div_tensor_30, [1024, 128, 128]);  div_tensor_30 = None
        transpose_int_56 = torch.ops.aten.transpose.int(_unsafe_view_default_85, 1, 2);  _unsafe_view_default_85 = None
        bmm_default_74 = torch.ops.aten.bmm.default(transpose_int_56, view_default_564);  transpose_int_56 = None
        transpose_int_57 = torch.ops.aten.transpose.int(_unsafe_view_default_86, 1, 2);  _unsafe_view_default_86 = None
        bmm_default_75 = torch.ops.aten.bmm.default(view_default_564, transpose_int_57);  view_default_564 = transpose_int_57 = None
        view_default_565 = torch.ops.aten.view.default(bmm_default_74, [64, 16, 64, 128]);  bmm_default_74 = None
        view_default_566 = torch.ops.aten.view.default(bmm_default_75, [64, 16, 128, 64]);  bmm_default_75 = None
        transpose_int_58 = torch.ops.aten.transpose.int(view_default_565, -1, -2);  view_default_565 = None
        permute_default_121 = torch.ops.aten.permute.default(view_default_566, [0, 2, 1, 3]);  view_default_566 = None
        clone_default_121 = torch.ops.aten.clone.default(permute_default_121, memory_format = torch.contiguous_format);  permute_default_121 = None
        _unsafe_view_default_145 = torch.ops.aten._unsafe_view.default(clone_default_121, [64, 128, 1024]);  clone_default_121 = None
        permute_default_122 = torch.ops.aten.permute.default(view_default_562, [0, 2, 1, 3]);  view_default_562 = None
        clone_default_122 = torch.ops.aten.clone.default(permute_default_122, memory_format = torch.contiguous_format);  permute_default_122 = None
        _unsafe_view_default_146 = torch.ops.aten._unsafe_view.default(clone_default_122, [64, 128, 1024]);  clone_default_122 = None
        view_default_567 = torch.ops.aten.view.default(_unsafe_view_default_146, [8192, 1024]);  _unsafe_view_default_146 = None
        t_default_300 = torch.ops.aten.t.default(t_default_104);  t_default_104 = None
        mm_default_78 = torch.ops.aten.mm.default(view_default_567, t_default_300);  t_default_300 = None
        t_default_301 = torch.ops.aten.t.default(view_default_567)
        mm_default_79 = torch.ops.aten.mm.default(t_default_301, view_default_294);  t_default_301 = view_default_294 = None
        t_default_302 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(view_default_567, [0], True);  view_default_567 = None
        view_default_568 = torch.ops.aten.view.default(sum_dim_int_list_39, [1024]);  sum_dim_int_list_39 = None
        t_default_303 = torch.ops.aten.t.default(t_default_302);  t_default_302 = None
        view_default_569 = torch.ops.aten.view.default(mm_default_78, [64, 128, 1024]);  mm_default_78 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(getitem_183, view_default_569);  getitem_183 = view_default_569 = None
        permute_default_123 = torch.ops.aten.permute.default(transpose_int_58, [0, 2, 1, 3]);  transpose_int_58 = None
        view_default_570 = torch.ops.aten.view.default(permute_default_123, [64, 128, 1024]);  permute_default_123 = None
        clone_default_123 = torch.ops.aten.clone.default(view_default_570, memory_format = torch.contiguous_format);  view_default_570 = None
        _unsafe_view_default_147 = torch.ops.aten._unsafe_view.default(clone_default_123, [8192, 1024]);  clone_default_123 = None
        t_default_304 = torch.ops.aten.t.default(t_default_103);  t_default_103 = None
        mm_default_80 = torch.ops.aten.mm.default(_unsafe_view_default_147, t_default_304);  t_default_304 = None
        t_default_305 = torch.ops.aten.t.default(_unsafe_view_default_147)
        mm_default_81 = torch.ops.aten.mm.default(t_default_305, view_default_291);  t_default_305 = view_default_291 = None
        t_default_306 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_147, [0], True);  _unsafe_view_default_147 = None
        view_default_571 = torch.ops.aten.view.default(sum_dim_int_list_40, [1024]);  sum_dim_int_list_40 = None
        t_default_307 = torch.ops.aten.t.default(t_default_306);  t_default_306 = None
        view_default_572 = torch.ops.aten.view.default(mm_default_80, [64, 128, 1024]);  mm_default_80 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_111, view_default_572);  add_tensor_111 = view_default_572 = None
        view_default_573 = torch.ops.aten.view.default(_unsafe_view_default_145, [8192, 1024]);  _unsafe_view_default_145 = None
        t_default_308 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_573, t_default_308);  t_default_308 = None
        t_default_309 = torch.ops.aten.t.default(view_default_573)
        mm_default_83 = torch.ops.aten.mm.default(t_default_309, view_default_289);  t_default_309 = view_default_289 = None
        t_default_310 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(view_default_573, [0], True);  view_default_573 = None
        view_default_574 = torch.ops.aten.view.default(sum_dim_int_list_41, [1024]);  sum_dim_int_list_41 = None
        t_default_311 = torch.ops.aten.t.default(t_default_310);  t_default_310 = None
        view_default_575 = torch.ops.aten.view.default(mm_default_82, [64, 128, 1024]);  mm_default_82 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_112, view_default_575);  add_tensor_112 = view_default_575 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_113, add_tensor_50, [1024], getitem_100, getitem_101, primals_126, primals_125, [True, True, True]);  add_tensor_113 = add_tensor_50 = getitem_100 = getitem_101 = primals_126 = primals_125 = None
        getitem_186 = native_layer_norm_backward_default_14[0]
        getitem_187 = native_layer_norm_backward_default_14[1]
        getitem_188 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_576 = torch.ops.aten.view.default(getitem_186, [8192, 1024])
        t_default_312 = torch.ops.aten.t.default(t_default_101);  t_default_101 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_576, t_default_312);  t_default_312 = None
        t_default_313 = torch.ops.aten.t.default(view_default_576)
        mm_default_85 = torch.ops.aten.mm.default(t_default_313, view_default_287);  t_default_313 = view_default_287 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_576, [0], True);  view_default_576 = None
        view_default_577 = torch.ops.aten.view.default(sum_dim_int_list_42, [1024]);  sum_dim_int_list_42 = None
        t_default_315 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_578 = torch.ops.aten.view.default(mm_default_84, [64, 128, 4096]);  mm_default_84 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_578, torch.float32);  view_default_578 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_286, torch.float32);  view_default_286 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_49);  mul_tensor_49 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(add_tensor_114, 0.5);  add_tensor_114 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_52 = torch.ops.aten.mul.Tensor(mul_tensor_51, -0.5);  mul_tensor_51 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_52);  mul_tensor_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_53);  to_dtype_22 = mul_tensor_53 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(mul_tensor_50, mul_tensor_54);  mul_tensor_50 = mul_tensor_54 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_115);  to_dtype_21 = add_tensor_115 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_55, torch.float32);  mul_tensor_55 = None
        view_default_579 = torch.ops.aten.view.default(to_dtype_23, [8192, 4096]);  to_dtype_23 = None
        t_default_316 = torch.ops.aten.t.default(t_default_100);  t_default_100 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_579, t_default_316);  t_default_316 = None
        t_default_317 = torch.ops.aten.t.default(view_default_579)
        mm_default_87 = torch.ops.aten.mm.default(t_default_317, view_default_285);  t_default_317 = view_default_285 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_579, [0], True);  view_default_579 = None
        view_default_580 = torch.ops.aten.view.default(sum_dim_int_list_43, [4096]);  sum_dim_int_list_43 = None
        t_default_319 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        view_default_581 = torch.ops.aten.view.default(mm_default_86, [64, 128, 1024]);  mm_default_86 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(getitem_186, view_default_581);  getitem_186 = view_default_581 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_116, add_tensor_49, [1024], getitem_97, getitem_98, primals_114, primals_113, [True, True, True]);  add_tensor_116 = add_tensor_49 = getitem_97 = getitem_98 = primals_114 = primals_113 = None
        getitem_189 = native_layer_norm_backward_default_15[0]
        getitem_190 = native_layer_norm_backward_default_15[1]
        getitem_191 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        view_default_582 = torch.ops.aten.view.default(getitem_189, [8192, 1024])
        t_default_320 = torch.ops.aten.t.default(t_default_99);  t_default_99 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_582, t_default_320);  t_default_320 = None
        t_default_321 = torch.ops.aten.t.default(view_default_582)
        mm_default_89 = torch.ops.aten.mm.default(t_default_321, view_default_283);  t_default_321 = view_default_283 = None
        t_default_322 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_582, [0], True);  view_default_582 = None
        view_default_583 = torch.ops.aten.view.default(sum_dim_int_list_44, [1024]);  sum_dim_int_list_44 = None
        t_default_323 = torch.ops.aten.t.default(t_default_322);  t_default_322 = None
        view_default_584 = torch.ops.aten.view.default(mm_default_88, [64, 128, 1024]);  mm_default_88 = None
        view_default_585 = torch.ops.aten.view.default(view_default_584, [64, 128, 16, 64]);  view_default_584 = None
        permute_default_124 = torch.ops.aten.permute.default(view_default_585, [0, 2, 1, 3]);  view_default_585 = None
        clone_default_124 = torch.ops.aten.clone.default(permute_default_124, memory_format = torch.contiguous_format);  permute_default_124 = None
        _unsafe_view_default_148 = torch.ops.aten._unsafe_view.default(clone_default_124, [1024, 128, 64]);  clone_default_124 = None
        transpose_int_59 = torch.ops.aten.transpose.int(view_default_281, 1, 2);  view_default_281 = None
        bmm_default_76 = torch.ops.aten.bmm.default(transpose_int_59, _unsafe_view_default_148);  transpose_int_59 = None
        transpose_int_60 = torch.ops.aten.transpose.int(_unsafe_view_default_83, 1, 2);  _unsafe_view_default_83 = None
        bmm_default_77 = torch.ops.aten.bmm.default(_unsafe_view_default_148, transpose_int_60);  _unsafe_view_default_148 = transpose_int_60 = None
        view_default_586 = torch.ops.aten.view.default(bmm_default_76, [64, 16, 128, 64]);  bmm_default_76 = None
        view_default_587 = torch.ops.aten.view.default(bmm_default_77, [64, 16, 128, 128]);  bmm_default_77 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_587, _softmax_default_16, -1, torch.float32);  view_default_587 = _softmax_default_16 = None
        div_tensor_31 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_7, 8.0);  _softmax_backward_data_default_7 = None
        view_default_588 = torch.ops.aten.view.default(div_tensor_31, [1024, 128, 128]);  div_tensor_31 = None
        transpose_int_61 = torch.ops.aten.transpose.int(_unsafe_view_default_80, 1, 2);  _unsafe_view_default_80 = None
        bmm_default_78 = torch.ops.aten.bmm.default(transpose_int_61, view_default_588);  transpose_int_61 = None
        transpose_int_62 = torch.ops.aten.transpose.int(_unsafe_view_default_81, 1, 2);  _unsafe_view_default_81 = None
        bmm_default_79 = torch.ops.aten.bmm.default(view_default_588, transpose_int_62);  view_default_588 = transpose_int_62 = None
        view_default_589 = torch.ops.aten.view.default(bmm_default_78, [64, 16, 64, 128]);  bmm_default_78 = None
        view_default_590 = torch.ops.aten.view.default(bmm_default_79, [64, 16, 128, 64]);  bmm_default_79 = None
        transpose_int_63 = torch.ops.aten.transpose.int(view_default_589, -1, -2);  view_default_589 = None
        permute_default_125 = torch.ops.aten.permute.default(view_default_590, [0, 2, 1, 3]);  view_default_590 = None
        clone_default_125 = torch.ops.aten.clone.default(permute_default_125, memory_format = torch.contiguous_format);  permute_default_125 = None
        _unsafe_view_default_149 = torch.ops.aten._unsafe_view.default(clone_default_125, [64, 128, 1024]);  clone_default_125 = None
        permute_default_126 = torch.ops.aten.permute.default(view_default_586, [0, 2, 1, 3]);  view_default_586 = None
        clone_default_126 = torch.ops.aten.clone.default(permute_default_126, memory_format = torch.contiguous_format);  permute_default_126 = None
        _unsafe_view_default_150 = torch.ops.aten._unsafe_view.default(clone_default_126, [64, 128, 1024]);  clone_default_126 = None
        view_default_591 = torch.ops.aten.view.default(_unsafe_view_default_150, [8192, 1024]);  _unsafe_view_default_150 = None
        t_default_324 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_591, t_default_324);  t_default_324 = None
        t_default_325 = torch.ops.aten.t.default(view_default_591)
        mm_default_91 = torch.ops.aten.mm.default(t_default_325, view_default_277);  t_default_325 = view_default_277 = None
        t_default_326 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(view_default_591, [0], True);  view_default_591 = None
        view_default_592 = torch.ops.aten.view.default(sum_dim_int_list_45, [1024]);  sum_dim_int_list_45 = None
        t_default_327 = torch.ops.aten.t.default(t_default_326);  t_default_326 = None
        view_default_593 = torch.ops.aten.view.default(mm_default_90, [64, 128, 1024]);  mm_default_90 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(getitem_189, view_default_593);  getitem_189 = view_default_593 = None
        permute_default_127 = torch.ops.aten.permute.default(transpose_int_63, [0, 2, 1, 3]);  transpose_int_63 = None
        view_default_594 = torch.ops.aten.view.default(permute_default_127, [64, 128, 1024]);  permute_default_127 = None
        clone_default_127 = torch.ops.aten.clone.default(view_default_594, memory_format = torch.contiguous_format);  view_default_594 = None
        _unsafe_view_default_151 = torch.ops.aten._unsafe_view.default(clone_default_127, [8192, 1024]);  clone_default_127 = None
        t_default_328 = torch.ops.aten.t.default(t_default_97);  t_default_97 = None
        mm_default_92 = torch.ops.aten.mm.default(_unsafe_view_default_151, t_default_328);  t_default_328 = None
        t_default_329 = torch.ops.aten.t.default(_unsafe_view_default_151)
        mm_default_93 = torch.ops.aten.mm.default(t_default_329, view_default_274);  t_default_329 = view_default_274 = None
        t_default_330 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_151, [0], True);  _unsafe_view_default_151 = None
        view_default_595 = torch.ops.aten.view.default(sum_dim_int_list_46, [1024]);  sum_dim_int_list_46 = None
        t_default_331 = torch.ops.aten.t.default(t_default_330);  t_default_330 = None
        view_default_596 = torch.ops.aten.view.default(mm_default_92, [64, 128, 1024]);  mm_default_92 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(add_tensor_117, view_default_596);  add_tensor_117 = view_default_596 = None
        view_default_597 = torch.ops.aten.view.default(_unsafe_view_default_149, [8192, 1024]);  _unsafe_view_default_149 = None
        t_default_332 = torch.ops.aten.t.default(t_default_96);  t_default_96 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_597, t_default_332);  t_default_332 = None
        t_default_333 = torch.ops.aten.t.default(view_default_597)
        mm_default_95 = torch.ops.aten.mm.default(t_default_333, view_default_272);  t_default_333 = view_default_272 = None
        t_default_334 = torch.ops.aten.t.default(mm_default_95);  mm_default_95 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(view_default_597, [0], True);  view_default_597 = None
        view_default_598 = torch.ops.aten.view.default(sum_dim_int_list_47, [1024]);  sum_dim_int_list_47 = None
        t_default_335 = torch.ops.aten.t.default(t_default_334);  t_default_334 = None
        view_default_599 = torch.ops.aten.view.default(mm_default_94, [64, 128, 1024]);  mm_default_94 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(add_tensor_118, view_default_599);  add_tensor_118 = view_default_599 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_119, add_tensor_47, [1024], getitem_94, getitem_95, primals_110, primals_109, [True, True, True]);  add_tensor_119 = add_tensor_47 = getitem_94 = getitem_95 = primals_110 = primals_109 = None
        getitem_192 = native_layer_norm_backward_default_16[0]
        getitem_193 = native_layer_norm_backward_default_16[1]
        getitem_194 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_600 = torch.ops.aten.view.default(getitem_192, [8192, 1024])
        t_default_336 = torch.ops.aten.t.default(t_default_95);  t_default_95 = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_600, t_default_336);  t_default_336 = None
        t_default_337 = torch.ops.aten.t.default(view_default_600)
        mm_default_97 = torch.ops.aten.mm.default(t_default_337, view_default_270);  t_default_337 = view_default_270 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_600, [0], True);  view_default_600 = None
        view_default_601 = torch.ops.aten.view.default(sum_dim_int_list_48, [1024]);  sum_dim_int_list_48 = None
        t_default_339 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        view_default_602 = torch.ops.aten.view.default(mm_default_96, [64, 128, 4096]);  mm_default_96 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_602, torch.float32);  view_default_602 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_269, torch.float32);  view_default_269 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_56);  mul_tensor_56 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(add_tensor_120, 0.5);  add_tensor_120 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_59 = torch.ops.aten.mul.Tensor(mul_tensor_58, -0.5);  mul_tensor_58 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_59);  mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_60);  to_dtype_25 = mul_tensor_60 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(mul_tensor_57, mul_tensor_61);  mul_tensor_57 = mul_tensor_61 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_121);  to_dtype_24 = add_tensor_121 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_62, torch.float32);  mul_tensor_62 = None
        view_default_603 = torch.ops.aten.view.default(to_dtype_26, [8192, 4096]);  to_dtype_26 = None
        t_default_340 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        mm_default_98 = torch.ops.aten.mm.default(view_default_603, t_default_340);  t_default_340 = None
        t_default_341 = torch.ops.aten.t.default(view_default_603)
        mm_default_99 = torch.ops.aten.mm.default(t_default_341, view_default_268);  t_default_341 = view_default_268 = None
        t_default_342 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(view_default_603, [0], True);  view_default_603 = None
        view_default_604 = torch.ops.aten.view.default(sum_dim_int_list_49, [4096]);  sum_dim_int_list_49 = None
        t_default_343 = torch.ops.aten.t.default(t_default_342);  t_default_342 = None
        view_default_605 = torch.ops.aten.view.default(mm_default_98, [64, 128, 1024]);  mm_default_98 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(getitem_192, view_default_605);  getitem_192 = view_default_605 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_122, add_tensor_46, [1024], getitem_91, getitem_92, primals_98, primals_97, [True, True, True]);  add_tensor_122 = add_tensor_46 = getitem_91 = getitem_92 = primals_98 = primals_97 = None
        getitem_195 = native_layer_norm_backward_default_17[0]
        getitem_196 = native_layer_norm_backward_default_17[1]
        getitem_197 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        view_default_606 = torch.ops.aten.view.default(getitem_195, [8192, 1024])
        t_default_344 = torch.ops.aten.t.default(t_default_93);  t_default_93 = None
        mm_default_100 = torch.ops.aten.mm.default(view_default_606, t_default_344);  t_default_344 = None
        t_default_345 = torch.ops.aten.t.default(view_default_606)
        mm_default_101 = torch.ops.aten.mm.default(t_default_345, view_default_266);  t_default_345 = view_default_266 = None
        t_default_346 = torch.ops.aten.t.default(mm_default_101);  mm_default_101 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(view_default_606, [0], True);  view_default_606 = None
        view_default_607 = torch.ops.aten.view.default(sum_dim_int_list_50, [1024]);  sum_dim_int_list_50 = None
        t_default_347 = torch.ops.aten.t.default(t_default_346);  t_default_346 = None
        view_default_608 = torch.ops.aten.view.default(mm_default_100, [64, 128, 1024]);  mm_default_100 = None
        view_default_609 = torch.ops.aten.view.default(view_default_608, [64, 128, 16, 64]);  view_default_608 = None
        permute_default_128 = torch.ops.aten.permute.default(view_default_609, [0, 2, 1, 3]);  view_default_609 = None
        clone_default_128 = torch.ops.aten.clone.default(permute_default_128, memory_format = torch.contiguous_format);  permute_default_128 = None
        _unsafe_view_default_152 = torch.ops.aten._unsafe_view.default(clone_default_128, [1024, 128, 64]);  clone_default_128 = None
        transpose_int_64 = torch.ops.aten.transpose.int(view_default_264, 1, 2);  view_default_264 = None
        bmm_default_80 = torch.ops.aten.bmm.default(transpose_int_64, _unsafe_view_default_152);  transpose_int_64 = None
        transpose_int_65 = torch.ops.aten.transpose.int(_unsafe_view_default_78, 1, 2);  _unsafe_view_default_78 = None
        bmm_default_81 = torch.ops.aten.bmm.default(_unsafe_view_default_152, transpose_int_65);  _unsafe_view_default_152 = transpose_int_65 = None
        view_default_610 = torch.ops.aten.view.default(bmm_default_80, [64, 16, 128, 64]);  bmm_default_80 = None
        view_default_611 = torch.ops.aten.view.default(bmm_default_81, [64, 16, 128, 128]);  bmm_default_81 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_611, _softmax_default_15, -1, torch.float32);  view_default_611 = _softmax_default_15 = None
        div_tensor_32 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_8, 8.0);  _softmax_backward_data_default_8 = None
        view_default_612 = torch.ops.aten.view.default(div_tensor_32, [1024, 128, 128]);  div_tensor_32 = None
        transpose_int_66 = torch.ops.aten.transpose.int(_unsafe_view_default_75, 1, 2);  _unsafe_view_default_75 = None
        bmm_default_82 = torch.ops.aten.bmm.default(transpose_int_66, view_default_612);  transpose_int_66 = None
        transpose_int_67 = torch.ops.aten.transpose.int(_unsafe_view_default_76, 1, 2);  _unsafe_view_default_76 = None
        bmm_default_83 = torch.ops.aten.bmm.default(view_default_612, transpose_int_67);  view_default_612 = transpose_int_67 = None
        view_default_613 = torch.ops.aten.view.default(bmm_default_82, [64, 16, 64, 128]);  bmm_default_82 = None
        view_default_614 = torch.ops.aten.view.default(bmm_default_83, [64, 16, 128, 64]);  bmm_default_83 = None
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_613, -1, -2);  view_default_613 = None
        permute_default_129 = torch.ops.aten.permute.default(view_default_614, [0, 2, 1, 3]);  view_default_614 = None
        clone_default_129 = torch.ops.aten.clone.default(permute_default_129, memory_format = torch.contiguous_format);  permute_default_129 = None
        _unsafe_view_default_153 = torch.ops.aten._unsafe_view.default(clone_default_129, [64, 128, 1024]);  clone_default_129 = None
        permute_default_130 = torch.ops.aten.permute.default(view_default_610, [0, 2, 1, 3]);  view_default_610 = None
        clone_default_130 = torch.ops.aten.clone.default(permute_default_130, memory_format = torch.contiguous_format);  permute_default_130 = None
        _unsafe_view_default_154 = torch.ops.aten._unsafe_view.default(clone_default_130, [64, 128, 1024]);  clone_default_130 = None
        view_default_615 = torch.ops.aten.view.default(_unsafe_view_default_154, [8192, 1024]);  _unsafe_view_default_154 = None
        t_default_348 = torch.ops.aten.t.default(t_default_92);  t_default_92 = None
        mm_default_102 = torch.ops.aten.mm.default(view_default_615, t_default_348);  t_default_348 = None
        t_default_349 = torch.ops.aten.t.default(view_default_615)
        mm_default_103 = torch.ops.aten.mm.default(t_default_349, view_default_260);  t_default_349 = view_default_260 = None
        t_default_350 = torch.ops.aten.t.default(mm_default_103);  mm_default_103 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(view_default_615, [0], True);  view_default_615 = None
        view_default_616 = torch.ops.aten.view.default(sum_dim_int_list_51, [1024]);  sum_dim_int_list_51 = None
        t_default_351 = torch.ops.aten.t.default(t_default_350);  t_default_350 = None
        view_default_617 = torch.ops.aten.view.default(mm_default_102, [64, 128, 1024]);  mm_default_102 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(getitem_195, view_default_617);  getitem_195 = view_default_617 = None
        permute_default_131 = torch.ops.aten.permute.default(transpose_int_68, [0, 2, 1, 3]);  transpose_int_68 = None
        view_default_618 = torch.ops.aten.view.default(permute_default_131, [64, 128, 1024]);  permute_default_131 = None
        clone_default_131 = torch.ops.aten.clone.default(view_default_618, memory_format = torch.contiguous_format);  view_default_618 = None
        _unsafe_view_default_155 = torch.ops.aten._unsafe_view.default(clone_default_131, [8192, 1024]);  clone_default_131 = None
        t_default_352 = torch.ops.aten.t.default(t_default_91);  t_default_91 = None
        mm_default_104 = torch.ops.aten.mm.default(_unsafe_view_default_155, t_default_352);  t_default_352 = None
        t_default_353 = torch.ops.aten.t.default(_unsafe_view_default_155)
        mm_default_105 = torch.ops.aten.mm.default(t_default_353, view_default_257);  t_default_353 = view_default_257 = None
        t_default_354 = torch.ops.aten.t.default(mm_default_105);  mm_default_105 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_155, [0], True);  _unsafe_view_default_155 = None
        view_default_619 = torch.ops.aten.view.default(sum_dim_int_list_52, [1024]);  sum_dim_int_list_52 = None
        t_default_355 = torch.ops.aten.t.default(t_default_354);  t_default_354 = None
        view_default_620 = torch.ops.aten.view.default(mm_default_104, [64, 128, 1024]);  mm_default_104 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(add_tensor_123, view_default_620);  add_tensor_123 = view_default_620 = None
        view_default_621 = torch.ops.aten.view.default(_unsafe_view_default_153, [8192, 1024]);  _unsafe_view_default_153 = None
        t_default_356 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        mm_default_106 = torch.ops.aten.mm.default(view_default_621, t_default_356);  t_default_356 = None
        t_default_357 = torch.ops.aten.t.default(view_default_621)
        mm_default_107 = torch.ops.aten.mm.default(t_default_357, view_default_255);  t_default_357 = view_default_255 = None
        t_default_358 = torch.ops.aten.t.default(mm_default_107);  mm_default_107 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(view_default_621, [0], True);  view_default_621 = None
        view_default_622 = torch.ops.aten.view.default(sum_dim_int_list_53, [1024]);  sum_dim_int_list_53 = None
        t_default_359 = torch.ops.aten.t.default(t_default_358);  t_default_358 = None
        view_default_623 = torch.ops.aten.view.default(mm_default_106, [64, 128, 1024]);  mm_default_106 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(add_tensor_124, view_default_623);  add_tensor_124 = view_default_623 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_125, add_tensor_44, [1024], getitem_88, getitem_89, primals_94, primals_93, [True, True, True]);  add_tensor_125 = add_tensor_44 = getitem_88 = getitem_89 = primals_94 = primals_93 = None
        getitem_198 = native_layer_norm_backward_default_18[0]
        getitem_199 = native_layer_norm_backward_default_18[1]
        getitem_200 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        view_default_624 = torch.ops.aten.view.default(getitem_198, [8192, 1024])
        t_default_360 = torch.ops.aten.t.default(t_default_89);  t_default_89 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_624, t_default_360);  t_default_360 = None
        t_default_361 = torch.ops.aten.t.default(view_default_624)
        mm_default_109 = torch.ops.aten.mm.default(t_default_361, view_default_253);  t_default_361 = view_default_253 = None
        t_default_362 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(view_default_624, [0], True);  view_default_624 = None
        view_default_625 = torch.ops.aten.view.default(sum_dim_int_list_54, [1024]);  sum_dim_int_list_54 = None
        t_default_363 = torch.ops.aten.t.default(t_default_362);  t_default_362 = None
        view_default_626 = torch.ops.aten.view.default(mm_default_108, [64, 128, 4096]);  mm_default_108 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_626, torch.float32);  view_default_626 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_252, torch.float32);  view_default_252 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_63);  mul_tensor_63 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(add_tensor_126, 0.5);  add_tensor_126 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_66 = torch.ops.aten.mul.Tensor(mul_tensor_65, -0.5);  mul_tensor_65 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_66);  mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_67);  to_dtype_28 = mul_tensor_67 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(mul_tensor_64, mul_tensor_68);  mul_tensor_64 = mul_tensor_68 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_127);  to_dtype_27 = add_tensor_127 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_69, torch.float32);  mul_tensor_69 = None
        view_default_627 = torch.ops.aten.view.default(to_dtype_29, [8192, 4096]);  to_dtype_29 = None
        t_default_364 = torch.ops.aten.t.default(t_default_88);  t_default_88 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_627, t_default_364);  t_default_364 = None
        t_default_365 = torch.ops.aten.t.default(view_default_627)
        mm_default_111 = torch.ops.aten.mm.default(t_default_365, view_default_251);  t_default_365 = view_default_251 = None
        t_default_366 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(view_default_627, [0], True);  view_default_627 = None
        view_default_628 = torch.ops.aten.view.default(sum_dim_int_list_55, [4096]);  sum_dim_int_list_55 = None
        t_default_367 = torch.ops.aten.t.default(t_default_366);  t_default_366 = None
        view_default_629 = torch.ops.aten.view.default(mm_default_110, [64, 128, 1024]);  mm_default_110 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(getitem_198, view_default_629);  getitem_198 = view_default_629 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_128, add_tensor_43, [1024], getitem_85, getitem_86, primals_82, primals_81, [True, True, True]);  add_tensor_128 = add_tensor_43 = getitem_85 = getitem_86 = primals_82 = primals_81 = None
        getitem_201 = native_layer_norm_backward_default_19[0]
        getitem_202 = native_layer_norm_backward_default_19[1]
        getitem_203 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        view_default_630 = torch.ops.aten.view.default(getitem_201, [8192, 1024])
        t_default_368 = torch.ops.aten.t.default(t_default_87);  t_default_87 = None
        mm_default_112 = torch.ops.aten.mm.default(view_default_630, t_default_368);  t_default_368 = None
        t_default_369 = torch.ops.aten.t.default(view_default_630)
        mm_default_113 = torch.ops.aten.mm.default(t_default_369, view_default_249);  t_default_369 = view_default_249 = None
        t_default_370 = torch.ops.aten.t.default(mm_default_113);  mm_default_113 = None
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(view_default_630, [0], True);  view_default_630 = None
        view_default_631 = torch.ops.aten.view.default(sum_dim_int_list_56, [1024]);  sum_dim_int_list_56 = None
        t_default_371 = torch.ops.aten.t.default(t_default_370);  t_default_370 = None
        view_default_632 = torch.ops.aten.view.default(mm_default_112, [64, 128, 1024]);  mm_default_112 = None
        view_default_633 = torch.ops.aten.view.default(view_default_632, [64, 128, 16, 64]);  view_default_632 = None
        permute_default_132 = torch.ops.aten.permute.default(view_default_633, [0, 2, 1, 3]);  view_default_633 = None
        clone_default_132 = torch.ops.aten.clone.default(permute_default_132, memory_format = torch.contiguous_format);  permute_default_132 = None
        _unsafe_view_default_156 = torch.ops.aten._unsafe_view.default(clone_default_132, [1024, 128, 64]);  clone_default_132 = None
        transpose_int_69 = torch.ops.aten.transpose.int(view_default_247, 1, 2);  view_default_247 = None
        bmm_default_84 = torch.ops.aten.bmm.default(transpose_int_69, _unsafe_view_default_156);  transpose_int_69 = None
        transpose_int_70 = torch.ops.aten.transpose.int(_unsafe_view_default_73, 1, 2);  _unsafe_view_default_73 = None
        bmm_default_85 = torch.ops.aten.bmm.default(_unsafe_view_default_156, transpose_int_70);  _unsafe_view_default_156 = transpose_int_70 = None
        view_default_634 = torch.ops.aten.view.default(bmm_default_84, [64, 16, 128, 64]);  bmm_default_84 = None
        view_default_635 = torch.ops.aten.view.default(bmm_default_85, [64, 16, 128, 128]);  bmm_default_85 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_635, _softmax_default_14, -1, torch.float32);  view_default_635 = _softmax_default_14 = None
        div_tensor_33 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_9, 8.0);  _softmax_backward_data_default_9 = None
        view_default_636 = torch.ops.aten.view.default(div_tensor_33, [1024, 128, 128]);  div_tensor_33 = None
        transpose_int_71 = torch.ops.aten.transpose.int(_unsafe_view_default_70, 1, 2);  _unsafe_view_default_70 = None
        bmm_default_86 = torch.ops.aten.bmm.default(transpose_int_71, view_default_636);  transpose_int_71 = None
        transpose_int_72 = torch.ops.aten.transpose.int(_unsafe_view_default_71, 1, 2);  _unsafe_view_default_71 = None
        bmm_default_87 = torch.ops.aten.bmm.default(view_default_636, transpose_int_72);  view_default_636 = transpose_int_72 = None
        view_default_637 = torch.ops.aten.view.default(bmm_default_86, [64, 16, 64, 128]);  bmm_default_86 = None
        view_default_638 = torch.ops.aten.view.default(bmm_default_87, [64, 16, 128, 64]);  bmm_default_87 = None
        transpose_int_73 = torch.ops.aten.transpose.int(view_default_637, -1, -2);  view_default_637 = None
        permute_default_133 = torch.ops.aten.permute.default(view_default_638, [0, 2, 1, 3]);  view_default_638 = None
        clone_default_133 = torch.ops.aten.clone.default(permute_default_133, memory_format = torch.contiguous_format);  permute_default_133 = None
        _unsafe_view_default_157 = torch.ops.aten._unsafe_view.default(clone_default_133, [64, 128, 1024]);  clone_default_133 = None
        permute_default_134 = torch.ops.aten.permute.default(view_default_634, [0, 2, 1, 3]);  view_default_634 = None
        clone_default_134 = torch.ops.aten.clone.default(permute_default_134, memory_format = torch.contiguous_format);  permute_default_134 = None
        _unsafe_view_default_158 = torch.ops.aten._unsafe_view.default(clone_default_134, [64, 128, 1024]);  clone_default_134 = None
        view_default_639 = torch.ops.aten.view.default(_unsafe_view_default_158, [8192, 1024]);  _unsafe_view_default_158 = None
        t_default_372 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        mm_default_114 = torch.ops.aten.mm.default(view_default_639, t_default_372);  t_default_372 = None
        t_default_373 = torch.ops.aten.t.default(view_default_639)
        mm_default_115 = torch.ops.aten.mm.default(t_default_373, view_default_243);  t_default_373 = view_default_243 = None
        t_default_374 = torch.ops.aten.t.default(mm_default_115);  mm_default_115 = None
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(view_default_639, [0], True);  view_default_639 = None
        view_default_640 = torch.ops.aten.view.default(sum_dim_int_list_57, [1024]);  sum_dim_int_list_57 = None
        t_default_375 = torch.ops.aten.t.default(t_default_374);  t_default_374 = None
        view_default_641 = torch.ops.aten.view.default(mm_default_114, [64, 128, 1024]);  mm_default_114 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(getitem_201, view_default_641);  getitem_201 = view_default_641 = None
        permute_default_135 = torch.ops.aten.permute.default(transpose_int_73, [0, 2, 1, 3]);  transpose_int_73 = None
        view_default_642 = torch.ops.aten.view.default(permute_default_135, [64, 128, 1024]);  permute_default_135 = None
        clone_default_135 = torch.ops.aten.clone.default(view_default_642, memory_format = torch.contiguous_format);  view_default_642 = None
        _unsafe_view_default_159 = torch.ops.aten._unsafe_view.default(clone_default_135, [8192, 1024]);  clone_default_135 = None
        t_default_376 = torch.ops.aten.t.default(t_default_85);  t_default_85 = None
        mm_default_116 = torch.ops.aten.mm.default(_unsafe_view_default_159, t_default_376);  t_default_376 = None
        t_default_377 = torch.ops.aten.t.default(_unsafe_view_default_159)
        mm_default_117 = torch.ops.aten.mm.default(t_default_377, view_default_240);  t_default_377 = view_default_240 = None
        t_default_378 = torch.ops.aten.t.default(mm_default_117);  mm_default_117 = None
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_159, [0], True);  _unsafe_view_default_159 = None
        view_default_643 = torch.ops.aten.view.default(sum_dim_int_list_58, [1024]);  sum_dim_int_list_58 = None
        t_default_379 = torch.ops.aten.t.default(t_default_378);  t_default_378 = None
        view_default_644 = torch.ops.aten.view.default(mm_default_116, [64, 128, 1024]);  mm_default_116 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_129, view_default_644);  add_tensor_129 = view_default_644 = None
        view_default_645 = torch.ops.aten.view.default(_unsafe_view_default_157, [8192, 1024]);  _unsafe_view_default_157 = None
        t_default_380 = torch.ops.aten.t.default(t_default_84);  t_default_84 = None
        mm_default_118 = torch.ops.aten.mm.default(view_default_645, t_default_380);  t_default_380 = None
        t_default_381 = torch.ops.aten.t.default(view_default_645)
        mm_default_119 = torch.ops.aten.mm.default(t_default_381, view_default_238);  t_default_381 = view_default_238 = None
        t_default_382 = torch.ops.aten.t.default(mm_default_119);  mm_default_119 = None
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(view_default_645, [0], True);  view_default_645 = None
        view_default_646 = torch.ops.aten.view.default(sum_dim_int_list_59, [1024]);  sum_dim_int_list_59 = None
        t_default_383 = torch.ops.aten.t.default(t_default_382);  t_default_382 = None
        view_default_647 = torch.ops.aten.view.default(mm_default_118, [64, 128, 1024]);  mm_default_118 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(add_tensor_130, view_default_647);  add_tensor_130 = view_default_647 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_131, add_tensor_41, [1024], getitem_82, getitem_83, primals_78, primals_77, [True, True, True]);  add_tensor_131 = add_tensor_41 = getitem_82 = getitem_83 = primals_78 = primals_77 = None
        getitem_204 = native_layer_norm_backward_default_20[0]
        getitem_205 = native_layer_norm_backward_default_20[1]
        getitem_206 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_648 = torch.ops.aten.view.default(getitem_204, [8192, 1024])
        t_default_384 = torch.ops.aten.t.default(t_default_83);  t_default_83 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_648, t_default_384);  t_default_384 = None
        t_default_385 = torch.ops.aten.t.default(view_default_648)
        mm_default_121 = torch.ops.aten.mm.default(t_default_385, view_default_236);  t_default_385 = view_default_236 = None
        t_default_386 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(view_default_648, [0], True);  view_default_648 = None
        view_default_649 = torch.ops.aten.view.default(sum_dim_int_list_60, [1024]);  sum_dim_int_list_60 = None
        t_default_387 = torch.ops.aten.t.default(t_default_386);  t_default_386 = None
        view_default_650 = torch.ops.aten.view.default(mm_default_120, [64, 128, 4096]);  mm_default_120 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_650, torch.float32);  view_default_650 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_235, torch.float32);  view_default_235 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_70);  mul_tensor_70 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(add_tensor_132, 0.5);  add_tensor_132 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_73 = torch.ops.aten.mul.Tensor(mul_tensor_72, -0.5);  mul_tensor_72 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_73);  mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_74);  to_dtype_31 = mul_tensor_74 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(mul_tensor_71, mul_tensor_75);  mul_tensor_71 = mul_tensor_75 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_133);  to_dtype_30 = add_tensor_133 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_76, torch.float32);  mul_tensor_76 = None
        view_default_651 = torch.ops.aten.view.default(to_dtype_32, [8192, 4096]);  to_dtype_32 = None
        t_default_388 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_651, t_default_388);  t_default_388 = None
        t_default_389 = torch.ops.aten.t.default(view_default_651)
        mm_default_123 = torch.ops.aten.mm.default(t_default_389, view_default_234);  t_default_389 = view_default_234 = None
        t_default_390 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(view_default_651, [0], True);  view_default_651 = None
        view_default_652 = torch.ops.aten.view.default(sum_dim_int_list_61, [4096]);  sum_dim_int_list_61 = None
        t_default_391 = torch.ops.aten.t.default(t_default_390);  t_default_390 = None
        view_default_653 = torch.ops.aten.view.default(mm_default_122, [64, 128, 1024]);  mm_default_122 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(getitem_204, view_default_653);  getitem_204 = view_default_653 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_134, add_tensor_40, [1024], getitem_79, getitem_80, primals_66, primals_65, [True, True, True]);  add_tensor_134 = add_tensor_40 = getitem_79 = getitem_80 = primals_66 = primals_65 = None
        getitem_207 = native_layer_norm_backward_default_21[0]
        getitem_208 = native_layer_norm_backward_default_21[1]
        getitem_209 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        view_default_654 = torch.ops.aten.view.default(getitem_207, [8192, 1024])
        t_default_392 = torch.ops.aten.t.default(t_default_81);  t_default_81 = None
        mm_default_124 = torch.ops.aten.mm.default(view_default_654, t_default_392);  t_default_392 = None
        t_default_393 = torch.ops.aten.t.default(view_default_654)
        mm_default_125 = torch.ops.aten.mm.default(t_default_393, view_default_232);  t_default_393 = view_default_232 = None
        t_default_394 = torch.ops.aten.t.default(mm_default_125);  mm_default_125 = None
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(view_default_654, [0], True);  view_default_654 = None
        view_default_655 = torch.ops.aten.view.default(sum_dim_int_list_62, [1024]);  sum_dim_int_list_62 = None
        t_default_395 = torch.ops.aten.t.default(t_default_394);  t_default_394 = None
        view_default_656 = torch.ops.aten.view.default(mm_default_124, [64, 128, 1024]);  mm_default_124 = None
        view_default_657 = torch.ops.aten.view.default(view_default_656, [64, 128, 16, 64]);  view_default_656 = None
        permute_default_136 = torch.ops.aten.permute.default(view_default_657, [0, 2, 1, 3]);  view_default_657 = None
        clone_default_136 = torch.ops.aten.clone.default(permute_default_136, memory_format = torch.contiguous_format);  permute_default_136 = None
        _unsafe_view_default_160 = torch.ops.aten._unsafe_view.default(clone_default_136, [1024, 128, 64]);  clone_default_136 = None
        transpose_int_74 = torch.ops.aten.transpose.int(view_default_230, 1, 2);  view_default_230 = None
        bmm_default_88 = torch.ops.aten.bmm.default(transpose_int_74, _unsafe_view_default_160);  transpose_int_74 = None
        transpose_int_75 = torch.ops.aten.transpose.int(_unsafe_view_default_68, 1, 2);  _unsafe_view_default_68 = None
        bmm_default_89 = torch.ops.aten.bmm.default(_unsafe_view_default_160, transpose_int_75);  _unsafe_view_default_160 = transpose_int_75 = None
        view_default_658 = torch.ops.aten.view.default(bmm_default_88, [64, 16, 128, 64]);  bmm_default_88 = None
        view_default_659 = torch.ops.aten.view.default(bmm_default_89, [64, 16, 128, 128]);  bmm_default_89 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_659, _softmax_default_13, -1, torch.float32);  view_default_659 = _softmax_default_13 = None
        div_tensor_34 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_10, 8.0);  _softmax_backward_data_default_10 = None
        view_default_660 = torch.ops.aten.view.default(div_tensor_34, [1024, 128, 128]);  div_tensor_34 = None
        transpose_int_76 = torch.ops.aten.transpose.int(_unsafe_view_default_65, 1, 2);  _unsafe_view_default_65 = None
        bmm_default_90 = torch.ops.aten.bmm.default(transpose_int_76, view_default_660);  transpose_int_76 = None
        transpose_int_77 = torch.ops.aten.transpose.int(_unsafe_view_default_66, 1, 2);  _unsafe_view_default_66 = None
        bmm_default_91 = torch.ops.aten.bmm.default(view_default_660, transpose_int_77);  view_default_660 = transpose_int_77 = None
        view_default_661 = torch.ops.aten.view.default(bmm_default_90, [64, 16, 64, 128]);  bmm_default_90 = None
        view_default_662 = torch.ops.aten.view.default(bmm_default_91, [64, 16, 128, 64]);  bmm_default_91 = None
        transpose_int_78 = torch.ops.aten.transpose.int(view_default_661, -1, -2);  view_default_661 = None
        permute_default_137 = torch.ops.aten.permute.default(view_default_662, [0, 2, 1, 3]);  view_default_662 = None
        clone_default_137 = torch.ops.aten.clone.default(permute_default_137, memory_format = torch.contiguous_format);  permute_default_137 = None
        _unsafe_view_default_161 = torch.ops.aten._unsafe_view.default(clone_default_137, [64, 128, 1024]);  clone_default_137 = None
        permute_default_138 = torch.ops.aten.permute.default(view_default_658, [0, 2, 1, 3]);  view_default_658 = None
        clone_default_138 = torch.ops.aten.clone.default(permute_default_138, memory_format = torch.contiguous_format);  permute_default_138 = None
        _unsafe_view_default_162 = torch.ops.aten._unsafe_view.default(clone_default_138, [64, 128, 1024]);  clone_default_138 = None
        view_default_663 = torch.ops.aten.view.default(_unsafe_view_default_162, [8192, 1024]);  _unsafe_view_default_162 = None
        t_default_396 = torch.ops.aten.t.default(t_default_80);  t_default_80 = None
        mm_default_126 = torch.ops.aten.mm.default(view_default_663, t_default_396);  t_default_396 = None
        t_default_397 = torch.ops.aten.t.default(view_default_663)
        mm_default_127 = torch.ops.aten.mm.default(t_default_397, view_default_226);  t_default_397 = view_default_226 = None
        t_default_398 = torch.ops.aten.t.default(mm_default_127);  mm_default_127 = None
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(view_default_663, [0], True);  view_default_663 = None
        view_default_664 = torch.ops.aten.view.default(sum_dim_int_list_63, [1024]);  sum_dim_int_list_63 = None
        t_default_399 = torch.ops.aten.t.default(t_default_398);  t_default_398 = None
        view_default_665 = torch.ops.aten.view.default(mm_default_126, [64, 128, 1024]);  mm_default_126 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(getitem_207, view_default_665);  getitem_207 = view_default_665 = None
        permute_default_139 = torch.ops.aten.permute.default(transpose_int_78, [0, 2, 1, 3]);  transpose_int_78 = None
        view_default_666 = torch.ops.aten.view.default(permute_default_139, [64, 128, 1024]);  permute_default_139 = None
        clone_default_139 = torch.ops.aten.clone.default(view_default_666, memory_format = torch.contiguous_format);  view_default_666 = None
        _unsafe_view_default_163 = torch.ops.aten._unsafe_view.default(clone_default_139, [8192, 1024]);  clone_default_139 = None
        t_default_400 = torch.ops.aten.t.default(t_default_79);  t_default_79 = None
        mm_default_128 = torch.ops.aten.mm.default(_unsafe_view_default_163, t_default_400);  t_default_400 = None
        t_default_401 = torch.ops.aten.t.default(_unsafe_view_default_163)
        mm_default_129 = torch.ops.aten.mm.default(t_default_401, view_default_223);  t_default_401 = view_default_223 = None
        t_default_402 = torch.ops.aten.t.default(mm_default_129);  mm_default_129 = None
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_163, [0], True);  _unsafe_view_default_163 = None
        view_default_667 = torch.ops.aten.view.default(sum_dim_int_list_64, [1024]);  sum_dim_int_list_64 = None
        t_default_403 = torch.ops.aten.t.default(t_default_402);  t_default_402 = None
        view_default_668 = torch.ops.aten.view.default(mm_default_128, [64, 128, 1024]);  mm_default_128 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(add_tensor_135, view_default_668);  add_tensor_135 = view_default_668 = None
        view_default_669 = torch.ops.aten.view.default(_unsafe_view_default_161, [8192, 1024]);  _unsafe_view_default_161 = None
        t_default_404 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        mm_default_130 = torch.ops.aten.mm.default(view_default_669, t_default_404);  t_default_404 = None
        t_default_405 = torch.ops.aten.t.default(view_default_669)
        mm_default_131 = torch.ops.aten.mm.default(t_default_405, view_default_221);  t_default_405 = view_default_221 = None
        t_default_406 = torch.ops.aten.t.default(mm_default_131);  mm_default_131 = None
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(view_default_669, [0], True);  view_default_669 = None
        view_default_670 = torch.ops.aten.view.default(sum_dim_int_list_65, [1024]);  sum_dim_int_list_65 = None
        t_default_407 = torch.ops.aten.t.default(t_default_406);  t_default_406 = None
        view_default_671 = torch.ops.aten.view.default(mm_default_130, [64, 128, 1024]);  mm_default_130 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(add_tensor_136, view_default_671);  add_tensor_136 = view_default_671 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_137, add_tensor_38, [1024], getitem_76, getitem_77, primals_62, primals_61, [True, True, True]);  add_tensor_137 = add_tensor_38 = getitem_76 = getitem_77 = primals_62 = primals_61 = None
        getitem_210 = native_layer_norm_backward_default_22[0]
        getitem_211 = native_layer_norm_backward_default_22[1]
        getitem_212 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_672 = torch.ops.aten.view.default(getitem_210, [8192, 1024])
        t_default_408 = torch.ops.aten.t.default(t_default_77);  t_default_77 = None
        mm_default_132 = torch.ops.aten.mm.default(view_default_672, t_default_408);  t_default_408 = None
        t_default_409 = torch.ops.aten.t.default(view_default_672)
        mm_default_133 = torch.ops.aten.mm.default(t_default_409, view_default_219);  t_default_409 = view_default_219 = None
        t_default_410 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(view_default_672, [0], True);  view_default_672 = None
        view_default_673 = torch.ops.aten.view.default(sum_dim_int_list_66, [1024]);  sum_dim_int_list_66 = None
        t_default_411 = torch.ops.aten.t.default(t_default_410);  t_default_410 = None
        view_default_674 = torch.ops.aten.view.default(mm_default_132, [64, 128, 4096]);  mm_default_132 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_674, torch.float32);  view_default_674 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_218, torch.float32);  view_default_218 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_77);  mul_tensor_77 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(add_tensor_138, 0.5);  add_tensor_138 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_80 = torch.ops.aten.mul.Tensor(mul_tensor_79, -0.5);  mul_tensor_79 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_80);  mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_81);  to_dtype_34 = mul_tensor_81 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(mul_tensor_78, mul_tensor_82);  mul_tensor_78 = mul_tensor_82 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_139);  to_dtype_33 = add_tensor_139 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_83, torch.float32);  mul_tensor_83 = None
        view_default_675 = torch.ops.aten.view.default(to_dtype_35, [8192, 4096]);  to_dtype_35 = None
        t_default_412 = torch.ops.aten.t.default(t_default_76);  t_default_76 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_675, t_default_412);  t_default_412 = None
        t_default_413 = torch.ops.aten.t.default(view_default_675)
        mm_default_135 = torch.ops.aten.mm.default(t_default_413, view_default_217);  t_default_413 = view_default_217 = None
        t_default_414 = torch.ops.aten.t.default(mm_default_135);  mm_default_135 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(view_default_675, [0], True);  view_default_675 = None
        view_default_676 = torch.ops.aten.view.default(sum_dim_int_list_67, [4096]);  sum_dim_int_list_67 = None
        t_default_415 = torch.ops.aten.t.default(t_default_414);  t_default_414 = None
        view_default_677 = torch.ops.aten.view.default(mm_default_134, [64, 128, 1024]);  mm_default_134 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(getitem_210, view_default_677);  getitem_210 = view_default_677 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_140, add_tensor_37, [1024], getitem_73, getitem_74, primals_50, primals_49, [True, True, True]);  add_tensor_140 = add_tensor_37 = getitem_73 = getitem_74 = primals_50 = primals_49 = None
        getitem_213 = native_layer_norm_backward_default_23[0]
        getitem_214 = native_layer_norm_backward_default_23[1]
        getitem_215 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        view_default_678 = torch.ops.aten.view.default(getitem_213, [8192, 1024])
        t_default_416 = torch.ops.aten.t.default(t_default_75);  t_default_75 = None
        mm_default_136 = torch.ops.aten.mm.default(view_default_678, t_default_416);  t_default_416 = None
        t_default_417 = torch.ops.aten.t.default(view_default_678)
        mm_default_137 = torch.ops.aten.mm.default(t_default_417, view_default_215);  t_default_417 = view_default_215 = None
        t_default_418 = torch.ops.aten.t.default(mm_default_137);  mm_default_137 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(view_default_678, [0], True);  view_default_678 = None
        view_default_679 = torch.ops.aten.view.default(sum_dim_int_list_68, [1024]);  sum_dim_int_list_68 = None
        t_default_419 = torch.ops.aten.t.default(t_default_418);  t_default_418 = None
        view_default_680 = torch.ops.aten.view.default(mm_default_136, [64, 128, 1024]);  mm_default_136 = None
        view_default_681 = torch.ops.aten.view.default(view_default_680, [64, 128, 16, 64]);  view_default_680 = None
        permute_default_140 = torch.ops.aten.permute.default(view_default_681, [0, 2, 1, 3]);  view_default_681 = None
        clone_default_140 = torch.ops.aten.clone.default(permute_default_140, memory_format = torch.contiguous_format);  permute_default_140 = None
        _unsafe_view_default_164 = torch.ops.aten._unsafe_view.default(clone_default_140, [1024, 128, 64]);  clone_default_140 = None
        transpose_int_79 = torch.ops.aten.transpose.int(view_default_213, 1, 2);  view_default_213 = None
        bmm_default_92 = torch.ops.aten.bmm.default(transpose_int_79, _unsafe_view_default_164);  transpose_int_79 = None
        transpose_int_80 = torch.ops.aten.transpose.int(_unsafe_view_default_63, 1, 2);  _unsafe_view_default_63 = None
        bmm_default_93 = torch.ops.aten.bmm.default(_unsafe_view_default_164, transpose_int_80);  _unsafe_view_default_164 = transpose_int_80 = None
        view_default_682 = torch.ops.aten.view.default(bmm_default_92, [64, 16, 128, 64]);  bmm_default_92 = None
        view_default_683 = torch.ops.aten.view.default(bmm_default_93, [64, 16, 128, 128]);  bmm_default_93 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_683, _softmax_default_12, -1, torch.float32);  view_default_683 = _softmax_default_12 = None
        div_tensor_35 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_11, 8.0);  _softmax_backward_data_default_11 = None
        view_default_684 = torch.ops.aten.view.default(div_tensor_35, [1024, 128, 128]);  div_tensor_35 = None
        transpose_int_81 = torch.ops.aten.transpose.int(_unsafe_view_default_60, 1, 2);  _unsafe_view_default_60 = None
        bmm_default_94 = torch.ops.aten.bmm.default(transpose_int_81, view_default_684);  transpose_int_81 = None
        transpose_int_82 = torch.ops.aten.transpose.int(_unsafe_view_default_61, 1, 2);  _unsafe_view_default_61 = None
        bmm_default_95 = torch.ops.aten.bmm.default(view_default_684, transpose_int_82);  view_default_684 = transpose_int_82 = None
        view_default_685 = torch.ops.aten.view.default(bmm_default_94, [64, 16, 64, 128]);  bmm_default_94 = None
        view_default_686 = torch.ops.aten.view.default(bmm_default_95, [64, 16, 128, 64]);  bmm_default_95 = None
        transpose_int_83 = torch.ops.aten.transpose.int(view_default_685, -1, -2);  view_default_685 = None
        permute_default_141 = torch.ops.aten.permute.default(view_default_686, [0, 2, 1, 3]);  view_default_686 = None
        clone_default_141 = torch.ops.aten.clone.default(permute_default_141, memory_format = torch.contiguous_format);  permute_default_141 = None
        _unsafe_view_default_165 = torch.ops.aten._unsafe_view.default(clone_default_141, [64, 128, 1024]);  clone_default_141 = None
        permute_default_142 = torch.ops.aten.permute.default(view_default_682, [0, 2, 1, 3]);  view_default_682 = None
        clone_default_142 = torch.ops.aten.clone.default(permute_default_142, memory_format = torch.contiguous_format);  permute_default_142 = None
        _unsafe_view_default_166 = torch.ops.aten._unsafe_view.default(clone_default_142, [64, 128, 1024]);  clone_default_142 = None
        view_default_687 = torch.ops.aten.view.default(_unsafe_view_default_166, [8192, 1024]);  _unsafe_view_default_166 = None
        t_default_420 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        mm_default_138 = torch.ops.aten.mm.default(view_default_687, t_default_420);  t_default_420 = None
        t_default_421 = torch.ops.aten.t.default(view_default_687)
        mm_default_139 = torch.ops.aten.mm.default(t_default_421, view_default_209);  t_default_421 = view_default_209 = None
        t_default_422 = torch.ops.aten.t.default(mm_default_139);  mm_default_139 = None
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(view_default_687, [0], True);  view_default_687 = None
        view_default_688 = torch.ops.aten.view.default(sum_dim_int_list_69, [1024]);  sum_dim_int_list_69 = None
        t_default_423 = torch.ops.aten.t.default(t_default_422);  t_default_422 = None
        view_default_689 = torch.ops.aten.view.default(mm_default_138, [64, 128, 1024]);  mm_default_138 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(getitem_213, view_default_689);  getitem_213 = view_default_689 = None
        permute_default_143 = torch.ops.aten.permute.default(transpose_int_83, [0, 2, 1, 3]);  transpose_int_83 = None
        view_default_690 = torch.ops.aten.view.default(permute_default_143, [64, 128, 1024]);  permute_default_143 = None
        clone_default_143 = torch.ops.aten.clone.default(view_default_690, memory_format = torch.contiguous_format);  view_default_690 = None
        _unsafe_view_default_167 = torch.ops.aten._unsafe_view.default(clone_default_143, [8192, 1024]);  clone_default_143 = None
        t_default_424 = torch.ops.aten.t.default(t_default_73);  t_default_73 = None
        mm_default_140 = torch.ops.aten.mm.default(_unsafe_view_default_167, t_default_424);  t_default_424 = None
        t_default_425 = torch.ops.aten.t.default(_unsafe_view_default_167)
        mm_default_141 = torch.ops.aten.mm.default(t_default_425, view_default_206);  t_default_425 = view_default_206 = None
        t_default_426 = torch.ops.aten.t.default(mm_default_141);  mm_default_141 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_167, [0], True);  _unsafe_view_default_167 = None
        view_default_691 = torch.ops.aten.view.default(sum_dim_int_list_70, [1024]);  sum_dim_int_list_70 = None
        t_default_427 = torch.ops.aten.t.default(t_default_426);  t_default_426 = None
        view_default_692 = torch.ops.aten.view.default(mm_default_140, [64, 128, 1024]);  mm_default_140 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_141, view_default_692);  add_tensor_141 = view_default_692 = None
        view_default_693 = torch.ops.aten.view.default(_unsafe_view_default_165, [8192, 1024]);  _unsafe_view_default_165 = None
        t_default_428 = torch.ops.aten.t.default(t_default_72);  t_default_72 = None
        mm_default_142 = torch.ops.aten.mm.default(view_default_693, t_default_428);  t_default_428 = None
        t_default_429 = torch.ops.aten.t.default(view_default_693)
        mm_default_143 = torch.ops.aten.mm.default(t_default_429, view_default_204);  t_default_429 = view_default_204 = None
        t_default_430 = torch.ops.aten.t.default(mm_default_143);  mm_default_143 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(view_default_693, [0], True);  view_default_693 = None
        view_default_694 = torch.ops.aten.view.default(sum_dim_int_list_71, [1024]);  sum_dim_int_list_71 = None
        t_default_431 = torch.ops.aten.t.default(t_default_430);  t_default_430 = None
        view_default_695 = torch.ops.aten.view.default(mm_default_142, [64, 128, 1024]);  mm_default_142 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(add_tensor_142, view_default_695);  add_tensor_142 = view_default_695 = None
        native_layer_norm_backward_default_24 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_143, add_tensor_35, [1024], getitem_70, getitem_71, primals_46, primals_45, [True, True, True]);  add_tensor_143 = add_tensor_35 = getitem_70 = getitem_71 = primals_46 = primals_45 = None
        getitem_216 = native_layer_norm_backward_default_24[0]
        getitem_217 = native_layer_norm_backward_default_24[1]
        getitem_218 = native_layer_norm_backward_default_24[2];  native_layer_norm_backward_default_24 = None
        view_default_696 = torch.ops.aten.view.default(getitem_216, [8192, 1024])
        t_default_432 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default_144 = torch.ops.aten.mm.default(view_default_696, t_default_432);  t_default_432 = None
        t_default_433 = torch.ops.aten.t.default(view_default_696)
        mm_default_145 = torch.ops.aten.mm.default(t_default_433, view_default_202);  t_default_433 = view_default_202 = None
        t_default_434 = torch.ops.aten.t.default(mm_default_145);  mm_default_145 = None
        sum_dim_int_list_72 = torch.ops.aten.sum.dim_IntList(view_default_696, [0], True);  view_default_696 = None
        view_default_697 = torch.ops.aten.view.default(sum_dim_int_list_72, [1024]);  sum_dim_int_list_72 = None
        t_default_435 = torch.ops.aten.t.default(t_default_434);  t_default_434 = None
        view_default_698 = torch.ops.aten.view.default(mm_default_144, [64, 128, 4096]);  mm_default_144 = None
        to_dtype_36 = torch.ops.aten.to.dtype(view_default_698, torch.float32);  view_default_698 = None
        to_dtype_37 = torch.ops.aten.to.dtype(view_default_201, torch.float32);  view_default_201 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_37, 0.7071067811865476)
        erf_default_12 = torch.ops.aten.erf.default(mul_tensor_84);  mul_tensor_84 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(erf_default_12, 1);  erf_default_12 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(add_tensor_144, 0.5);  add_tensor_144 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_37, to_dtype_37)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(mul_tensor_86, -0.5);  mul_tensor_86 = None
        exp_default_12 = torch.ops.aten.exp.default(mul_tensor_87);  mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(exp_default_12, 0.3989422804014327);  exp_default_12 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_37, mul_tensor_88);  to_dtype_37 = mul_tensor_88 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(mul_tensor_85, mul_tensor_89);  mul_tensor_85 = mul_tensor_89 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_36, add_tensor_145);  to_dtype_36 = add_tensor_145 = None
        to_dtype_38 = torch.ops.aten.to.dtype(mul_tensor_90, torch.float32);  mul_tensor_90 = None
        view_default_699 = torch.ops.aten.view.default(to_dtype_38, [8192, 4096]);  to_dtype_38 = None
        t_default_436 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_146 = torch.ops.aten.mm.default(view_default_699, t_default_436);  t_default_436 = None
        t_default_437 = torch.ops.aten.t.default(view_default_699)
        mm_default_147 = torch.ops.aten.mm.default(t_default_437, view_default_200);  t_default_437 = view_default_200 = None
        t_default_438 = torch.ops.aten.t.default(mm_default_147);  mm_default_147 = None
        sum_dim_int_list_73 = torch.ops.aten.sum.dim_IntList(view_default_699, [0], True);  view_default_699 = None
        view_default_700 = torch.ops.aten.view.default(sum_dim_int_list_73, [4096]);  sum_dim_int_list_73 = None
        t_default_439 = torch.ops.aten.t.default(t_default_438);  t_default_438 = None
        view_default_701 = torch.ops.aten.view.default(mm_default_146, [64, 128, 1024]);  mm_default_146 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(getitem_216, view_default_701);  getitem_216 = view_default_701 = None
        native_layer_norm_backward_default_25 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_146, add_tensor_34, [1024], getitem_67, getitem_68, primals_34, primals_33, [True, True, True]);  add_tensor_146 = add_tensor_34 = getitem_67 = getitem_68 = primals_34 = primals_33 = None
        getitem_219 = native_layer_norm_backward_default_25[0]
        getitem_220 = native_layer_norm_backward_default_25[1]
        getitem_221 = native_layer_norm_backward_default_25[2];  native_layer_norm_backward_default_25 = None
        view_default_702 = torch.ops.aten.view.default(getitem_219, [8192, 1024])
        t_default_440 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_148 = torch.ops.aten.mm.default(view_default_702, t_default_440);  t_default_440 = None
        t_default_441 = torch.ops.aten.t.default(view_default_702)
        mm_default_149 = torch.ops.aten.mm.default(t_default_441, view_default_198);  t_default_441 = view_default_198 = None
        t_default_442 = torch.ops.aten.t.default(mm_default_149);  mm_default_149 = None
        sum_dim_int_list_74 = torch.ops.aten.sum.dim_IntList(view_default_702, [0], True);  view_default_702 = None
        view_default_703 = torch.ops.aten.view.default(sum_dim_int_list_74, [1024]);  sum_dim_int_list_74 = None
        t_default_443 = torch.ops.aten.t.default(t_default_442);  t_default_442 = None
        view_default_704 = torch.ops.aten.view.default(mm_default_148, [64, 128, 1024]);  mm_default_148 = None
        view_default_705 = torch.ops.aten.view.default(view_default_704, [64, 128, 16, 64]);  view_default_704 = None
        permute_default_144 = torch.ops.aten.permute.default(view_default_705, [0, 2, 1, 3]);  view_default_705 = None
        clone_default_144 = torch.ops.aten.clone.default(permute_default_144, memory_format = torch.contiguous_format);  permute_default_144 = None
        _unsafe_view_default_168 = torch.ops.aten._unsafe_view.default(clone_default_144, [1024, 128, 64]);  clone_default_144 = None
        transpose_int_84 = torch.ops.aten.transpose.int(view_default_196, 1, 2);  view_default_196 = None
        bmm_default_96 = torch.ops.aten.bmm.default(transpose_int_84, _unsafe_view_default_168);  transpose_int_84 = None
        transpose_int_85 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        bmm_default_97 = torch.ops.aten.bmm.default(_unsafe_view_default_168, transpose_int_85);  _unsafe_view_default_168 = transpose_int_85 = None
        view_default_706 = torch.ops.aten.view.default(bmm_default_96, [64, 16, 128, 64]);  bmm_default_96 = None
        view_default_707 = torch.ops.aten.view.default(bmm_default_97, [64, 16, 128, 128]);  bmm_default_97 = None
        _softmax_backward_data_default_12 = torch.ops.aten._softmax_backward_data.default(view_default_707, _softmax_default_11, -1, torch.float32);  view_default_707 = _softmax_default_11 = None
        div_tensor_36 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_12, 8.0);  _softmax_backward_data_default_12 = None
        view_default_708 = torch.ops.aten.view.default(div_tensor_36, [1024, 128, 128]);  div_tensor_36 = None
        transpose_int_86 = torch.ops.aten.transpose.int(_unsafe_view_default_55, 1, 2);  _unsafe_view_default_55 = None
        bmm_default_98 = torch.ops.aten.bmm.default(transpose_int_86, view_default_708);  transpose_int_86 = None
        transpose_int_87 = torch.ops.aten.transpose.int(_unsafe_view_default_56, 1, 2);  _unsafe_view_default_56 = None
        bmm_default_99 = torch.ops.aten.bmm.default(view_default_708, transpose_int_87);  view_default_708 = transpose_int_87 = None
        view_default_709 = torch.ops.aten.view.default(bmm_default_98, [64, 16, 64, 128]);  bmm_default_98 = None
        view_default_710 = torch.ops.aten.view.default(bmm_default_99, [64, 16, 128, 64]);  bmm_default_99 = None
        transpose_int_88 = torch.ops.aten.transpose.int(view_default_709, -1, -2);  view_default_709 = None
        permute_default_145 = torch.ops.aten.permute.default(view_default_710, [0, 2, 1, 3]);  view_default_710 = None
        clone_default_145 = torch.ops.aten.clone.default(permute_default_145, memory_format = torch.contiguous_format);  permute_default_145 = None
        _unsafe_view_default_169 = torch.ops.aten._unsafe_view.default(clone_default_145, [64, 128, 1024]);  clone_default_145 = None
        permute_default_146 = torch.ops.aten.permute.default(view_default_706, [0, 2, 1, 3]);  view_default_706 = None
        clone_default_146 = torch.ops.aten.clone.default(permute_default_146, memory_format = torch.contiguous_format);  permute_default_146 = None
        _unsafe_view_default_170 = torch.ops.aten._unsafe_view.default(clone_default_146, [64, 128, 1024]);  clone_default_146 = None
        view_default_711 = torch.ops.aten.view.default(_unsafe_view_default_170, [8192, 1024]);  _unsafe_view_default_170 = None
        t_default_444 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_150 = torch.ops.aten.mm.default(view_default_711, t_default_444);  t_default_444 = None
        t_default_445 = torch.ops.aten.t.default(view_default_711)
        mm_default_151 = torch.ops.aten.mm.default(t_default_445, view_default_192);  t_default_445 = view_default_192 = None
        t_default_446 = torch.ops.aten.t.default(mm_default_151);  mm_default_151 = None
        sum_dim_int_list_75 = torch.ops.aten.sum.dim_IntList(view_default_711, [0], True);  view_default_711 = None
        view_default_712 = torch.ops.aten.view.default(sum_dim_int_list_75, [1024]);  sum_dim_int_list_75 = None
        t_default_447 = torch.ops.aten.t.default(t_default_446);  t_default_446 = None
        view_default_713 = torch.ops.aten.view.default(mm_default_150, [64, 128, 1024]);  mm_default_150 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(getitem_219, view_default_713);  getitem_219 = view_default_713 = None
        permute_default_147 = torch.ops.aten.permute.default(transpose_int_88, [0, 2, 1, 3]);  transpose_int_88 = None
        view_default_714 = torch.ops.aten.view.default(permute_default_147, [64, 128, 1024]);  permute_default_147 = None
        clone_default_147 = torch.ops.aten.clone.default(view_default_714, memory_format = torch.contiguous_format);  view_default_714 = None
        _unsafe_view_default_171 = torch.ops.aten._unsafe_view.default(clone_default_147, [8192, 1024]);  clone_default_147 = None
        t_default_448 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_152 = torch.ops.aten.mm.default(_unsafe_view_default_171, t_default_448);  t_default_448 = None
        t_default_449 = torch.ops.aten.t.default(_unsafe_view_default_171)
        mm_default_153 = torch.ops.aten.mm.default(t_default_449, view_default_189);  t_default_449 = view_default_189 = None
        t_default_450 = torch.ops.aten.t.default(mm_default_153);  mm_default_153 = None
        sum_dim_int_list_76 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_171, [0], True);  _unsafe_view_default_171 = None
        view_default_715 = torch.ops.aten.view.default(sum_dim_int_list_76, [1024]);  sum_dim_int_list_76 = None
        t_default_451 = torch.ops.aten.t.default(t_default_450);  t_default_450 = None
        view_default_716 = torch.ops.aten.view.default(mm_default_152, [64, 128, 1024]);  mm_default_152 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_147, view_default_716);  add_tensor_147 = view_default_716 = None
        view_default_717 = torch.ops.aten.view.default(_unsafe_view_default_169, [8192, 1024]);  _unsafe_view_default_169 = None
        t_default_452 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_154 = torch.ops.aten.mm.default(view_default_717, t_default_452);  t_default_452 = None
        t_default_453 = torch.ops.aten.t.default(view_default_717)
        mm_default_155 = torch.ops.aten.mm.default(t_default_453, view_default_187);  t_default_453 = view_default_187 = None
        t_default_454 = torch.ops.aten.t.default(mm_default_155);  mm_default_155 = None
        sum_dim_int_list_77 = torch.ops.aten.sum.dim_IntList(view_default_717, [0], True);  view_default_717 = None
        view_default_718 = torch.ops.aten.view.default(sum_dim_int_list_77, [1024]);  sum_dim_int_list_77 = None
        t_default_455 = torch.ops.aten.t.default(t_default_454);  t_default_454 = None
        view_default_719 = torch.ops.aten.view.default(mm_default_154, [64, 128, 1024]);  mm_default_154 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(add_tensor_148, view_default_719);  add_tensor_148 = view_default_719 = None
        native_layer_norm_backward_default_26 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_149, add_tensor_32, [1024], getitem_64, getitem_65, primals_30, primals_29, [True, True, True]);  add_tensor_149 = add_tensor_32 = getitem_64 = getitem_65 = primals_30 = primals_29 = None
        getitem_222 = native_layer_norm_backward_default_26[0]
        getitem_223 = native_layer_norm_backward_default_26[1]
        getitem_224 = native_layer_norm_backward_default_26[2];  native_layer_norm_backward_default_26 = None
        view_default_720 = torch.ops.aten.view.default(getitem_222, [8192, 1024])
        t_default_456 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_156 = torch.ops.aten.mm.default(view_default_720, t_default_456);  t_default_456 = None
        t_default_457 = torch.ops.aten.t.default(view_default_720)
        mm_default_157 = torch.ops.aten.mm.default(t_default_457, view_default_185);  t_default_457 = view_default_185 = None
        t_default_458 = torch.ops.aten.t.default(mm_default_157);  mm_default_157 = None
        sum_dim_int_list_78 = torch.ops.aten.sum.dim_IntList(view_default_720, [0], True);  view_default_720 = None
        view_default_721 = torch.ops.aten.view.default(sum_dim_int_list_78, [1024]);  sum_dim_int_list_78 = None
        t_default_459 = torch.ops.aten.t.default(t_default_458);  t_default_458 = None
        view_default_722 = torch.ops.aten.view.default(mm_default_156, [64, 128, 4096]);  mm_default_156 = None
        to_dtype_39 = torch.ops.aten.to.dtype(view_default_722, torch.float32);  view_default_722 = None
        to_dtype_40 = torch.ops.aten.to.dtype(view_default_184, torch.float32);  view_default_184 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_40, 0.7071067811865476)
        erf_default_13 = torch.ops.aten.erf.default(mul_tensor_91);  mul_tensor_91 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(erf_default_13, 1);  erf_default_13 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(add_tensor_150, 0.5);  add_tensor_150 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_40, to_dtype_40)
        mul_tensor_94 = torch.ops.aten.mul.Tensor(mul_tensor_93, -0.5);  mul_tensor_93 = None
        exp_default_13 = torch.ops.aten.exp.default(mul_tensor_94);  mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(exp_default_13, 0.3989422804014327);  exp_default_13 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(to_dtype_40, mul_tensor_95);  to_dtype_40 = mul_tensor_95 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(mul_tensor_92, mul_tensor_96);  mul_tensor_92 = mul_tensor_96 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_39, add_tensor_151);  to_dtype_39 = add_tensor_151 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_97, torch.float32);  mul_tensor_97 = None
        view_default_723 = torch.ops.aten.view.default(to_dtype_41, [8192, 4096]);  to_dtype_41 = None
        t_default_460 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_158 = torch.ops.aten.mm.default(view_default_723, t_default_460);  t_default_460 = None
        t_default_461 = torch.ops.aten.t.default(view_default_723)
        mm_default_159 = torch.ops.aten.mm.default(t_default_461, view_default_183);  t_default_461 = view_default_183 = None
        t_default_462 = torch.ops.aten.t.default(mm_default_159);  mm_default_159 = None
        sum_dim_int_list_79 = torch.ops.aten.sum.dim_IntList(view_default_723, [0], True);  view_default_723 = None
        view_default_724 = torch.ops.aten.view.default(sum_dim_int_list_79, [4096]);  sum_dim_int_list_79 = None
        t_default_463 = torch.ops.aten.t.default(t_default_462);  t_default_462 = None
        view_default_725 = torch.ops.aten.view.default(mm_default_158, [64, 128, 1024]);  mm_default_158 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(getitem_222, view_default_725);  getitem_222 = view_default_725 = None
        native_layer_norm_backward_default_27 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_152, add_tensor_31, [1024], getitem_61, getitem_62, primals_18, primals_17, [True, True, True]);  add_tensor_152 = add_tensor_31 = getitem_61 = getitem_62 = primals_18 = primals_17 = None
        getitem_225 = native_layer_norm_backward_default_27[0]
        getitem_226 = native_layer_norm_backward_default_27[1]
        getitem_227 = native_layer_norm_backward_default_27[2];  native_layer_norm_backward_default_27 = None
        view_default_726 = torch.ops.aten.view.default(getitem_225, [8192, 1024])
        t_default_464 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_160 = torch.ops.aten.mm.default(view_default_726, t_default_464);  t_default_464 = None
        t_default_465 = torch.ops.aten.t.default(view_default_726)
        mm_default_161 = torch.ops.aten.mm.default(t_default_465, view_default_181);  t_default_465 = view_default_181 = None
        t_default_466 = torch.ops.aten.t.default(mm_default_161);  mm_default_161 = None
        sum_dim_int_list_80 = torch.ops.aten.sum.dim_IntList(view_default_726, [0], True);  view_default_726 = None
        view_default_727 = torch.ops.aten.view.default(sum_dim_int_list_80, [1024]);  sum_dim_int_list_80 = None
        t_default_467 = torch.ops.aten.t.default(t_default_466);  t_default_466 = None
        view_default_728 = torch.ops.aten.view.default(mm_default_160, [64, 128, 1024]);  mm_default_160 = None
        view_default_729 = torch.ops.aten.view.default(view_default_728, [64, 128, 16, 64]);  view_default_728 = None
        permute_default_148 = torch.ops.aten.permute.default(view_default_729, [0, 2, 1, 3]);  view_default_729 = None
        clone_default_148 = torch.ops.aten.clone.default(permute_default_148, memory_format = torch.contiguous_format);  permute_default_148 = None
        _unsafe_view_default_172 = torch.ops.aten._unsafe_view.default(clone_default_148, [1024, 128, 64]);  clone_default_148 = None
        transpose_int_89 = torch.ops.aten.transpose.int(view_default_179, 1, 2);  view_default_179 = None
        bmm_default_100 = torch.ops.aten.bmm.default(transpose_int_89, _unsafe_view_default_172);  transpose_int_89 = None
        transpose_int_90 = torch.ops.aten.transpose.int(_unsafe_view_default_53, 1, 2);  _unsafe_view_default_53 = None
        bmm_default_101 = torch.ops.aten.bmm.default(_unsafe_view_default_172, transpose_int_90);  _unsafe_view_default_172 = transpose_int_90 = None
        view_default_730 = torch.ops.aten.view.default(bmm_default_100, [64, 16, 128, 64]);  bmm_default_100 = None
        view_default_731 = torch.ops.aten.view.default(bmm_default_101, [64, 16, 128, 128]);  bmm_default_101 = None
        _softmax_backward_data_default_13 = torch.ops.aten._softmax_backward_data.default(view_default_731, _softmax_default_10, -1, torch.float32);  view_default_731 = _softmax_default_10 = None
        div_tensor_37 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_13, 8.0);  _softmax_backward_data_default_13 = None
        view_default_732 = torch.ops.aten.view.default(div_tensor_37, [1024, 128, 128]);  div_tensor_37 = None
        transpose_int_91 = torch.ops.aten.transpose.int(_unsafe_view_default_50, 1, 2);  _unsafe_view_default_50 = None
        bmm_default_102 = torch.ops.aten.bmm.default(transpose_int_91, view_default_732);  transpose_int_91 = None
        transpose_int_92 = torch.ops.aten.transpose.int(_unsafe_view_default_51, 1, 2);  _unsafe_view_default_51 = None
        bmm_default_103 = torch.ops.aten.bmm.default(view_default_732, transpose_int_92);  view_default_732 = transpose_int_92 = None
        view_default_733 = torch.ops.aten.view.default(bmm_default_102, [64, 16, 64, 128]);  bmm_default_102 = None
        view_default_734 = torch.ops.aten.view.default(bmm_default_103, [64, 16, 128, 64]);  bmm_default_103 = None
        transpose_int_93 = torch.ops.aten.transpose.int(view_default_733, -1, -2);  view_default_733 = None
        permute_default_149 = torch.ops.aten.permute.default(view_default_734, [0, 2, 1, 3]);  view_default_734 = None
        clone_default_149 = torch.ops.aten.clone.default(permute_default_149, memory_format = torch.contiguous_format);  permute_default_149 = None
        _unsafe_view_default_173 = torch.ops.aten._unsafe_view.default(clone_default_149, [64, 128, 1024]);  clone_default_149 = None
        permute_default_150 = torch.ops.aten.permute.default(view_default_730, [0, 2, 1, 3]);  view_default_730 = None
        clone_default_150 = torch.ops.aten.clone.default(permute_default_150, memory_format = torch.contiguous_format);  permute_default_150 = None
        _unsafe_view_default_174 = torch.ops.aten._unsafe_view.default(clone_default_150, [64, 128, 1024]);  clone_default_150 = None
        view_default_735 = torch.ops.aten.view.default(_unsafe_view_default_174, [8192, 1024]);  _unsafe_view_default_174 = None
        t_default_468 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_162 = torch.ops.aten.mm.default(view_default_735, t_default_468);  t_default_468 = None
        t_default_469 = torch.ops.aten.t.default(view_default_735)
        mm_default_163 = torch.ops.aten.mm.default(t_default_469, view_default_175);  t_default_469 = view_default_175 = None
        t_default_470 = torch.ops.aten.t.default(mm_default_163);  mm_default_163 = None
        sum_dim_int_list_81 = torch.ops.aten.sum.dim_IntList(view_default_735, [0], True);  view_default_735 = None
        view_default_736 = torch.ops.aten.view.default(sum_dim_int_list_81, [1024]);  sum_dim_int_list_81 = None
        t_default_471 = torch.ops.aten.t.default(t_default_470);  t_default_470 = None
        view_default_737 = torch.ops.aten.view.default(mm_default_162, [64, 128, 1024]);  mm_default_162 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(getitem_225, view_default_737);  getitem_225 = view_default_737 = None
        permute_default_151 = torch.ops.aten.permute.default(transpose_int_93, [0, 2, 1, 3]);  transpose_int_93 = None
        view_default_738 = torch.ops.aten.view.default(permute_default_151, [64, 128, 1024]);  permute_default_151 = None
        clone_default_151 = torch.ops.aten.clone.default(view_default_738, memory_format = torch.contiguous_format);  view_default_738 = None
        _unsafe_view_default_175 = torch.ops.aten._unsafe_view.default(clone_default_151, [8192, 1024]);  clone_default_151 = None
        t_default_472 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_164 = torch.ops.aten.mm.default(_unsafe_view_default_175, t_default_472);  t_default_472 = None
        t_default_473 = torch.ops.aten.t.default(_unsafe_view_default_175)
        mm_default_165 = torch.ops.aten.mm.default(t_default_473, view_default_172);  t_default_473 = view_default_172 = None
        t_default_474 = torch.ops.aten.t.default(mm_default_165);  mm_default_165 = None
        sum_dim_int_list_82 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_175, [0], True);  _unsafe_view_default_175 = None
        view_default_739 = torch.ops.aten.view.default(sum_dim_int_list_82, [1024]);  sum_dim_int_list_82 = None
        t_default_475 = torch.ops.aten.t.default(t_default_474);  t_default_474 = None
        view_default_740 = torch.ops.aten.view.default(mm_default_164, [64, 128, 1024]);  mm_default_164 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(add_tensor_153, view_default_740);  add_tensor_153 = view_default_740 = None
        view_default_741 = torch.ops.aten.view.default(_unsafe_view_default_173, [8192, 1024]);  _unsafe_view_default_173 = None
        t_default_476 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_166 = torch.ops.aten.mm.default(view_default_741, t_default_476);  t_default_476 = None
        t_default_477 = torch.ops.aten.t.default(view_default_741)
        mm_default_167 = torch.ops.aten.mm.default(t_default_477, view_default_170);  t_default_477 = view_default_170 = None
        t_default_478 = torch.ops.aten.t.default(mm_default_167);  mm_default_167 = None
        sum_dim_int_list_83 = torch.ops.aten.sum.dim_IntList(view_default_741, [0], True);  view_default_741 = None
        view_default_742 = torch.ops.aten.view.default(sum_dim_int_list_83, [1024]);  sum_dim_int_list_83 = None
        t_default_479 = torch.ops.aten.t.default(t_default_478);  t_default_478 = None
        view_default_743 = torch.ops.aten.view.default(mm_default_166, [64, 128, 1024]);  mm_default_166 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(add_tensor_154, view_default_743);  add_tensor_154 = view_default_743 = None
        native_layer_norm_backward_default_28 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_155, add_tensor_29, [1024], getitem_58, getitem_59, primals_382, primals_381, [True, True, True]);  add_tensor_155 = add_tensor_29 = getitem_58 = getitem_59 = primals_382 = primals_381 = None
        getitem_228 = native_layer_norm_backward_default_28[0]
        getitem_229 = native_layer_norm_backward_default_28[1]
        getitem_230 = native_layer_norm_backward_default_28[2];  native_layer_norm_backward_default_28 = None
        view_default_744 = torch.ops.aten.view.default(getitem_228, [8192, 1024])
        t_default_480 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_168 = torch.ops.aten.mm.default(view_default_744, t_default_480);  t_default_480 = None
        t_default_481 = torch.ops.aten.t.default(view_default_744)
        mm_default_169 = torch.ops.aten.mm.default(t_default_481, view_default_168);  t_default_481 = view_default_168 = None
        t_default_482 = torch.ops.aten.t.default(mm_default_169);  mm_default_169 = None
        sum_dim_int_list_84 = torch.ops.aten.sum.dim_IntList(view_default_744, [0], True);  view_default_744 = None
        view_default_745 = torch.ops.aten.view.default(sum_dim_int_list_84, [1024]);  sum_dim_int_list_84 = None
        t_default_483 = torch.ops.aten.t.default(t_default_482);  t_default_482 = None
        view_default_746 = torch.ops.aten.view.default(mm_default_168, [64, 128, 4096]);  mm_default_168 = None
        to_dtype_42 = torch.ops.aten.to.dtype(view_default_746, torch.float32);  view_default_746 = None
        to_dtype_43 = torch.ops.aten.to.dtype(view_default_167, torch.float32);  view_default_167 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_43, 0.7071067811865476)
        erf_default_14 = torch.ops.aten.erf.default(mul_tensor_98);  mul_tensor_98 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(erf_default_14, 1);  erf_default_14 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(add_tensor_156, 0.5);  add_tensor_156 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype_43, to_dtype_43)
        mul_tensor_101 = torch.ops.aten.mul.Tensor(mul_tensor_100, -0.5);  mul_tensor_100 = None
        exp_default_14 = torch.ops.aten.exp.default(mul_tensor_101);  mul_tensor_101 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(exp_default_14, 0.3989422804014327);  exp_default_14 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_43, mul_tensor_102);  to_dtype_43 = mul_tensor_102 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(mul_tensor_99, mul_tensor_103);  mul_tensor_99 = mul_tensor_103 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_42, add_tensor_157);  to_dtype_42 = add_tensor_157 = None
        to_dtype_44 = torch.ops.aten.to.dtype(mul_tensor_104, torch.float32);  mul_tensor_104 = None
        view_default_747 = torch.ops.aten.view.default(to_dtype_44, [8192, 4096]);  to_dtype_44 = None
        t_default_484 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_170 = torch.ops.aten.mm.default(view_default_747, t_default_484);  t_default_484 = None
        t_default_485 = torch.ops.aten.t.default(view_default_747)
        mm_default_171 = torch.ops.aten.mm.default(t_default_485, view_default_166);  t_default_485 = view_default_166 = None
        t_default_486 = torch.ops.aten.t.default(mm_default_171);  mm_default_171 = None
        sum_dim_int_list_85 = torch.ops.aten.sum.dim_IntList(view_default_747, [0], True);  view_default_747 = None
        view_default_748 = torch.ops.aten.view.default(sum_dim_int_list_85, [4096]);  sum_dim_int_list_85 = None
        t_default_487 = torch.ops.aten.t.default(t_default_486);  t_default_486 = None
        view_default_749 = torch.ops.aten.view.default(mm_default_170, [64, 128, 1024]);  mm_default_170 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(getitem_228, view_default_749);  getitem_228 = view_default_749 = None
        native_layer_norm_backward_default_29 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_158, add_tensor_28, [1024], getitem_55, getitem_56, primals_370, primals_369, [True, True, True]);  add_tensor_158 = add_tensor_28 = getitem_55 = getitem_56 = primals_370 = primals_369 = None
        getitem_231 = native_layer_norm_backward_default_29[0]
        getitem_232 = native_layer_norm_backward_default_29[1]
        getitem_233 = native_layer_norm_backward_default_29[2];  native_layer_norm_backward_default_29 = None
        view_default_750 = torch.ops.aten.view.default(getitem_231, [8192, 1024])
        t_default_488 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_172 = torch.ops.aten.mm.default(view_default_750, t_default_488);  t_default_488 = None
        t_default_489 = torch.ops.aten.t.default(view_default_750)
        mm_default_173 = torch.ops.aten.mm.default(t_default_489, view_default_164);  t_default_489 = view_default_164 = None
        t_default_490 = torch.ops.aten.t.default(mm_default_173);  mm_default_173 = None
        sum_dim_int_list_86 = torch.ops.aten.sum.dim_IntList(view_default_750, [0], True);  view_default_750 = None
        view_default_751 = torch.ops.aten.view.default(sum_dim_int_list_86, [1024]);  sum_dim_int_list_86 = None
        t_default_491 = torch.ops.aten.t.default(t_default_490);  t_default_490 = None
        view_default_752 = torch.ops.aten.view.default(mm_default_172, [64, 128, 1024]);  mm_default_172 = None
        view_default_753 = torch.ops.aten.view.default(view_default_752, [64, 128, 16, 64]);  view_default_752 = None
        permute_default_152 = torch.ops.aten.permute.default(view_default_753, [0, 2, 1, 3]);  view_default_753 = None
        clone_default_152 = torch.ops.aten.clone.default(permute_default_152, memory_format = torch.contiguous_format);  permute_default_152 = None
        _unsafe_view_default_176 = torch.ops.aten._unsafe_view.default(clone_default_152, [1024, 128, 64]);  clone_default_152 = None
        transpose_int_94 = torch.ops.aten.transpose.int(view_default_162, 1, 2);  view_default_162 = None
        bmm_default_104 = torch.ops.aten.bmm.default(transpose_int_94, _unsafe_view_default_176);  transpose_int_94 = None
        transpose_int_95 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_105 = torch.ops.aten.bmm.default(_unsafe_view_default_176, transpose_int_95);  _unsafe_view_default_176 = transpose_int_95 = None
        view_default_754 = torch.ops.aten.view.default(bmm_default_104, [64, 16, 128, 64]);  bmm_default_104 = None
        view_default_755 = torch.ops.aten.view.default(bmm_default_105, [64, 16, 128, 128]);  bmm_default_105 = None
        _softmax_backward_data_default_14 = torch.ops.aten._softmax_backward_data.default(view_default_755, _softmax_default_9, -1, torch.float32);  view_default_755 = _softmax_default_9 = None
        div_tensor_38 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_14, 8.0);  _softmax_backward_data_default_14 = None
        view_default_756 = torch.ops.aten.view.default(div_tensor_38, [1024, 128, 128]);  div_tensor_38 = None
        transpose_int_96 = torch.ops.aten.transpose.int(_unsafe_view_default_45, 1, 2);  _unsafe_view_default_45 = None
        bmm_default_106 = torch.ops.aten.bmm.default(transpose_int_96, view_default_756);  transpose_int_96 = None
        transpose_int_97 = torch.ops.aten.transpose.int(_unsafe_view_default_46, 1, 2);  _unsafe_view_default_46 = None
        bmm_default_107 = torch.ops.aten.bmm.default(view_default_756, transpose_int_97);  view_default_756 = transpose_int_97 = None
        view_default_757 = torch.ops.aten.view.default(bmm_default_106, [64, 16, 64, 128]);  bmm_default_106 = None
        view_default_758 = torch.ops.aten.view.default(bmm_default_107, [64, 16, 128, 64]);  bmm_default_107 = None
        transpose_int_98 = torch.ops.aten.transpose.int(view_default_757, -1, -2);  view_default_757 = None
        permute_default_153 = torch.ops.aten.permute.default(view_default_758, [0, 2, 1, 3]);  view_default_758 = None
        clone_default_153 = torch.ops.aten.clone.default(permute_default_153, memory_format = torch.contiguous_format);  permute_default_153 = None
        _unsafe_view_default_177 = torch.ops.aten._unsafe_view.default(clone_default_153, [64, 128, 1024]);  clone_default_153 = None
        permute_default_154 = torch.ops.aten.permute.default(view_default_754, [0, 2, 1, 3]);  view_default_754 = None
        clone_default_154 = torch.ops.aten.clone.default(permute_default_154, memory_format = torch.contiguous_format);  permute_default_154 = None
        _unsafe_view_default_178 = torch.ops.aten._unsafe_view.default(clone_default_154, [64, 128, 1024]);  clone_default_154 = None
        view_default_759 = torch.ops.aten.view.default(_unsafe_view_default_178, [8192, 1024]);  _unsafe_view_default_178 = None
        t_default_492 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_174 = torch.ops.aten.mm.default(view_default_759, t_default_492);  t_default_492 = None
        t_default_493 = torch.ops.aten.t.default(view_default_759)
        mm_default_175 = torch.ops.aten.mm.default(t_default_493, view_default_158);  t_default_493 = view_default_158 = None
        t_default_494 = torch.ops.aten.t.default(mm_default_175);  mm_default_175 = None
        sum_dim_int_list_87 = torch.ops.aten.sum.dim_IntList(view_default_759, [0], True);  view_default_759 = None
        view_default_760 = torch.ops.aten.view.default(sum_dim_int_list_87, [1024]);  sum_dim_int_list_87 = None
        t_default_495 = torch.ops.aten.t.default(t_default_494);  t_default_494 = None
        view_default_761 = torch.ops.aten.view.default(mm_default_174, [64, 128, 1024]);  mm_default_174 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(getitem_231, view_default_761);  getitem_231 = view_default_761 = None
        permute_default_155 = torch.ops.aten.permute.default(transpose_int_98, [0, 2, 1, 3]);  transpose_int_98 = None
        view_default_762 = torch.ops.aten.view.default(permute_default_155, [64, 128, 1024]);  permute_default_155 = None
        clone_default_155 = torch.ops.aten.clone.default(view_default_762, memory_format = torch.contiguous_format);  view_default_762 = None
        _unsafe_view_default_179 = torch.ops.aten._unsafe_view.default(clone_default_155, [8192, 1024]);  clone_default_155 = None
        t_default_496 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_176 = torch.ops.aten.mm.default(_unsafe_view_default_179, t_default_496);  t_default_496 = None
        t_default_497 = torch.ops.aten.t.default(_unsafe_view_default_179)
        mm_default_177 = torch.ops.aten.mm.default(t_default_497, view_default_155);  t_default_497 = view_default_155 = None
        t_default_498 = torch.ops.aten.t.default(mm_default_177);  mm_default_177 = None
        sum_dim_int_list_88 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_179, [0], True);  _unsafe_view_default_179 = None
        view_default_763 = torch.ops.aten.view.default(sum_dim_int_list_88, [1024]);  sum_dim_int_list_88 = None
        t_default_499 = torch.ops.aten.t.default(t_default_498);  t_default_498 = None
        view_default_764 = torch.ops.aten.view.default(mm_default_176, [64, 128, 1024]);  mm_default_176 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(add_tensor_159, view_default_764);  add_tensor_159 = view_default_764 = None
        view_default_765 = torch.ops.aten.view.default(_unsafe_view_default_177, [8192, 1024]);  _unsafe_view_default_177 = None
        t_default_500 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_178 = torch.ops.aten.mm.default(view_default_765, t_default_500);  t_default_500 = None
        t_default_501 = torch.ops.aten.t.default(view_default_765)
        mm_default_179 = torch.ops.aten.mm.default(t_default_501, view_default_153);  t_default_501 = view_default_153 = None
        t_default_502 = torch.ops.aten.t.default(mm_default_179);  mm_default_179 = None
        sum_dim_int_list_89 = torch.ops.aten.sum.dim_IntList(view_default_765, [0], True);  view_default_765 = None
        view_default_766 = torch.ops.aten.view.default(sum_dim_int_list_89, [1024]);  sum_dim_int_list_89 = None
        t_default_503 = torch.ops.aten.t.default(t_default_502);  t_default_502 = None
        view_default_767 = torch.ops.aten.view.default(mm_default_178, [64, 128, 1024]);  mm_default_178 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(add_tensor_160, view_default_767);  add_tensor_160 = view_default_767 = None
        native_layer_norm_backward_default_30 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_161, add_tensor_26, [1024], getitem_52, getitem_53, primals_366, primals_365, [True, True, True]);  add_tensor_161 = add_tensor_26 = getitem_52 = getitem_53 = primals_366 = primals_365 = None
        getitem_234 = native_layer_norm_backward_default_30[0]
        getitem_235 = native_layer_norm_backward_default_30[1]
        getitem_236 = native_layer_norm_backward_default_30[2];  native_layer_norm_backward_default_30 = None
        view_default_768 = torch.ops.aten.view.default(getitem_234, [8192, 1024])
        t_default_504 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_180 = torch.ops.aten.mm.default(view_default_768, t_default_504);  t_default_504 = None
        t_default_505 = torch.ops.aten.t.default(view_default_768)
        mm_default_181 = torch.ops.aten.mm.default(t_default_505, view_default_151);  t_default_505 = view_default_151 = None
        t_default_506 = torch.ops.aten.t.default(mm_default_181);  mm_default_181 = None
        sum_dim_int_list_90 = torch.ops.aten.sum.dim_IntList(view_default_768, [0], True);  view_default_768 = None
        view_default_769 = torch.ops.aten.view.default(sum_dim_int_list_90, [1024]);  sum_dim_int_list_90 = None
        t_default_507 = torch.ops.aten.t.default(t_default_506);  t_default_506 = None
        view_default_770 = torch.ops.aten.view.default(mm_default_180, [64, 128, 4096]);  mm_default_180 = None
        to_dtype_45 = torch.ops.aten.to.dtype(view_default_770, torch.float32);  view_default_770 = None
        to_dtype_46 = torch.ops.aten.to.dtype(view_default_150, torch.float32);  view_default_150 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_46, 0.7071067811865476)
        erf_default_15 = torch.ops.aten.erf.default(mul_tensor_105);  mul_tensor_105 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(erf_default_15, 1);  erf_default_15 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(add_tensor_162, 0.5);  add_tensor_162 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(to_dtype_46, to_dtype_46)
        mul_tensor_108 = torch.ops.aten.mul.Tensor(mul_tensor_107, -0.5);  mul_tensor_107 = None
        exp_default_15 = torch.ops.aten.exp.default(mul_tensor_108);  mul_tensor_108 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(exp_default_15, 0.3989422804014327);  exp_default_15 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_46, mul_tensor_109);  to_dtype_46 = mul_tensor_109 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(mul_tensor_106, mul_tensor_110);  mul_tensor_106 = mul_tensor_110 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(to_dtype_45, add_tensor_163);  to_dtype_45 = add_tensor_163 = None
        to_dtype_47 = torch.ops.aten.to.dtype(mul_tensor_111, torch.float32);  mul_tensor_111 = None
        view_default_771 = torch.ops.aten.view.default(to_dtype_47, [8192, 4096]);  to_dtype_47 = None
        t_default_508 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_182 = torch.ops.aten.mm.default(view_default_771, t_default_508);  t_default_508 = None
        t_default_509 = torch.ops.aten.t.default(view_default_771)
        mm_default_183 = torch.ops.aten.mm.default(t_default_509, view_default_149);  t_default_509 = view_default_149 = None
        t_default_510 = torch.ops.aten.t.default(mm_default_183);  mm_default_183 = None
        sum_dim_int_list_91 = torch.ops.aten.sum.dim_IntList(view_default_771, [0], True);  view_default_771 = None
        view_default_772 = torch.ops.aten.view.default(sum_dim_int_list_91, [4096]);  sum_dim_int_list_91 = None
        t_default_511 = torch.ops.aten.t.default(t_default_510);  t_default_510 = None
        view_default_773 = torch.ops.aten.view.default(mm_default_182, [64, 128, 1024]);  mm_default_182 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(getitem_234, view_default_773);  getitem_234 = view_default_773 = None
        native_layer_norm_backward_default_31 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_164, add_tensor_25, [1024], getitem_49, getitem_50, primals_354, primals_353, [True, True, True]);  add_tensor_164 = add_tensor_25 = getitem_49 = getitem_50 = primals_354 = primals_353 = None
        getitem_237 = native_layer_norm_backward_default_31[0]
        getitem_238 = native_layer_norm_backward_default_31[1]
        getitem_239 = native_layer_norm_backward_default_31[2];  native_layer_norm_backward_default_31 = None
        view_default_774 = torch.ops.aten.view.default(getitem_237, [8192, 1024])
        t_default_512 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_184 = torch.ops.aten.mm.default(view_default_774, t_default_512);  t_default_512 = None
        t_default_513 = torch.ops.aten.t.default(view_default_774)
        mm_default_185 = torch.ops.aten.mm.default(t_default_513, view_default_147);  t_default_513 = view_default_147 = None
        t_default_514 = torch.ops.aten.t.default(mm_default_185);  mm_default_185 = None
        sum_dim_int_list_92 = torch.ops.aten.sum.dim_IntList(view_default_774, [0], True);  view_default_774 = None
        view_default_775 = torch.ops.aten.view.default(sum_dim_int_list_92, [1024]);  sum_dim_int_list_92 = None
        t_default_515 = torch.ops.aten.t.default(t_default_514);  t_default_514 = None
        view_default_776 = torch.ops.aten.view.default(mm_default_184, [64, 128, 1024]);  mm_default_184 = None
        view_default_777 = torch.ops.aten.view.default(view_default_776, [64, 128, 16, 64]);  view_default_776 = None
        permute_default_156 = torch.ops.aten.permute.default(view_default_777, [0, 2, 1, 3]);  view_default_777 = None
        clone_default_156 = torch.ops.aten.clone.default(permute_default_156, memory_format = torch.contiguous_format);  permute_default_156 = None
        _unsafe_view_default_180 = torch.ops.aten._unsafe_view.default(clone_default_156, [1024, 128, 64]);  clone_default_156 = None
        transpose_int_99 = torch.ops.aten.transpose.int(view_default_145, 1, 2);  view_default_145 = None
        bmm_default_108 = torch.ops.aten.bmm.default(transpose_int_99, _unsafe_view_default_180);  transpose_int_99 = None
        transpose_int_100 = torch.ops.aten.transpose.int(_unsafe_view_default_43, 1, 2);  _unsafe_view_default_43 = None
        bmm_default_109 = torch.ops.aten.bmm.default(_unsafe_view_default_180, transpose_int_100);  _unsafe_view_default_180 = transpose_int_100 = None
        view_default_778 = torch.ops.aten.view.default(bmm_default_108, [64, 16, 128, 64]);  bmm_default_108 = None
        view_default_779 = torch.ops.aten.view.default(bmm_default_109, [64, 16, 128, 128]);  bmm_default_109 = None
        _softmax_backward_data_default_15 = torch.ops.aten._softmax_backward_data.default(view_default_779, _softmax_default_8, -1, torch.float32);  view_default_779 = _softmax_default_8 = None
        div_tensor_39 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_15, 8.0);  _softmax_backward_data_default_15 = None
        view_default_780 = torch.ops.aten.view.default(div_tensor_39, [1024, 128, 128]);  div_tensor_39 = None
        transpose_int_101 = torch.ops.aten.transpose.int(_unsafe_view_default_40, 1, 2);  _unsafe_view_default_40 = None
        bmm_default_110 = torch.ops.aten.bmm.default(transpose_int_101, view_default_780);  transpose_int_101 = None
        transpose_int_102 = torch.ops.aten.transpose.int(_unsafe_view_default_41, 1, 2);  _unsafe_view_default_41 = None
        bmm_default_111 = torch.ops.aten.bmm.default(view_default_780, transpose_int_102);  view_default_780 = transpose_int_102 = None
        view_default_781 = torch.ops.aten.view.default(bmm_default_110, [64, 16, 64, 128]);  bmm_default_110 = None
        view_default_782 = torch.ops.aten.view.default(bmm_default_111, [64, 16, 128, 64]);  bmm_default_111 = None
        transpose_int_103 = torch.ops.aten.transpose.int(view_default_781, -1, -2);  view_default_781 = None
        permute_default_157 = torch.ops.aten.permute.default(view_default_782, [0, 2, 1, 3]);  view_default_782 = None
        clone_default_157 = torch.ops.aten.clone.default(permute_default_157, memory_format = torch.contiguous_format);  permute_default_157 = None
        _unsafe_view_default_181 = torch.ops.aten._unsafe_view.default(clone_default_157, [64, 128, 1024]);  clone_default_157 = None
        permute_default_158 = torch.ops.aten.permute.default(view_default_778, [0, 2, 1, 3]);  view_default_778 = None
        clone_default_158 = torch.ops.aten.clone.default(permute_default_158, memory_format = torch.contiguous_format);  permute_default_158 = None
        _unsafe_view_default_182 = torch.ops.aten._unsafe_view.default(clone_default_158, [64, 128, 1024]);  clone_default_158 = None
        view_default_783 = torch.ops.aten.view.default(_unsafe_view_default_182, [8192, 1024]);  _unsafe_view_default_182 = None
        t_default_516 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_186 = torch.ops.aten.mm.default(view_default_783, t_default_516);  t_default_516 = None
        t_default_517 = torch.ops.aten.t.default(view_default_783)
        mm_default_187 = torch.ops.aten.mm.default(t_default_517, view_default_141);  t_default_517 = view_default_141 = None
        t_default_518 = torch.ops.aten.t.default(mm_default_187);  mm_default_187 = None
        sum_dim_int_list_93 = torch.ops.aten.sum.dim_IntList(view_default_783, [0], True);  view_default_783 = None
        view_default_784 = torch.ops.aten.view.default(sum_dim_int_list_93, [1024]);  sum_dim_int_list_93 = None
        t_default_519 = torch.ops.aten.t.default(t_default_518);  t_default_518 = None
        view_default_785 = torch.ops.aten.view.default(mm_default_186, [64, 128, 1024]);  mm_default_186 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(getitem_237, view_default_785);  getitem_237 = view_default_785 = None
        permute_default_159 = torch.ops.aten.permute.default(transpose_int_103, [0, 2, 1, 3]);  transpose_int_103 = None
        view_default_786 = torch.ops.aten.view.default(permute_default_159, [64, 128, 1024]);  permute_default_159 = None
        clone_default_159 = torch.ops.aten.clone.default(view_default_786, memory_format = torch.contiguous_format);  view_default_786 = None
        _unsafe_view_default_183 = torch.ops.aten._unsafe_view.default(clone_default_159, [8192, 1024]);  clone_default_159 = None
        t_default_520 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_188 = torch.ops.aten.mm.default(_unsafe_view_default_183, t_default_520);  t_default_520 = None
        t_default_521 = torch.ops.aten.t.default(_unsafe_view_default_183)
        mm_default_189 = torch.ops.aten.mm.default(t_default_521, view_default_138);  t_default_521 = view_default_138 = None
        t_default_522 = torch.ops.aten.t.default(mm_default_189);  mm_default_189 = None
        sum_dim_int_list_94 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_183, [0], True);  _unsafe_view_default_183 = None
        view_default_787 = torch.ops.aten.view.default(sum_dim_int_list_94, [1024]);  sum_dim_int_list_94 = None
        t_default_523 = torch.ops.aten.t.default(t_default_522);  t_default_522 = None
        view_default_788 = torch.ops.aten.view.default(mm_default_188, [64, 128, 1024]);  mm_default_188 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(add_tensor_165, view_default_788);  add_tensor_165 = view_default_788 = None
        view_default_789 = torch.ops.aten.view.default(_unsafe_view_default_181, [8192, 1024]);  _unsafe_view_default_181 = None
        t_default_524 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_190 = torch.ops.aten.mm.default(view_default_789, t_default_524);  t_default_524 = None
        t_default_525 = torch.ops.aten.t.default(view_default_789)
        mm_default_191 = torch.ops.aten.mm.default(t_default_525, view_default_136);  t_default_525 = view_default_136 = None
        t_default_526 = torch.ops.aten.t.default(mm_default_191);  mm_default_191 = None
        sum_dim_int_list_95 = torch.ops.aten.sum.dim_IntList(view_default_789, [0], True);  view_default_789 = None
        view_default_790 = torch.ops.aten.view.default(sum_dim_int_list_95, [1024]);  sum_dim_int_list_95 = None
        t_default_527 = torch.ops.aten.t.default(t_default_526);  t_default_526 = None
        view_default_791 = torch.ops.aten.view.default(mm_default_190, [64, 128, 1024]);  mm_default_190 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(add_tensor_166, view_default_791);  add_tensor_166 = view_default_791 = None
        native_layer_norm_backward_default_32 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_167, add_tensor_23, [1024], getitem_46, getitem_47, primals_350, primals_349, [True, True, True]);  add_tensor_167 = add_tensor_23 = getitem_46 = getitem_47 = primals_350 = primals_349 = None
        getitem_240 = native_layer_norm_backward_default_32[0]
        getitem_241 = native_layer_norm_backward_default_32[1]
        getitem_242 = native_layer_norm_backward_default_32[2];  native_layer_norm_backward_default_32 = None
        view_default_792 = torch.ops.aten.view.default(getitem_240, [8192, 1024])
        t_default_528 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_192 = torch.ops.aten.mm.default(view_default_792, t_default_528);  t_default_528 = None
        t_default_529 = torch.ops.aten.t.default(view_default_792)
        mm_default_193 = torch.ops.aten.mm.default(t_default_529, view_default_134);  t_default_529 = view_default_134 = None
        t_default_530 = torch.ops.aten.t.default(mm_default_193);  mm_default_193 = None
        sum_dim_int_list_96 = torch.ops.aten.sum.dim_IntList(view_default_792, [0], True);  view_default_792 = None
        view_default_793 = torch.ops.aten.view.default(sum_dim_int_list_96, [1024]);  sum_dim_int_list_96 = None
        t_default_531 = torch.ops.aten.t.default(t_default_530);  t_default_530 = None
        view_default_794 = torch.ops.aten.view.default(mm_default_192, [64, 128, 4096]);  mm_default_192 = None
        to_dtype_48 = torch.ops.aten.to.dtype(view_default_794, torch.float32);  view_default_794 = None
        to_dtype_49 = torch.ops.aten.to.dtype(view_default_133, torch.float32);  view_default_133 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_49, 0.7071067811865476)
        erf_default_16 = torch.ops.aten.erf.default(mul_tensor_112);  mul_tensor_112 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(erf_default_16, 1);  erf_default_16 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(add_tensor_168, 0.5);  add_tensor_168 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_49, to_dtype_49)
        mul_tensor_115 = torch.ops.aten.mul.Tensor(mul_tensor_114, -0.5);  mul_tensor_114 = None
        exp_default_16 = torch.ops.aten.exp.default(mul_tensor_115);  mul_tensor_115 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(exp_default_16, 0.3989422804014327);  exp_default_16 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_49, mul_tensor_116);  to_dtype_49 = mul_tensor_116 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(mul_tensor_113, mul_tensor_117);  mul_tensor_113 = mul_tensor_117 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(to_dtype_48, add_tensor_169);  to_dtype_48 = add_tensor_169 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_118, torch.float32);  mul_tensor_118 = None
        view_default_795 = torch.ops.aten.view.default(to_dtype_50, [8192, 4096]);  to_dtype_50 = None
        t_default_532 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_194 = torch.ops.aten.mm.default(view_default_795, t_default_532);  t_default_532 = None
        t_default_533 = torch.ops.aten.t.default(view_default_795)
        mm_default_195 = torch.ops.aten.mm.default(t_default_533, view_default_132);  t_default_533 = view_default_132 = None
        t_default_534 = torch.ops.aten.t.default(mm_default_195);  mm_default_195 = None
        sum_dim_int_list_97 = torch.ops.aten.sum.dim_IntList(view_default_795, [0], True);  view_default_795 = None
        view_default_796 = torch.ops.aten.view.default(sum_dim_int_list_97, [4096]);  sum_dim_int_list_97 = None
        t_default_535 = torch.ops.aten.t.default(t_default_534);  t_default_534 = None
        view_default_797 = torch.ops.aten.view.default(mm_default_194, [64, 128, 1024]);  mm_default_194 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(getitem_240, view_default_797);  getitem_240 = view_default_797 = None
        native_layer_norm_backward_default_33 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_170, add_tensor_22, [1024], getitem_43, getitem_44, primals_338, primals_337, [True, True, True]);  add_tensor_170 = add_tensor_22 = getitem_43 = getitem_44 = primals_338 = primals_337 = None
        getitem_243 = native_layer_norm_backward_default_33[0]
        getitem_244 = native_layer_norm_backward_default_33[1]
        getitem_245 = native_layer_norm_backward_default_33[2];  native_layer_norm_backward_default_33 = None
        view_default_798 = torch.ops.aten.view.default(getitem_243, [8192, 1024])
        t_default_536 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_196 = torch.ops.aten.mm.default(view_default_798, t_default_536);  t_default_536 = None
        t_default_537 = torch.ops.aten.t.default(view_default_798)
        mm_default_197 = torch.ops.aten.mm.default(t_default_537, view_default_130);  t_default_537 = view_default_130 = None
        t_default_538 = torch.ops.aten.t.default(mm_default_197);  mm_default_197 = None
        sum_dim_int_list_98 = torch.ops.aten.sum.dim_IntList(view_default_798, [0], True);  view_default_798 = None
        view_default_799 = torch.ops.aten.view.default(sum_dim_int_list_98, [1024]);  sum_dim_int_list_98 = None
        t_default_539 = torch.ops.aten.t.default(t_default_538);  t_default_538 = None
        view_default_800 = torch.ops.aten.view.default(mm_default_196, [64, 128, 1024]);  mm_default_196 = None
        view_default_801 = torch.ops.aten.view.default(view_default_800, [64, 128, 16, 64]);  view_default_800 = None
        permute_default_160 = torch.ops.aten.permute.default(view_default_801, [0, 2, 1, 3]);  view_default_801 = None
        clone_default_160 = torch.ops.aten.clone.default(permute_default_160, memory_format = torch.contiguous_format);  permute_default_160 = None
        _unsafe_view_default_184 = torch.ops.aten._unsafe_view.default(clone_default_160, [1024, 128, 64]);  clone_default_160 = None
        transpose_int_104 = torch.ops.aten.transpose.int(view_default_128, 1, 2);  view_default_128 = None
        bmm_default_112 = torch.ops.aten.bmm.default(transpose_int_104, _unsafe_view_default_184);  transpose_int_104 = None
        transpose_int_105 = torch.ops.aten.transpose.int(_unsafe_view_default_38, 1, 2);  _unsafe_view_default_38 = None
        bmm_default_113 = torch.ops.aten.bmm.default(_unsafe_view_default_184, transpose_int_105);  _unsafe_view_default_184 = transpose_int_105 = None
        view_default_802 = torch.ops.aten.view.default(bmm_default_112, [64, 16, 128, 64]);  bmm_default_112 = None
        view_default_803 = torch.ops.aten.view.default(bmm_default_113, [64, 16, 128, 128]);  bmm_default_113 = None
        _softmax_backward_data_default_16 = torch.ops.aten._softmax_backward_data.default(view_default_803, _softmax_default_7, -1, torch.float32);  view_default_803 = _softmax_default_7 = None
        div_tensor_40 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_16, 8.0);  _softmax_backward_data_default_16 = None
        view_default_804 = torch.ops.aten.view.default(div_tensor_40, [1024, 128, 128]);  div_tensor_40 = None
        transpose_int_106 = torch.ops.aten.transpose.int(_unsafe_view_default_35, 1, 2);  _unsafe_view_default_35 = None
        bmm_default_114 = torch.ops.aten.bmm.default(transpose_int_106, view_default_804);  transpose_int_106 = None
        transpose_int_107 = torch.ops.aten.transpose.int(_unsafe_view_default_36, 1, 2);  _unsafe_view_default_36 = None
        bmm_default_115 = torch.ops.aten.bmm.default(view_default_804, transpose_int_107);  view_default_804 = transpose_int_107 = None
        view_default_805 = torch.ops.aten.view.default(bmm_default_114, [64, 16, 64, 128]);  bmm_default_114 = None
        view_default_806 = torch.ops.aten.view.default(bmm_default_115, [64, 16, 128, 64]);  bmm_default_115 = None
        transpose_int_108 = torch.ops.aten.transpose.int(view_default_805, -1, -2);  view_default_805 = None
        permute_default_161 = torch.ops.aten.permute.default(view_default_806, [0, 2, 1, 3]);  view_default_806 = None
        clone_default_161 = torch.ops.aten.clone.default(permute_default_161, memory_format = torch.contiguous_format);  permute_default_161 = None
        _unsafe_view_default_185 = torch.ops.aten._unsafe_view.default(clone_default_161, [64, 128, 1024]);  clone_default_161 = None
        permute_default_162 = torch.ops.aten.permute.default(view_default_802, [0, 2, 1, 3]);  view_default_802 = None
        clone_default_162 = torch.ops.aten.clone.default(permute_default_162, memory_format = torch.contiguous_format);  permute_default_162 = None
        _unsafe_view_default_186 = torch.ops.aten._unsafe_view.default(clone_default_162, [64, 128, 1024]);  clone_default_162 = None
        view_default_807 = torch.ops.aten.view.default(_unsafe_view_default_186, [8192, 1024]);  _unsafe_view_default_186 = None
        t_default_540 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_198 = torch.ops.aten.mm.default(view_default_807, t_default_540);  t_default_540 = None
        t_default_541 = torch.ops.aten.t.default(view_default_807)
        mm_default_199 = torch.ops.aten.mm.default(t_default_541, view_default_124);  t_default_541 = view_default_124 = None
        t_default_542 = torch.ops.aten.t.default(mm_default_199);  mm_default_199 = None
        sum_dim_int_list_99 = torch.ops.aten.sum.dim_IntList(view_default_807, [0], True);  view_default_807 = None
        view_default_808 = torch.ops.aten.view.default(sum_dim_int_list_99, [1024]);  sum_dim_int_list_99 = None
        t_default_543 = torch.ops.aten.t.default(t_default_542);  t_default_542 = None
        view_default_809 = torch.ops.aten.view.default(mm_default_198, [64, 128, 1024]);  mm_default_198 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(getitem_243, view_default_809);  getitem_243 = view_default_809 = None
        permute_default_163 = torch.ops.aten.permute.default(transpose_int_108, [0, 2, 1, 3]);  transpose_int_108 = None
        view_default_810 = torch.ops.aten.view.default(permute_default_163, [64, 128, 1024]);  permute_default_163 = None
        clone_default_163 = torch.ops.aten.clone.default(view_default_810, memory_format = torch.contiguous_format);  view_default_810 = None
        _unsafe_view_default_187 = torch.ops.aten._unsafe_view.default(clone_default_163, [8192, 1024]);  clone_default_163 = None
        t_default_544 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_200 = torch.ops.aten.mm.default(_unsafe_view_default_187, t_default_544);  t_default_544 = None
        t_default_545 = torch.ops.aten.t.default(_unsafe_view_default_187)
        mm_default_201 = torch.ops.aten.mm.default(t_default_545, view_default_121);  t_default_545 = view_default_121 = None
        t_default_546 = torch.ops.aten.t.default(mm_default_201);  mm_default_201 = None
        sum_dim_int_list_100 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_187, [0], True);  _unsafe_view_default_187 = None
        view_default_811 = torch.ops.aten.view.default(sum_dim_int_list_100, [1024]);  sum_dim_int_list_100 = None
        t_default_547 = torch.ops.aten.t.default(t_default_546);  t_default_546 = None
        view_default_812 = torch.ops.aten.view.default(mm_default_200, [64, 128, 1024]);  mm_default_200 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(add_tensor_171, view_default_812);  add_tensor_171 = view_default_812 = None
        view_default_813 = torch.ops.aten.view.default(_unsafe_view_default_185, [8192, 1024]);  _unsafe_view_default_185 = None
        t_default_548 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_202 = torch.ops.aten.mm.default(view_default_813, t_default_548);  t_default_548 = None
        t_default_549 = torch.ops.aten.t.default(view_default_813)
        mm_default_203 = torch.ops.aten.mm.default(t_default_549, view_default_119);  t_default_549 = view_default_119 = None
        t_default_550 = torch.ops.aten.t.default(mm_default_203);  mm_default_203 = None
        sum_dim_int_list_101 = torch.ops.aten.sum.dim_IntList(view_default_813, [0], True);  view_default_813 = None
        view_default_814 = torch.ops.aten.view.default(sum_dim_int_list_101, [1024]);  sum_dim_int_list_101 = None
        t_default_551 = torch.ops.aten.t.default(t_default_550);  t_default_550 = None
        view_default_815 = torch.ops.aten.view.default(mm_default_202, [64, 128, 1024]);  mm_default_202 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(add_tensor_172, view_default_815);  add_tensor_172 = view_default_815 = None
        native_layer_norm_backward_default_34 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_173, add_tensor_20, [1024], getitem_40, getitem_41, primals_334, primals_333, [True, True, True]);  add_tensor_173 = add_tensor_20 = getitem_40 = getitem_41 = primals_334 = primals_333 = None
        getitem_246 = native_layer_norm_backward_default_34[0]
        getitem_247 = native_layer_norm_backward_default_34[1]
        getitem_248 = native_layer_norm_backward_default_34[2];  native_layer_norm_backward_default_34 = None
        view_default_816 = torch.ops.aten.view.default(getitem_246, [8192, 1024])
        t_default_552 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_204 = torch.ops.aten.mm.default(view_default_816, t_default_552);  t_default_552 = None
        t_default_553 = torch.ops.aten.t.default(view_default_816)
        mm_default_205 = torch.ops.aten.mm.default(t_default_553, view_default_117);  t_default_553 = view_default_117 = None
        t_default_554 = torch.ops.aten.t.default(mm_default_205);  mm_default_205 = None
        sum_dim_int_list_102 = torch.ops.aten.sum.dim_IntList(view_default_816, [0], True);  view_default_816 = None
        view_default_817 = torch.ops.aten.view.default(sum_dim_int_list_102, [1024]);  sum_dim_int_list_102 = None
        t_default_555 = torch.ops.aten.t.default(t_default_554);  t_default_554 = None
        view_default_818 = torch.ops.aten.view.default(mm_default_204, [64, 128, 4096]);  mm_default_204 = None
        to_dtype_51 = torch.ops.aten.to.dtype(view_default_818, torch.float32);  view_default_818 = None
        to_dtype_52 = torch.ops.aten.to.dtype(view_default_116, torch.float32);  view_default_116 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_52, 0.7071067811865476)
        erf_default_17 = torch.ops.aten.erf.default(mul_tensor_119);  mul_tensor_119 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(erf_default_17, 1);  erf_default_17 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(add_tensor_174, 0.5);  add_tensor_174 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_52, to_dtype_52)
        mul_tensor_122 = torch.ops.aten.mul.Tensor(mul_tensor_121, -0.5);  mul_tensor_121 = None
        exp_default_17 = torch.ops.aten.exp.default(mul_tensor_122);  mul_tensor_122 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(exp_default_17, 0.3989422804014327);  exp_default_17 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_52, mul_tensor_123);  to_dtype_52 = mul_tensor_123 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(mul_tensor_120, mul_tensor_124);  mul_tensor_120 = mul_tensor_124 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_51, add_tensor_175);  to_dtype_51 = add_tensor_175 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_125, torch.float32);  mul_tensor_125 = None
        view_default_819 = torch.ops.aten.view.default(to_dtype_53, [8192, 4096]);  to_dtype_53 = None
        t_default_556 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_206 = torch.ops.aten.mm.default(view_default_819, t_default_556);  t_default_556 = None
        t_default_557 = torch.ops.aten.t.default(view_default_819)
        mm_default_207 = torch.ops.aten.mm.default(t_default_557, view_default_115);  t_default_557 = view_default_115 = None
        t_default_558 = torch.ops.aten.t.default(mm_default_207);  mm_default_207 = None
        sum_dim_int_list_103 = torch.ops.aten.sum.dim_IntList(view_default_819, [0], True);  view_default_819 = None
        view_default_820 = torch.ops.aten.view.default(sum_dim_int_list_103, [4096]);  sum_dim_int_list_103 = None
        t_default_559 = torch.ops.aten.t.default(t_default_558);  t_default_558 = None
        view_default_821 = torch.ops.aten.view.default(mm_default_206, [64, 128, 1024]);  mm_default_206 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(getitem_246, view_default_821);  getitem_246 = view_default_821 = None
        native_layer_norm_backward_default_35 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_176, add_tensor_19, [1024], getitem_37, getitem_38, primals_322, primals_321, [True, True, True]);  add_tensor_176 = add_tensor_19 = getitem_37 = getitem_38 = primals_322 = primals_321 = None
        getitem_249 = native_layer_norm_backward_default_35[0]
        getitem_250 = native_layer_norm_backward_default_35[1]
        getitem_251 = native_layer_norm_backward_default_35[2];  native_layer_norm_backward_default_35 = None
        view_default_822 = torch.ops.aten.view.default(getitem_249, [8192, 1024])
        t_default_560 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_208 = torch.ops.aten.mm.default(view_default_822, t_default_560);  t_default_560 = None
        t_default_561 = torch.ops.aten.t.default(view_default_822)
        mm_default_209 = torch.ops.aten.mm.default(t_default_561, view_default_113);  t_default_561 = view_default_113 = None
        t_default_562 = torch.ops.aten.t.default(mm_default_209);  mm_default_209 = None
        sum_dim_int_list_104 = torch.ops.aten.sum.dim_IntList(view_default_822, [0], True);  view_default_822 = None
        view_default_823 = torch.ops.aten.view.default(sum_dim_int_list_104, [1024]);  sum_dim_int_list_104 = None
        t_default_563 = torch.ops.aten.t.default(t_default_562);  t_default_562 = None
        view_default_824 = torch.ops.aten.view.default(mm_default_208, [64, 128, 1024]);  mm_default_208 = None
        view_default_825 = torch.ops.aten.view.default(view_default_824, [64, 128, 16, 64]);  view_default_824 = None
        permute_default_164 = torch.ops.aten.permute.default(view_default_825, [0, 2, 1, 3]);  view_default_825 = None
        clone_default_164 = torch.ops.aten.clone.default(permute_default_164, memory_format = torch.contiguous_format);  permute_default_164 = None
        _unsafe_view_default_188 = torch.ops.aten._unsafe_view.default(clone_default_164, [1024, 128, 64]);  clone_default_164 = None
        transpose_int_109 = torch.ops.aten.transpose.int(view_default_111, 1, 2);  view_default_111 = None
        bmm_default_116 = torch.ops.aten.bmm.default(transpose_int_109, _unsafe_view_default_188);  transpose_int_109 = None
        transpose_int_110 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_117 = torch.ops.aten.bmm.default(_unsafe_view_default_188, transpose_int_110);  _unsafe_view_default_188 = transpose_int_110 = None
        view_default_826 = torch.ops.aten.view.default(bmm_default_116, [64, 16, 128, 64]);  bmm_default_116 = None
        view_default_827 = torch.ops.aten.view.default(bmm_default_117, [64, 16, 128, 128]);  bmm_default_117 = None
        _softmax_backward_data_default_17 = torch.ops.aten._softmax_backward_data.default(view_default_827, _softmax_default_6, -1, torch.float32);  view_default_827 = _softmax_default_6 = None
        div_tensor_41 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_17, 8.0);  _softmax_backward_data_default_17 = None
        view_default_828 = torch.ops.aten.view.default(div_tensor_41, [1024, 128, 128]);  div_tensor_41 = None
        transpose_int_111 = torch.ops.aten.transpose.int(_unsafe_view_default_30, 1, 2);  _unsafe_view_default_30 = None
        bmm_default_118 = torch.ops.aten.bmm.default(transpose_int_111, view_default_828);  transpose_int_111 = None
        transpose_int_112 = torch.ops.aten.transpose.int(_unsafe_view_default_31, 1, 2);  _unsafe_view_default_31 = None
        bmm_default_119 = torch.ops.aten.bmm.default(view_default_828, transpose_int_112);  view_default_828 = transpose_int_112 = None
        view_default_829 = torch.ops.aten.view.default(bmm_default_118, [64, 16, 64, 128]);  bmm_default_118 = None
        view_default_830 = torch.ops.aten.view.default(bmm_default_119, [64, 16, 128, 64]);  bmm_default_119 = None
        transpose_int_113 = torch.ops.aten.transpose.int(view_default_829, -1, -2);  view_default_829 = None
        permute_default_165 = torch.ops.aten.permute.default(view_default_830, [0, 2, 1, 3]);  view_default_830 = None
        clone_default_165 = torch.ops.aten.clone.default(permute_default_165, memory_format = torch.contiguous_format);  permute_default_165 = None
        _unsafe_view_default_189 = torch.ops.aten._unsafe_view.default(clone_default_165, [64, 128, 1024]);  clone_default_165 = None
        permute_default_166 = torch.ops.aten.permute.default(view_default_826, [0, 2, 1, 3]);  view_default_826 = None
        clone_default_166 = torch.ops.aten.clone.default(permute_default_166, memory_format = torch.contiguous_format);  permute_default_166 = None
        _unsafe_view_default_190 = torch.ops.aten._unsafe_view.default(clone_default_166, [64, 128, 1024]);  clone_default_166 = None
        view_default_831 = torch.ops.aten.view.default(_unsafe_view_default_190, [8192, 1024]);  _unsafe_view_default_190 = None
        t_default_564 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_210 = torch.ops.aten.mm.default(view_default_831, t_default_564);  t_default_564 = None
        t_default_565 = torch.ops.aten.t.default(view_default_831)
        mm_default_211 = torch.ops.aten.mm.default(t_default_565, view_default_107);  t_default_565 = view_default_107 = None
        t_default_566 = torch.ops.aten.t.default(mm_default_211);  mm_default_211 = None
        sum_dim_int_list_105 = torch.ops.aten.sum.dim_IntList(view_default_831, [0], True);  view_default_831 = None
        view_default_832 = torch.ops.aten.view.default(sum_dim_int_list_105, [1024]);  sum_dim_int_list_105 = None
        t_default_567 = torch.ops.aten.t.default(t_default_566);  t_default_566 = None
        view_default_833 = torch.ops.aten.view.default(mm_default_210, [64, 128, 1024]);  mm_default_210 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(getitem_249, view_default_833);  getitem_249 = view_default_833 = None
        permute_default_167 = torch.ops.aten.permute.default(transpose_int_113, [0, 2, 1, 3]);  transpose_int_113 = None
        view_default_834 = torch.ops.aten.view.default(permute_default_167, [64, 128, 1024]);  permute_default_167 = None
        clone_default_167 = torch.ops.aten.clone.default(view_default_834, memory_format = torch.contiguous_format);  view_default_834 = None
        _unsafe_view_default_191 = torch.ops.aten._unsafe_view.default(clone_default_167, [8192, 1024]);  clone_default_167 = None
        t_default_568 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_212 = torch.ops.aten.mm.default(_unsafe_view_default_191, t_default_568);  t_default_568 = None
        t_default_569 = torch.ops.aten.t.default(_unsafe_view_default_191)
        mm_default_213 = torch.ops.aten.mm.default(t_default_569, view_default_104);  t_default_569 = view_default_104 = None
        t_default_570 = torch.ops.aten.t.default(mm_default_213);  mm_default_213 = None
        sum_dim_int_list_106 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_191, [0], True);  _unsafe_view_default_191 = None
        view_default_835 = torch.ops.aten.view.default(sum_dim_int_list_106, [1024]);  sum_dim_int_list_106 = None
        t_default_571 = torch.ops.aten.t.default(t_default_570);  t_default_570 = None
        view_default_836 = torch.ops.aten.view.default(mm_default_212, [64, 128, 1024]);  mm_default_212 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(add_tensor_177, view_default_836);  add_tensor_177 = view_default_836 = None
        view_default_837 = torch.ops.aten.view.default(_unsafe_view_default_189, [8192, 1024]);  _unsafe_view_default_189 = None
        t_default_572 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_214 = torch.ops.aten.mm.default(view_default_837, t_default_572);  t_default_572 = None
        t_default_573 = torch.ops.aten.t.default(view_default_837)
        mm_default_215 = torch.ops.aten.mm.default(t_default_573, view_default_102);  t_default_573 = view_default_102 = None
        t_default_574 = torch.ops.aten.t.default(mm_default_215);  mm_default_215 = None
        sum_dim_int_list_107 = torch.ops.aten.sum.dim_IntList(view_default_837, [0], True);  view_default_837 = None
        view_default_838 = torch.ops.aten.view.default(sum_dim_int_list_107, [1024]);  sum_dim_int_list_107 = None
        t_default_575 = torch.ops.aten.t.default(t_default_574);  t_default_574 = None
        view_default_839 = torch.ops.aten.view.default(mm_default_214, [64, 128, 1024]);  mm_default_214 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(add_tensor_178, view_default_839);  add_tensor_178 = view_default_839 = None
        native_layer_norm_backward_default_36 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_179, add_tensor_17, [1024], getitem_34, getitem_35, primals_318, primals_317, [True, True, True]);  add_tensor_179 = add_tensor_17 = getitem_34 = getitem_35 = primals_318 = primals_317 = None
        getitem_252 = native_layer_norm_backward_default_36[0]
        getitem_253 = native_layer_norm_backward_default_36[1]
        getitem_254 = native_layer_norm_backward_default_36[2];  native_layer_norm_backward_default_36 = None
        view_default_840 = torch.ops.aten.view.default(getitem_252, [8192, 1024])
        t_default_576 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_216 = torch.ops.aten.mm.default(view_default_840, t_default_576);  t_default_576 = None
        t_default_577 = torch.ops.aten.t.default(view_default_840)
        mm_default_217 = torch.ops.aten.mm.default(t_default_577, view_default_100);  t_default_577 = view_default_100 = None
        t_default_578 = torch.ops.aten.t.default(mm_default_217);  mm_default_217 = None
        sum_dim_int_list_108 = torch.ops.aten.sum.dim_IntList(view_default_840, [0], True);  view_default_840 = None
        view_default_841 = torch.ops.aten.view.default(sum_dim_int_list_108, [1024]);  sum_dim_int_list_108 = None
        t_default_579 = torch.ops.aten.t.default(t_default_578);  t_default_578 = None
        view_default_842 = torch.ops.aten.view.default(mm_default_216, [64, 128, 4096]);  mm_default_216 = None
        to_dtype_54 = torch.ops.aten.to.dtype(view_default_842, torch.float32);  view_default_842 = None
        to_dtype_55 = torch.ops.aten.to.dtype(view_default_99, torch.float32);  view_default_99 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_55, 0.7071067811865476)
        erf_default_18 = torch.ops.aten.erf.default(mul_tensor_126);  mul_tensor_126 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(erf_default_18, 1);  erf_default_18 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(add_tensor_180, 0.5);  add_tensor_180 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(to_dtype_55, to_dtype_55)
        mul_tensor_129 = torch.ops.aten.mul.Tensor(mul_tensor_128, -0.5);  mul_tensor_128 = None
        exp_default_18 = torch.ops.aten.exp.default(mul_tensor_129);  mul_tensor_129 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(exp_default_18, 0.3989422804014327);  exp_default_18 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(to_dtype_55, mul_tensor_130);  to_dtype_55 = mul_tensor_130 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(mul_tensor_127, mul_tensor_131);  mul_tensor_127 = mul_tensor_131 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(to_dtype_54, add_tensor_181);  to_dtype_54 = add_tensor_181 = None
        to_dtype_56 = torch.ops.aten.to.dtype(mul_tensor_132, torch.float32);  mul_tensor_132 = None
        view_default_843 = torch.ops.aten.view.default(to_dtype_56, [8192, 4096]);  to_dtype_56 = None
        t_default_580 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_218 = torch.ops.aten.mm.default(view_default_843, t_default_580);  t_default_580 = None
        t_default_581 = torch.ops.aten.t.default(view_default_843)
        mm_default_219 = torch.ops.aten.mm.default(t_default_581, view_default_98);  t_default_581 = view_default_98 = None
        t_default_582 = torch.ops.aten.t.default(mm_default_219);  mm_default_219 = None
        sum_dim_int_list_109 = torch.ops.aten.sum.dim_IntList(view_default_843, [0], True);  view_default_843 = None
        view_default_844 = torch.ops.aten.view.default(sum_dim_int_list_109, [4096]);  sum_dim_int_list_109 = None
        t_default_583 = torch.ops.aten.t.default(t_default_582);  t_default_582 = None
        view_default_845 = torch.ops.aten.view.default(mm_default_218, [64, 128, 1024]);  mm_default_218 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(getitem_252, view_default_845);  getitem_252 = view_default_845 = None
        native_layer_norm_backward_default_37 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_182, add_tensor_16, [1024], getitem_31, getitem_32, primals_306, primals_305, [True, True, True]);  add_tensor_182 = add_tensor_16 = getitem_31 = getitem_32 = primals_306 = primals_305 = None
        getitem_255 = native_layer_norm_backward_default_37[0]
        getitem_256 = native_layer_norm_backward_default_37[1]
        getitem_257 = native_layer_norm_backward_default_37[2];  native_layer_norm_backward_default_37 = None
        view_default_846 = torch.ops.aten.view.default(getitem_255, [8192, 1024])
        t_default_584 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_220 = torch.ops.aten.mm.default(view_default_846, t_default_584);  t_default_584 = None
        t_default_585 = torch.ops.aten.t.default(view_default_846)
        mm_default_221 = torch.ops.aten.mm.default(t_default_585, view_default_96);  t_default_585 = view_default_96 = None
        t_default_586 = torch.ops.aten.t.default(mm_default_221);  mm_default_221 = None
        sum_dim_int_list_110 = torch.ops.aten.sum.dim_IntList(view_default_846, [0], True);  view_default_846 = None
        view_default_847 = torch.ops.aten.view.default(sum_dim_int_list_110, [1024]);  sum_dim_int_list_110 = None
        t_default_587 = torch.ops.aten.t.default(t_default_586);  t_default_586 = None
        view_default_848 = torch.ops.aten.view.default(mm_default_220, [64, 128, 1024]);  mm_default_220 = None
        view_default_849 = torch.ops.aten.view.default(view_default_848, [64, 128, 16, 64]);  view_default_848 = None
        permute_default_168 = torch.ops.aten.permute.default(view_default_849, [0, 2, 1, 3]);  view_default_849 = None
        clone_default_168 = torch.ops.aten.clone.default(permute_default_168, memory_format = torch.contiguous_format);  permute_default_168 = None
        _unsafe_view_default_192 = torch.ops.aten._unsafe_view.default(clone_default_168, [1024, 128, 64]);  clone_default_168 = None
        transpose_int_114 = torch.ops.aten.transpose.int(view_default_94, 1, 2);  view_default_94 = None
        bmm_default_120 = torch.ops.aten.bmm.default(transpose_int_114, _unsafe_view_default_192);  transpose_int_114 = None
        transpose_int_115 = torch.ops.aten.transpose.int(_unsafe_view_default_28, 1, 2);  _unsafe_view_default_28 = None
        bmm_default_121 = torch.ops.aten.bmm.default(_unsafe_view_default_192, transpose_int_115);  _unsafe_view_default_192 = transpose_int_115 = None
        view_default_850 = torch.ops.aten.view.default(bmm_default_120, [64, 16, 128, 64]);  bmm_default_120 = None
        view_default_851 = torch.ops.aten.view.default(bmm_default_121, [64, 16, 128, 128]);  bmm_default_121 = None
        _softmax_backward_data_default_18 = torch.ops.aten._softmax_backward_data.default(view_default_851, _softmax_default_5, -1, torch.float32);  view_default_851 = _softmax_default_5 = None
        div_tensor_42 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_18, 8.0);  _softmax_backward_data_default_18 = None
        view_default_852 = torch.ops.aten.view.default(div_tensor_42, [1024, 128, 128]);  div_tensor_42 = None
        transpose_int_116 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        bmm_default_122 = torch.ops.aten.bmm.default(transpose_int_116, view_default_852);  transpose_int_116 = None
        transpose_int_117 = torch.ops.aten.transpose.int(_unsafe_view_default_26, 1, 2);  _unsafe_view_default_26 = None
        bmm_default_123 = torch.ops.aten.bmm.default(view_default_852, transpose_int_117);  view_default_852 = transpose_int_117 = None
        view_default_853 = torch.ops.aten.view.default(bmm_default_122, [64, 16, 64, 128]);  bmm_default_122 = None
        view_default_854 = torch.ops.aten.view.default(bmm_default_123, [64, 16, 128, 64]);  bmm_default_123 = None
        transpose_int_118 = torch.ops.aten.transpose.int(view_default_853, -1, -2);  view_default_853 = None
        permute_default_169 = torch.ops.aten.permute.default(view_default_854, [0, 2, 1, 3]);  view_default_854 = None
        clone_default_169 = torch.ops.aten.clone.default(permute_default_169, memory_format = torch.contiguous_format);  permute_default_169 = None
        _unsafe_view_default_193 = torch.ops.aten._unsafe_view.default(clone_default_169, [64, 128, 1024]);  clone_default_169 = None
        permute_default_170 = torch.ops.aten.permute.default(view_default_850, [0, 2, 1, 3]);  view_default_850 = None
        clone_default_170 = torch.ops.aten.clone.default(permute_default_170, memory_format = torch.contiguous_format);  permute_default_170 = None
        _unsafe_view_default_194 = torch.ops.aten._unsafe_view.default(clone_default_170, [64, 128, 1024]);  clone_default_170 = None
        view_default_855 = torch.ops.aten.view.default(_unsafe_view_default_194, [8192, 1024]);  _unsafe_view_default_194 = None
        t_default_588 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_222 = torch.ops.aten.mm.default(view_default_855, t_default_588);  t_default_588 = None
        t_default_589 = torch.ops.aten.t.default(view_default_855)
        mm_default_223 = torch.ops.aten.mm.default(t_default_589, view_default_90);  t_default_589 = view_default_90 = None
        t_default_590 = torch.ops.aten.t.default(mm_default_223);  mm_default_223 = None
        sum_dim_int_list_111 = torch.ops.aten.sum.dim_IntList(view_default_855, [0], True);  view_default_855 = None
        view_default_856 = torch.ops.aten.view.default(sum_dim_int_list_111, [1024]);  sum_dim_int_list_111 = None
        t_default_591 = torch.ops.aten.t.default(t_default_590);  t_default_590 = None
        view_default_857 = torch.ops.aten.view.default(mm_default_222, [64, 128, 1024]);  mm_default_222 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(getitem_255, view_default_857);  getitem_255 = view_default_857 = None
        permute_default_171 = torch.ops.aten.permute.default(transpose_int_118, [0, 2, 1, 3]);  transpose_int_118 = None
        view_default_858 = torch.ops.aten.view.default(permute_default_171, [64, 128, 1024]);  permute_default_171 = None
        clone_default_171 = torch.ops.aten.clone.default(view_default_858, memory_format = torch.contiguous_format);  view_default_858 = None
        _unsafe_view_default_195 = torch.ops.aten._unsafe_view.default(clone_default_171, [8192, 1024]);  clone_default_171 = None
        t_default_592 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_224 = torch.ops.aten.mm.default(_unsafe_view_default_195, t_default_592);  t_default_592 = None
        t_default_593 = torch.ops.aten.t.default(_unsafe_view_default_195)
        mm_default_225 = torch.ops.aten.mm.default(t_default_593, view_default_87);  t_default_593 = view_default_87 = None
        t_default_594 = torch.ops.aten.t.default(mm_default_225);  mm_default_225 = None
        sum_dim_int_list_112 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_195, [0], True);  _unsafe_view_default_195 = None
        view_default_859 = torch.ops.aten.view.default(sum_dim_int_list_112, [1024]);  sum_dim_int_list_112 = None
        t_default_595 = torch.ops.aten.t.default(t_default_594);  t_default_594 = None
        view_default_860 = torch.ops.aten.view.default(mm_default_224, [64, 128, 1024]);  mm_default_224 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(add_tensor_183, view_default_860);  add_tensor_183 = view_default_860 = None
        view_default_861 = torch.ops.aten.view.default(_unsafe_view_default_193, [8192, 1024]);  _unsafe_view_default_193 = None
        t_default_596 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_226 = torch.ops.aten.mm.default(view_default_861, t_default_596);  t_default_596 = None
        t_default_597 = torch.ops.aten.t.default(view_default_861)
        mm_default_227 = torch.ops.aten.mm.default(t_default_597, view_default_85);  t_default_597 = view_default_85 = None
        t_default_598 = torch.ops.aten.t.default(mm_default_227);  mm_default_227 = None
        sum_dim_int_list_113 = torch.ops.aten.sum.dim_IntList(view_default_861, [0], True);  view_default_861 = None
        view_default_862 = torch.ops.aten.view.default(sum_dim_int_list_113, [1024]);  sum_dim_int_list_113 = None
        t_default_599 = torch.ops.aten.t.default(t_default_598);  t_default_598 = None
        view_default_863 = torch.ops.aten.view.default(mm_default_226, [64, 128, 1024]);  mm_default_226 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(add_tensor_184, view_default_863);  add_tensor_184 = view_default_863 = None
        native_layer_norm_backward_default_38 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_185, add_tensor_14, [1024], getitem_28, getitem_29, primals_302, primals_301, [True, True, True]);  add_tensor_185 = add_tensor_14 = getitem_28 = getitem_29 = primals_302 = primals_301 = None
        getitem_258 = native_layer_norm_backward_default_38[0]
        getitem_259 = native_layer_norm_backward_default_38[1]
        getitem_260 = native_layer_norm_backward_default_38[2];  native_layer_norm_backward_default_38 = None
        view_default_864 = torch.ops.aten.view.default(getitem_258, [8192, 1024])
        t_default_600 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_228 = torch.ops.aten.mm.default(view_default_864, t_default_600);  t_default_600 = None
        t_default_601 = torch.ops.aten.t.default(view_default_864)
        mm_default_229 = torch.ops.aten.mm.default(t_default_601, view_default_83);  t_default_601 = view_default_83 = None
        t_default_602 = torch.ops.aten.t.default(mm_default_229);  mm_default_229 = None
        sum_dim_int_list_114 = torch.ops.aten.sum.dim_IntList(view_default_864, [0], True);  view_default_864 = None
        view_default_865 = torch.ops.aten.view.default(sum_dim_int_list_114, [1024]);  sum_dim_int_list_114 = None
        t_default_603 = torch.ops.aten.t.default(t_default_602);  t_default_602 = None
        view_default_866 = torch.ops.aten.view.default(mm_default_228, [64, 128, 4096]);  mm_default_228 = None
        to_dtype_57 = torch.ops.aten.to.dtype(view_default_866, torch.float32);  view_default_866 = None
        to_dtype_58 = torch.ops.aten.to.dtype(view_default_82, torch.float32);  view_default_82 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_58, 0.7071067811865476)
        erf_default_19 = torch.ops.aten.erf.default(mul_tensor_133);  mul_tensor_133 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(erf_default_19, 1);  erf_default_19 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(add_tensor_186, 0.5);  add_tensor_186 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(to_dtype_58, to_dtype_58)
        mul_tensor_136 = torch.ops.aten.mul.Tensor(mul_tensor_135, -0.5);  mul_tensor_135 = None
        exp_default_19 = torch.ops.aten.exp.default(mul_tensor_136);  mul_tensor_136 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(exp_default_19, 0.3989422804014327);  exp_default_19 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_58, mul_tensor_137);  to_dtype_58 = mul_tensor_137 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(mul_tensor_134, mul_tensor_138);  mul_tensor_134 = mul_tensor_138 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(to_dtype_57, add_tensor_187);  to_dtype_57 = add_tensor_187 = None
        to_dtype_59 = torch.ops.aten.to.dtype(mul_tensor_139, torch.float32);  mul_tensor_139 = None
        view_default_867 = torch.ops.aten.view.default(to_dtype_59, [8192, 4096]);  to_dtype_59 = None
        t_default_604 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_230 = torch.ops.aten.mm.default(view_default_867, t_default_604);  t_default_604 = None
        t_default_605 = torch.ops.aten.t.default(view_default_867)
        mm_default_231 = torch.ops.aten.mm.default(t_default_605, view_default_81);  t_default_605 = view_default_81 = None
        t_default_606 = torch.ops.aten.t.default(mm_default_231);  mm_default_231 = None
        sum_dim_int_list_115 = torch.ops.aten.sum.dim_IntList(view_default_867, [0], True);  view_default_867 = None
        view_default_868 = torch.ops.aten.view.default(sum_dim_int_list_115, [4096]);  sum_dim_int_list_115 = None
        t_default_607 = torch.ops.aten.t.default(t_default_606);  t_default_606 = None
        view_default_869 = torch.ops.aten.view.default(mm_default_230, [64, 128, 1024]);  mm_default_230 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(getitem_258, view_default_869);  getitem_258 = view_default_869 = None
        native_layer_norm_backward_default_39 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_188, add_tensor_13, [1024], getitem_25, getitem_26, primals_290, primals_289, [True, True, True]);  add_tensor_188 = add_tensor_13 = getitem_25 = getitem_26 = primals_290 = primals_289 = None
        getitem_261 = native_layer_norm_backward_default_39[0]
        getitem_262 = native_layer_norm_backward_default_39[1]
        getitem_263 = native_layer_norm_backward_default_39[2];  native_layer_norm_backward_default_39 = None
        view_default_870 = torch.ops.aten.view.default(getitem_261, [8192, 1024])
        t_default_608 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_232 = torch.ops.aten.mm.default(view_default_870, t_default_608);  t_default_608 = None
        t_default_609 = torch.ops.aten.t.default(view_default_870)
        mm_default_233 = torch.ops.aten.mm.default(t_default_609, view_default_79);  t_default_609 = view_default_79 = None
        t_default_610 = torch.ops.aten.t.default(mm_default_233);  mm_default_233 = None
        sum_dim_int_list_116 = torch.ops.aten.sum.dim_IntList(view_default_870, [0], True);  view_default_870 = None
        view_default_871 = torch.ops.aten.view.default(sum_dim_int_list_116, [1024]);  sum_dim_int_list_116 = None
        t_default_611 = torch.ops.aten.t.default(t_default_610);  t_default_610 = None
        view_default_872 = torch.ops.aten.view.default(mm_default_232, [64, 128, 1024]);  mm_default_232 = None
        view_default_873 = torch.ops.aten.view.default(view_default_872, [64, 128, 16, 64]);  view_default_872 = None
        permute_default_172 = torch.ops.aten.permute.default(view_default_873, [0, 2, 1, 3]);  view_default_873 = None
        clone_default_172 = torch.ops.aten.clone.default(permute_default_172, memory_format = torch.contiguous_format);  permute_default_172 = None
        _unsafe_view_default_196 = torch.ops.aten._unsafe_view.default(clone_default_172, [1024, 128, 64]);  clone_default_172 = None
        transpose_int_119 = torch.ops.aten.transpose.int(view_default_77, 1, 2);  view_default_77 = None
        bmm_default_124 = torch.ops.aten.bmm.default(transpose_int_119, _unsafe_view_default_196);  transpose_int_119 = None
        transpose_int_120 = torch.ops.aten.transpose.int(_unsafe_view_default_23, 1, 2);  _unsafe_view_default_23 = None
        bmm_default_125 = torch.ops.aten.bmm.default(_unsafe_view_default_196, transpose_int_120);  _unsafe_view_default_196 = transpose_int_120 = None
        view_default_874 = torch.ops.aten.view.default(bmm_default_124, [64, 16, 128, 64]);  bmm_default_124 = None
        view_default_875 = torch.ops.aten.view.default(bmm_default_125, [64, 16, 128, 128]);  bmm_default_125 = None
        _softmax_backward_data_default_19 = torch.ops.aten._softmax_backward_data.default(view_default_875, _softmax_default_4, -1, torch.float32);  view_default_875 = _softmax_default_4 = None
        div_tensor_43 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_19, 8.0);  _softmax_backward_data_default_19 = None
        view_default_876 = torch.ops.aten.view.default(div_tensor_43, [1024, 128, 128]);  div_tensor_43 = None
        transpose_int_121 = torch.ops.aten.transpose.int(_unsafe_view_default_20, 1, 2);  _unsafe_view_default_20 = None
        bmm_default_126 = torch.ops.aten.bmm.default(transpose_int_121, view_default_876);  transpose_int_121 = None
        transpose_int_122 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_127 = torch.ops.aten.bmm.default(view_default_876, transpose_int_122);  view_default_876 = transpose_int_122 = None
        view_default_877 = torch.ops.aten.view.default(bmm_default_126, [64, 16, 64, 128]);  bmm_default_126 = None
        view_default_878 = torch.ops.aten.view.default(bmm_default_127, [64, 16, 128, 64]);  bmm_default_127 = None
        transpose_int_123 = torch.ops.aten.transpose.int(view_default_877, -1, -2);  view_default_877 = None
        permute_default_173 = torch.ops.aten.permute.default(view_default_878, [0, 2, 1, 3]);  view_default_878 = None
        clone_default_173 = torch.ops.aten.clone.default(permute_default_173, memory_format = torch.contiguous_format);  permute_default_173 = None
        _unsafe_view_default_197 = torch.ops.aten._unsafe_view.default(clone_default_173, [64, 128, 1024]);  clone_default_173 = None
        permute_default_174 = torch.ops.aten.permute.default(view_default_874, [0, 2, 1, 3]);  view_default_874 = None
        clone_default_174 = torch.ops.aten.clone.default(permute_default_174, memory_format = torch.contiguous_format);  permute_default_174 = None
        _unsafe_view_default_198 = torch.ops.aten._unsafe_view.default(clone_default_174, [64, 128, 1024]);  clone_default_174 = None
        view_default_879 = torch.ops.aten.view.default(_unsafe_view_default_198, [8192, 1024]);  _unsafe_view_default_198 = None
        t_default_612 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_234 = torch.ops.aten.mm.default(view_default_879, t_default_612);  t_default_612 = None
        t_default_613 = torch.ops.aten.t.default(view_default_879)
        mm_default_235 = torch.ops.aten.mm.default(t_default_613, view_default_73);  t_default_613 = view_default_73 = None
        t_default_614 = torch.ops.aten.t.default(mm_default_235);  mm_default_235 = None
        sum_dim_int_list_117 = torch.ops.aten.sum.dim_IntList(view_default_879, [0], True);  view_default_879 = None
        view_default_880 = torch.ops.aten.view.default(sum_dim_int_list_117, [1024]);  sum_dim_int_list_117 = None
        t_default_615 = torch.ops.aten.t.default(t_default_614);  t_default_614 = None
        view_default_881 = torch.ops.aten.view.default(mm_default_234, [64, 128, 1024]);  mm_default_234 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(getitem_261, view_default_881);  getitem_261 = view_default_881 = None
        permute_default_175 = torch.ops.aten.permute.default(transpose_int_123, [0, 2, 1, 3]);  transpose_int_123 = None
        view_default_882 = torch.ops.aten.view.default(permute_default_175, [64, 128, 1024]);  permute_default_175 = None
        clone_default_175 = torch.ops.aten.clone.default(view_default_882, memory_format = torch.contiguous_format);  view_default_882 = None
        _unsafe_view_default_199 = torch.ops.aten._unsafe_view.default(clone_default_175, [8192, 1024]);  clone_default_175 = None
        t_default_616 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_236 = torch.ops.aten.mm.default(_unsafe_view_default_199, t_default_616);  t_default_616 = None
        t_default_617 = torch.ops.aten.t.default(_unsafe_view_default_199)
        mm_default_237 = torch.ops.aten.mm.default(t_default_617, view_default_70);  t_default_617 = view_default_70 = None
        t_default_618 = torch.ops.aten.t.default(mm_default_237);  mm_default_237 = None
        sum_dim_int_list_118 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_199, [0], True);  _unsafe_view_default_199 = None
        view_default_883 = torch.ops.aten.view.default(sum_dim_int_list_118, [1024]);  sum_dim_int_list_118 = None
        t_default_619 = torch.ops.aten.t.default(t_default_618);  t_default_618 = None
        view_default_884 = torch.ops.aten.view.default(mm_default_236, [64, 128, 1024]);  mm_default_236 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(add_tensor_189, view_default_884);  add_tensor_189 = view_default_884 = None
        view_default_885 = torch.ops.aten.view.default(_unsafe_view_default_197, [8192, 1024]);  _unsafe_view_default_197 = None
        t_default_620 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_238 = torch.ops.aten.mm.default(view_default_885, t_default_620);  t_default_620 = None
        t_default_621 = torch.ops.aten.t.default(view_default_885)
        mm_default_239 = torch.ops.aten.mm.default(t_default_621, view_default_68);  t_default_621 = view_default_68 = None
        t_default_622 = torch.ops.aten.t.default(mm_default_239);  mm_default_239 = None
        sum_dim_int_list_119 = torch.ops.aten.sum.dim_IntList(view_default_885, [0], True);  view_default_885 = None
        view_default_886 = torch.ops.aten.view.default(sum_dim_int_list_119, [1024]);  sum_dim_int_list_119 = None
        t_default_623 = torch.ops.aten.t.default(t_default_622);  t_default_622 = None
        view_default_887 = torch.ops.aten.view.default(mm_default_238, [64, 128, 1024]);  mm_default_238 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(add_tensor_190, view_default_887);  add_tensor_190 = view_default_887 = None
        native_layer_norm_backward_default_40 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_191, add_tensor_11, [1024], getitem_22, getitem_23, primals_286, primals_285, [True, True, True]);  add_tensor_191 = add_tensor_11 = getitem_22 = getitem_23 = primals_286 = primals_285 = None
        getitem_264 = native_layer_norm_backward_default_40[0]
        getitem_265 = native_layer_norm_backward_default_40[1]
        getitem_266 = native_layer_norm_backward_default_40[2];  native_layer_norm_backward_default_40 = None
        view_default_888 = torch.ops.aten.view.default(getitem_264, [8192, 1024])
        t_default_624 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_240 = torch.ops.aten.mm.default(view_default_888, t_default_624);  t_default_624 = None
        t_default_625 = torch.ops.aten.t.default(view_default_888)
        mm_default_241 = torch.ops.aten.mm.default(t_default_625, view_default_66);  t_default_625 = view_default_66 = None
        t_default_626 = torch.ops.aten.t.default(mm_default_241);  mm_default_241 = None
        sum_dim_int_list_120 = torch.ops.aten.sum.dim_IntList(view_default_888, [0], True);  view_default_888 = None
        view_default_889 = torch.ops.aten.view.default(sum_dim_int_list_120, [1024]);  sum_dim_int_list_120 = None
        t_default_627 = torch.ops.aten.t.default(t_default_626);  t_default_626 = None
        view_default_890 = torch.ops.aten.view.default(mm_default_240, [64, 128, 4096]);  mm_default_240 = None
        to_dtype_60 = torch.ops.aten.to.dtype(view_default_890, torch.float32);  view_default_890 = None
        to_dtype_61 = torch.ops.aten.to.dtype(view_default_65, torch.float32);  view_default_65 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(to_dtype_61, 0.7071067811865476)
        erf_default_20 = torch.ops.aten.erf.default(mul_tensor_140);  mul_tensor_140 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(erf_default_20, 1);  erf_default_20 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(add_tensor_192, 0.5);  add_tensor_192 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_61, to_dtype_61)
        mul_tensor_143 = torch.ops.aten.mul.Tensor(mul_tensor_142, -0.5);  mul_tensor_142 = None
        exp_default_20 = torch.ops.aten.exp.default(mul_tensor_143);  mul_tensor_143 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(exp_default_20, 0.3989422804014327);  exp_default_20 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_61, mul_tensor_144);  to_dtype_61 = mul_tensor_144 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(mul_tensor_141, mul_tensor_145);  mul_tensor_141 = mul_tensor_145 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_60, add_tensor_193);  to_dtype_60 = add_tensor_193 = None
        to_dtype_62 = torch.ops.aten.to.dtype(mul_tensor_146, torch.float32);  mul_tensor_146 = None
        view_default_891 = torch.ops.aten.view.default(to_dtype_62, [8192, 4096]);  to_dtype_62 = None
        t_default_628 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_242 = torch.ops.aten.mm.default(view_default_891, t_default_628);  t_default_628 = None
        t_default_629 = torch.ops.aten.t.default(view_default_891)
        mm_default_243 = torch.ops.aten.mm.default(t_default_629, view_default_64);  t_default_629 = view_default_64 = None
        t_default_630 = torch.ops.aten.t.default(mm_default_243);  mm_default_243 = None
        sum_dim_int_list_121 = torch.ops.aten.sum.dim_IntList(view_default_891, [0], True);  view_default_891 = None
        view_default_892 = torch.ops.aten.view.default(sum_dim_int_list_121, [4096]);  sum_dim_int_list_121 = None
        t_default_631 = torch.ops.aten.t.default(t_default_630);  t_default_630 = None
        view_default_893 = torch.ops.aten.view.default(mm_default_242, [64, 128, 1024]);  mm_default_242 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(getitem_264, view_default_893);  getitem_264 = view_default_893 = None
        native_layer_norm_backward_default_41 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_194, add_tensor_10, [1024], getitem_19, getitem_20, primals_274, primals_273, [True, True, True]);  add_tensor_194 = add_tensor_10 = getitem_19 = getitem_20 = primals_274 = primals_273 = None
        getitem_267 = native_layer_norm_backward_default_41[0]
        getitem_268 = native_layer_norm_backward_default_41[1]
        getitem_269 = native_layer_norm_backward_default_41[2];  native_layer_norm_backward_default_41 = None
        view_default_894 = torch.ops.aten.view.default(getitem_267, [8192, 1024])
        t_default_632 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_244 = torch.ops.aten.mm.default(view_default_894, t_default_632);  t_default_632 = None
        t_default_633 = torch.ops.aten.t.default(view_default_894)
        mm_default_245 = torch.ops.aten.mm.default(t_default_633, view_default_62);  t_default_633 = view_default_62 = None
        t_default_634 = torch.ops.aten.t.default(mm_default_245);  mm_default_245 = None
        sum_dim_int_list_122 = torch.ops.aten.sum.dim_IntList(view_default_894, [0], True);  view_default_894 = None
        view_default_895 = torch.ops.aten.view.default(sum_dim_int_list_122, [1024]);  sum_dim_int_list_122 = None
        t_default_635 = torch.ops.aten.t.default(t_default_634);  t_default_634 = None
        view_default_896 = torch.ops.aten.view.default(mm_default_244, [64, 128, 1024]);  mm_default_244 = None
        view_default_897 = torch.ops.aten.view.default(view_default_896, [64, 128, 16, 64]);  view_default_896 = None
        permute_default_176 = torch.ops.aten.permute.default(view_default_897, [0, 2, 1, 3]);  view_default_897 = None
        clone_default_176 = torch.ops.aten.clone.default(permute_default_176, memory_format = torch.contiguous_format);  permute_default_176 = None
        _unsafe_view_default_200 = torch.ops.aten._unsafe_view.default(clone_default_176, [1024, 128, 64]);  clone_default_176 = None
        transpose_int_124 = torch.ops.aten.transpose.int(view_default_60, 1, 2);  view_default_60 = None
        bmm_default_128 = torch.ops.aten.bmm.default(transpose_int_124, _unsafe_view_default_200);  transpose_int_124 = None
        transpose_int_125 = torch.ops.aten.transpose.int(_unsafe_view_default_18, 1, 2);  _unsafe_view_default_18 = None
        bmm_default_129 = torch.ops.aten.bmm.default(_unsafe_view_default_200, transpose_int_125);  _unsafe_view_default_200 = transpose_int_125 = None
        view_default_898 = torch.ops.aten.view.default(bmm_default_128, [64, 16, 128, 64]);  bmm_default_128 = None
        view_default_899 = torch.ops.aten.view.default(bmm_default_129, [64, 16, 128, 128]);  bmm_default_129 = None
        _softmax_backward_data_default_20 = torch.ops.aten._softmax_backward_data.default(view_default_899, _softmax_default_3, -1, torch.float32);  view_default_899 = _softmax_default_3 = None
        div_tensor_44 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_20, 8.0);  _softmax_backward_data_default_20 = None
        view_default_900 = torch.ops.aten.view.default(div_tensor_44, [1024, 128, 128]);  div_tensor_44 = None
        transpose_int_126 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_130 = torch.ops.aten.bmm.default(transpose_int_126, view_default_900);  transpose_int_126 = None
        transpose_int_127 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        bmm_default_131 = torch.ops.aten.bmm.default(view_default_900, transpose_int_127);  view_default_900 = transpose_int_127 = None
        view_default_901 = torch.ops.aten.view.default(bmm_default_130, [64, 16, 64, 128]);  bmm_default_130 = None
        view_default_902 = torch.ops.aten.view.default(bmm_default_131, [64, 16, 128, 64]);  bmm_default_131 = None
        transpose_int_128 = torch.ops.aten.transpose.int(view_default_901, -1, -2);  view_default_901 = None
        permute_default_177 = torch.ops.aten.permute.default(view_default_902, [0, 2, 1, 3]);  view_default_902 = None
        clone_default_177 = torch.ops.aten.clone.default(permute_default_177, memory_format = torch.contiguous_format);  permute_default_177 = None
        _unsafe_view_default_201 = torch.ops.aten._unsafe_view.default(clone_default_177, [64, 128, 1024]);  clone_default_177 = None
        permute_default_178 = torch.ops.aten.permute.default(view_default_898, [0, 2, 1, 3]);  view_default_898 = None
        clone_default_178 = torch.ops.aten.clone.default(permute_default_178, memory_format = torch.contiguous_format);  permute_default_178 = None
        _unsafe_view_default_202 = torch.ops.aten._unsafe_view.default(clone_default_178, [64, 128, 1024]);  clone_default_178 = None
        view_default_903 = torch.ops.aten.view.default(_unsafe_view_default_202, [8192, 1024]);  _unsafe_view_default_202 = None
        t_default_636 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_246 = torch.ops.aten.mm.default(view_default_903, t_default_636);  t_default_636 = None
        t_default_637 = torch.ops.aten.t.default(view_default_903)
        mm_default_247 = torch.ops.aten.mm.default(t_default_637, view_default_56);  t_default_637 = view_default_56 = None
        t_default_638 = torch.ops.aten.t.default(mm_default_247);  mm_default_247 = None
        sum_dim_int_list_123 = torch.ops.aten.sum.dim_IntList(view_default_903, [0], True);  view_default_903 = None
        view_default_904 = torch.ops.aten.view.default(sum_dim_int_list_123, [1024]);  sum_dim_int_list_123 = None
        t_default_639 = torch.ops.aten.t.default(t_default_638);  t_default_638 = None
        view_default_905 = torch.ops.aten.view.default(mm_default_246, [64, 128, 1024]);  mm_default_246 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(getitem_267, view_default_905);  getitem_267 = view_default_905 = None
        permute_default_179 = torch.ops.aten.permute.default(transpose_int_128, [0, 2, 1, 3]);  transpose_int_128 = None
        view_default_906 = torch.ops.aten.view.default(permute_default_179, [64, 128, 1024]);  permute_default_179 = None
        clone_default_179 = torch.ops.aten.clone.default(view_default_906, memory_format = torch.contiguous_format);  view_default_906 = None
        _unsafe_view_default_203 = torch.ops.aten._unsafe_view.default(clone_default_179, [8192, 1024]);  clone_default_179 = None
        t_default_640 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_248 = torch.ops.aten.mm.default(_unsafe_view_default_203, t_default_640);  t_default_640 = None
        t_default_641 = torch.ops.aten.t.default(_unsafe_view_default_203)
        mm_default_249 = torch.ops.aten.mm.default(t_default_641, view_default_53);  t_default_641 = view_default_53 = None
        t_default_642 = torch.ops.aten.t.default(mm_default_249);  mm_default_249 = None
        sum_dim_int_list_124 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_203, [0], True);  _unsafe_view_default_203 = None
        view_default_907 = torch.ops.aten.view.default(sum_dim_int_list_124, [1024]);  sum_dim_int_list_124 = None
        t_default_643 = torch.ops.aten.t.default(t_default_642);  t_default_642 = None
        view_default_908 = torch.ops.aten.view.default(mm_default_248, [64, 128, 1024]);  mm_default_248 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(add_tensor_195, view_default_908);  add_tensor_195 = view_default_908 = None
        view_default_909 = torch.ops.aten.view.default(_unsafe_view_default_201, [8192, 1024]);  _unsafe_view_default_201 = None
        t_default_644 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_250 = torch.ops.aten.mm.default(view_default_909, t_default_644);  t_default_644 = None
        t_default_645 = torch.ops.aten.t.default(view_default_909)
        mm_default_251 = torch.ops.aten.mm.default(t_default_645, view_default_51);  t_default_645 = view_default_51 = None
        t_default_646 = torch.ops.aten.t.default(mm_default_251);  mm_default_251 = None
        sum_dim_int_list_125 = torch.ops.aten.sum.dim_IntList(view_default_909, [0], True);  view_default_909 = None
        view_default_910 = torch.ops.aten.view.default(sum_dim_int_list_125, [1024]);  sum_dim_int_list_125 = None
        t_default_647 = torch.ops.aten.t.default(t_default_646);  t_default_646 = None
        view_default_911 = torch.ops.aten.view.default(mm_default_250, [64, 128, 1024]);  mm_default_250 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(add_tensor_196, view_default_911);  add_tensor_196 = view_default_911 = None
        native_layer_norm_backward_default_42 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_197, add_tensor_8, [1024], getitem_16, getitem_17, primals_270, primals_269, [True, True, True]);  add_tensor_197 = add_tensor_8 = getitem_16 = getitem_17 = primals_270 = primals_269 = None
        getitem_270 = native_layer_norm_backward_default_42[0]
        getitem_271 = native_layer_norm_backward_default_42[1]
        getitem_272 = native_layer_norm_backward_default_42[2];  native_layer_norm_backward_default_42 = None
        view_default_912 = torch.ops.aten.view.default(getitem_270, [8192, 1024])
        t_default_648 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_252 = torch.ops.aten.mm.default(view_default_912, t_default_648);  t_default_648 = None
        t_default_649 = torch.ops.aten.t.default(view_default_912)
        mm_default_253 = torch.ops.aten.mm.default(t_default_649, view_default_49);  t_default_649 = view_default_49 = None
        t_default_650 = torch.ops.aten.t.default(mm_default_253);  mm_default_253 = None
        sum_dim_int_list_126 = torch.ops.aten.sum.dim_IntList(view_default_912, [0], True);  view_default_912 = None
        view_default_913 = torch.ops.aten.view.default(sum_dim_int_list_126, [1024]);  sum_dim_int_list_126 = None
        t_default_651 = torch.ops.aten.t.default(t_default_650);  t_default_650 = None
        view_default_914 = torch.ops.aten.view.default(mm_default_252, [64, 128, 4096]);  mm_default_252 = None
        to_dtype_63 = torch.ops.aten.to.dtype(view_default_914, torch.float32);  view_default_914 = None
        to_dtype_64 = torch.ops.aten.to.dtype(view_default_48, torch.float32);  view_default_48 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(to_dtype_64, 0.7071067811865476)
        erf_default_21 = torch.ops.aten.erf.default(mul_tensor_147);  mul_tensor_147 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(erf_default_21, 1);  erf_default_21 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(add_tensor_198, 0.5);  add_tensor_198 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_64, to_dtype_64)
        mul_tensor_150 = torch.ops.aten.mul.Tensor(mul_tensor_149, -0.5);  mul_tensor_149 = None
        exp_default_21 = torch.ops.aten.exp.default(mul_tensor_150);  mul_tensor_150 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(exp_default_21, 0.3989422804014327);  exp_default_21 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_64, mul_tensor_151);  to_dtype_64 = mul_tensor_151 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(mul_tensor_148, mul_tensor_152);  mul_tensor_148 = mul_tensor_152 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_63, add_tensor_199);  to_dtype_63 = add_tensor_199 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_153, torch.float32);  mul_tensor_153 = None
        view_default_915 = torch.ops.aten.view.default(to_dtype_65, [8192, 4096]);  to_dtype_65 = None
        t_default_652 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_254 = torch.ops.aten.mm.default(view_default_915, t_default_652);  t_default_652 = None
        t_default_653 = torch.ops.aten.t.default(view_default_915)
        mm_default_255 = torch.ops.aten.mm.default(t_default_653, view_default_47);  t_default_653 = view_default_47 = None
        t_default_654 = torch.ops.aten.t.default(mm_default_255);  mm_default_255 = None
        sum_dim_int_list_127 = torch.ops.aten.sum.dim_IntList(view_default_915, [0], True);  view_default_915 = None
        view_default_916 = torch.ops.aten.view.default(sum_dim_int_list_127, [4096]);  sum_dim_int_list_127 = None
        t_default_655 = torch.ops.aten.t.default(t_default_654);  t_default_654 = None
        view_default_917 = torch.ops.aten.view.default(mm_default_254, [64, 128, 1024]);  mm_default_254 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(getitem_270, view_default_917);  getitem_270 = view_default_917 = None
        native_layer_norm_backward_default_43 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_200, add_tensor_7, [1024], getitem_13, getitem_14, primals_258, primals_257, [True, True, True]);  add_tensor_200 = add_tensor_7 = getitem_13 = getitem_14 = primals_258 = primals_257 = None
        getitem_273 = native_layer_norm_backward_default_43[0]
        getitem_274 = native_layer_norm_backward_default_43[1]
        getitem_275 = native_layer_norm_backward_default_43[2];  native_layer_norm_backward_default_43 = None
        view_default_918 = torch.ops.aten.view.default(getitem_273, [8192, 1024])
        t_default_656 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_256 = torch.ops.aten.mm.default(view_default_918, t_default_656);  t_default_656 = None
        t_default_657 = torch.ops.aten.t.default(view_default_918)
        mm_default_257 = torch.ops.aten.mm.default(t_default_657, view_default_45);  t_default_657 = view_default_45 = None
        t_default_658 = torch.ops.aten.t.default(mm_default_257);  mm_default_257 = None
        sum_dim_int_list_128 = torch.ops.aten.sum.dim_IntList(view_default_918, [0], True);  view_default_918 = None
        view_default_919 = torch.ops.aten.view.default(sum_dim_int_list_128, [1024]);  sum_dim_int_list_128 = None
        t_default_659 = torch.ops.aten.t.default(t_default_658);  t_default_658 = None
        view_default_920 = torch.ops.aten.view.default(mm_default_256, [64, 128, 1024]);  mm_default_256 = None
        view_default_921 = torch.ops.aten.view.default(view_default_920, [64, 128, 16, 64]);  view_default_920 = None
        permute_default_180 = torch.ops.aten.permute.default(view_default_921, [0, 2, 1, 3]);  view_default_921 = None
        clone_default_180 = torch.ops.aten.clone.default(permute_default_180, memory_format = torch.contiguous_format);  permute_default_180 = None
        _unsafe_view_default_204 = torch.ops.aten._unsafe_view.default(clone_default_180, [1024, 128, 64]);  clone_default_180 = None
        transpose_int_129 = torch.ops.aten.transpose.int(view_default_43, 1, 2);  view_default_43 = None
        bmm_default_132 = torch.ops.aten.bmm.default(transpose_int_129, _unsafe_view_default_204);  transpose_int_129 = None
        transpose_int_130 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_133 = torch.ops.aten.bmm.default(_unsafe_view_default_204, transpose_int_130);  _unsafe_view_default_204 = transpose_int_130 = None
        view_default_922 = torch.ops.aten.view.default(bmm_default_132, [64, 16, 128, 64]);  bmm_default_132 = None
        view_default_923 = torch.ops.aten.view.default(bmm_default_133, [64, 16, 128, 128]);  bmm_default_133 = None
        _softmax_backward_data_default_21 = torch.ops.aten._softmax_backward_data.default(view_default_923, _softmax_default_2, -1, torch.float32);  view_default_923 = _softmax_default_2 = None
        div_tensor_45 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_21, 8.0);  _softmax_backward_data_default_21 = None
        view_default_924 = torch.ops.aten.view.default(div_tensor_45, [1024, 128, 128]);  div_tensor_45 = None
        transpose_int_131 = torch.ops.aten.transpose.int(_unsafe_view_default_10, 1, 2);  _unsafe_view_default_10 = None
        bmm_default_134 = torch.ops.aten.bmm.default(transpose_int_131, view_default_924);  transpose_int_131 = None
        transpose_int_132 = torch.ops.aten.transpose.int(_unsafe_view_default_11, 1, 2);  _unsafe_view_default_11 = None
        bmm_default_135 = torch.ops.aten.bmm.default(view_default_924, transpose_int_132);  view_default_924 = transpose_int_132 = None
        view_default_925 = torch.ops.aten.view.default(bmm_default_134, [64, 16, 64, 128]);  bmm_default_134 = None
        view_default_926 = torch.ops.aten.view.default(bmm_default_135, [64, 16, 128, 64]);  bmm_default_135 = None
        transpose_int_133 = torch.ops.aten.transpose.int(view_default_925, -1, -2);  view_default_925 = None
        permute_default_181 = torch.ops.aten.permute.default(view_default_926, [0, 2, 1, 3]);  view_default_926 = None
        clone_default_181 = torch.ops.aten.clone.default(permute_default_181, memory_format = torch.contiguous_format);  permute_default_181 = None
        _unsafe_view_default_205 = torch.ops.aten._unsafe_view.default(clone_default_181, [64, 128, 1024]);  clone_default_181 = None
        permute_default_182 = torch.ops.aten.permute.default(view_default_922, [0, 2, 1, 3]);  view_default_922 = None
        clone_default_182 = torch.ops.aten.clone.default(permute_default_182, memory_format = torch.contiguous_format);  permute_default_182 = None
        _unsafe_view_default_206 = torch.ops.aten._unsafe_view.default(clone_default_182, [64, 128, 1024]);  clone_default_182 = None
        view_default_927 = torch.ops.aten.view.default(_unsafe_view_default_206, [8192, 1024]);  _unsafe_view_default_206 = None
        t_default_660 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_258 = torch.ops.aten.mm.default(view_default_927, t_default_660);  t_default_660 = None
        t_default_661 = torch.ops.aten.t.default(view_default_927)
        mm_default_259 = torch.ops.aten.mm.default(t_default_661, view_default_39);  t_default_661 = view_default_39 = None
        t_default_662 = torch.ops.aten.t.default(mm_default_259);  mm_default_259 = None
        sum_dim_int_list_129 = torch.ops.aten.sum.dim_IntList(view_default_927, [0], True);  view_default_927 = None
        view_default_928 = torch.ops.aten.view.default(sum_dim_int_list_129, [1024]);  sum_dim_int_list_129 = None
        t_default_663 = torch.ops.aten.t.default(t_default_662);  t_default_662 = None
        view_default_929 = torch.ops.aten.view.default(mm_default_258, [64, 128, 1024]);  mm_default_258 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(getitem_273, view_default_929);  getitem_273 = view_default_929 = None
        permute_default_183 = torch.ops.aten.permute.default(transpose_int_133, [0, 2, 1, 3]);  transpose_int_133 = None
        view_default_930 = torch.ops.aten.view.default(permute_default_183, [64, 128, 1024]);  permute_default_183 = None
        clone_default_183 = torch.ops.aten.clone.default(view_default_930, memory_format = torch.contiguous_format);  view_default_930 = None
        _unsafe_view_default_207 = torch.ops.aten._unsafe_view.default(clone_default_183, [8192, 1024]);  clone_default_183 = None
        t_default_664 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_260 = torch.ops.aten.mm.default(_unsafe_view_default_207, t_default_664);  t_default_664 = None
        t_default_665 = torch.ops.aten.t.default(_unsafe_view_default_207)
        mm_default_261 = torch.ops.aten.mm.default(t_default_665, view_default_36);  t_default_665 = view_default_36 = None
        t_default_666 = torch.ops.aten.t.default(mm_default_261);  mm_default_261 = None
        sum_dim_int_list_130 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_207, [0], True);  _unsafe_view_default_207 = None
        view_default_931 = torch.ops.aten.view.default(sum_dim_int_list_130, [1024]);  sum_dim_int_list_130 = None
        t_default_667 = torch.ops.aten.t.default(t_default_666);  t_default_666 = None
        view_default_932 = torch.ops.aten.view.default(mm_default_260, [64, 128, 1024]);  mm_default_260 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(add_tensor_201, view_default_932);  add_tensor_201 = view_default_932 = None
        view_default_933 = torch.ops.aten.view.default(_unsafe_view_default_205, [8192, 1024]);  _unsafe_view_default_205 = None
        t_default_668 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_262 = torch.ops.aten.mm.default(view_default_933, t_default_668);  t_default_668 = None
        t_default_669 = torch.ops.aten.t.default(view_default_933)
        mm_default_263 = torch.ops.aten.mm.default(t_default_669, view_default_34);  t_default_669 = view_default_34 = None
        t_default_670 = torch.ops.aten.t.default(mm_default_263);  mm_default_263 = None
        sum_dim_int_list_131 = torch.ops.aten.sum.dim_IntList(view_default_933, [0], True);  view_default_933 = None
        view_default_934 = torch.ops.aten.view.default(sum_dim_int_list_131, [1024]);  sum_dim_int_list_131 = None
        t_default_671 = torch.ops.aten.t.default(t_default_670);  t_default_670 = None
        view_default_935 = torch.ops.aten.view.default(mm_default_262, [64, 128, 1024]);  mm_default_262 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(add_tensor_202, view_default_935);  add_tensor_202 = view_default_935 = None
        native_layer_norm_backward_default_44 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_203, add_tensor_5, [1024], getitem_10, getitem_11, primals_190, primals_189, [True, True, True]);  add_tensor_203 = add_tensor_5 = getitem_10 = getitem_11 = primals_190 = primals_189 = None
        getitem_276 = native_layer_norm_backward_default_44[0]
        getitem_277 = native_layer_norm_backward_default_44[1]
        getitem_278 = native_layer_norm_backward_default_44[2];  native_layer_norm_backward_default_44 = None
        view_default_936 = torch.ops.aten.view.default(getitem_276, [8192, 1024])
        t_default_672 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_264 = torch.ops.aten.mm.default(view_default_936, t_default_672);  t_default_672 = None
        t_default_673 = torch.ops.aten.t.default(view_default_936)
        mm_default_265 = torch.ops.aten.mm.default(t_default_673, view_default_32);  t_default_673 = view_default_32 = None
        t_default_674 = torch.ops.aten.t.default(mm_default_265);  mm_default_265 = None
        sum_dim_int_list_132 = torch.ops.aten.sum.dim_IntList(view_default_936, [0], True);  view_default_936 = None
        view_default_937 = torch.ops.aten.view.default(sum_dim_int_list_132, [1024]);  sum_dim_int_list_132 = None
        t_default_675 = torch.ops.aten.t.default(t_default_674);  t_default_674 = None
        view_default_938 = torch.ops.aten.view.default(mm_default_264, [64, 128, 4096]);  mm_default_264 = None
        to_dtype_66 = torch.ops.aten.to.dtype(view_default_938, torch.float32);  view_default_938 = None
        to_dtype_67 = torch.ops.aten.to.dtype(view_default_31, torch.float32);  view_default_31 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_67, 0.7071067811865476)
        erf_default_22 = torch.ops.aten.erf.default(mul_tensor_154);  mul_tensor_154 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(erf_default_22, 1);  erf_default_22 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(add_tensor_204, 0.5);  add_tensor_204 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(to_dtype_67, to_dtype_67)
        mul_tensor_157 = torch.ops.aten.mul.Tensor(mul_tensor_156, -0.5);  mul_tensor_156 = None
        exp_default_22 = torch.ops.aten.exp.default(mul_tensor_157);  mul_tensor_157 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(exp_default_22, 0.3989422804014327);  exp_default_22 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(to_dtype_67, mul_tensor_158);  to_dtype_67 = mul_tensor_158 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(mul_tensor_155, mul_tensor_159);  mul_tensor_155 = mul_tensor_159 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(to_dtype_66, add_tensor_205);  to_dtype_66 = add_tensor_205 = None
        to_dtype_68 = torch.ops.aten.to.dtype(mul_tensor_160, torch.float32);  mul_tensor_160 = None
        view_default_939 = torch.ops.aten.view.default(to_dtype_68, [8192, 4096]);  to_dtype_68 = None
        t_default_676 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_266 = torch.ops.aten.mm.default(view_default_939, t_default_676);  t_default_676 = None
        t_default_677 = torch.ops.aten.t.default(view_default_939)
        mm_default_267 = torch.ops.aten.mm.default(t_default_677, view_default_30);  t_default_677 = view_default_30 = None
        t_default_678 = torch.ops.aten.t.default(mm_default_267);  mm_default_267 = None
        sum_dim_int_list_133 = torch.ops.aten.sum.dim_IntList(view_default_939, [0], True);  view_default_939 = None
        view_default_940 = torch.ops.aten.view.default(sum_dim_int_list_133, [4096]);  sum_dim_int_list_133 = None
        t_default_679 = torch.ops.aten.t.default(t_default_678);  t_default_678 = None
        view_default_941 = torch.ops.aten.view.default(mm_default_266, [64, 128, 1024]);  mm_default_266 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(getitem_276, view_default_941);  getitem_276 = view_default_941 = None
        native_layer_norm_backward_default_45 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_206, add_tensor_4, [1024], getitem_7, getitem_8, primals_178, primals_177, [True, True, True]);  add_tensor_206 = add_tensor_4 = getitem_7 = getitem_8 = primals_178 = primals_177 = None
        getitem_279 = native_layer_norm_backward_default_45[0]
        getitem_280 = native_layer_norm_backward_default_45[1]
        getitem_281 = native_layer_norm_backward_default_45[2];  native_layer_norm_backward_default_45 = None
        view_default_942 = torch.ops.aten.view.default(getitem_279, [8192, 1024])
        t_default_680 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_268 = torch.ops.aten.mm.default(view_default_942, t_default_680);  t_default_680 = None
        t_default_681 = torch.ops.aten.t.default(view_default_942)
        mm_default_269 = torch.ops.aten.mm.default(t_default_681, view_default_28);  t_default_681 = view_default_28 = None
        t_default_682 = torch.ops.aten.t.default(mm_default_269);  mm_default_269 = None
        sum_dim_int_list_134 = torch.ops.aten.sum.dim_IntList(view_default_942, [0], True);  view_default_942 = None
        view_default_943 = torch.ops.aten.view.default(sum_dim_int_list_134, [1024]);  sum_dim_int_list_134 = None
        t_default_683 = torch.ops.aten.t.default(t_default_682);  t_default_682 = None
        view_default_944 = torch.ops.aten.view.default(mm_default_268, [64, 128, 1024]);  mm_default_268 = None
        view_default_945 = torch.ops.aten.view.default(view_default_944, [64, 128, 16, 64]);  view_default_944 = None
        permute_default_184 = torch.ops.aten.permute.default(view_default_945, [0, 2, 1, 3]);  view_default_945 = None
        clone_default_184 = torch.ops.aten.clone.default(permute_default_184, memory_format = torch.contiguous_format);  permute_default_184 = None
        _unsafe_view_default_208 = torch.ops.aten._unsafe_view.default(clone_default_184, [1024, 128, 64]);  clone_default_184 = None
        transpose_int_134 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        bmm_default_136 = torch.ops.aten.bmm.default(transpose_int_134, _unsafe_view_default_208);  transpose_int_134 = None
        transpose_int_135 = torch.ops.aten.transpose.int(_unsafe_view_default_8, 1, 2);  _unsafe_view_default_8 = None
        bmm_default_137 = torch.ops.aten.bmm.default(_unsafe_view_default_208, transpose_int_135);  _unsafe_view_default_208 = transpose_int_135 = None
        view_default_946 = torch.ops.aten.view.default(bmm_default_136, [64, 16, 128, 64]);  bmm_default_136 = None
        view_default_947 = torch.ops.aten.view.default(bmm_default_137, [64, 16, 128, 128]);  bmm_default_137 = None
        _softmax_backward_data_default_22 = torch.ops.aten._softmax_backward_data.default(view_default_947, _softmax_default_1, -1, torch.float32);  view_default_947 = _softmax_default_1 = None
        div_tensor_46 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_22, 8.0);  _softmax_backward_data_default_22 = None
        view_default_948 = torch.ops.aten.view.default(div_tensor_46, [1024, 128, 128]);  div_tensor_46 = None
        transpose_int_136 = torch.ops.aten.transpose.int(_unsafe_view_default_5, 1, 2);  _unsafe_view_default_5 = None
        bmm_default_138 = torch.ops.aten.bmm.default(transpose_int_136, view_default_948);  transpose_int_136 = None
        transpose_int_137 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_139 = torch.ops.aten.bmm.default(view_default_948, transpose_int_137);  view_default_948 = transpose_int_137 = None
        view_default_949 = torch.ops.aten.view.default(bmm_default_138, [64, 16, 64, 128]);  bmm_default_138 = None
        view_default_950 = torch.ops.aten.view.default(bmm_default_139, [64, 16, 128, 64]);  bmm_default_139 = None
        transpose_int_138 = torch.ops.aten.transpose.int(view_default_949, -1, -2);  view_default_949 = None
        permute_default_185 = torch.ops.aten.permute.default(view_default_950, [0, 2, 1, 3]);  view_default_950 = None
        clone_default_185 = torch.ops.aten.clone.default(permute_default_185, memory_format = torch.contiguous_format);  permute_default_185 = None
        _unsafe_view_default_209 = torch.ops.aten._unsafe_view.default(clone_default_185, [64, 128, 1024]);  clone_default_185 = None
        permute_default_186 = torch.ops.aten.permute.default(view_default_946, [0, 2, 1, 3]);  view_default_946 = None
        clone_default_186 = torch.ops.aten.clone.default(permute_default_186, memory_format = torch.contiguous_format);  permute_default_186 = None
        _unsafe_view_default_210 = torch.ops.aten._unsafe_view.default(clone_default_186, [64, 128, 1024]);  clone_default_186 = None
        view_default_951 = torch.ops.aten.view.default(_unsafe_view_default_210, [8192, 1024]);  _unsafe_view_default_210 = None
        t_default_684 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_270 = torch.ops.aten.mm.default(view_default_951, t_default_684);  t_default_684 = None
        t_default_685 = torch.ops.aten.t.default(view_default_951)
        mm_default_271 = torch.ops.aten.mm.default(t_default_685, view_default_22);  t_default_685 = view_default_22 = None
        t_default_686 = torch.ops.aten.t.default(mm_default_271);  mm_default_271 = None
        sum_dim_int_list_135 = torch.ops.aten.sum.dim_IntList(view_default_951, [0], True);  view_default_951 = None
        view_default_952 = torch.ops.aten.view.default(sum_dim_int_list_135, [1024]);  sum_dim_int_list_135 = None
        t_default_687 = torch.ops.aten.t.default(t_default_686);  t_default_686 = None
        view_default_953 = torch.ops.aten.view.default(mm_default_270, [64, 128, 1024]);  mm_default_270 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(getitem_279, view_default_953);  getitem_279 = view_default_953 = None
        permute_default_187 = torch.ops.aten.permute.default(transpose_int_138, [0, 2, 1, 3]);  transpose_int_138 = None
        view_default_954 = torch.ops.aten.view.default(permute_default_187, [64, 128, 1024]);  permute_default_187 = None
        clone_default_187 = torch.ops.aten.clone.default(view_default_954, memory_format = torch.contiguous_format);  view_default_954 = None
        _unsafe_view_default_211 = torch.ops.aten._unsafe_view.default(clone_default_187, [8192, 1024]);  clone_default_187 = None
        t_default_688 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_272 = torch.ops.aten.mm.default(_unsafe_view_default_211, t_default_688);  t_default_688 = None
        t_default_689 = torch.ops.aten.t.default(_unsafe_view_default_211)
        mm_default_273 = torch.ops.aten.mm.default(t_default_689, view_default_19);  t_default_689 = view_default_19 = None
        t_default_690 = torch.ops.aten.t.default(mm_default_273);  mm_default_273 = None
        sum_dim_int_list_136 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_211, [0], True);  _unsafe_view_default_211 = None
        view_default_955 = torch.ops.aten.view.default(sum_dim_int_list_136, [1024]);  sum_dim_int_list_136 = None
        t_default_691 = torch.ops.aten.t.default(t_default_690);  t_default_690 = None
        view_default_956 = torch.ops.aten.view.default(mm_default_272, [64, 128, 1024]);  mm_default_272 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(add_tensor_207, view_default_956);  add_tensor_207 = view_default_956 = None
        view_default_957 = torch.ops.aten.view.default(_unsafe_view_default_209, [8192, 1024]);  _unsafe_view_default_209 = None
        t_default_692 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_274 = torch.ops.aten.mm.default(view_default_957, t_default_692);  t_default_692 = None
        t_default_693 = torch.ops.aten.t.default(view_default_957)
        mm_default_275 = torch.ops.aten.mm.default(t_default_693, view_default_17);  t_default_693 = view_default_17 = None
        t_default_694 = torch.ops.aten.t.default(mm_default_275);  mm_default_275 = None
        sum_dim_int_list_137 = torch.ops.aten.sum.dim_IntList(view_default_957, [0], True);  view_default_957 = None
        view_default_958 = torch.ops.aten.view.default(sum_dim_int_list_137, [1024]);  sum_dim_int_list_137 = None
        t_default_695 = torch.ops.aten.t.default(t_default_694);  t_default_694 = None
        view_default_959 = torch.ops.aten.view.default(mm_default_274, [64, 128, 1024]);  mm_default_274 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(add_tensor_208, view_default_959);  add_tensor_208 = view_default_959 = None
        native_layer_norm_backward_default_46 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_209, add_tensor_2, [1024], getitem_4, getitem_5, primals_14, primals_13, [True, True, True]);  add_tensor_209 = add_tensor_2 = getitem_4 = getitem_5 = primals_14 = primals_13 = None
        getitem_282 = native_layer_norm_backward_default_46[0]
        getitem_283 = native_layer_norm_backward_default_46[1]
        getitem_284 = native_layer_norm_backward_default_46[2];  native_layer_norm_backward_default_46 = None
        view_default_960 = torch.ops.aten.view.default(getitem_282, [8192, 1024])
        t_default_696 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_276 = torch.ops.aten.mm.default(view_default_960, t_default_696);  t_default_696 = None
        t_default_697 = torch.ops.aten.t.default(view_default_960)
        mm_default_277 = torch.ops.aten.mm.default(t_default_697, view_default_15);  t_default_697 = view_default_15 = None
        t_default_698 = torch.ops.aten.t.default(mm_default_277);  mm_default_277 = None
        sum_dim_int_list_138 = torch.ops.aten.sum.dim_IntList(view_default_960, [0], True);  view_default_960 = None
        view_default_961 = torch.ops.aten.view.default(sum_dim_int_list_138, [1024]);  sum_dim_int_list_138 = None
        t_default_699 = torch.ops.aten.t.default(t_default_698);  t_default_698 = None
        view_default_962 = torch.ops.aten.view.default(mm_default_276, [64, 128, 4096]);  mm_default_276 = None
        to_dtype_69 = torch.ops.aten.to.dtype(view_default_962, torch.float32);  view_default_962 = None
        to_dtype_70 = torch.ops.aten.to.dtype(view_default_14, torch.float32);  view_default_14 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_70, 0.7071067811865476)
        erf_default_23 = torch.ops.aten.erf.default(mul_tensor_161);  mul_tensor_161 = None
        add_tensor_210 = torch.ops.aten.add.Tensor(erf_default_23, 1);  erf_default_23 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(add_tensor_210, 0.5);  add_tensor_210 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(to_dtype_70, to_dtype_70)
        mul_tensor_164 = torch.ops.aten.mul.Tensor(mul_tensor_163, -0.5);  mul_tensor_163 = None
        exp_default_23 = torch.ops.aten.exp.default(mul_tensor_164);  mul_tensor_164 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(exp_default_23, 0.3989422804014327);  exp_default_23 = None
        mul_tensor_166 = torch.ops.aten.mul.Tensor(to_dtype_70, mul_tensor_165);  to_dtype_70 = mul_tensor_165 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(mul_tensor_162, mul_tensor_166);  mul_tensor_162 = mul_tensor_166 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(to_dtype_69, add_tensor_211);  to_dtype_69 = add_tensor_211 = None
        to_dtype_71 = torch.ops.aten.to.dtype(mul_tensor_167, torch.float32);  mul_tensor_167 = None
        view_default_963 = torch.ops.aten.view.default(to_dtype_71, [8192, 4096]);  to_dtype_71 = None
        t_default_700 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_278 = torch.ops.aten.mm.default(view_default_963, t_default_700);  t_default_700 = None
        t_default_701 = torch.ops.aten.t.default(view_default_963)
        mm_default_279 = torch.ops.aten.mm.default(t_default_701, view_default_13);  t_default_701 = view_default_13 = None
        t_default_702 = torch.ops.aten.t.default(mm_default_279);  mm_default_279 = None
        sum_dim_int_list_139 = torch.ops.aten.sum.dim_IntList(view_default_963, [0], True);  view_default_963 = None
        view_default_964 = torch.ops.aten.view.default(sum_dim_int_list_139, [4096]);  sum_dim_int_list_139 = None
        t_default_703 = torch.ops.aten.t.default(t_default_702);  t_default_702 = None
        view_default_965 = torch.ops.aten.view.default(mm_default_278, [64, 128, 1024]);  mm_default_278 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(getitem_282, view_default_965);  getitem_282 = view_default_965 = None
        native_layer_norm_backward_default_47 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_212, add_tensor_1, [1024], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  add_tensor_212 = add_tensor_1 = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_285 = native_layer_norm_backward_default_47[0]
        getitem_286 = native_layer_norm_backward_default_47[1]
        getitem_287 = native_layer_norm_backward_default_47[2];  native_layer_norm_backward_default_47 = None
        view_default_966 = torch.ops.aten.view.default(getitem_285, [8192, 1024])
        t_default_704 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_280 = torch.ops.aten.mm.default(view_default_966, t_default_704);  t_default_704 = None
        t_default_705 = torch.ops.aten.t.default(view_default_966)
        mm_default_281 = torch.ops.aten.mm.default(t_default_705, view_default_11);  t_default_705 = view_default_11 = None
        t_default_706 = torch.ops.aten.t.default(mm_default_281);  mm_default_281 = None
        sum_dim_int_list_140 = torch.ops.aten.sum.dim_IntList(view_default_966, [0], True);  view_default_966 = None
        view_default_967 = torch.ops.aten.view.default(sum_dim_int_list_140, [1024]);  sum_dim_int_list_140 = None
        t_default_707 = torch.ops.aten.t.default(t_default_706);  t_default_706 = None
        view_default_968 = torch.ops.aten.view.default(mm_default_280, [64, 128, 1024]);  mm_default_280 = None
        view_default_969 = torch.ops.aten.view.default(view_default_968, [64, 128, 16, 64]);  view_default_968 = None
        permute_default_188 = torch.ops.aten.permute.default(view_default_969, [0, 2, 1, 3]);  view_default_969 = None
        clone_default_188 = torch.ops.aten.clone.default(permute_default_188, memory_format = torch.contiguous_format);  permute_default_188 = None
        _unsafe_view_default_212 = torch.ops.aten._unsafe_view.default(clone_default_188, [1024, 128, 64]);  clone_default_188 = None
        transpose_int_139 = torch.ops.aten.transpose.int(view_default_9, 1, 2);  view_default_9 = None
        bmm_default_140 = torch.ops.aten.bmm.default(transpose_int_139, _unsafe_view_default_212);  transpose_int_139 = None
        transpose_int_140 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_141 = torch.ops.aten.bmm.default(_unsafe_view_default_212, transpose_int_140);  _unsafe_view_default_212 = transpose_int_140 = None
        view_default_970 = torch.ops.aten.view.default(bmm_default_140, [64, 16, 128, 64]);  bmm_default_140 = None
        view_default_971 = torch.ops.aten.view.default(bmm_default_141, [64, 16, 128, 128]);  bmm_default_141 = None
        _softmax_backward_data_default_23 = torch.ops.aten._softmax_backward_data.default(view_default_971, _softmax_default, -1, torch.float32);  view_default_971 = _softmax_default = None
        div_tensor_47 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_23, 8.0);  _softmax_backward_data_default_23 = None
        view_default_972 = torch.ops.aten.view.default(div_tensor_47, [1024, 128, 128]);  div_tensor_47 = None
        transpose_int_141 = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_142 = torch.ops.aten.bmm.default(transpose_int_141, view_default_972);  transpose_int_141 = None
        transpose_int_142 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_143 = torch.ops.aten.bmm.default(view_default_972, transpose_int_142);  view_default_972 = transpose_int_142 = None
        view_default_973 = torch.ops.aten.view.default(bmm_default_142, [64, 16, 64, 128]);  bmm_default_142 = None
        view_default_974 = torch.ops.aten.view.default(bmm_default_143, [64, 16, 128, 64]);  bmm_default_143 = None
        transpose_int_143 = torch.ops.aten.transpose.int(view_default_973, -1, -2);  view_default_973 = None
        permute_default_189 = torch.ops.aten.permute.default(view_default_974, [0, 2, 1, 3]);  view_default_974 = None
        clone_default_189 = torch.ops.aten.clone.default(permute_default_189, memory_format = torch.contiguous_format);  permute_default_189 = None
        _unsafe_view_default_213 = torch.ops.aten._unsafe_view.default(clone_default_189, [64, 128, 1024]);  clone_default_189 = None
        permute_default_190 = torch.ops.aten.permute.default(view_default_970, [0, 2, 1, 3]);  view_default_970 = None
        clone_default_190 = torch.ops.aten.clone.default(permute_default_190, memory_format = torch.contiguous_format);  permute_default_190 = None
        _unsafe_view_default_214 = torch.ops.aten._unsafe_view.default(clone_default_190, [64, 128, 1024]);  clone_default_190 = None
        view_default_975 = torch.ops.aten.view.default(_unsafe_view_default_214, [8192, 1024]);  _unsafe_view_default_214 = None
        t_default_708 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_282 = torch.ops.aten.mm.default(view_default_975, t_default_708);  t_default_708 = None
        t_default_709 = torch.ops.aten.t.default(view_default_975)
        mm_default_283 = torch.ops.aten.mm.default(t_default_709, view_default_5);  t_default_709 = view_default_5 = None
        t_default_710 = torch.ops.aten.t.default(mm_default_283);  mm_default_283 = None
        sum_dim_int_list_141 = torch.ops.aten.sum.dim_IntList(view_default_975, [0], True);  view_default_975 = None
        view_default_976 = torch.ops.aten.view.default(sum_dim_int_list_141, [1024]);  sum_dim_int_list_141 = None
        t_default_711 = torch.ops.aten.t.default(t_default_710);  t_default_710 = None
        view_default_977 = torch.ops.aten.view.default(mm_default_282, [64, 128, 1024]);  mm_default_282 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(getitem_285, view_default_977);  getitem_285 = view_default_977 = None
        permute_default_191 = torch.ops.aten.permute.default(transpose_int_143, [0, 2, 1, 3]);  transpose_int_143 = None
        view_default_978 = torch.ops.aten.view.default(permute_default_191, [64, 128, 1024]);  permute_default_191 = None
        clone_default_191 = torch.ops.aten.clone.default(view_default_978, memory_format = torch.contiguous_format);  view_default_978 = None
        _unsafe_view_default_215 = torch.ops.aten._unsafe_view.default(clone_default_191, [8192, 1024]);  clone_default_191 = None
        t_default_712 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_284 = torch.ops.aten.mm.default(_unsafe_view_default_215, t_default_712);  t_default_712 = None
        t_default_713 = torch.ops.aten.t.default(_unsafe_view_default_215)
        mm_default_285 = torch.ops.aten.mm.default(t_default_713, view_default_2);  t_default_713 = view_default_2 = None
        t_default_714 = torch.ops.aten.t.default(mm_default_285);  mm_default_285 = None
        sum_dim_int_list_142 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_215, [0], True);  _unsafe_view_default_215 = None
        view_default_979 = torch.ops.aten.view.default(sum_dim_int_list_142, [1024]);  sum_dim_int_list_142 = None
        t_default_715 = torch.ops.aten.t.default(t_default_714);  t_default_714 = None
        view_default_980 = torch.ops.aten.view.default(mm_default_284, [64, 128, 1024]);  mm_default_284 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(add_tensor_213, view_default_980);  add_tensor_213 = view_default_980 = None
        view_default_981 = torch.ops.aten.view.default(_unsafe_view_default_213, [8192, 1024]);  _unsafe_view_default_213 = None
        t_default_716 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_286 = torch.ops.aten.mm.default(view_default_981, t_default_716);  t_default_716 = None
        t_default_717 = torch.ops.aten.t.default(view_default_981)
        mm_default_287 = torch.ops.aten.mm.default(t_default_717, view_default);  t_default_717 = view_default = None
        t_default_718 = torch.ops.aten.t.default(mm_default_287);  mm_default_287 = None
        sum_dim_int_list_143 = torch.ops.aten.sum.dim_IntList(view_default_981, [0], True);  view_default_981 = None
        view_default_982 = torch.ops.aten.view.default(sum_dim_int_list_143, [1024]);  sum_dim_int_list_143 = None
        t_default_719 = torch.ops.aten.t.default(t_default_718);  t_default_718 = None
        view_default_983 = torch.ops.aten.view.default(mm_default_286, [64, 128, 1024]);  mm_default_286 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(add_tensor_214, view_default_983);  add_tensor_214 = view_default_983 = None
        return [getitem_287, getitem_286, view_default_967, t_default_707, view_default_979, t_default_715, view_default_982, t_default_719, view_default_976, t_default_711, view_default_964, t_default_703, getitem_284, getitem_283, view_default_961, t_default_699, getitem_227, getitem_226, view_default_727, t_default_467, view_default_739, t_default_475, view_default_742, t_default_479, view_default_736, t_default_471, view_default_724, t_default_463, getitem_224, getitem_223, view_default_721, t_default_459, getitem_221, getitem_220, view_default_703, t_default_443, view_default_715, t_default_451, view_default_718, t_default_455, view_default_712, t_default_447, view_default_700, t_default_439, getitem_218, getitem_217, view_default_697, t_default_435, getitem_215, getitem_214, view_default_679, t_default_419, view_default_691, t_default_427, view_default_694, t_default_431, view_default_688, t_default_423, view_default_676, t_default_415, getitem_212, getitem_211, view_default_673, t_default_411, getitem_209, getitem_208, view_default_655, t_default_395, view_default_667, t_default_403, view_default_670, t_default_407, view_default_664, t_default_399, view_default_652, t_default_391, getitem_206, getitem_205, view_default_649, t_default_387, getitem_203, getitem_202, view_default_631, t_default_371, view_default_643, t_default_379, view_default_646, t_default_383, view_default_640, t_default_375, view_default_628, t_default_367, getitem_200, getitem_199, view_default_625, t_default_363, getitem_197, getitem_196, view_default_607, t_default_347, view_default_619, t_default_355, view_default_622, t_default_359, view_default_616, t_default_351, view_default_604, t_default_343, getitem_194, getitem_193, view_default_601, t_default_339, getitem_191, getitem_190, view_default_583, t_default_323, view_default_595, t_default_331, view_default_598, t_default_335, view_default_592, t_default_327, view_default_580, t_default_319, getitem_188, getitem_187, view_default_577, t_default_315, getitem_185, getitem_184, view_default_559, t_default_299, view_default_571, t_default_307, view_default_574, t_default_311, view_default_568, t_default_303, view_default_556, t_default_295, getitem_182, getitem_181, view_default_553, t_default_291, getitem_179, getitem_178, view_default_535, t_default_275, view_default_547, t_default_283, view_default_550, t_default_287, view_default_544, t_default_279, view_default_532, t_default_271, getitem_176, getitem_175, view_default_529, t_default_267, getitem_173, getitem_172, view_default_511, t_default_251, view_default_523, t_default_259, view_default_526, t_default_263, view_default_520, t_default_255, view_default_508, t_default_247, getitem_170, getitem_169, view_default_505, t_default_243, getitem_281, getitem_280, view_default_943, t_default_683, view_default_955, t_default_691, view_default_958, t_default_695, view_default_952, t_default_687, view_default_940, t_default_679, getitem_278, getitem_277, view_default_937, t_default_675, getitem_167, getitem_166, view_default_487, t_default_227, view_default_499, t_default_235, view_default_502, t_default_239, view_default_496, t_default_231, view_default_484, t_default_223, getitem_164, getitem_163, view_default_481, t_default_219, getitem_161, getitem_160, view_default_463, t_default_203, view_default_475, t_default_211, view_default_478, t_default_215, view_default_472, t_default_207, view_default_460, t_default_199, getitem_158, getitem_157, view_default_457, t_default_195, getitem_155, getitem_154, view_default_439, t_default_179, view_default_451, t_default_187, view_default_454, t_default_191, view_default_448, t_default_183, view_default_436, t_default_175, getitem_152, getitem_151, view_default_433, t_default_171, getitem_149, getitem_148, view_default_415, t_default_155, view_default_427, t_default_163, view_default_430, t_default_167, view_default_424, t_default_159, view_default_412, t_default_151, getitem_146, getitem_145, view_default_409, t_default_147, getitem_275, getitem_274, view_default_919, t_default_659, view_default_931, t_default_667, view_default_934, t_default_671, view_default_928, t_default_663, view_default_916, t_default_655, getitem_272, getitem_271, view_default_913, t_default_651, getitem_269, getitem_268, view_default_895, t_default_635, view_default_907, t_default_643, view_default_910, t_default_647, view_default_904, t_default_639, view_default_892, t_default_631, getitem_266, getitem_265, view_default_889, t_default_627, getitem_263, getitem_262, view_default_871, t_default_611, view_default_883, t_default_619, view_default_886, t_default_623, view_default_880, t_default_615, view_default_868, t_default_607, getitem_260, getitem_259, view_default_865, t_default_603, getitem_257, getitem_256, view_default_847, t_default_587, view_default_859, t_default_595, view_default_862, t_default_599, view_default_856, t_default_591, view_default_844, t_default_583, getitem_254, getitem_253, view_default_841, t_default_579, getitem_251, getitem_250, view_default_823, t_default_563, view_default_835, t_default_571, view_default_838, t_default_575, view_default_832, t_default_567, view_default_820, t_default_559, getitem_248, getitem_247, view_default_817, t_default_555, getitem_245, getitem_244, view_default_799, t_default_539, view_default_811, t_default_547, view_default_814, t_default_551, view_default_808, t_default_543, view_default_796, t_default_535, getitem_242, getitem_241, view_default_793, t_default_531, getitem_239, getitem_238, view_default_775, t_default_515, view_default_787, t_default_523, view_default_790, t_default_527, view_default_784, t_default_519, view_default_772, t_default_511, getitem_236, getitem_235, view_default_769, t_default_507, getitem_233, getitem_232, view_default_751, t_default_491, view_default_763, t_default_499, view_default_766, t_default_503, view_default_760, t_default_495, view_default_748, t_default_487, getitem_230, getitem_229, view_default_745, t_default_483, add_tensor_215, None]
        
