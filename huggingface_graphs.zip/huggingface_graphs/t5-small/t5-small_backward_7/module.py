
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/t5-small/t5-small_backward_7/state_dict.pt'))

    
    
    def forward(self, tangents_1):
        return [None]
        
