
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/t5-small/t5-small_forward_6/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2):
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(primals_2, 2)
        mean_dim = torch.ops.aten.mean.dim(pow_tensor_scalar, [-1], True);  pow_tensor_scalar = None
        add_tensor = torch.ops.aten.add.Tensor(mean_dim, 1e-06);  mean_dim = None
        rsqrt_default = torch.ops.aten.rsqrt.default(add_tensor);  add_tensor = None
        mul_tensor = torch.ops.aten.mul.Tensor(primals_2, rsqrt_default)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(primals_1, mul_tensor)
        return [mul_tensor_1, primals_1, rsqrt_default, primals_2, mul_tensor]
        
