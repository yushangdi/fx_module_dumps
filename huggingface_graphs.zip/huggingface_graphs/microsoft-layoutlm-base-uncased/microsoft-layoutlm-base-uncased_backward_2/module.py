
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/microsoft-layoutlm-base-uncased/microsoft-layoutlm-base-uncased_backward_2/state_dict.pt'))

    
    
    def forward(self, t_default, select_int, tanh_default, tangents_1):
        to_dtype = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32);  tanh_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor, 1);  mul_tensor = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_1, torch.float32);  mul_tensor_1 = None
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(to_dtype_2, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(to_dtype_2)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, select_int);  t_default_2 = select_int = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(to_dtype_2, [0], True);  to_dtype_2 = None
        view_default = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        select_backward_default = torch.ops.aten.select_backward.default(mm_default, [8, 512, 768], 1, 0);  mm_default = None
        slice_backward_default = torch.ops.aten.slice_backward.default(select_backward_default, [8, 512, 768], 0, 0, 9223372036854775807, 1);  select_backward_default = None
        return [view_default, t_default_4, slice_backward_default]
        
