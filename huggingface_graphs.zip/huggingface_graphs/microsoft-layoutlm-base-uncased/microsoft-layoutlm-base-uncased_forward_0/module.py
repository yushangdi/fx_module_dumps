
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/microsoft-layoutlm-base-uncased/microsoft-layoutlm-base-uncased_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13):
        slice_tensor = torch.ops.aten.slice.Tensor(primals_5, 0, 0, 9223372036854775807);  primals_5 = None
        embedding_default = torch.ops.aten.embedding.default(primals_8, primals_11, 0);  primals_8 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_4, slice_tensor);  primals_4 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 1, 0, 9223372036854775807);  slice_tensor_1 = None
        select_int = torch.ops.aten.select.int(slice_tensor_2, 2, 0);  slice_tensor_2 = None
        embedding_default_2 = torch.ops.aten.embedding.default(primals_9, select_int)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(slice_tensor_3, 1, 0, 9223372036854775807);  slice_tensor_3 = None
        select_int_1 = torch.ops.aten.select.int(slice_tensor_4, 2, 1);  slice_tensor_4 = None
        embedding_default_3 = torch.ops.aten.embedding.default(primals_10, select_int_1)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_5, 1, 0, 9223372036854775807);  slice_tensor_5 = None
        select_int_2 = torch.ops.aten.select.int(slice_tensor_6, 2, 2);  slice_tensor_6 = None
        embedding_default_4 = torch.ops.aten.embedding.default(primals_9, select_int_2);  primals_9 = None
        slice_tensor_7 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(slice_tensor_7, 1, 0, 9223372036854775807);  slice_tensor_7 = None
        select_int_3 = torch.ops.aten.select.int(slice_tensor_8, 2, 3);  slice_tensor_8 = None
        embedding_default_5 = torch.ops.aten.embedding.default(primals_10, select_int_3);  primals_10 = None
        slice_tensor_9 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(slice_tensor_9, 1, 0, 9223372036854775807);  slice_tensor_9 = None
        select_int_4 = torch.ops.aten.select.int(slice_tensor_10, 2, 3);  slice_tensor_10 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807)
        slice_tensor_12 = torch.ops.aten.slice.Tensor(slice_tensor_11, 1, 0, 9223372036854775807);  slice_tensor_11 = None
        select_int_5 = torch.ops.aten.select.int(slice_tensor_12, 2, 1);  slice_tensor_12 = None
        sub_tensor = torch.ops.aten.sub.Tensor(select_int_4, select_int_5);  select_int_4 = select_int_5 = None
        embedding_default_6 = torch.ops.aten.embedding.default(primals_3, sub_tensor);  primals_3 = None
        slice_tensor_13 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(slice_tensor_13, 1, 0, 9223372036854775807);  slice_tensor_13 = None
        select_int_6 = torch.ops.aten.select.int(slice_tensor_14, 2, 2);  slice_tensor_14 = None
        slice_tensor_15 = torch.ops.aten.slice.Tensor(primals_12, 0, 0, 9223372036854775807);  primals_12 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(slice_tensor_15, 1, 0, 9223372036854775807);  slice_tensor_15 = None
        select_int_7 = torch.ops.aten.select.int(slice_tensor_16, 2, 0);  slice_tensor_16 = None
        sub_tensor_1 = torch.ops.aten.sub.Tensor(select_int_6, select_int_7);  select_int_6 = select_int_7 = None
        embedding_default_7 = torch.ops.aten.embedding.default(primals_7, sub_tensor_1);  primals_7 = None
        embedding_default_8 = torch.ops.aten.embedding.default(primals_6, primals_13);  primals_6 = None
        add_tensor = torch.ops.aten.add.Tensor(embedding_default, embedding_default_1);  embedding_default = embedding_default_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, embedding_default_2);  add_tensor = embedding_default_2 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, embedding_default_3);  add_tensor_1 = embedding_default_3 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, embedding_default_4);  add_tensor_2 = embedding_default_4 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, embedding_default_5);  add_tensor_3 = embedding_default_5 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, embedding_default_6);  add_tensor_4 = embedding_default_6 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, embedding_default_7);  add_tensor_5 = embedding_default_7 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, embedding_default_8);  add_tensor_6 = embedding_default_8 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_7, [768], primals_2, primals_1, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        return [getitem, sub_tensor_1, primals_13, select_int_3, add_tensor_7, slice_tensor, primals_1, primals_11, getitem_2, select_int, primals_2, getitem_1, select_int_1, sub_tensor, select_int_2]
        
