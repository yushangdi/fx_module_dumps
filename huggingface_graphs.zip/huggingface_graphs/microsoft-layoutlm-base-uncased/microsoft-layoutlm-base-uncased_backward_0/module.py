
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/microsoft-layoutlm-base-uncased/microsoft-layoutlm-base-uncased_backward_0/state_dict.pt'))

    
    
    def forward(self, sub_tensor_1, primals_13, select_int_3, add_tensor_7, slice_tensor, primals_1, primals_11, getitem_2, select_int, primals_2, getitem_1, select_int_1, sub_tensor, select_int_2, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_7, [768], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  tangents_1 = add_tensor_7 = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_3 = native_layer_norm_backward_default[0]
        getitem_4 = native_layer_norm_backward_default[1]
        getitem_5 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(getitem_3, [0], True)
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(getitem_3, primals_13, 2, -1, False);  primals_13 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(getitem_3, sub_tensor_1, 1024, -1, False);  sub_tensor_1 = None
        embedding_dense_backward_default_2 = torch.ops.aten.embedding_dense_backward.default(getitem_3, sub_tensor, 1024, -1, False);  sub_tensor = None
        embedding_dense_backward_default_3 = torch.ops.aten.embedding_dense_backward.default(getitem_3, select_int_3, 1024, -1, False);  select_int_3 = None
        embedding_dense_backward_default_4 = torch.ops.aten.embedding_dense_backward.default(getitem_3, select_int_2, 1024, -1, False);  select_int_2 = None
        embedding_dense_backward_default_5 = torch.ops.aten.embedding_dense_backward.default(getitem_3, select_int_1, 1024, -1, False);  select_int_1 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(embedding_dense_backward_default_3, embedding_dense_backward_default_5);  embedding_dense_backward_default_3 = embedding_dense_backward_default_5 = None
        embedding_dense_backward_default_6 = torch.ops.aten.embedding_dense_backward.default(getitem_3, select_int, 1024, -1, False);  select_int = None
        add_tensor_9 = torch.ops.aten.add.Tensor(embedding_dense_backward_default_4, embedding_dense_backward_default_6);  embedding_dense_backward_default_4 = embedding_dense_backward_default_6 = None
        embedding_dense_backward_default_7 = torch.ops.aten.embedding_dense_backward.default(sum_dim_int_list, slice_tensor, 512, -1, False);  sum_dim_int_list = slice_tensor = None
        embedding_dense_backward_default_8 = torch.ops.aten.embedding_dense_backward.default(getitem_3, primals_11, 30522, 0, False);  getitem_3 = primals_11 = None
        return [getitem_5, getitem_4, embedding_dense_backward_default_2, embedding_dense_backward_default_7, None, embedding_dense_backward_default, embedding_dense_backward_default_1, embedding_dense_backward_default_8, add_tensor_9, add_tensor_8, None, None, None]
        
