
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/BertForPreTraining_P1_bert/BertForPreTraining_P1_bert_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386):
        view_default = torch.ops.aten.view.default(primals_385, [8192, 1024])
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [64, 128, 1024]);  addmm_default = None
        view_default_2 = torch.ops.aten.view.default(primals_385, [8192, 1024])
        t_default_1 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_5, view_default_2, t_default_1);  primals_5 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default_1, [64, 128, 1024]);  addmm_default_1 = None
        view_default_4 = torch.ops.aten.view.default(view_default_3, [64, 128, 16, 64]);  view_default_3 = None
        permute_default = torch.ops.aten.permute.default(view_default_4, [0, 2, 1, 3]);  view_default_4 = None
        view_default_5 = torch.ops.aten.view.default(primals_385, [8192, 1024])
        t_default_2 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_9, view_default_5, t_default_2);  primals_9 = None
        view_default_6 = torch.ops.aten.view.default(addmm_default_2, [64, 128, 1024]);  addmm_default_2 = None
        view_default_7 = torch.ops.aten.view.default(view_default_6, [64, 128, 16, 64]);  view_default_6 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_7, [0, 2, 1, 3]);  view_default_7 = None
        view_default_8 = torch.ops.aten.view.default(view_default_1, [64, 128, 16, 64]);  view_default_1 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_8, [0, 2, 1, 3]);  view_default_8 = None
        transpose_int = torch.ops.aten.transpose.int(permute_default, -1, -2);  permute_default = None
        expand_default = torch.ops.aten.expand.default(permute_default_2, [64, 16, 128, 64]);  permute_default_2 = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [1024, 128, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int, [64, 16, 64, 128]);  transpose_int = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [1024, 64, 128]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [64, 16, 128, 128]);  bmm_default = None
        div_tensor = torch.ops.aten.div.Tensor(_unsafe_view_default_2, 8.0);  _unsafe_view_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(div_tensor, primals_386);  div_tensor = None
        _softmax_default = torch.ops.aten._softmax.default(add_tensor, -1, False);  add_tensor = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [64, 16, 128, 128])
        view_default_9 = torch.ops.aten.view.default(expand_default_2, [1024, 128, 128]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(permute_default_1, [64, 16, 128, 64]);  permute_default_1 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [1024, 128, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_9, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [64, 16, 128, 64]);  bmm_default_1 = None
        permute_default_3 = torch.ops.aten.permute.default(_unsafe_view_default_4, [0, 2, 1, 3]);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        view_default_10 = torch.ops.aten.view.default(clone_default_3, [64, 128, 1024]);  clone_default_3 = None
        view_default_11 = torch.ops.aten.view.default(view_default_10, [8192, 1024]);  view_default_10 = None
        t_default_3 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_3, view_default_11, t_default_3);  primals_3 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_3, [64, 128, 1024]);  addmm_default_3 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_12, primals_385);  view_default_12 = primals_385 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_1, [1024], primals_2, primals_1, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_13 = torch.ops.aten.view.default(getitem, [8192, 1024])
        t_default_4 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_11, view_default_13, t_default_4);  primals_11 = None
        view_default_14 = torch.ops.aten.view.default(addmm_default_4, [64, 128, 4096]);  addmm_default_4 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_14)
        view_default_15 = torch.ops.aten.view.default(gelu_default, [8192, 4096]);  gelu_default = None
        t_default_5 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_15, view_default_15, t_default_5);  primals_15 = None
        view_default_16 = torch.ops.aten.view.default(addmm_default_5, [64, 128, 1024]);  addmm_default_5 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_16, getitem);  view_default_16 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_2, [1024], primals_14, primals_13, 1e-12)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_17 = torch.ops.aten.view.default(getitem_3, [8192, 1024])
        t_default_6 = torch.ops.aten.t.default(primals_184);  primals_184 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_183, view_default_17, t_default_6);  primals_183 = None
        view_default_18 = torch.ops.aten.view.default(addmm_default_6, [64, 128, 1024]);  addmm_default_6 = None
        view_default_19 = torch.ops.aten.view.default(getitem_3, [8192, 1024])
        t_default_7 = torch.ops.aten.t.default(primals_182);  primals_182 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_181, view_default_19, t_default_7);  primals_181 = None
        view_default_20 = torch.ops.aten.view.default(addmm_default_7, [64, 128, 1024]);  addmm_default_7 = None
        view_default_21 = torch.ops.aten.view.default(view_default_20, [64, 128, 16, 64]);  view_default_20 = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_21, [0, 2, 1, 3]);  view_default_21 = None
        view_default_22 = torch.ops.aten.view.default(getitem_3, [8192, 1024])
        t_default_8 = torch.ops.aten.t.default(primals_186);  primals_186 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_185, view_default_22, t_default_8);  primals_185 = None
        view_default_23 = torch.ops.aten.view.default(addmm_default_8, [64, 128, 1024]);  addmm_default_8 = None
        view_default_24 = torch.ops.aten.view.default(view_default_23, [64, 128, 16, 64]);  view_default_23 = None
        permute_default_5 = torch.ops.aten.permute.default(view_default_24, [0, 2, 1, 3]);  view_default_24 = None
        view_default_25 = torch.ops.aten.view.default(view_default_18, [64, 128, 16, 64]);  view_default_18 = None
        permute_default_6 = torch.ops.aten.permute.default(view_default_25, [0, 2, 1, 3]);  view_default_25 = None
        transpose_int_1 = torch.ops.aten.transpose.int(permute_default_4, -1, -2);  permute_default_4 = None
        expand_default_4 = torch.ops.aten.expand.default(permute_default_6, [64, 16, 128, 64]);  permute_default_6 = None
        clone_default_4 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_4, [1024, 128, 64]);  clone_default_4 = None
        expand_default_5 = torch.ops.aten.expand.default(transpose_int_1, [64, 16, 64, 128]);  transpose_int_1 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_5, [1024, 64, 128]);  clone_default_5 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_5, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_2, [64, 16, 128, 128]);  bmm_default_2 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(_unsafe_view_default_7, 8.0);  _unsafe_view_default_7 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(div_tensor_1, primals_386);  div_tensor_1 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(add_tensor_3, -1, False);  add_tensor_3 = None
        expand_default_6 = torch.ops.aten.expand.default(_softmax_default_1, [64, 16, 128, 128])
        view_default_26 = torch.ops.aten.view.default(expand_default_6, [1024, 128, 128]);  expand_default_6 = None
        expand_default_7 = torch.ops.aten.expand.default(permute_default_5, [64, 16, 128, 64]);  permute_default_5 = None
        clone_default_6 = torch.ops.aten.clone.default(expand_default_7, memory_format = torch.contiguous_format);  expand_default_7 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_6, [1024, 128, 64]);  clone_default_6 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_26, _unsafe_view_default_8)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(bmm_default_3, [64, 16, 128, 64]);  bmm_default_3 = None
        permute_default_7 = torch.ops.aten.permute.default(_unsafe_view_default_9, [0, 2, 1, 3]);  _unsafe_view_default_9 = None
        clone_default_7 = torch.ops.aten.clone.default(permute_default_7, memory_format = torch.contiguous_format);  permute_default_7 = None
        view_default_27 = torch.ops.aten.view.default(clone_default_7, [64, 128, 1024]);  clone_default_7 = None
        view_default_28 = torch.ops.aten.view.default(view_default_27, [8192, 1024]);  view_default_27 = None
        t_default_9 = torch.ops.aten.t.default(primals_180);  primals_180 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_179, view_default_28, t_default_9);  primals_179 = None
        view_default_29 = torch.ops.aten.view.default(addmm_default_9, [64, 128, 1024]);  addmm_default_9 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(view_default_29, getitem_3);  view_default_29 = getitem_3 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [1024], primals_178, primals_177, 1e-12)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_30 = torch.ops.aten.view.default(getitem_6, [8192, 1024])
        t_default_10 = torch.ops.aten.t.default(primals_188);  primals_188 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_187, view_default_30, t_default_10);  primals_187 = None
        view_default_31 = torch.ops.aten.view.default(addmm_default_10, [64, 128, 4096]);  addmm_default_10 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_31)
        view_default_32 = torch.ops.aten.view.default(gelu_default_1, [8192, 4096]);  gelu_default_1 = None
        t_default_11 = torch.ops.aten.t.default(primals_192);  primals_192 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_191, view_default_32, t_default_11);  primals_191 = None
        view_default_33 = torch.ops.aten.view.default(addmm_default_11, [64, 128, 1024]);  addmm_default_11 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(view_default_33, getitem_6);  view_default_33 = getitem_6 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [1024], primals_190, primals_189, 1e-12)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_34 = torch.ops.aten.view.default(getitem_9, [8192, 1024])
        t_default_12 = torch.ops.aten.t.default(primals_264);  primals_264 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_263, view_default_34, t_default_12);  primals_263 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_12, [64, 128, 1024]);  addmm_default_12 = None
        view_default_36 = torch.ops.aten.view.default(getitem_9, [8192, 1024])
        t_default_13 = torch.ops.aten.t.default(primals_262);  primals_262 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_261, view_default_36, t_default_13);  primals_261 = None
        view_default_37 = torch.ops.aten.view.default(addmm_default_13, [64, 128, 1024]);  addmm_default_13 = None
        view_default_38 = torch.ops.aten.view.default(view_default_37, [64, 128, 16, 64]);  view_default_37 = None
        permute_default_8 = torch.ops.aten.permute.default(view_default_38, [0, 2, 1, 3]);  view_default_38 = None
        view_default_39 = torch.ops.aten.view.default(getitem_9, [8192, 1024])
        t_default_14 = torch.ops.aten.t.default(primals_266);  primals_266 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_265, view_default_39, t_default_14);  primals_265 = None
        view_default_40 = torch.ops.aten.view.default(addmm_default_14, [64, 128, 1024]);  addmm_default_14 = None
        view_default_41 = torch.ops.aten.view.default(view_default_40, [64, 128, 16, 64]);  view_default_40 = None
        permute_default_9 = torch.ops.aten.permute.default(view_default_41, [0, 2, 1, 3]);  view_default_41 = None
        view_default_42 = torch.ops.aten.view.default(view_default_35, [64, 128, 16, 64]);  view_default_35 = None
        permute_default_10 = torch.ops.aten.permute.default(view_default_42, [0, 2, 1, 3]);  view_default_42 = None
        transpose_int_2 = torch.ops.aten.transpose.int(permute_default_8, -1, -2);  permute_default_8 = None
        expand_default_8 = torch.ops.aten.expand.default(permute_default_10, [64, 16, 128, 64]);  permute_default_10 = None
        clone_default_8 = torch.ops.aten.clone.default(expand_default_8, memory_format = torch.contiguous_format);  expand_default_8 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_8, [1024, 128, 64]);  clone_default_8 = None
        expand_default_9 = torch.ops.aten.expand.default(transpose_int_2, [64, 16, 64, 128]);  transpose_int_2 = None
        clone_default_9 = torch.ops.aten.clone.default(expand_default_9, memory_format = torch.contiguous_format);  expand_default_9 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_9, [1024, 64, 128]);  clone_default_9 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_10, _unsafe_view_default_11)
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(bmm_default_4, [64, 16, 128, 128]);  bmm_default_4 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(_unsafe_view_default_12, 8.0);  _unsafe_view_default_12 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(div_tensor_2, primals_386);  div_tensor_2 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(add_tensor_6, -1, False);  add_tensor_6 = None
        expand_default_10 = torch.ops.aten.expand.default(_softmax_default_2, [64, 16, 128, 128])
        view_default_43 = torch.ops.aten.view.default(expand_default_10, [1024, 128, 128]);  expand_default_10 = None
        expand_default_11 = torch.ops.aten.expand.default(permute_default_9, [64, 16, 128, 64]);  permute_default_9 = None
        clone_default_10 = torch.ops.aten.clone.default(expand_default_11, memory_format = torch.contiguous_format);  expand_default_11 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_10, [1024, 128, 64]);  clone_default_10 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_43, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_5, [64, 16, 128, 64]);  bmm_default_5 = None
        permute_default_11 = torch.ops.aten.permute.default(_unsafe_view_default_14, [0, 2, 1, 3]);  _unsafe_view_default_14 = None
        clone_default_11 = torch.ops.aten.clone.default(permute_default_11, memory_format = torch.contiguous_format);  permute_default_11 = None
        view_default_44 = torch.ops.aten.view.default(clone_default_11, [64, 128, 1024]);  clone_default_11 = None
        view_default_45 = torch.ops.aten.view.default(view_default_44, [8192, 1024]);  view_default_44 = None
        t_default_15 = torch.ops.aten.t.default(primals_260);  primals_260 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_259, view_default_45, t_default_15);  primals_259 = None
        view_default_46 = torch.ops.aten.view.default(addmm_default_15, [64, 128, 1024]);  addmm_default_15 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(view_default_46, getitem_9);  view_default_46 = getitem_9 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_7, [1024], primals_258, primals_257, 1e-12)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_47 = torch.ops.aten.view.default(getitem_12, [8192, 1024])
        t_default_16 = torch.ops.aten.t.default(primals_268);  primals_268 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_267, view_default_47, t_default_16);  primals_267 = None
        view_default_48 = torch.ops.aten.view.default(addmm_default_16, [64, 128, 4096]);  addmm_default_16 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_48)
        view_default_49 = torch.ops.aten.view.default(gelu_default_2, [8192, 4096]);  gelu_default_2 = None
        t_default_17 = torch.ops.aten.t.default(primals_272);  primals_272 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_271, view_default_49, t_default_17);  primals_271 = None
        view_default_50 = torch.ops.aten.view.default(addmm_default_17, [64, 128, 1024]);  addmm_default_17 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(view_default_50, getitem_12);  view_default_50 = getitem_12 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_8, [1024], primals_270, primals_269, 1e-12)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_51 = torch.ops.aten.view.default(getitem_15, [8192, 1024])
        t_default_18 = torch.ops.aten.t.default(primals_280);  primals_280 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_279, view_default_51, t_default_18);  primals_279 = None
        view_default_52 = torch.ops.aten.view.default(addmm_default_18, [64, 128, 1024]);  addmm_default_18 = None
        view_default_53 = torch.ops.aten.view.default(getitem_15, [8192, 1024])
        t_default_19 = torch.ops.aten.t.default(primals_278);  primals_278 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_277, view_default_53, t_default_19);  primals_277 = None
        view_default_54 = torch.ops.aten.view.default(addmm_default_19, [64, 128, 1024]);  addmm_default_19 = None
        view_default_55 = torch.ops.aten.view.default(view_default_54, [64, 128, 16, 64]);  view_default_54 = None
        permute_default_12 = torch.ops.aten.permute.default(view_default_55, [0, 2, 1, 3]);  view_default_55 = None
        view_default_56 = torch.ops.aten.view.default(getitem_15, [8192, 1024])
        t_default_20 = torch.ops.aten.t.default(primals_282);  primals_282 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_281, view_default_56, t_default_20);  primals_281 = None
        view_default_57 = torch.ops.aten.view.default(addmm_default_20, [64, 128, 1024]);  addmm_default_20 = None
        view_default_58 = torch.ops.aten.view.default(view_default_57, [64, 128, 16, 64]);  view_default_57 = None
        permute_default_13 = torch.ops.aten.permute.default(view_default_58, [0, 2, 1, 3]);  view_default_58 = None
        view_default_59 = torch.ops.aten.view.default(view_default_52, [64, 128, 16, 64]);  view_default_52 = None
        permute_default_14 = torch.ops.aten.permute.default(view_default_59, [0, 2, 1, 3]);  view_default_59 = None
        transpose_int_3 = torch.ops.aten.transpose.int(permute_default_12, -1, -2);  permute_default_12 = None
        expand_default_12 = torch.ops.aten.expand.default(permute_default_14, [64, 16, 128, 64]);  permute_default_14 = None
        clone_default_12 = torch.ops.aten.clone.default(expand_default_12, memory_format = torch.contiguous_format);  expand_default_12 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_12, [1024, 128, 64]);  clone_default_12 = None
        expand_default_13 = torch.ops.aten.expand.default(transpose_int_3, [64, 16, 64, 128]);  transpose_int_3 = None
        clone_default_13 = torch.ops.aten.clone.default(expand_default_13, memory_format = torch.contiguous_format);  expand_default_13 = None
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(clone_default_13, [1024, 64, 128]);  clone_default_13 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_15, _unsafe_view_default_16)
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(bmm_default_6, [64, 16, 128, 128]);  bmm_default_6 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(_unsafe_view_default_17, 8.0);  _unsafe_view_default_17 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(div_tensor_3, primals_386);  div_tensor_3 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(add_tensor_9, -1, False);  add_tensor_9 = None
        expand_default_14 = torch.ops.aten.expand.default(_softmax_default_3, [64, 16, 128, 128])
        view_default_60 = torch.ops.aten.view.default(expand_default_14, [1024, 128, 128]);  expand_default_14 = None
        expand_default_15 = torch.ops.aten.expand.default(permute_default_13, [64, 16, 128, 64]);  permute_default_13 = None
        clone_default_14 = torch.ops.aten.clone.default(expand_default_15, memory_format = torch.contiguous_format);  expand_default_15 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_14, [1024, 128, 64]);  clone_default_14 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_60, _unsafe_view_default_18)
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(bmm_default_7, [64, 16, 128, 64]);  bmm_default_7 = None
        permute_default_15 = torch.ops.aten.permute.default(_unsafe_view_default_19, [0, 2, 1, 3]);  _unsafe_view_default_19 = None
        clone_default_15 = torch.ops.aten.clone.default(permute_default_15, memory_format = torch.contiguous_format);  permute_default_15 = None
        view_default_61 = torch.ops.aten.view.default(clone_default_15, [64, 128, 1024]);  clone_default_15 = None
        view_default_62 = torch.ops.aten.view.default(view_default_61, [8192, 1024]);  view_default_61 = None
        t_default_21 = torch.ops.aten.t.default(primals_276);  primals_276 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_275, view_default_62, t_default_21);  primals_275 = None
        view_default_63 = torch.ops.aten.view.default(addmm_default_21, [64, 128, 1024]);  addmm_default_21 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(view_default_63, getitem_15);  view_default_63 = getitem_15 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_10, [1024], primals_274, primals_273, 1e-12)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_64 = torch.ops.aten.view.default(getitem_18, [8192, 1024])
        t_default_22 = torch.ops.aten.t.default(primals_284);  primals_284 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_283, view_default_64, t_default_22);  primals_283 = None
        view_default_65 = torch.ops.aten.view.default(addmm_default_22, [64, 128, 4096]);  addmm_default_22 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_65)
        view_default_66 = torch.ops.aten.view.default(gelu_default_3, [8192, 4096]);  gelu_default_3 = None
        t_default_23 = torch.ops.aten.t.default(primals_288);  primals_288 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_287, view_default_66, t_default_23);  primals_287 = None
        view_default_67 = torch.ops.aten.view.default(addmm_default_23, [64, 128, 1024]);  addmm_default_23 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(view_default_67, getitem_18);  view_default_67 = getitem_18 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_11, [1024], primals_286, primals_285, 1e-12)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_68 = torch.ops.aten.view.default(getitem_21, [8192, 1024])
        t_default_24 = torch.ops.aten.t.default(primals_296);  primals_296 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_295, view_default_68, t_default_24);  primals_295 = None
        view_default_69 = torch.ops.aten.view.default(addmm_default_24, [64, 128, 1024]);  addmm_default_24 = None
        view_default_70 = torch.ops.aten.view.default(getitem_21, [8192, 1024])
        t_default_25 = torch.ops.aten.t.default(primals_294);  primals_294 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_293, view_default_70, t_default_25);  primals_293 = None
        view_default_71 = torch.ops.aten.view.default(addmm_default_25, [64, 128, 1024]);  addmm_default_25 = None
        view_default_72 = torch.ops.aten.view.default(view_default_71, [64, 128, 16, 64]);  view_default_71 = None
        permute_default_16 = torch.ops.aten.permute.default(view_default_72, [0, 2, 1, 3]);  view_default_72 = None
        view_default_73 = torch.ops.aten.view.default(getitem_21, [8192, 1024])
        t_default_26 = torch.ops.aten.t.default(primals_298);  primals_298 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_297, view_default_73, t_default_26);  primals_297 = None
        view_default_74 = torch.ops.aten.view.default(addmm_default_26, [64, 128, 1024]);  addmm_default_26 = None
        view_default_75 = torch.ops.aten.view.default(view_default_74, [64, 128, 16, 64]);  view_default_74 = None
        permute_default_17 = torch.ops.aten.permute.default(view_default_75, [0, 2, 1, 3]);  view_default_75 = None
        view_default_76 = torch.ops.aten.view.default(view_default_69, [64, 128, 16, 64]);  view_default_69 = None
        permute_default_18 = torch.ops.aten.permute.default(view_default_76, [0, 2, 1, 3]);  view_default_76 = None
        transpose_int_4 = torch.ops.aten.transpose.int(permute_default_16, -1, -2);  permute_default_16 = None
        expand_default_16 = torch.ops.aten.expand.default(permute_default_18, [64, 16, 128, 64]);  permute_default_18 = None
        clone_default_16 = torch.ops.aten.clone.default(expand_default_16, memory_format = torch.contiguous_format);  expand_default_16 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_16, [1024, 128, 64]);  clone_default_16 = None
        expand_default_17 = torch.ops.aten.expand.default(transpose_int_4, [64, 16, 64, 128]);  transpose_int_4 = None
        clone_default_17 = torch.ops.aten.clone.default(expand_default_17, memory_format = torch.contiguous_format);  expand_default_17 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_17, [1024, 64, 128]);  clone_default_17 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_20, _unsafe_view_default_21)
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(bmm_default_8, [64, 16, 128, 128]);  bmm_default_8 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(_unsafe_view_default_22, 8.0);  _unsafe_view_default_22 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(div_tensor_4, primals_386);  div_tensor_4 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(add_tensor_12, -1, False);  add_tensor_12 = None
        expand_default_18 = torch.ops.aten.expand.default(_softmax_default_4, [64, 16, 128, 128])
        view_default_77 = torch.ops.aten.view.default(expand_default_18, [1024, 128, 128]);  expand_default_18 = None
        expand_default_19 = torch.ops.aten.expand.default(permute_default_17, [64, 16, 128, 64]);  permute_default_17 = None
        clone_default_18 = torch.ops.aten.clone.default(expand_default_19, memory_format = torch.contiguous_format);  expand_default_19 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_18, [1024, 128, 64]);  clone_default_18 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_77, _unsafe_view_default_23)
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(bmm_default_9, [64, 16, 128, 64]);  bmm_default_9 = None
        permute_default_19 = torch.ops.aten.permute.default(_unsafe_view_default_24, [0, 2, 1, 3]);  _unsafe_view_default_24 = None
        clone_default_19 = torch.ops.aten.clone.default(permute_default_19, memory_format = torch.contiguous_format);  permute_default_19 = None
        view_default_78 = torch.ops.aten.view.default(clone_default_19, [64, 128, 1024]);  clone_default_19 = None
        view_default_79 = torch.ops.aten.view.default(view_default_78, [8192, 1024]);  view_default_78 = None
        t_default_27 = torch.ops.aten.t.default(primals_292);  primals_292 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_291, view_default_79, t_default_27);  primals_291 = None
        view_default_80 = torch.ops.aten.view.default(addmm_default_27, [64, 128, 1024]);  addmm_default_27 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(view_default_80, getitem_21);  view_default_80 = getitem_21 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_13, [1024], primals_290, primals_289, 1e-12)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_81 = torch.ops.aten.view.default(getitem_24, [8192, 1024])
        t_default_28 = torch.ops.aten.t.default(primals_300);  primals_300 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_299, view_default_81, t_default_28);  primals_299 = None
        view_default_82 = torch.ops.aten.view.default(addmm_default_28, [64, 128, 4096]);  addmm_default_28 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_82)
        view_default_83 = torch.ops.aten.view.default(gelu_default_4, [8192, 4096]);  gelu_default_4 = None
        t_default_29 = torch.ops.aten.t.default(primals_304);  primals_304 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_303, view_default_83, t_default_29);  primals_303 = None
        view_default_84 = torch.ops.aten.view.default(addmm_default_29, [64, 128, 1024]);  addmm_default_29 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(view_default_84, getitem_24);  view_default_84 = getitem_24 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_14, [1024], primals_302, primals_301, 1e-12)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_85 = torch.ops.aten.view.default(getitem_27, [8192, 1024])
        t_default_30 = torch.ops.aten.t.default(primals_312);  primals_312 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_311, view_default_85, t_default_30);  primals_311 = None
        view_default_86 = torch.ops.aten.view.default(addmm_default_30, [64, 128, 1024]);  addmm_default_30 = None
        view_default_87 = torch.ops.aten.view.default(getitem_27, [8192, 1024])
        t_default_31 = torch.ops.aten.t.default(primals_310);  primals_310 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_309, view_default_87, t_default_31);  primals_309 = None
        view_default_88 = torch.ops.aten.view.default(addmm_default_31, [64, 128, 1024]);  addmm_default_31 = None
        view_default_89 = torch.ops.aten.view.default(view_default_88, [64, 128, 16, 64]);  view_default_88 = None
        permute_default_20 = torch.ops.aten.permute.default(view_default_89, [0, 2, 1, 3]);  view_default_89 = None
        view_default_90 = torch.ops.aten.view.default(getitem_27, [8192, 1024])
        t_default_32 = torch.ops.aten.t.default(primals_314);  primals_314 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_313, view_default_90, t_default_32);  primals_313 = None
        view_default_91 = torch.ops.aten.view.default(addmm_default_32, [64, 128, 1024]);  addmm_default_32 = None
        view_default_92 = torch.ops.aten.view.default(view_default_91, [64, 128, 16, 64]);  view_default_91 = None
        permute_default_21 = torch.ops.aten.permute.default(view_default_92, [0, 2, 1, 3]);  view_default_92 = None
        view_default_93 = torch.ops.aten.view.default(view_default_86, [64, 128, 16, 64]);  view_default_86 = None
        permute_default_22 = torch.ops.aten.permute.default(view_default_93, [0, 2, 1, 3]);  view_default_93 = None
        transpose_int_5 = torch.ops.aten.transpose.int(permute_default_20, -1, -2);  permute_default_20 = None
        expand_default_20 = torch.ops.aten.expand.default(permute_default_22, [64, 16, 128, 64]);  permute_default_22 = None
        clone_default_20 = torch.ops.aten.clone.default(expand_default_20, memory_format = torch.contiguous_format);  expand_default_20 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_20, [1024, 128, 64]);  clone_default_20 = None
        expand_default_21 = torch.ops.aten.expand.default(transpose_int_5, [64, 16, 64, 128]);  transpose_int_5 = None
        clone_default_21 = torch.ops.aten.clone.default(expand_default_21, memory_format = torch.contiguous_format);  expand_default_21 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_21, [1024, 64, 128]);  clone_default_21 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_25, _unsafe_view_default_26)
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(bmm_default_10, [64, 16, 128, 128]);  bmm_default_10 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(_unsafe_view_default_27, 8.0);  _unsafe_view_default_27 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(div_tensor_5, primals_386);  div_tensor_5 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(add_tensor_15, -1, False);  add_tensor_15 = None
        expand_default_22 = torch.ops.aten.expand.default(_softmax_default_5, [64, 16, 128, 128])
        view_default_94 = torch.ops.aten.view.default(expand_default_22, [1024, 128, 128]);  expand_default_22 = None
        expand_default_23 = torch.ops.aten.expand.default(permute_default_21, [64, 16, 128, 64]);  permute_default_21 = None
        clone_default_22 = torch.ops.aten.clone.default(expand_default_23, memory_format = torch.contiguous_format);  expand_default_23 = None
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_22, [1024, 128, 64]);  clone_default_22 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_94, _unsafe_view_default_28)
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(bmm_default_11, [64, 16, 128, 64]);  bmm_default_11 = None
        permute_default_23 = torch.ops.aten.permute.default(_unsafe_view_default_29, [0, 2, 1, 3]);  _unsafe_view_default_29 = None
        clone_default_23 = torch.ops.aten.clone.default(permute_default_23, memory_format = torch.contiguous_format);  permute_default_23 = None
        view_default_95 = torch.ops.aten.view.default(clone_default_23, [64, 128, 1024]);  clone_default_23 = None
        view_default_96 = torch.ops.aten.view.default(view_default_95, [8192, 1024]);  view_default_95 = None
        t_default_33 = torch.ops.aten.t.default(primals_308);  primals_308 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_307, view_default_96, t_default_33);  primals_307 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_33, [64, 128, 1024]);  addmm_default_33 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(view_default_97, getitem_27);  view_default_97 = getitem_27 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_16, [1024], primals_306, primals_305, 1e-12)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_98 = torch.ops.aten.view.default(getitem_30, [8192, 1024])
        t_default_34 = torch.ops.aten.t.default(primals_316);  primals_316 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_315, view_default_98, t_default_34);  primals_315 = None
        view_default_99 = torch.ops.aten.view.default(addmm_default_34, [64, 128, 4096]);  addmm_default_34 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_99)
        view_default_100 = torch.ops.aten.view.default(gelu_default_5, [8192, 4096]);  gelu_default_5 = None
        t_default_35 = torch.ops.aten.t.default(primals_320);  primals_320 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_319, view_default_100, t_default_35);  primals_319 = None
        view_default_101 = torch.ops.aten.view.default(addmm_default_35, [64, 128, 1024]);  addmm_default_35 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(view_default_101, getitem_30);  view_default_101 = getitem_30 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_17, [1024], primals_318, primals_317, 1e-12)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_102 = torch.ops.aten.view.default(getitem_33, [8192, 1024])
        t_default_36 = torch.ops.aten.t.default(primals_328);  primals_328 = None
        addmm_default_36 = torch.ops.aten.addmm.default(primals_327, view_default_102, t_default_36);  primals_327 = None
        view_default_103 = torch.ops.aten.view.default(addmm_default_36, [64, 128, 1024]);  addmm_default_36 = None
        view_default_104 = torch.ops.aten.view.default(getitem_33, [8192, 1024])
        t_default_37 = torch.ops.aten.t.default(primals_326);  primals_326 = None
        addmm_default_37 = torch.ops.aten.addmm.default(primals_325, view_default_104, t_default_37);  primals_325 = None
        view_default_105 = torch.ops.aten.view.default(addmm_default_37, [64, 128, 1024]);  addmm_default_37 = None
        view_default_106 = torch.ops.aten.view.default(view_default_105, [64, 128, 16, 64]);  view_default_105 = None
        permute_default_24 = torch.ops.aten.permute.default(view_default_106, [0, 2, 1, 3]);  view_default_106 = None
        view_default_107 = torch.ops.aten.view.default(getitem_33, [8192, 1024])
        t_default_38 = torch.ops.aten.t.default(primals_330);  primals_330 = None
        addmm_default_38 = torch.ops.aten.addmm.default(primals_329, view_default_107, t_default_38);  primals_329 = None
        view_default_108 = torch.ops.aten.view.default(addmm_default_38, [64, 128, 1024]);  addmm_default_38 = None
        view_default_109 = torch.ops.aten.view.default(view_default_108, [64, 128, 16, 64]);  view_default_108 = None
        permute_default_25 = torch.ops.aten.permute.default(view_default_109, [0, 2, 1, 3]);  view_default_109 = None
        view_default_110 = torch.ops.aten.view.default(view_default_103, [64, 128, 16, 64]);  view_default_103 = None
        permute_default_26 = torch.ops.aten.permute.default(view_default_110, [0, 2, 1, 3]);  view_default_110 = None
        transpose_int_6 = torch.ops.aten.transpose.int(permute_default_24, -1, -2);  permute_default_24 = None
        expand_default_24 = torch.ops.aten.expand.default(permute_default_26, [64, 16, 128, 64]);  permute_default_26 = None
        clone_default_24 = torch.ops.aten.clone.default(expand_default_24, memory_format = torch.contiguous_format);  expand_default_24 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_24, [1024, 128, 64]);  clone_default_24 = None
        expand_default_25 = torch.ops.aten.expand.default(transpose_int_6, [64, 16, 64, 128]);  transpose_int_6 = None
        clone_default_25 = torch.ops.aten.clone.default(expand_default_25, memory_format = torch.contiguous_format);  expand_default_25 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_25, [1024, 64, 128]);  clone_default_25 = None
        bmm_default_12 = torch.ops.aten.bmm.default(_unsafe_view_default_30, _unsafe_view_default_31)
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(bmm_default_12, [64, 16, 128, 128]);  bmm_default_12 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(_unsafe_view_default_32, 8.0);  _unsafe_view_default_32 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(div_tensor_6, primals_386);  div_tensor_6 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(add_tensor_18, -1, False);  add_tensor_18 = None
        expand_default_26 = torch.ops.aten.expand.default(_softmax_default_6, [64, 16, 128, 128])
        view_default_111 = torch.ops.aten.view.default(expand_default_26, [1024, 128, 128]);  expand_default_26 = None
        expand_default_27 = torch.ops.aten.expand.default(permute_default_25, [64, 16, 128, 64]);  permute_default_25 = None
        clone_default_26 = torch.ops.aten.clone.default(expand_default_27, memory_format = torch.contiguous_format);  expand_default_27 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_26, [1024, 128, 64]);  clone_default_26 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_111, _unsafe_view_default_33)
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(bmm_default_13, [64, 16, 128, 64]);  bmm_default_13 = None
        permute_default_27 = torch.ops.aten.permute.default(_unsafe_view_default_34, [0, 2, 1, 3]);  _unsafe_view_default_34 = None
        clone_default_27 = torch.ops.aten.clone.default(permute_default_27, memory_format = torch.contiguous_format);  permute_default_27 = None
        view_default_112 = torch.ops.aten.view.default(clone_default_27, [64, 128, 1024]);  clone_default_27 = None
        view_default_113 = torch.ops.aten.view.default(view_default_112, [8192, 1024]);  view_default_112 = None
        t_default_39 = torch.ops.aten.t.default(primals_324);  primals_324 = None
        addmm_default_39 = torch.ops.aten.addmm.default(primals_323, view_default_113, t_default_39);  primals_323 = None
        view_default_114 = torch.ops.aten.view.default(addmm_default_39, [64, 128, 1024]);  addmm_default_39 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(view_default_114, getitem_33);  view_default_114 = getitem_33 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add_tensor_19, [1024], primals_322, primals_321, 1e-12)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        view_default_115 = torch.ops.aten.view.default(getitem_36, [8192, 1024])
        t_default_40 = torch.ops.aten.t.default(primals_332);  primals_332 = None
        addmm_default_40 = torch.ops.aten.addmm.default(primals_331, view_default_115, t_default_40);  primals_331 = None
        view_default_116 = torch.ops.aten.view.default(addmm_default_40, [64, 128, 4096]);  addmm_default_40 = None
        gelu_default_6 = torch.ops.aten.gelu.default(view_default_116)
        view_default_117 = torch.ops.aten.view.default(gelu_default_6, [8192, 4096]);  gelu_default_6 = None
        t_default_41 = torch.ops.aten.t.default(primals_336);  primals_336 = None
        addmm_default_41 = torch.ops.aten.addmm.default(primals_335, view_default_117, t_default_41);  primals_335 = None
        view_default_118 = torch.ops.aten.view.default(addmm_default_41, [64, 128, 1024]);  addmm_default_41 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(view_default_118, getitem_36);  view_default_118 = getitem_36 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_20, [1024], primals_334, primals_333, 1e-12)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        view_default_119 = torch.ops.aten.view.default(getitem_39, [8192, 1024])
        t_default_42 = torch.ops.aten.t.default(primals_344);  primals_344 = None
        addmm_default_42 = torch.ops.aten.addmm.default(primals_343, view_default_119, t_default_42);  primals_343 = None
        view_default_120 = torch.ops.aten.view.default(addmm_default_42, [64, 128, 1024]);  addmm_default_42 = None
        view_default_121 = torch.ops.aten.view.default(getitem_39, [8192, 1024])
        t_default_43 = torch.ops.aten.t.default(primals_342);  primals_342 = None
        addmm_default_43 = torch.ops.aten.addmm.default(primals_341, view_default_121, t_default_43);  primals_341 = None
        view_default_122 = torch.ops.aten.view.default(addmm_default_43, [64, 128, 1024]);  addmm_default_43 = None
        view_default_123 = torch.ops.aten.view.default(view_default_122, [64, 128, 16, 64]);  view_default_122 = None
        permute_default_28 = torch.ops.aten.permute.default(view_default_123, [0, 2, 1, 3]);  view_default_123 = None
        view_default_124 = torch.ops.aten.view.default(getitem_39, [8192, 1024])
        t_default_44 = torch.ops.aten.t.default(primals_346);  primals_346 = None
        addmm_default_44 = torch.ops.aten.addmm.default(primals_345, view_default_124, t_default_44);  primals_345 = None
        view_default_125 = torch.ops.aten.view.default(addmm_default_44, [64, 128, 1024]);  addmm_default_44 = None
        view_default_126 = torch.ops.aten.view.default(view_default_125, [64, 128, 16, 64]);  view_default_125 = None
        permute_default_29 = torch.ops.aten.permute.default(view_default_126, [0, 2, 1, 3]);  view_default_126 = None
        view_default_127 = torch.ops.aten.view.default(view_default_120, [64, 128, 16, 64]);  view_default_120 = None
        permute_default_30 = torch.ops.aten.permute.default(view_default_127, [0, 2, 1, 3]);  view_default_127 = None
        transpose_int_7 = torch.ops.aten.transpose.int(permute_default_28, -1, -2);  permute_default_28 = None
        expand_default_28 = torch.ops.aten.expand.default(permute_default_30, [64, 16, 128, 64]);  permute_default_30 = None
        clone_default_28 = torch.ops.aten.clone.default(expand_default_28, memory_format = torch.contiguous_format);  expand_default_28 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_28, [1024, 128, 64]);  clone_default_28 = None
        expand_default_29 = torch.ops.aten.expand.default(transpose_int_7, [64, 16, 64, 128]);  transpose_int_7 = None
        clone_default_29 = torch.ops.aten.clone.default(expand_default_29, memory_format = torch.contiguous_format);  expand_default_29 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_29, [1024, 64, 128]);  clone_default_29 = None
        bmm_default_14 = torch.ops.aten.bmm.default(_unsafe_view_default_35, _unsafe_view_default_36)
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(bmm_default_14, [64, 16, 128, 128]);  bmm_default_14 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(_unsafe_view_default_37, 8.0);  _unsafe_view_default_37 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(div_tensor_7, primals_386);  div_tensor_7 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(add_tensor_21, -1, False);  add_tensor_21 = None
        expand_default_30 = torch.ops.aten.expand.default(_softmax_default_7, [64, 16, 128, 128])
        view_default_128 = torch.ops.aten.view.default(expand_default_30, [1024, 128, 128]);  expand_default_30 = None
        expand_default_31 = torch.ops.aten.expand.default(permute_default_29, [64, 16, 128, 64]);  permute_default_29 = None
        clone_default_30 = torch.ops.aten.clone.default(expand_default_31, memory_format = torch.contiguous_format);  expand_default_31 = None
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(clone_default_30, [1024, 128, 64]);  clone_default_30 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_128, _unsafe_view_default_38)
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(bmm_default_15, [64, 16, 128, 64]);  bmm_default_15 = None
        permute_default_31 = torch.ops.aten.permute.default(_unsafe_view_default_39, [0, 2, 1, 3]);  _unsafe_view_default_39 = None
        clone_default_31 = torch.ops.aten.clone.default(permute_default_31, memory_format = torch.contiguous_format);  permute_default_31 = None
        view_default_129 = torch.ops.aten.view.default(clone_default_31, [64, 128, 1024]);  clone_default_31 = None
        view_default_130 = torch.ops.aten.view.default(view_default_129, [8192, 1024]);  view_default_129 = None
        t_default_45 = torch.ops.aten.t.default(primals_340);  primals_340 = None
        addmm_default_45 = torch.ops.aten.addmm.default(primals_339, view_default_130, t_default_45);  primals_339 = None
        view_default_131 = torch.ops.aten.view.default(addmm_default_45, [64, 128, 1024]);  addmm_default_45 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(view_default_131, getitem_39);  view_default_131 = getitem_39 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add_tensor_22, [1024], primals_338, primals_337, 1e-12)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        view_default_132 = torch.ops.aten.view.default(getitem_42, [8192, 1024])
        t_default_46 = torch.ops.aten.t.default(primals_348);  primals_348 = None
        addmm_default_46 = torch.ops.aten.addmm.default(primals_347, view_default_132, t_default_46);  primals_347 = None
        view_default_133 = torch.ops.aten.view.default(addmm_default_46, [64, 128, 4096]);  addmm_default_46 = None
        gelu_default_7 = torch.ops.aten.gelu.default(view_default_133)
        view_default_134 = torch.ops.aten.view.default(gelu_default_7, [8192, 4096]);  gelu_default_7 = None
        t_default_47 = torch.ops.aten.t.default(primals_352);  primals_352 = None
        addmm_default_47 = torch.ops.aten.addmm.default(primals_351, view_default_134, t_default_47);  primals_351 = None
        view_default_135 = torch.ops.aten.view.default(addmm_default_47, [64, 128, 1024]);  addmm_default_47 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(view_default_135, getitem_42);  view_default_135 = getitem_42 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add_tensor_23, [1024], primals_350, primals_349, 1e-12)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        view_default_136 = torch.ops.aten.view.default(getitem_45, [8192, 1024])
        t_default_48 = torch.ops.aten.t.default(primals_360);  primals_360 = None
        addmm_default_48 = torch.ops.aten.addmm.default(primals_359, view_default_136, t_default_48);  primals_359 = None
        view_default_137 = torch.ops.aten.view.default(addmm_default_48, [64, 128, 1024]);  addmm_default_48 = None
        view_default_138 = torch.ops.aten.view.default(getitem_45, [8192, 1024])
        t_default_49 = torch.ops.aten.t.default(primals_358);  primals_358 = None
        addmm_default_49 = torch.ops.aten.addmm.default(primals_357, view_default_138, t_default_49);  primals_357 = None
        view_default_139 = torch.ops.aten.view.default(addmm_default_49, [64, 128, 1024]);  addmm_default_49 = None
        view_default_140 = torch.ops.aten.view.default(view_default_139, [64, 128, 16, 64]);  view_default_139 = None
        permute_default_32 = torch.ops.aten.permute.default(view_default_140, [0, 2, 1, 3]);  view_default_140 = None
        view_default_141 = torch.ops.aten.view.default(getitem_45, [8192, 1024])
        t_default_50 = torch.ops.aten.t.default(primals_362);  primals_362 = None
        addmm_default_50 = torch.ops.aten.addmm.default(primals_361, view_default_141, t_default_50);  primals_361 = None
        view_default_142 = torch.ops.aten.view.default(addmm_default_50, [64, 128, 1024]);  addmm_default_50 = None
        view_default_143 = torch.ops.aten.view.default(view_default_142, [64, 128, 16, 64]);  view_default_142 = None
        permute_default_33 = torch.ops.aten.permute.default(view_default_143, [0, 2, 1, 3]);  view_default_143 = None
        view_default_144 = torch.ops.aten.view.default(view_default_137, [64, 128, 16, 64]);  view_default_137 = None
        permute_default_34 = torch.ops.aten.permute.default(view_default_144, [0, 2, 1, 3]);  view_default_144 = None
        transpose_int_8 = torch.ops.aten.transpose.int(permute_default_32, -1, -2);  permute_default_32 = None
        expand_default_32 = torch.ops.aten.expand.default(permute_default_34, [64, 16, 128, 64]);  permute_default_34 = None
        clone_default_32 = torch.ops.aten.clone.default(expand_default_32, memory_format = torch.contiguous_format);  expand_default_32 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_32, [1024, 128, 64]);  clone_default_32 = None
        expand_default_33 = torch.ops.aten.expand.default(transpose_int_8, [64, 16, 64, 128]);  transpose_int_8 = None
        clone_default_33 = torch.ops.aten.clone.default(expand_default_33, memory_format = torch.contiguous_format);  expand_default_33 = None
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_33, [1024, 64, 128]);  clone_default_33 = None
        bmm_default_16 = torch.ops.aten.bmm.default(_unsafe_view_default_40, _unsafe_view_default_41)
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(bmm_default_16, [64, 16, 128, 128]);  bmm_default_16 = None
        div_tensor_8 = torch.ops.aten.div.Tensor(_unsafe_view_default_42, 8.0);  _unsafe_view_default_42 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(div_tensor_8, primals_386);  div_tensor_8 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(add_tensor_24, -1, False);  add_tensor_24 = None
        expand_default_34 = torch.ops.aten.expand.default(_softmax_default_8, [64, 16, 128, 128])
        view_default_145 = torch.ops.aten.view.default(expand_default_34, [1024, 128, 128]);  expand_default_34 = None
        expand_default_35 = torch.ops.aten.expand.default(permute_default_33, [64, 16, 128, 64]);  permute_default_33 = None
        clone_default_34 = torch.ops.aten.clone.default(expand_default_35, memory_format = torch.contiguous_format);  expand_default_35 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_34, [1024, 128, 64]);  clone_default_34 = None
        bmm_default_17 = torch.ops.aten.bmm.default(view_default_145, _unsafe_view_default_43)
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(bmm_default_17, [64, 16, 128, 64]);  bmm_default_17 = None
        permute_default_35 = torch.ops.aten.permute.default(_unsafe_view_default_44, [0, 2, 1, 3]);  _unsafe_view_default_44 = None
        clone_default_35 = torch.ops.aten.clone.default(permute_default_35, memory_format = torch.contiguous_format);  permute_default_35 = None
        view_default_146 = torch.ops.aten.view.default(clone_default_35, [64, 128, 1024]);  clone_default_35 = None
        view_default_147 = torch.ops.aten.view.default(view_default_146, [8192, 1024]);  view_default_146 = None
        t_default_51 = torch.ops.aten.t.default(primals_356);  primals_356 = None
        addmm_default_51 = torch.ops.aten.addmm.default(primals_355, view_default_147, t_default_51);  primals_355 = None
        view_default_148 = torch.ops.aten.view.default(addmm_default_51, [64, 128, 1024]);  addmm_default_51 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(view_default_148, getitem_45);  view_default_148 = getitem_45 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add_tensor_25, [1024], primals_354, primals_353, 1e-12)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        view_default_149 = torch.ops.aten.view.default(getitem_48, [8192, 1024])
        t_default_52 = torch.ops.aten.t.default(primals_364);  primals_364 = None
        addmm_default_52 = torch.ops.aten.addmm.default(primals_363, view_default_149, t_default_52);  primals_363 = None
        view_default_150 = torch.ops.aten.view.default(addmm_default_52, [64, 128, 4096]);  addmm_default_52 = None
        gelu_default_8 = torch.ops.aten.gelu.default(view_default_150)
        view_default_151 = torch.ops.aten.view.default(gelu_default_8, [8192, 4096]);  gelu_default_8 = None
        t_default_53 = torch.ops.aten.t.default(primals_368);  primals_368 = None
        addmm_default_53 = torch.ops.aten.addmm.default(primals_367, view_default_151, t_default_53);  primals_367 = None
        view_default_152 = torch.ops.aten.view.default(addmm_default_53, [64, 128, 1024]);  addmm_default_53 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(view_default_152, getitem_48);  view_default_152 = getitem_48 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add_tensor_26, [1024], primals_366, primals_365, 1e-12)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        view_default_153 = torch.ops.aten.view.default(getitem_51, [8192, 1024])
        t_default_54 = torch.ops.aten.t.default(primals_376);  primals_376 = None
        addmm_default_54 = torch.ops.aten.addmm.default(primals_375, view_default_153, t_default_54);  primals_375 = None
        view_default_154 = torch.ops.aten.view.default(addmm_default_54, [64, 128, 1024]);  addmm_default_54 = None
        view_default_155 = torch.ops.aten.view.default(getitem_51, [8192, 1024])
        t_default_55 = torch.ops.aten.t.default(primals_374);  primals_374 = None
        addmm_default_55 = torch.ops.aten.addmm.default(primals_373, view_default_155, t_default_55);  primals_373 = None
        view_default_156 = torch.ops.aten.view.default(addmm_default_55, [64, 128, 1024]);  addmm_default_55 = None
        view_default_157 = torch.ops.aten.view.default(view_default_156, [64, 128, 16, 64]);  view_default_156 = None
        permute_default_36 = torch.ops.aten.permute.default(view_default_157, [0, 2, 1, 3]);  view_default_157 = None
        view_default_158 = torch.ops.aten.view.default(getitem_51, [8192, 1024])
        t_default_56 = torch.ops.aten.t.default(primals_378);  primals_378 = None
        addmm_default_56 = torch.ops.aten.addmm.default(primals_377, view_default_158, t_default_56);  primals_377 = None
        view_default_159 = torch.ops.aten.view.default(addmm_default_56, [64, 128, 1024]);  addmm_default_56 = None
        view_default_160 = torch.ops.aten.view.default(view_default_159, [64, 128, 16, 64]);  view_default_159 = None
        permute_default_37 = torch.ops.aten.permute.default(view_default_160, [0, 2, 1, 3]);  view_default_160 = None
        view_default_161 = torch.ops.aten.view.default(view_default_154, [64, 128, 16, 64]);  view_default_154 = None
        permute_default_38 = torch.ops.aten.permute.default(view_default_161, [0, 2, 1, 3]);  view_default_161 = None
        transpose_int_9 = torch.ops.aten.transpose.int(permute_default_36, -1, -2);  permute_default_36 = None
        expand_default_36 = torch.ops.aten.expand.default(permute_default_38, [64, 16, 128, 64]);  permute_default_38 = None
        clone_default_36 = torch.ops.aten.clone.default(expand_default_36, memory_format = torch.contiguous_format);  expand_default_36 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_36, [1024, 128, 64]);  clone_default_36 = None
        expand_default_37 = torch.ops.aten.expand.default(transpose_int_9, [64, 16, 64, 128]);  transpose_int_9 = None
        clone_default_37 = torch.ops.aten.clone.default(expand_default_37, memory_format = torch.contiguous_format);  expand_default_37 = None
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(clone_default_37, [1024, 64, 128]);  clone_default_37 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_45, _unsafe_view_default_46)
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(bmm_default_18, [64, 16, 128, 128]);  bmm_default_18 = None
        div_tensor_9 = torch.ops.aten.div.Tensor(_unsafe_view_default_47, 8.0);  _unsafe_view_default_47 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(div_tensor_9, primals_386);  div_tensor_9 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(add_tensor_27, -1, False);  add_tensor_27 = None
        expand_default_38 = torch.ops.aten.expand.default(_softmax_default_9, [64, 16, 128, 128])
        view_default_162 = torch.ops.aten.view.default(expand_default_38, [1024, 128, 128]);  expand_default_38 = None
        expand_default_39 = torch.ops.aten.expand.default(permute_default_37, [64, 16, 128, 64]);  permute_default_37 = None
        clone_default_38 = torch.ops.aten.clone.default(expand_default_39, memory_format = torch.contiguous_format);  expand_default_39 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_38, [1024, 128, 64]);  clone_default_38 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_162, _unsafe_view_default_48)
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(bmm_default_19, [64, 16, 128, 64]);  bmm_default_19 = None
        permute_default_39 = torch.ops.aten.permute.default(_unsafe_view_default_49, [0, 2, 1, 3]);  _unsafe_view_default_49 = None
        clone_default_39 = torch.ops.aten.clone.default(permute_default_39, memory_format = torch.contiguous_format);  permute_default_39 = None
        view_default_163 = torch.ops.aten.view.default(clone_default_39, [64, 128, 1024]);  clone_default_39 = None
        view_default_164 = torch.ops.aten.view.default(view_default_163, [8192, 1024]);  view_default_163 = None
        t_default_57 = torch.ops.aten.t.default(primals_372);  primals_372 = None
        addmm_default_57 = torch.ops.aten.addmm.default(primals_371, view_default_164, t_default_57);  primals_371 = None
        view_default_165 = torch.ops.aten.view.default(addmm_default_57, [64, 128, 1024]);  addmm_default_57 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(view_default_165, getitem_51);  view_default_165 = getitem_51 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add_tensor_28, [1024], primals_370, primals_369, 1e-12)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        view_default_166 = torch.ops.aten.view.default(getitem_54, [8192, 1024])
        t_default_58 = torch.ops.aten.t.default(primals_380);  primals_380 = None
        addmm_default_58 = torch.ops.aten.addmm.default(primals_379, view_default_166, t_default_58);  primals_379 = None
        view_default_167 = torch.ops.aten.view.default(addmm_default_58, [64, 128, 4096]);  addmm_default_58 = None
        gelu_default_9 = torch.ops.aten.gelu.default(view_default_167)
        view_default_168 = torch.ops.aten.view.default(gelu_default_9, [8192, 4096]);  gelu_default_9 = None
        t_default_59 = torch.ops.aten.t.default(primals_384);  primals_384 = None
        addmm_default_59 = torch.ops.aten.addmm.default(primals_383, view_default_168, t_default_59);  primals_383 = None
        view_default_169 = torch.ops.aten.view.default(addmm_default_59, [64, 128, 1024]);  addmm_default_59 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(view_default_169, getitem_54);  view_default_169 = getitem_54 = None
        native_layer_norm_default_19 = torch.ops.aten.native_layer_norm.default(add_tensor_29, [1024], primals_382, primals_381, 1e-12)
        getitem_57 = native_layer_norm_default_19[0]
        getitem_58 = native_layer_norm_default_19[1]
        getitem_59 = native_layer_norm_default_19[2];  native_layer_norm_default_19 = None
        view_default_170 = torch.ops.aten.view.default(getitem_57, [8192, 1024])
        t_default_60 = torch.ops.aten.t.default(primals_24);  primals_24 = None
        addmm_default_60 = torch.ops.aten.addmm.default(primals_23, view_default_170, t_default_60);  primals_23 = None
        view_default_171 = torch.ops.aten.view.default(addmm_default_60, [64, 128, 1024]);  addmm_default_60 = None
        view_default_172 = torch.ops.aten.view.default(getitem_57, [8192, 1024])
        t_default_61 = torch.ops.aten.t.default(primals_22);  primals_22 = None
        addmm_default_61 = torch.ops.aten.addmm.default(primals_21, view_default_172, t_default_61);  primals_21 = None
        view_default_173 = torch.ops.aten.view.default(addmm_default_61, [64, 128, 1024]);  addmm_default_61 = None
        view_default_174 = torch.ops.aten.view.default(view_default_173, [64, 128, 16, 64]);  view_default_173 = None
        permute_default_40 = torch.ops.aten.permute.default(view_default_174, [0, 2, 1, 3]);  view_default_174 = None
        view_default_175 = torch.ops.aten.view.default(getitem_57, [8192, 1024])
        t_default_62 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        addmm_default_62 = torch.ops.aten.addmm.default(primals_25, view_default_175, t_default_62);  primals_25 = None
        view_default_176 = torch.ops.aten.view.default(addmm_default_62, [64, 128, 1024]);  addmm_default_62 = None
        view_default_177 = torch.ops.aten.view.default(view_default_176, [64, 128, 16, 64]);  view_default_176 = None
        permute_default_41 = torch.ops.aten.permute.default(view_default_177, [0, 2, 1, 3]);  view_default_177 = None
        view_default_178 = torch.ops.aten.view.default(view_default_171, [64, 128, 16, 64]);  view_default_171 = None
        permute_default_42 = torch.ops.aten.permute.default(view_default_178, [0, 2, 1, 3]);  view_default_178 = None
        transpose_int_10 = torch.ops.aten.transpose.int(permute_default_40, -1, -2);  permute_default_40 = None
        expand_default_40 = torch.ops.aten.expand.default(permute_default_42, [64, 16, 128, 64]);  permute_default_42 = None
        clone_default_40 = torch.ops.aten.clone.default(expand_default_40, memory_format = torch.contiguous_format);  expand_default_40 = None
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(clone_default_40, [1024, 128, 64]);  clone_default_40 = None
        expand_default_41 = torch.ops.aten.expand.default(transpose_int_10, [64, 16, 64, 128]);  transpose_int_10 = None
        clone_default_41 = torch.ops.aten.clone.default(expand_default_41, memory_format = torch.contiguous_format);  expand_default_41 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_41, [1024, 64, 128]);  clone_default_41 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_50, _unsafe_view_default_51)
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(bmm_default_20, [64, 16, 128, 128]);  bmm_default_20 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(_unsafe_view_default_52, 8.0);  _unsafe_view_default_52 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(div_tensor_10, primals_386);  div_tensor_10 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(add_tensor_30, -1, False);  add_tensor_30 = None
        expand_default_42 = torch.ops.aten.expand.default(_softmax_default_10, [64, 16, 128, 128])
        view_default_179 = torch.ops.aten.view.default(expand_default_42, [1024, 128, 128]);  expand_default_42 = None
        expand_default_43 = torch.ops.aten.expand.default(permute_default_41, [64, 16, 128, 64]);  permute_default_41 = None
        clone_default_42 = torch.ops.aten.clone.default(expand_default_43, memory_format = torch.contiguous_format);  expand_default_43 = None
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(clone_default_42, [1024, 128, 64]);  clone_default_42 = None
        bmm_default_21 = torch.ops.aten.bmm.default(view_default_179, _unsafe_view_default_53)
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(bmm_default_21, [64, 16, 128, 64]);  bmm_default_21 = None
        permute_default_43 = torch.ops.aten.permute.default(_unsafe_view_default_54, [0, 2, 1, 3]);  _unsafe_view_default_54 = None
        clone_default_43 = torch.ops.aten.clone.default(permute_default_43, memory_format = torch.contiguous_format);  permute_default_43 = None
        view_default_180 = torch.ops.aten.view.default(clone_default_43, [64, 128, 1024]);  clone_default_43 = None
        view_default_181 = torch.ops.aten.view.default(view_default_180, [8192, 1024]);  view_default_180 = None
        t_default_63 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default_63 = torch.ops.aten.addmm.default(primals_19, view_default_181, t_default_63);  primals_19 = None
        view_default_182 = torch.ops.aten.view.default(addmm_default_63, [64, 128, 1024]);  addmm_default_63 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(view_default_182, getitem_57);  view_default_182 = getitem_57 = None
        native_layer_norm_default_20 = torch.ops.aten.native_layer_norm.default(add_tensor_31, [1024], primals_18, primals_17, 1e-12)
        getitem_60 = native_layer_norm_default_20[0]
        getitem_61 = native_layer_norm_default_20[1]
        getitem_62 = native_layer_norm_default_20[2];  native_layer_norm_default_20 = None
        view_default_183 = torch.ops.aten.view.default(getitem_60, [8192, 1024])
        t_default_64 = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default_64 = torch.ops.aten.addmm.default(primals_27, view_default_183, t_default_64);  primals_27 = None
        view_default_184 = torch.ops.aten.view.default(addmm_default_64, [64, 128, 4096]);  addmm_default_64 = None
        gelu_default_10 = torch.ops.aten.gelu.default(view_default_184)
        view_default_185 = torch.ops.aten.view.default(gelu_default_10, [8192, 4096]);  gelu_default_10 = None
        t_default_65 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_65 = torch.ops.aten.addmm.default(primals_31, view_default_185, t_default_65);  primals_31 = None
        view_default_186 = torch.ops.aten.view.default(addmm_default_65, [64, 128, 1024]);  addmm_default_65 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(view_default_186, getitem_60);  view_default_186 = getitem_60 = None
        native_layer_norm_default_21 = torch.ops.aten.native_layer_norm.default(add_tensor_32, [1024], primals_30, primals_29, 1e-12)
        getitem_63 = native_layer_norm_default_21[0]
        getitem_64 = native_layer_norm_default_21[1]
        getitem_65 = native_layer_norm_default_21[2];  native_layer_norm_default_21 = None
        view_default_187 = torch.ops.aten.view.default(getitem_63, [8192, 1024])
        t_default_66 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        addmm_default_66 = torch.ops.aten.addmm.default(primals_39, view_default_187, t_default_66);  primals_39 = None
        view_default_188 = torch.ops.aten.view.default(addmm_default_66, [64, 128, 1024]);  addmm_default_66 = None
        view_default_189 = torch.ops.aten.view.default(getitem_63, [8192, 1024])
        t_default_67 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        addmm_default_67 = torch.ops.aten.addmm.default(primals_37, view_default_189, t_default_67);  primals_37 = None
        view_default_190 = torch.ops.aten.view.default(addmm_default_67, [64, 128, 1024]);  addmm_default_67 = None
        view_default_191 = torch.ops.aten.view.default(view_default_190, [64, 128, 16, 64]);  view_default_190 = None
        permute_default_44 = torch.ops.aten.permute.default(view_default_191, [0, 2, 1, 3]);  view_default_191 = None
        view_default_192 = torch.ops.aten.view.default(getitem_63, [8192, 1024])
        t_default_68 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        addmm_default_68 = torch.ops.aten.addmm.default(primals_41, view_default_192, t_default_68);  primals_41 = None
        view_default_193 = torch.ops.aten.view.default(addmm_default_68, [64, 128, 1024]);  addmm_default_68 = None
        view_default_194 = torch.ops.aten.view.default(view_default_193, [64, 128, 16, 64]);  view_default_193 = None
        permute_default_45 = torch.ops.aten.permute.default(view_default_194, [0, 2, 1, 3]);  view_default_194 = None
        view_default_195 = torch.ops.aten.view.default(view_default_188, [64, 128, 16, 64]);  view_default_188 = None
        permute_default_46 = torch.ops.aten.permute.default(view_default_195, [0, 2, 1, 3]);  view_default_195 = None
        transpose_int_11 = torch.ops.aten.transpose.int(permute_default_44, -1, -2);  permute_default_44 = None
        expand_default_44 = torch.ops.aten.expand.default(permute_default_46, [64, 16, 128, 64]);  permute_default_46 = None
        clone_default_44 = torch.ops.aten.clone.default(expand_default_44, memory_format = torch.contiguous_format);  expand_default_44 = None
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(clone_default_44, [1024, 128, 64]);  clone_default_44 = None
        expand_default_45 = torch.ops.aten.expand.default(transpose_int_11, [64, 16, 64, 128]);  transpose_int_11 = None
        clone_default_45 = torch.ops.aten.clone.default(expand_default_45, memory_format = torch.contiguous_format);  expand_default_45 = None
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(clone_default_45, [1024, 64, 128]);  clone_default_45 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_55, _unsafe_view_default_56)
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(bmm_default_22, [64, 16, 128, 128]);  bmm_default_22 = None
        div_tensor_11 = torch.ops.aten.div.Tensor(_unsafe_view_default_57, 8.0);  _unsafe_view_default_57 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(div_tensor_11, primals_386);  div_tensor_11 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(add_tensor_33, -1, False);  add_tensor_33 = None
        expand_default_46 = torch.ops.aten.expand.default(_softmax_default_11, [64, 16, 128, 128])
        view_default_196 = torch.ops.aten.view.default(expand_default_46, [1024, 128, 128]);  expand_default_46 = None
        expand_default_47 = torch.ops.aten.expand.default(permute_default_45, [64, 16, 128, 64]);  permute_default_45 = None
        clone_default_46 = torch.ops.aten.clone.default(expand_default_47, memory_format = torch.contiguous_format);  expand_default_47 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_46, [1024, 128, 64]);  clone_default_46 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_196, _unsafe_view_default_58)
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(bmm_default_23, [64, 16, 128, 64]);  bmm_default_23 = None
        permute_default_47 = torch.ops.aten.permute.default(_unsafe_view_default_59, [0, 2, 1, 3]);  _unsafe_view_default_59 = None
        clone_default_47 = torch.ops.aten.clone.default(permute_default_47, memory_format = torch.contiguous_format);  permute_default_47 = None
        view_default_197 = torch.ops.aten.view.default(clone_default_47, [64, 128, 1024]);  clone_default_47 = None
        view_default_198 = torch.ops.aten.view.default(view_default_197, [8192, 1024]);  view_default_197 = None
        t_default_69 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        addmm_default_69 = torch.ops.aten.addmm.default(primals_35, view_default_198, t_default_69);  primals_35 = None
        view_default_199 = torch.ops.aten.view.default(addmm_default_69, [64, 128, 1024]);  addmm_default_69 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(view_default_199, getitem_63);  view_default_199 = getitem_63 = None
        native_layer_norm_default_22 = torch.ops.aten.native_layer_norm.default(add_tensor_34, [1024], primals_34, primals_33, 1e-12)
        getitem_66 = native_layer_norm_default_22[0]
        getitem_67 = native_layer_norm_default_22[1]
        getitem_68 = native_layer_norm_default_22[2];  native_layer_norm_default_22 = None
        view_default_200 = torch.ops.aten.view.default(getitem_66, [8192, 1024])
        t_default_70 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_70 = torch.ops.aten.addmm.default(primals_43, view_default_200, t_default_70);  primals_43 = None
        view_default_201 = torch.ops.aten.view.default(addmm_default_70, [64, 128, 4096]);  addmm_default_70 = None
        gelu_default_11 = torch.ops.aten.gelu.default(view_default_201)
        view_default_202 = torch.ops.aten.view.default(gelu_default_11, [8192, 4096]);  gelu_default_11 = None
        t_default_71 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_71 = torch.ops.aten.addmm.default(primals_47, view_default_202, t_default_71);  primals_47 = None
        view_default_203 = torch.ops.aten.view.default(addmm_default_71, [64, 128, 1024]);  addmm_default_71 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(view_default_203, getitem_66);  view_default_203 = getitem_66 = None
        native_layer_norm_default_23 = torch.ops.aten.native_layer_norm.default(add_tensor_35, [1024], primals_46, primals_45, 1e-12)
        getitem_69 = native_layer_norm_default_23[0]
        getitem_70 = native_layer_norm_default_23[1]
        getitem_71 = native_layer_norm_default_23[2];  native_layer_norm_default_23 = None
        view_default_204 = torch.ops.aten.view.default(getitem_69, [8192, 1024])
        t_default_72 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        addmm_default_72 = torch.ops.aten.addmm.default(primals_55, view_default_204, t_default_72);  primals_55 = None
        view_default_205 = torch.ops.aten.view.default(addmm_default_72, [64, 128, 1024]);  addmm_default_72 = None
        view_default_206 = torch.ops.aten.view.default(getitem_69, [8192, 1024])
        t_default_73 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        addmm_default_73 = torch.ops.aten.addmm.default(primals_53, view_default_206, t_default_73);  primals_53 = None
        view_default_207 = torch.ops.aten.view.default(addmm_default_73, [64, 128, 1024]);  addmm_default_73 = None
        view_default_208 = torch.ops.aten.view.default(view_default_207, [64, 128, 16, 64]);  view_default_207 = None
        permute_default_48 = torch.ops.aten.permute.default(view_default_208, [0, 2, 1, 3]);  view_default_208 = None
        view_default_209 = torch.ops.aten.view.default(getitem_69, [8192, 1024])
        t_default_74 = torch.ops.aten.t.default(primals_58);  primals_58 = None
        addmm_default_74 = torch.ops.aten.addmm.default(primals_57, view_default_209, t_default_74);  primals_57 = None
        view_default_210 = torch.ops.aten.view.default(addmm_default_74, [64, 128, 1024]);  addmm_default_74 = None
        view_default_211 = torch.ops.aten.view.default(view_default_210, [64, 128, 16, 64]);  view_default_210 = None
        permute_default_49 = torch.ops.aten.permute.default(view_default_211, [0, 2, 1, 3]);  view_default_211 = None
        view_default_212 = torch.ops.aten.view.default(view_default_205, [64, 128, 16, 64]);  view_default_205 = None
        permute_default_50 = torch.ops.aten.permute.default(view_default_212, [0, 2, 1, 3]);  view_default_212 = None
        transpose_int_12 = torch.ops.aten.transpose.int(permute_default_48, -1, -2);  permute_default_48 = None
        expand_default_48 = torch.ops.aten.expand.default(permute_default_50, [64, 16, 128, 64]);  permute_default_50 = None
        clone_default_48 = torch.ops.aten.clone.default(expand_default_48, memory_format = torch.contiguous_format);  expand_default_48 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_48, [1024, 128, 64]);  clone_default_48 = None
        expand_default_49 = torch.ops.aten.expand.default(transpose_int_12, [64, 16, 64, 128]);  transpose_int_12 = None
        clone_default_49 = torch.ops.aten.clone.default(expand_default_49, memory_format = torch.contiguous_format);  expand_default_49 = None
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(clone_default_49, [1024, 64, 128]);  clone_default_49 = None
        bmm_default_24 = torch.ops.aten.bmm.default(_unsafe_view_default_60, _unsafe_view_default_61)
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(bmm_default_24, [64, 16, 128, 128]);  bmm_default_24 = None
        div_tensor_12 = torch.ops.aten.div.Tensor(_unsafe_view_default_62, 8.0);  _unsafe_view_default_62 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(div_tensor_12, primals_386);  div_tensor_12 = None
        _softmax_default_12 = torch.ops.aten._softmax.default(add_tensor_36, -1, False);  add_tensor_36 = None
        expand_default_50 = torch.ops.aten.expand.default(_softmax_default_12, [64, 16, 128, 128])
        view_default_213 = torch.ops.aten.view.default(expand_default_50, [1024, 128, 128]);  expand_default_50 = None
        expand_default_51 = torch.ops.aten.expand.default(permute_default_49, [64, 16, 128, 64]);  permute_default_49 = None
        clone_default_50 = torch.ops.aten.clone.default(expand_default_51, memory_format = torch.contiguous_format);  expand_default_51 = None
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(clone_default_50, [1024, 128, 64]);  clone_default_50 = None
        bmm_default_25 = torch.ops.aten.bmm.default(view_default_213, _unsafe_view_default_63)
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(bmm_default_25, [64, 16, 128, 64]);  bmm_default_25 = None
        permute_default_51 = torch.ops.aten.permute.default(_unsafe_view_default_64, [0, 2, 1, 3]);  _unsafe_view_default_64 = None
        clone_default_51 = torch.ops.aten.clone.default(permute_default_51, memory_format = torch.contiguous_format);  permute_default_51 = None
        view_default_214 = torch.ops.aten.view.default(clone_default_51, [64, 128, 1024]);  clone_default_51 = None
        view_default_215 = torch.ops.aten.view.default(view_default_214, [8192, 1024]);  view_default_214 = None
        t_default_75 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default_75 = torch.ops.aten.addmm.default(primals_51, view_default_215, t_default_75);  primals_51 = None
        view_default_216 = torch.ops.aten.view.default(addmm_default_75, [64, 128, 1024]);  addmm_default_75 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(view_default_216, getitem_69);  view_default_216 = getitem_69 = None
        native_layer_norm_default_24 = torch.ops.aten.native_layer_norm.default(add_tensor_37, [1024], primals_50, primals_49, 1e-12)
        getitem_72 = native_layer_norm_default_24[0]
        getitem_73 = native_layer_norm_default_24[1]
        getitem_74 = native_layer_norm_default_24[2];  native_layer_norm_default_24 = None
        view_default_217 = torch.ops.aten.view.default(getitem_72, [8192, 1024])
        t_default_76 = torch.ops.aten.t.default(primals_60);  primals_60 = None
        addmm_default_76 = torch.ops.aten.addmm.default(primals_59, view_default_217, t_default_76);  primals_59 = None
        view_default_218 = torch.ops.aten.view.default(addmm_default_76, [64, 128, 4096]);  addmm_default_76 = None
        gelu_default_12 = torch.ops.aten.gelu.default(view_default_218)
        view_default_219 = torch.ops.aten.view.default(gelu_default_12, [8192, 4096]);  gelu_default_12 = None
        t_default_77 = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default_77 = torch.ops.aten.addmm.default(primals_63, view_default_219, t_default_77);  primals_63 = None
        view_default_220 = torch.ops.aten.view.default(addmm_default_77, [64, 128, 1024]);  addmm_default_77 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(view_default_220, getitem_72);  view_default_220 = getitem_72 = None
        native_layer_norm_default_25 = torch.ops.aten.native_layer_norm.default(add_tensor_38, [1024], primals_62, primals_61, 1e-12)
        getitem_75 = native_layer_norm_default_25[0]
        getitem_76 = native_layer_norm_default_25[1]
        getitem_77 = native_layer_norm_default_25[2];  native_layer_norm_default_25 = None
        view_default_221 = torch.ops.aten.view.default(getitem_75, [8192, 1024])
        t_default_78 = torch.ops.aten.t.default(primals_72);  primals_72 = None
        addmm_default_78 = torch.ops.aten.addmm.default(primals_71, view_default_221, t_default_78);  primals_71 = None
        view_default_222 = torch.ops.aten.view.default(addmm_default_78, [64, 128, 1024]);  addmm_default_78 = None
        view_default_223 = torch.ops.aten.view.default(getitem_75, [8192, 1024])
        t_default_79 = torch.ops.aten.t.default(primals_70);  primals_70 = None
        addmm_default_79 = torch.ops.aten.addmm.default(primals_69, view_default_223, t_default_79);  primals_69 = None
        view_default_224 = torch.ops.aten.view.default(addmm_default_79, [64, 128, 1024]);  addmm_default_79 = None
        view_default_225 = torch.ops.aten.view.default(view_default_224, [64, 128, 16, 64]);  view_default_224 = None
        permute_default_52 = torch.ops.aten.permute.default(view_default_225, [0, 2, 1, 3]);  view_default_225 = None
        view_default_226 = torch.ops.aten.view.default(getitem_75, [8192, 1024])
        t_default_80 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        addmm_default_80 = torch.ops.aten.addmm.default(primals_73, view_default_226, t_default_80);  primals_73 = None
        view_default_227 = torch.ops.aten.view.default(addmm_default_80, [64, 128, 1024]);  addmm_default_80 = None
        view_default_228 = torch.ops.aten.view.default(view_default_227, [64, 128, 16, 64]);  view_default_227 = None
        permute_default_53 = torch.ops.aten.permute.default(view_default_228, [0, 2, 1, 3]);  view_default_228 = None
        view_default_229 = torch.ops.aten.view.default(view_default_222, [64, 128, 16, 64]);  view_default_222 = None
        permute_default_54 = torch.ops.aten.permute.default(view_default_229, [0, 2, 1, 3]);  view_default_229 = None
        transpose_int_13 = torch.ops.aten.transpose.int(permute_default_52, -1, -2);  permute_default_52 = None
        expand_default_52 = torch.ops.aten.expand.default(permute_default_54, [64, 16, 128, 64]);  permute_default_54 = None
        clone_default_52 = torch.ops.aten.clone.default(expand_default_52, memory_format = torch.contiguous_format);  expand_default_52 = None
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(clone_default_52, [1024, 128, 64]);  clone_default_52 = None
        expand_default_53 = torch.ops.aten.expand.default(transpose_int_13, [64, 16, 64, 128]);  transpose_int_13 = None
        clone_default_53 = torch.ops.aten.clone.default(expand_default_53, memory_format = torch.contiguous_format);  expand_default_53 = None
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(clone_default_53, [1024, 64, 128]);  clone_default_53 = None
        bmm_default_26 = torch.ops.aten.bmm.default(_unsafe_view_default_65, _unsafe_view_default_66)
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(bmm_default_26, [64, 16, 128, 128]);  bmm_default_26 = None
        div_tensor_13 = torch.ops.aten.div.Tensor(_unsafe_view_default_67, 8.0);  _unsafe_view_default_67 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(div_tensor_13, primals_386);  div_tensor_13 = None
        _softmax_default_13 = torch.ops.aten._softmax.default(add_tensor_39, -1, False);  add_tensor_39 = None
        expand_default_54 = torch.ops.aten.expand.default(_softmax_default_13, [64, 16, 128, 128])
        view_default_230 = torch.ops.aten.view.default(expand_default_54, [1024, 128, 128]);  expand_default_54 = None
        expand_default_55 = torch.ops.aten.expand.default(permute_default_53, [64, 16, 128, 64]);  permute_default_53 = None
        clone_default_54 = torch.ops.aten.clone.default(expand_default_55, memory_format = torch.contiguous_format);  expand_default_55 = None
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(clone_default_54, [1024, 128, 64]);  clone_default_54 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_230, _unsafe_view_default_68)
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(bmm_default_27, [64, 16, 128, 64]);  bmm_default_27 = None
        permute_default_55 = torch.ops.aten.permute.default(_unsafe_view_default_69, [0, 2, 1, 3]);  _unsafe_view_default_69 = None
        clone_default_55 = torch.ops.aten.clone.default(permute_default_55, memory_format = torch.contiguous_format);  permute_default_55 = None
        view_default_231 = torch.ops.aten.view.default(clone_default_55, [64, 128, 1024]);  clone_default_55 = None
        view_default_232 = torch.ops.aten.view.default(view_default_231, [8192, 1024]);  view_default_231 = None
        t_default_81 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_81 = torch.ops.aten.addmm.default(primals_67, view_default_232, t_default_81);  primals_67 = None
        view_default_233 = torch.ops.aten.view.default(addmm_default_81, [64, 128, 1024]);  addmm_default_81 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(view_default_233, getitem_75);  view_default_233 = getitem_75 = None
        native_layer_norm_default_26 = torch.ops.aten.native_layer_norm.default(add_tensor_40, [1024], primals_66, primals_65, 1e-12)
        getitem_78 = native_layer_norm_default_26[0]
        getitem_79 = native_layer_norm_default_26[1]
        getitem_80 = native_layer_norm_default_26[2];  native_layer_norm_default_26 = None
        view_default_234 = torch.ops.aten.view.default(getitem_78, [8192, 1024])
        t_default_82 = torch.ops.aten.t.default(primals_76);  primals_76 = None
        addmm_default_82 = torch.ops.aten.addmm.default(primals_75, view_default_234, t_default_82);  primals_75 = None
        view_default_235 = torch.ops.aten.view.default(addmm_default_82, [64, 128, 4096]);  addmm_default_82 = None
        gelu_default_13 = torch.ops.aten.gelu.default(view_default_235)
        view_default_236 = torch.ops.aten.view.default(gelu_default_13, [8192, 4096]);  gelu_default_13 = None
        t_default_83 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        addmm_default_83 = torch.ops.aten.addmm.default(primals_79, view_default_236, t_default_83);  primals_79 = None
        view_default_237 = torch.ops.aten.view.default(addmm_default_83, [64, 128, 1024]);  addmm_default_83 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(view_default_237, getitem_78);  view_default_237 = getitem_78 = None
        native_layer_norm_default_27 = torch.ops.aten.native_layer_norm.default(add_tensor_41, [1024], primals_78, primals_77, 1e-12)
        getitem_81 = native_layer_norm_default_27[0]
        getitem_82 = native_layer_norm_default_27[1]
        getitem_83 = native_layer_norm_default_27[2];  native_layer_norm_default_27 = None
        view_default_238 = torch.ops.aten.view.default(getitem_81, [8192, 1024])
        t_default_84 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        addmm_default_84 = torch.ops.aten.addmm.default(primals_87, view_default_238, t_default_84);  primals_87 = None
        view_default_239 = torch.ops.aten.view.default(addmm_default_84, [64, 128, 1024]);  addmm_default_84 = None
        view_default_240 = torch.ops.aten.view.default(getitem_81, [8192, 1024])
        t_default_85 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        addmm_default_85 = torch.ops.aten.addmm.default(primals_85, view_default_240, t_default_85);  primals_85 = None
        view_default_241 = torch.ops.aten.view.default(addmm_default_85, [64, 128, 1024]);  addmm_default_85 = None
        view_default_242 = torch.ops.aten.view.default(view_default_241, [64, 128, 16, 64]);  view_default_241 = None
        permute_default_56 = torch.ops.aten.permute.default(view_default_242, [0, 2, 1, 3]);  view_default_242 = None
        view_default_243 = torch.ops.aten.view.default(getitem_81, [8192, 1024])
        t_default_86 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        addmm_default_86 = torch.ops.aten.addmm.default(primals_89, view_default_243, t_default_86);  primals_89 = None
        view_default_244 = torch.ops.aten.view.default(addmm_default_86, [64, 128, 1024]);  addmm_default_86 = None
        view_default_245 = torch.ops.aten.view.default(view_default_244, [64, 128, 16, 64]);  view_default_244 = None
        permute_default_57 = torch.ops.aten.permute.default(view_default_245, [0, 2, 1, 3]);  view_default_245 = None
        view_default_246 = torch.ops.aten.view.default(view_default_239, [64, 128, 16, 64]);  view_default_239 = None
        permute_default_58 = torch.ops.aten.permute.default(view_default_246, [0, 2, 1, 3]);  view_default_246 = None
        transpose_int_14 = torch.ops.aten.transpose.int(permute_default_56, -1, -2);  permute_default_56 = None
        expand_default_56 = torch.ops.aten.expand.default(permute_default_58, [64, 16, 128, 64]);  permute_default_58 = None
        clone_default_56 = torch.ops.aten.clone.default(expand_default_56, memory_format = torch.contiguous_format);  expand_default_56 = None
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(clone_default_56, [1024, 128, 64]);  clone_default_56 = None
        expand_default_57 = torch.ops.aten.expand.default(transpose_int_14, [64, 16, 64, 128]);  transpose_int_14 = None
        clone_default_57 = torch.ops.aten.clone.default(expand_default_57, memory_format = torch.contiguous_format);  expand_default_57 = None
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(clone_default_57, [1024, 64, 128]);  clone_default_57 = None
        bmm_default_28 = torch.ops.aten.bmm.default(_unsafe_view_default_70, _unsafe_view_default_71)
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(bmm_default_28, [64, 16, 128, 128]);  bmm_default_28 = None
        div_tensor_14 = torch.ops.aten.div.Tensor(_unsafe_view_default_72, 8.0);  _unsafe_view_default_72 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(div_tensor_14, primals_386);  div_tensor_14 = None
        _softmax_default_14 = torch.ops.aten._softmax.default(add_tensor_42, -1, False);  add_tensor_42 = None
        expand_default_58 = torch.ops.aten.expand.default(_softmax_default_14, [64, 16, 128, 128])
        view_default_247 = torch.ops.aten.view.default(expand_default_58, [1024, 128, 128]);  expand_default_58 = None
        expand_default_59 = torch.ops.aten.expand.default(permute_default_57, [64, 16, 128, 64]);  permute_default_57 = None
        clone_default_58 = torch.ops.aten.clone.default(expand_default_59, memory_format = torch.contiguous_format);  expand_default_59 = None
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(clone_default_58, [1024, 128, 64]);  clone_default_58 = None
        bmm_default_29 = torch.ops.aten.bmm.default(view_default_247, _unsafe_view_default_73)
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(bmm_default_29, [64, 16, 128, 64]);  bmm_default_29 = None
        permute_default_59 = torch.ops.aten.permute.default(_unsafe_view_default_74, [0, 2, 1, 3]);  _unsafe_view_default_74 = None
        clone_default_59 = torch.ops.aten.clone.default(permute_default_59, memory_format = torch.contiguous_format);  permute_default_59 = None
        view_default_248 = torch.ops.aten.view.default(clone_default_59, [64, 128, 1024]);  clone_default_59 = None
        view_default_249 = torch.ops.aten.view.default(view_default_248, [8192, 1024]);  view_default_248 = None
        t_default_87 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_87 = torch.ops.aten.addmm.default(primals_83, view_default_249, t_default_87);  primals_83 = None
        view_default_250 = torch.ops.aten.view.default(addmm_default_87, [64, 128, 1024]);  addmm_default_87 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(view_default_250, getitem_81);  view_default_250 = getitem_81 = None
        native_layer_norm_default_28 = torch.ops.aten.native_layer_norm.default(add_tensor_43, [1024], primals_82, primals_81, 1e-12)
        getitem_84 = native_layer_norm_default_28[0]
        getitem_85 = native_layer_norm_default_28[1]
        getitem_86 = native_layer_norm_default_28[2];  native_layer_norm_default_28 = None
        view_default_251 = torch.ops.aten.view.default(getitem_84, [8192, 1024])
        t_default_88 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_88 = torch.ops.aten.addmm.default(primals_91, view_default_251, t_default_88);  primals_91 = None
        view_default_252 = torch.ops.aten.view.default(addmm_default_88, [64, 128, 4096]);  addmm_default_88 = None
        gelu_default_14 = torch.ops.aten.gelu.default(view_default_252)
        view_default_253 = torch.ops.aten.view.default(gelu_default_14, [8192, 4096]);  gelu_default_14 = None
        t_default_89 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_89 = torch.ops.aten.addmm.default(primals_95, view_default_253, t_default_89);  primals_95 = None
        view_default_254 = torch.ops.aten.view.default(addmm_default_89, [64, 128, 1024]);  addmm_default_89 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(view_default_254, getitem_84);  view_default_254 = getitem_84 = None
        native_layer_norm_default_29 = torch.ops.aten.native_layer_norm.default(add_tensor_44, [1024], primals_94, primals_93, 1e-12)
        getitem_87 = native_layer_norm_default_29[0]
        getitem_88 = native_layer_norm_default_29[1]
        getitem_89 = native_layer_norm_default_29[2];  native_layer_norm_default_29 = None
        view_default_255 = torch.ops.aten.view.default(getitem_87, [8192, 1024])
        t_default_90 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        addmm_default_90 = torch.ops.aten.addmm.default(primals_103, view_default_255, t_default_90);  primals_103 = None
        view_default_256 = torch.ops.aten.view.default(addmm_default_90, [64, 128, 1024]);  addmm_default_90 = None
        view_default_257 = torch.ops.aten.view.default(getitem_87, [8192, 1024])
        t_default_91 = torch.ops.aten.t.default(primals_102);  primals_102 = None
        addmm_default_91 = torch.ops.aten.addmm.default(primals_101, view_default_257, t_default_91);  primals_101 = None
        view_default_258 = torch.ops.aten.view.default(addmm_default_91, [64, 128, 1024]);  addmm_default_91 = None
        view_default_259 = torch.ops.aten.view.default(view_default_258, [64, 128, 16, 64]);  view_default_258 = None
        permute_default_60 = torch.ops.aten.permute.default(view_default_259, [0, 2, 1, 3]);  view_default_259 = None
        view_default_260 = torch.ops.aten.view.default(getitem_87, [8192, 1024])
        t_default_92 = torch.ops.aten.t.default(primals_106);  primals_106 = None
        addmm_default_92 = torch.ops.aten.addmm.default(primals_105, view_default_260, t_default_92);  primals_105 = None
        view_default_261 = torch.ops.aten.view.default(addmm_default_92, [64, 128, 1024]);  addmm_default_92 = None
        view_default_262 = torch.ops.aten.view.default(view_default_261, [64, 128, 16, 64]);  view_default_261 = None
        permute_default_61 = torch.ops.aten.permute.default(view_default_262, [0, 2, 1, 3]);  view_default_262 = None
        view_default_263 = torch.ops.aten.view.default(view_default_256, [64, 128, 16, 64]);  view_default_256 = None
        permute_default_62 = torch.ops.aten.permute.default(view_default_263, [0, 2, 1, 3]);  view_default_263 = None
        transpose_int_15 = torch.ops.aten.transpose.int(permute_default_60, -1, -2);  permute_default_60 = None
        expand_default_60 = torch.ops.aten.expand.default(permute_default_62, [64, 16, 128, 64]);  permute_default_62 = None
        clone_default_60 = torch.ops.aten.clone.default(expand_default_60, memory_format = torch.contiguous_format);  expand_default_60 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_60, [1024, 128, 64]);  clone_default_60 = None
        expand_default_61 = torch.ops.aten.expand.default(transpose_int_15, [64, 16, 64, 128]);  transpose_int_15 = None
        clone_default_61 = torch.ops.aten.clone.default(expand_default_61, memory_format = torch.contiguous_format);  expand_default_61 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_61, [1024, 64, 128]);  clone_default_61 = None
        bmm_default_30 = torch.ops.aten.bmm.default(_unsafe_view_default_75, _unsafe_view_default_76)
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(bmm_default_30, [64, 16, 128, 128]);  bmm_default_30 = None
        div_tensor_15 = torch.ops.aten.div.Tensor(_unsafe_view_default_77, 8.0);  _unsafe_view_default_77 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(div_tensor_15, primals_386);  div_tensor_15 = None
        _softmax_default_15 = torch.ops.aten._softmax.default(add_tensor_45, -1, False);  add_tensor_45 = None
        expand_default_62 = torch.ops.aten.expand.default(_softmax_default_15, [64, 16, 128, 128])
        view_default_264 = torch.ops.aten.view.default(expand_default_62, [1024, 128, 128]);  expand_default_62 = None
        expand_default_63 = torch.ops.aten.expand.default(permute_default_61, [64, 16, 128, 64]);  permute_default_61 = None
        clone_default_62 = torch.ops.aten.clone.default(expand_default_63, memory_format = torch.contiguous_format);  expand_default_63 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_62, [1024, 128, 64]);  clone_default_62 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_264, _unsafe_view_default_78)
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(bmm_default_31, [64, 16, 128, 64]);  bmm_default_31 = None
        permute_default_63 = torch.ops.aten.permute.default(_unsafe_view_default_79, [0, 2, 1, 3]);  _unsafe_view_default_79 = None
        clone_default_63 = torch.ops.aten.clone.default(permute_default_63, memory_format = torch.contiguous_format);  permute_default_63 = None
        view_default_265 = torch.ops.aten.view.default(clone_default_63, [64, 128, 1024]);  clone_default_63 = None
        view_default_266 = torch.ops.aten.view.default(view_default_265, [8192, 1024]);  view_default_265 = None
        t_default_93 = torch.ops.aten.t.default(primals_100);  primals_100 = None
        addmm_default_93 = torch.ops.aten.addmm.default(primals_99, view_default_266, t_default_93);  primals_99 = None
        view_default_267 = torch.ops.aten.view.default(addmm_default_93, [64, 128, 1024]);  addmm_default_93 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(view_default_267, getitem_87);  view_default_267 = getitem_87 = None
        native_layer_norm_default_30 = torch.ops.aten.native_layer_norm.default(add_tensor_46, [1024], primals_98, primals_97, 1e-12)
        getitem_90 = native_layer_norm_default_30[0]
        getitem_91 = native_layer_norm_default_30[1]
        getitem_92 = native_layer_norm_default_30[2];  native_layer_norm_default_30 = None
        view_default_268 = torch.ops.aten.view.default(getitem_90, [8192, 1024])
        t_default_94 = torch.ops.aten.t.default(primals_108);  primals_108 = None
        addmm_default_94 = torch.ops.aten.addmm.default(primals_107, view_default_268, t_default_94);  primals_107 = None
        view_default_269 = torch.ops.aten.view.default(addmm_default_94, [64, 128, 4096]);  addmm_default_94 = None
        gelu_default_15 = torch.ops.aten.gelu.default(view_default_269)
        view_default_270 = torch.ops.aten.view.default(gelu_default_15, [8192, 4096]);  gelu_default_15 = None
        t_default_95 = torch.ops.aten.t.default(primals_112);  primals_112 = None
        addmm_default_95 = torch.ops.aten.addmm.default(primals_111, view_default_270, t_default_95);  primals_111 = None
        view_default_271 = torch.ops.aten.view.default(addmm_default_95, [64, 128, 1024]);  addmm_default_95 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(view_default_271, getitem_90);  view_default_271 = getitem_90 = None
        native_layer_norm_default_31 = torch.ops.aten.native_layer_norm.default(add_tensor_47, [1024], primals_110, primals_109, 1e-12)
        getitem_93 = native_layer_norm_default_31[0]
        getitem_94 = native_layer_norm_default_31[1]
        getitem_95 = native_layer_norm_default_31[2];  native_layer_norm_default_31 = None
        view_default_272 = torch.ops.aten.view.default(getitem_93, [8192, 1024])
        t_default_96 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        addmm_default_96 = torch.ops.aten.addmm.default(primals_119, view_default_272, t_default_96);  primals_119 = None
        view_default_273 = torch.ops.aten.view.default(addmm_default_96, [64, 128, 1024]);  addmm_default_96 = None
        view_default_274 = torch.ops.aten.view.default(getitem_93, [8192, 1024])
        t_default_97 = torch.ops.aten.t.default(primals_118);  primals_118 = None
        addmm_default_97 = torch.ops.aten.addmm.default(primals_117, view_default_274, t_default_97);  primals_117 = None
        view_default_275 = torch.ops.aten.view.default(addmm_default_97, [64, 128, 1024]);  addmm_default_97 = None
        view_default_276 = torch.ops.aten.view.default(view_default_275, [64, 128, 16, 64]);  view_default_275 = None
        permute_default_64 = torch.ops.aten.permute.default(view_default_276, [0, 2, 1, 3]);  view_default_276 = None
        view_default_277 = torch.ops.aten.view.default(getitem_93, [8192, 1024])
        t_default_98 = torch.ops.aten.t.default(primals_122);  primals_122 = None
        addmm_default_98 = torch.ops.aten.addmm.default(primals_121, view_default_277, t_default_98);  primals_121 = None
        view_default_278 = torch.ops.aten.view.default(addmm_default_98, [64, 128, 1024]);  addmm_default_98 = None
        view_default_279 = torch.ops.aten.view.default(view_default_278, [64, 128, 16, 64]);  view_default_278 = None
        permute_default_65 = torch.ops.aten.permute.default(view_default_279, [0, 2, 1, 3]);  view_default_279 = None
        view_default_280 = torch.ops.aten.view.default(view_default_273, [64, 128, 16, 64]);  view_default_273 = None
        permute_default_66 = torch.ops.aten.permute.default(view_default_280, [0, 2, 1, 3]);  view_default_280 = None
        transpose_int_16 = torch.ops.aten.transpose.int(permute_default_64, -1, -2);  permute_default_64 = None
        expand_default_64 = torch.ops.aten.expand.default(permute_default_66, [64, 16, 128, 64]);  permute_default_66 = None
        clone_default_64 = torch.ops.aten.clone.default(expand_default_64, memory_format = torch.contiguous_format);  expand_default_64 = None
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(clone_default_64, [1024, 128, 64]);  clone_default_64 = None
        expand_default_65 = torch.ops.aten.expand.default(transpose_int_16, [64, 16, 64, 128]);  transpose_int_16 = None
        clone_default_65 = torch.ops.aten.clone.default(expand_default_65, memory_format = torch.contiguous_format);  expand_default_65 = None
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(clone_default_65, [1024, 64, 128]);  clone_default_65 = None
        bmm_default_32 = torch.ops.aten.bmm.default(_unsafe_view_default_80, _unsafe_view_default_81)
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(bmm_default_32, [64, 16, 128, 128]);  bmm_default_32 = None
        div_tensor_16 = torch.ops.aten.div.Tensor(_unsafe_view_default_82, 8.0);  _unsafe_view_default_82 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(div_tensor_16, primals_386);  div_tensor_16 = None
        _softmax_default_16 = torch.ops.aten._softmax.default(add_tensor_48, -1, False);  add_tensor_48 = None
        expand_default_66 = torch.ops.aten.expand.default(_softmax_default_16, [64, 16, 128, 128])
        view_default_281 = torch.ops.aten.view.default(expand_default_66, [1024, 128, 128]);  expand_default_66 = None
        expand_default_67 = torch.ops.aten.expand.default(permute_default_65, [64, 16, 128, 64]);  permute_default_65 = None
        clone_default_66 = torch.ops.aten.clone.default(expand_default_67, memory_format = torch.contiguous_format);  expand_default_67 = None
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(clone_default_66, [1024, 128, 64]);  clone_default_66 = None
        bmm_default_33 = torch.ops.aten.bmm.default(view_default_281, _unsafe_view_default_83)
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(bmm_default_33, [64, 16, 128, 64]);  bmm_default_33 = None
        permute_default_67 = torch.ops.aten.permute.default(_unsafe_view_default_84, [0, 2, 1, 3]);  _unsafe_view_default_84 = None
        clone_default_67 = torch.ops.aten.clone.default(permute_default_67, memory_format = torch.contiguous_format);  permute_default_67 = None
        view_default_282 = torch.ops.aten.view.default(clone_default_67, [64, 128, 1024]);  clone_default_67 = None
        view_default_283 = torch.ops.aten.view.default(view_default_282, [8192, 1024]);  view_default_282 = None
        t_default_99 = torch.ops.aten.t.default(primals_116);  primals_116 = None
        addmm_default_99 = torch.ops.aten.addmm.default(primals_115, view_default_283, t_default_99);  primals_115 = None
        view_default_284 = torch.ops.aten.view.default(addmm_default_99, [64, 128, 1024]);  addmm_default_99 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(view_default_284, getitem_93);  view_default_284 = getitem_93 = None
        native_layer_norm_default_32 = torch.ops.aten.native_layer_norm.default(add_tensor_49, [1024], primals_114, primals_113, 1e-12)
        getitem_96 = native_layer_norm_default_32[0]
        getitem_97 = native_layer_norm_default_32[1]
        getitem_98 = native_layer_norm_default_32[2];  native_layer_norm_default_32 = None
        view_default_285 = torch.ops.aten.view.default(getitem_96, [8192, 1024])
        t_default_100 = torch.ops.aten.t.default(primals_124);  primals_124 = None
        addmm_default_100 = torch.ops.aten.addmm.default(primals_123, view_default_285, t_default_100);  primals_123 = None
        view_default_286 = torch.ops.aten.view.default(addmm_default_100, [64, 128, 4096]);  addmm_default_100 = None
        gelu_default_16 = torch.ops.aten.gelu.default(view_default_286)
        view_default_287 = torch.ops.aten.view.default(gelu_default_16, [8192, 4096]);  gelu_default_16 = None
        t_default_101 = torch.ops.aten.t.default(primals_128);  primals_128 = None
        addmm_default_101 = torch.ops.aten.addmm.default(primals_127, view_default_287, t_default_101);  primals_127 = None
        view_default_288 = torch.ops.aten.view.default(addmm_default_101, [64, 128, 1024]);  addmm_default_101 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(view_default_288, getitem_96);  view_default_288 = getitem_96 = None
        native_layer_norm_default_33 = torch.ops.aten.native_layer_norm.default(add_tensor_50, [1024], primals_126, primals_125, 1e-12)
        getitem_99 = native_layer_norm_default_33[0]
        getitem_100 = native_layer_norm_default_33[1]
        getitem_101 = native_layer_norm_default_33[2];  native_layer_norm_default_33 = None
        view_default_289 = torch.ops.aten.view.default(getitem_99, [8192, 1024])
        t_default_102 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        addmm_default_102 = torch.ops.aten.addmm.default(primals_135, view_default_289, t_default_102);  primals_135 = None
        view_default_290 = torch.ops.aten.view.default(addmm_default_102, [64, 128, 1024]);  addmm_default_102 = None
        view_default_291 = torch.ops.aten.view.default(getitem_99, [8192, 1024])
        t_default_103 = torch.ops.aten.t.default(primals_134);  primals_134 = None
        addmm_default_103 = torch.ops.aten.addmm.default(primals_133, view_default_291, t_default_103);  primals_133 = None
        view_default_292 = torch.ops.aten.view.default(addmm_default_103, [64, 128, 1024]);  addmm_default_103 = None
        view_default_293 = torch.ops.aten.view.default(view_default_292, [64, 128, 16, 64]);  view_default_292 = None
        permute_default_68 = torch.ops.aten.permute.default(view_default_293, [0, 2, 1, 3]);  view_default_293 = None
        view_default_294 = torch.ops.aten.view.default(getitem_99, [8192, 1024])
        t_default_104 = torch.ops.aten.t.default(primals_138);  primals_138 = None
        addmm_default_104 = torch.ops.aten.addmm.default(primals_137, view_default_294, t_default_104);  primals_137 = None
        view_default_295 = torch.ops.aten.view.default(addmm_default_104, [64, 128, 1024]);  addmm_default_104 = None
        view_default_296 = torch.ops.aten.view.default(view_default_295, [64, 128, 16, 64]);  view_default_295 = None
        permute_default_69 = torch.ops.aten.permute.default(view_default_296, [0, 2, 1, 3]);  view_default_296 = None
        view_default_297 = torch.ops.aten.view.default(view_default_290, [64, 128, 16, 64]);  view_default_290 = None
        permute_default_70 = torch.ops.aten.permute.default(view_default_297, [0, 2, 1, 3]);  view_default_297 = None
        transpose_int_17 = torch.ops.aten.transpose.int(permute_default_68, -1, -2);  permute_default_68 = None
        expand_default_68 = torch.ops.aten.expand.default(permute_default_70, [64, 16, 128, 64]);  permute_default_70 = None
        clone_default_68 = torch.ops.aten.clone.default(expand_default_68, memory_format = torch.contiguous_format);  expand_default_68 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_68, [1024, 128, 64]);  clone_default_68 = None
        expand_default_69 = torch.ops.aten.expand.default(transpose_int_17, [64, 16, 64, 128]);  transpose_int_17 = None
        clone_default_69 = torch.ops.aten.clone.default(expand_default_69, memory_format = torch.contiguous_format);  expand_default_69 = None
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(clone_default_69, [1024, 64, 128]);  clone_default_69 = None
        bmm_default_34 = torch.ops.aten.bmm.default(_unsafe_view_default_85, _unsafe_view_default_86)
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(bmm_default_34, [64, 16, 128, 128]);  bmm_default_34 = None
        div_tensor_17 = torch.ops.aten.div.Tensor(_unsafe_view_default_87, 8.0);  _unsafe_view_default_87 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(div_tensor_17, primals_386);  div_tensor_17 = None
        _softmax_default_17 = torch.ops.aten._softmax.default(add_tensor_51, -1, False);  add_tensor_51 = None
        expand_default_70 = torch.ops.aten.expand.default(_softmax_default_17, [64, 16, 128, 128])
        view_default_298 = torch.ops.aten.view.default(expand_default_70, [1024, 128, 128]);  expand_default_70 = None
        expand_default_71 = torch.ops.aten.expand.default(permute_default_69, [64, 16, 128, 64]);  permute_default_69 = None
        clone_default_70 = torch.ops.aten.clone.default(expand_default_71, memory_format = torch.contiguous_format);  expand_default_71 = None
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(clone_default_70, [1024, 128, 64]);  clone_default_70 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_298, _unsafe_view_default_88)
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(bmm_default_35, [64, 16, 128, 64]);  bmm_default_35 = None
        permute_default_71 = torch.ops.aten.permute.default(_unsafe_view_default_89, [0, 2, 1, 3]);  _unsafe_view_default_89 = None
        clone_default_71 = torch.ops.aten.clone.default(permute_default_71, memory_format = torch.contiguous_format);  permute_default_71 = None
        view_default_299 = torch.ops.aten.view.default(clone_default_71, [64, 128, 1024]);  clone_default_71 = None
        view_default_300 = torch.ops.aten.view.default(view_default_299, [8192, 1024]);  view_default_299 = None
        t_default_105 = torch.ops.aten.t.default(primals_132);  primals_132 = None
        addmm_default_105 = torch.ops.aten.addmm.default(primals_131, view_default_300, t_default_105);  primals_131 = None
        view_default_301 = torch.ops.aten.view.default(addmm_default_105, [64, 128, 1024]);  addmm_default_105 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(view_default_301, getitem_99);  view_default_301 = getitem_99 = None
        native_layer_norm_default_34 = torch.ops.aten.native_layer_norm.default(add_tensor_52, [1024], primals_130, primals_129, 1e-12)
        getitem_102 = native_layer_norm_default_34[0]
        getitem_103 = native_layer_norm_default_34[1]
        getitem_104 = native_layer_norm_default_34[2];  native_layer_norm_default_34 = None
        view_default_302 = torch.ops.aten.view.default(getitem_102, [8192, 1024])
        t_default_106 = torch.ops.aten.t.default(primals_140);  primals_140 = None
        addmm_default_106 = torch.ops.aten.addmm.default(primals_139, view_default_302, t_default_106);  primals_139 = None
        view_default_303 = torch.ops.aten.view.default(addmm_default_106, [64, 128, 4096]);  addmm_default_106 = None
        gelu_default_17 = torch.ops.aten.gelu.default(view_default_303)
        view_default_304 = torch.ops.aten.view.default(gelu_default_17, [8192, 4096]);  gelu_default_17 = None
        t_default_107 = torch.ops.aten.t.default(primals_144);  primals_144 = None
        addmm_default_107 = torch.ops.aten.addmm.default(primals_143, view_default_304, t_default_107);  primals_143 = None
        view_default_305 = torch.ops.aten.view.default(addmm_default_107, [64, 128, 1024]);  addmm_default_107 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(view_default_305, getitem_102);  view_default_305 = getitem_102 = None
        native_layer_norm_default_35 = torch.ops.aten.native_layer_norm.default(add_tensor_53, [1024], primals_142, primals_141, 1e-12)
        getitem_105 = native_layer_norm_default_35[0]
        getitem_106 = native_layer_norm_default_35[1]
        getitem_107 = native_layer_norm_default_35[2];  native_layer_norm_default_35 = None
        view_default_306 = torch.ops.aten.view.default(getitem_105, [8192, 1024])
        t_default_108 = torch.ops.aten.t.default(primals_152);  primals_152 = None
        addmm_default_108 = torch.ops.aten.addmm.default(primals_151, view_default_306, t_default_108);  primals_151 = None
        view_default_307 = torch.ops.aten.view.default(addmm_default_108, [64, 128, 1024]);  addmm_default_108 = None
        view_default_308 = torch.ops.aten.view.default(getitem_105, [8192, 1024])
        t_default_109 = torch.ops.aten.t.default(primals_150);  primals_150 = None
        addmm_default_109 = torch.ops.aten.addmm.default(primals_149, view_default_308, t_default_109);  primals_149 = None
        view_default_309 = torch.ops.aten.view.default(addmm_default_109, [64, 128, 1024]);  addmm_default_109 = None
        view_default_310 = torch.ops.aten.view.default(view_default_309, [64, 128, 16, 64]);  view_default_309 = None
        permute_default_72 = torch.ops.aten.permute.default(view_default_310, [0, 2, 1, 3]);  view_default_310 = None
        view_default_311 = torch.ops.aten.view.default(getitem_105, [8192, 1024])
        t_default_110 = torch.ops.aten.t.default(primals_154);  primals_154 = None
        addmm_default_110 = torch.ops.aten.addmm.default(primals_153, view_default_311, t_default_110);  primals_153 = None
        view_default_312 = torch.ops.aten.view.default(addmm_default_110, [64, 128, 1024]);  addmm_default_110 = None
        view_default_313 = torch.ops.aten.view.default(view_default_312, [64, 128, 16, 64]);  view_default_312 = None
        permute_default_73 = torch.ops.aten.permute.default(view_default_313, [0, 2, 1, 3]);  view_default_313 = None
        view_default_314 = torch.ops.aten.view.default(view_default_307, [64, 128, 16, 64]);  view_default_307 = None
        permute_default_74 = torch.ops.aten.permute.default(view_default_314, [0, 2, 1, 3]);  view_default_314 = None
        transpose_int_18 = torch.ops.aten.transpose.int(permute_default_72, -1, -2);  permute_default_72 = None
        expand_default_72 = torch.ops.aten.expand.default(permute_default_74, [64, 16, 128, 64]);  permute_default_74 = None
        clone_default_72 = torch.ops.aten.clone.default(expand_default_72, memory_format = torch.contiguous_format);  expand_default_72 = None
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(clone_default_72, [1024, 128, 64]);  clone_default_72 = None
        expand_default_73 = torch.ops.aten.expand.default(transpose_int_18, [64, 16, 64, 128]);  transpose_int_18 = None
        clone_default_73 = torch.ops.aten.clone.default(expand_default_73, memory_format = torch.contiguous_format);  expand_default_73 = None
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(clone_default_73, [1024, 64, 128]);  clone_default_73 = None
        bmm_default_36 = torch.ops.aten.bmm.default(_unsafe_view_default_90, _unsafe_view_default_91)
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(bmm_default_36, [64, 16, 128, 128]);  bmm_default_36 = None
        div_tensor_18 = torch.ops.aten.div.Tensor(_unsafe_view_default_92, 8.0);  _unsafe_view_default_92 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(div_tensor_18, primals_386);  div_tensor_18 = None
        _softmax_default_18 = torch.ops.aten._softmax.default(add_tensor_54, -1, False);  add_tensor_54 = None
        expand_default_74 = torch.ops.aten.expand.default(_softmax_default_18, [64, 16, 128, 128])
        view_default_315 = torch.ops.aten.view.default(expand_default_74, [1024, 128, 128]);  expand_default_74 = None
        expand_default_75 = torch.ops.aten.expand.default(permute_default_73, [64, 16, 128, 64]);  permute_default_73 = None
        clone_default_74 = torch.ops.aten.clone.default(expand_default_75, memory_format = torch.contiguous_format);  expand_default_75 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_74, [1024, 128, 64]);  clone_default_74 = None
        bmm_default_37 = torch.ops.aten.bmm.default(view_default_315, _unsafe_view_default_93)
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(bmm_default_37, [64, 16, 128, 64]);  bmm_default_37 = None
        permute_default_75 = torch.ops.aten.permute.default(_unsafe_view_default_94, [0, 2, 1, 3]);  _unsafe_view_default_94 = None
        clone_default_75 = torch.ops.aten.clone.default(permute_default_75, memory_format = torch.contiguous_format);  permute_default_75 = None
        view_default_316 = torch.ops.aten.view.default(clone_default_75, [64, 128, 1024]);  clone_default_75 = None
        view_default_317 = torch.ops.aten.view.default(view_default_316, [8192, 1024]);  view_default_316 = None
        t_default_111 = torch.ops.aten.t.default(primals_148);  primals_148 = None
        addmm_default_111 = torch.ops.aten.addmm.default(primals_147, view_default_317, t_default_111);  primals_147 = None
        view_default_318 = torch.ops.aten.view.default(addmm_default_111, [64, 128, 1024]);  addmm_default_111 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(view_default_318, getitem_105);  view_default_318 = getitem_105 = None
        native_layer_norm_default_36 = torch.ops.aten.native_layer_norm.default(add_tensor_55, [1024], primals_146, primals_145, 1e-12)
        getitem_108 = native_layer_norm_default_36[0]
        getitem_109 = native_layer_norm_default_36[1]
        getitem_110 = native_layer_norm_default_36[2];  native_layer_norm_default_36 = None
        view_default_319 = torch.ops.aten.view.default(getitem_108, [8192, 1024])
        t_default_112 = torch.ops.aten.t.default(primals_156);  primals_156 = None
        addmm_default_112 = torch.ops.aten.addmm.default(primals_155, view_default_319, t_default_112);  primals_155 = None
        view_default_320 = torch.ops.aten.view.default(addmm_default_112, [64, 128, 4096]);  addmm_default_112 = None
        gelu_default_18 = torch.ops.aten.gelu.default(view_default_320)
        view_default_321 = torch.ops.aten.view.default(gelu_default_18, [8192, 4096]);  gelu_default_18 = None
        t_default_113 = torch.ops.aten.t.default(primals_160);  primals_160 = None
        addmm_default_113 = torch.ops.aten.addmm.default(primals_159, view_default_321, t_default_113);  primals_159 = None
        view_default_322 = torch.ops.aten.view.default(addmm_default_113, [64, 128, 1024]);  addmm_default_113 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(view_default_322, getitem_108);  view_default_322 = getitem_108 = None
        native_layer_norm_default_37 = torch.ops.aten.native_layer_norm.default(add_tensor_56, [1024], primals_158, primals_157, 1e-12)
        getitem_111 = native_layer_norm_default_37[0]
        getitem_112 = native_layer_norm_default_37[1]
        getitem_113 = native_layer_norm_default_37[2];  native_layer_norm_default_37 = None
        view_default_323 = torch.ops.aten.view.default(getitem_111, [8192, 1024])
        t_default_114 = torch.ops.aten.t.default(primals_168);  primals_168 = None
        addmm_default_114 = torch.ops.aten.addmm.default(primals_167, view_default_323, t_default_114);  primals_167 = None
        view_default_324 = torch.ops.aten.view.default(addmm_default_114, [64, 128, 1024]);  addmm_default_114 = None
        view_default_325 = torch.ops.aten.view.default(getitem_111, [8192, 1024])
        t_default_115 = torch.ops.aten.t.default(primals_166);  primals_166 = None
        addmm_default_115 = torch.ops.aten.addmm.default(primals_165, view_default_325, t_default_115);  primals_165 = None
        view_default_326 = torch.ops.aten.view.default(addmm_default_115, [64, 128, 1024]);  addmm_default_115 = None
        view_default_327 = torch.ops.aten.view.default(view_default_326, [64, 128, 16, 64]);  view_default_326 = None
        permute_default_76 = torch.ops.aten.permute.default(view_default_327, [0, 2, 1, 3]);  view_default_327 = None
        view_default_328 = torch.ops.aten.view.default(getitem_111, [8192, 1024])
        t_default_116 = torch.ops.aten.t.default(primals_170);  primals_170 = None
        addmm_default_116 = torch.ops.aten.addmm.default(primals_169, view_default_328, t_default_116);  primals_169 = None
        view_default_329 = torch.ops.aten.view.default(addmm_default_116, [64, 128, 1024]);  addmm_default_116 = None
        view_default_330 = torch.ops.aten.view.default(view_default_329, [64, 128, 16, 64]);  view_default_329 = None
        permute_default_77 = torch.ops.aten.permute.default(view_default_330, [0, 2, 1, 3]);  view_default_330 = None
        view_default_331 = torch.ops.aten.view.default(view_default_324, [64, 128, 16, 64]);  view_default_324 = None
        permute_default_78 = torch.ops.aten.permute.default(view_default_331, [0, 2, 1, 3]);  view_default_331 = None
        transpose_int_19 = torch.ops.aten.transpose.int(permute_default_76, -1, -2);  permute_default_76 = None
        expand_default_76 = torch.ops.aten.expand.default(permute_default_78, [64, 16, 128, 64]);  permute_default_78 = None
        clone_default_76 = torch.ops.aten.clone.default(expand_default_76, memory_format = torch.contiguous_format);  expand_default_76 = None
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(clone_default_76, [1024, 128, 64]);  clone_default_76 = None
        expand_default_77 = torch.ops.aten.expand.default(transpose_int_19, [64, 16, 64, 128]);  transpose_int_19 = None
        clone_default_77 = torch.ops.aten.clone.default(expand_default_77, memory_format = torch.contiguous_format);  expand_default_77 = None
        _unsafe_view_default_96 = torch.ops.aten._unsafe_view.default(clone_default_77, [1024, 64, 128]);  clone_default_77 = None
        bmm_default_38 = torch.ops.aten.bmm.default(_unsafe_view_default_95, _unsafe_view_default_96)
        _unsafe_view_default_97 = torch.ops.aten._unsafe_view.default(bmm_default_38, [64, 16, 128, 128]);  bmm_default_38 = None
        div_tensor_19 = torch.ops.aten.div.Tensor(_unsafe_view_default_97, 8.0);  _unsafe_view_default_97 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(div_tensor_19, primals_386);  div_tensor_19 = None
        _softmax_default_19 = torch.ops.aten._softmax.default(add_tensor_57, -1, False);  add_tensor_57 = None
        expand_default_78 = torch.ops.aten.expand.default(_softmax_default_19, [64, 16, 128, 128])
        view_default_332 = torch.ops.aten.view.default(expand_default_78, [1024, 128, 128]);  expand_default_78 = None
        expand_default_79 = torch.ops.aten.expand.default(permute_default_77, [64, 16, 128, 64]);  permute_default_77 = None
        clone_default_78 = torch.ops.aten.clone.default(expand_default_79, memory_format = torch.contiguous_format);  expand_default_79 = None
        _unsafe_view_default_98 = torch.ops.aten._unsafe_view.default(clone_default_78, [1024, 128, 64]);  clone_default_78 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_332, _unsafe_view_default_98)
        _unsafe_view_default_99 = torch.ops.aten._unsafe_view.default(bmm_default_39, [64, 16, 128, 64]);  bmm_default_39 = None
        permute_default_79 = torch.ops.aten.permute.default(_unsafe_view_default_99, [0, 2, 1, 3]);  _unsafe_view_default_99 = None
        clone_default_79 = torch.ops.aten.clone.default(permute_default_79, memory_format = torch.contiguous_format);  permute_default_79 = None
        view_default_333 = torch.ops.aten.view.default(clone_default_79, [64, 128, 1024]);  clone_default_79 = None
        view_default_334 = torch.ops.aten.view.default(view_default_333, [8192, 1024]);  view_default_333 = None
        t_default_117 = torch.ops.aten.t.default(primals_164);  primals_164 = None
        addmm_default_117 = torch.ops.aten.addmm.default(primals_163, view_default_334, t_default_117);  primals_163 = None
        view_default_335 = torch.ops.aten.view.default(addmm_default_117, [64, 128, 1024]);  addmm_default_117 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(view_default_335, getitem_111);  view_default_335 = getitem_111 = None
        native_layer_norm_default_38 = torch.ops.aten.native_layer_norm.default(add_tensor_58, [1024], primals_162, primals_161, 1e-12)
        getitem_114 = native_layer_norm_default_38[0]
        getitem_115 = native_layer_norm_default_38[1]
        getitem_116 = native_layer_norm_default_38[2];  native_layer_norm_default_38 = None
        view_default_336 = torch.ops.aten.view.default(getitem_114, [8192, 1024])
        t_default_118 = torch.ops.aten.t.default(primals_172);  primals_172 = None
        addmm_default_118 = torch.ops.aten.addmm.default(primals_171, view_default_336, t_default_118);  primals_171 = None
        view_default_337 = torch.ops.aten.view.default(addmm_default_118, [64, 128, 4096]);  addmm_default_118 = None
        gelu_default_19 = torch.ops.aten.gelu.default(view_default_337)
        view_default_338 = torch.ops.aten.view.default(gelu_default_19, [8192, 4096]);  gelu_default_19 = None
        t_default_119 = torch.ops.aten.t.default(primals_176);  primals_176 = None
        addmm_default_119 = torch.ops.aten.addmm.default(primals_175, view_default_338, t_default_119);  primals_175 = None
        view_default_339 = torch.ops.aten.view.default(addmm_default_119, [64, 128, 1024]);  addmm_default_119 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(view_default_339, getitem_114);  view_default_339 = getitem_114 = None
        native_layer_norm_default_39 = torch.ops.aten.native_layer_norm.default(add_tensor_59, [1024], primals_174, primals_173, 1e-12)
        getitem_117 = native_layer_norm_default_39[0]
        getitem_118 = native_layer_norm_default_39[1]
        getitem_119 = native_layer_norm_default_39[2];  native_layer_norm_default_39 = None
        view_default_340 = torch.ops.aten.view.default(getitem_117, [8192, 1024])
        t_default_120 = torch.ops.aten.t.default(primals_200);  primals_200 = None
        addmm_default_120 = torch.ops.aten.addmm.default(primals_199, view_default_340, t_default_120);  primals_199 = None
        view_default_341 = torch.ops.aten.view.default(addmm_default_120, [64, 128, 1024]);  addmm_default_120 = None
        view_default_342 = torch.ops.aten.view.default(getitem_117, [8192, 1024])
        t_default_121 = torch.ops.aten.t.default(primals_198);  primals_198 = None
        addmm_default_121 = torch.ops.aten.addmm.default(primals_197, view_default_342, t_default_121);  primals_197 = None
        view_default_343 = torch.ops.aten.view.default(addmm_default_121, [64, 128, 1024]);  addmm_default_121 = None
        view_default_344 = torch.ops.aten.view.default(view_default_343, [64, 128, 16, 64]);  view_default_343 = None
        permute_default_80 = torch.ops.aten.permute.default(view_default_344, [0, 2, 1, 3]);  view_default_344 = None
        view_default_345 = torch.ops.aten.view.default(getitem_117, [8192, 1024])
        t_default_122 = torch.ops.aten.t.default(primals_202);  primals_202 = None
        addmm_default_122 = torch.ops.aten.addmm.default(primals_201, view_default_345, t_default_122);  primals_201 = None
        view_default_346 = torch.ops.aten.view.default(addmm_default_122, [64, 128, 1024]);  addmm_default_122 = None
        view_default_347 = torch.ops.aten.view.default(view_default_346, [64, 128, 16, 64]);  view_default_346 = None
        permute_default_81 = torch.ops.aten.permute.default(view_default_347, [0, 2, 1, 3]);  view_default_347 = None
        view_default_348 = torch.ops.aten.view.default(view_default_341, [64, 128, 16, 64]);  view_default_341 = None
        permute_default_82 = torch.ops.aten.permute.default(view_default_348, [0, 2, 1, 3]);  view_default_348 = None
        transpose_int_20 = torch.ops.aten.transpose.int(permute_default_80, -1, -2);  permute_default_80 = None
        expand_default_80 = torch.ops.aten.expand.default(permute_default_82, [64, 16, 128, 64]);  permute_default_82 = None
        clone_default_80 = torch.ops.aten.clone.default(expand_default_80, memory_format = torch.contiguous_format);  expand_default_80 = None
        _unsafe_view_default_100 = torch.ops.aten._unsafe_view.default(clone_default_80, [1024, 128, 64]);  clone_default_80 = None
        expand_default_81 = torch.ops.aten.expand.default(transpose_int_20, [64, 16, 64, 128]);  transpose_int_20 = None
        clone_default_81 = torch.ops.aten.clone.default(expand_default_81, memory_format = torch.contiguous_format);  expand_default_81 = None
        _unsafe_view_default_101 = torch.ops.aten._unsafe_view.default(clone_default_81, [1024, 64, 128]);  clone_default_81 = None
        bmm_default_40 = torch.ops.aten.bmm.default(_unsafe_view_default_100, _unsafe_view_default_101)
        _unsafe_view_default_102 = torch.ops.aten._unsafe_view.default(bmm_default_40, [64, 16, 128, 128]);  bmm_default_40 = None
        div_tensor_20 = torch.ops.aten.div.Tensor(_unsafe_view_default_102, 8.0);  _unsafe_view_default_102 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(div_tensor_20, primals_386);  div_tensor_20 = None
        _softmax_default_20 = torch.ops.aten._softmax.default(add_tensor_60, -1, False);  add_tensor_60 = None
        expand_default_82 = torch.ops.aten.expand.default(_softmax_default_20, [64, 16, 128, 128])
        view_default_349 = torch.ops.aten.view.default(expand_default_82, [1024, 128, 128]);  expand_default_82 = None
        expand_default_83 = torch.ops.aten.expand.default(permute_default_81, [64, 16, 128, 64]);  permute_default_81 = None
        clone_default_82 = torch.ops.aten.clone.default(expand_default_83, memory_format = torch.contiguous_format);  expand_default_83 = None
        _unsafe_view_default_103 = torch.ops.aten._unsafe_view.default(clone_default_82, [1024, 128, 64]);  clone_default_82 = None
        bmm_default_41 = torch.ops.aten.bmm.default(view_default_349, _unsafe_view_default_103)
        _unsafe_view_default_104 = torch.ops.aten._unsafe_view.default(bmm_default_41, [64, 16, 128, 64]);  bmm_default_41 = None
        permute_default_83 = torch.ops.aten.permute.default(_unsafe_view_default_104, [0, 2, 1, 3]);  _unsafe_view_default_104 = None
        clone_default_83 = torch.ops.aten.clone.default(permute_default_83, memory_format = torch.contiguous_format);  permute_default_83 = None
        view_default_350 = torch.ops.aten.view.default(clone_default_83, [64, 128, 1024]);  clone_default_83 = None
        view_default_351 = torch.ops.aten.view.default(view_default_350, [8192, 1024]);  view_default_350 = None
        t_default_123 = torch.ops.aten.t.default(primals_196);  primals_196 = None
        addmm_default_123 = torch.ops.aten.addmm.default(primals_195, view_default_351, t_default_123);  primals_195 = None
        view_default_352 = torch.ops.aten.view.default(addmm_default_123, [64, 128, 1024]);  addmm_default_123 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(view_default_352, getitem_117);  view_default_352 = getitem_117 = None
        native_layer_norm_default_40 = torch.ops.aten.native_layer_norm.default(add_tensor_61, [1024], primals_194, primals_193, 1e-12)
        getitem_120 = native_layer_norm_default_40[0]
        getitem_121 = native_layer_norm_default_40[1]
        getitem_122 = native_layer_norm_default_40[2];  native_layer_norm_default_40 = None
        view_default_353 = torch.ops.aten.view.default(getitem_120, [8192, 1024])
        t_default_124 = torch.ops.aten.t.default(primals_204);  primals_204 = None
        addmm_default_124 = torch.ops.aten.addmm.default(primals_203, view_default_353, t_default_124);  primals_203 = None
        view_default_354 = torch.ops.aten.view.default(addmm_default_124, [64, 128, 4096]);  addmm_default_124 = None
        gelu_default_20 = torch.ops.aten.gelu.default(view_default_354)
        view_default_355 = torch.ops.aten.view.default(gelu_default_20, [8192, 4096]);  gelu_default_20 = None
        t_default_125 = torch.ops.aten.t.default(primals_208);  primals_208 = None
        addmm_default_125 = torch.ops.aten.addmm.default(primals_207, view_default_355, t_default_125);  primals_207 = None
        view_default_356 = torch.ops.aten.view.default(addmm_default_125, [64, 128, 1024]);  addmm_default_125 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(view_default_356, getitem_120);  view_default_356 = getitem_120 = None
        native_layer_norm_default_41 = torch.ops.aten.native_layer_norm.default(add_tensor_62, [1024], primals_206, primals_205, 1e-12)
        getitem_123 = native_layer_norm_default_41[0]
        getitem_124 = native_layer_norm_default_41[1]
        getitem_125 = native_layer_norm_default_41[2];  native_layer_norm_default_41 = None
        view_default_357 = torch.ops.aten.view.default(getitem_123, [8192, 1024])
        t_default_126 = torch.ops.aten.t.default(primals_216);  primals_216 = None
        addmm_default_126 = torch.ops.aten.addmm.default(primals_215, view_default_357, t_default_126);  primals_215 = None
        view_default_358 = torch.ops.aten.view.default(addmm_default_126, [64, 128, 1024]);  addmm_default_126 = None
        view_default_359 = torch.ops.aten.view.default(getitem_123, [8192, 1024])
        t_default_127 = torch.ops.aten.t.default(primals_214);  primals_214 = None
        addmm_default_127 = torch.ops.aten.addmm.default(primals_213, view_default_359, t_default_127);  primals_213 = None
        view_default_360 = torch.ops.aten.view.default(addmm_default_127, [64, 128, 1024]);  addmm_default_127 = None
        view_default_361 = torch.ops.aten.view.default(view_default_360, [64, 128, 16, 64]);  view_default_360 = None
        permute_default_84 = torch.ops.aten.permute.default(view_default_361, [0, 2, 1, 3]);  view_default_361 = None
        view_default_362 = torch.ops.aten.view.default(getitem_123, [8192, 1024])
        t_default_128 = torch.ops.aten.t.default(primals_218);  primals_218 = None
        addmm_default_128 = torch.ops.aten.addmm.default(primals_217, view_default_362, t_default_128);  primals_217 = None
        view_default_363 = torch.ops.aten.view.default(addmm_default_128, [64, 128, 1024]);  addmm_default_128 = None
        view_default_364 = torch.ops.aten.view.default(view_default_363, [64, 128, 16, 64]);  view_default_363 = None
        permute_default_85 = torch.ops.aten.permute.default(view_default_364, [0, 2, 1, 3]);  view_default_364 = None
        view_default_365 = torch.ops.aten.view.default(view_default_358, [64, 128, 16, 64]);  view_default_358 = None
        permute_default_86 = torch.ops.aten.permute.default(view_default_365, [0, 2, 1, 3]);  view_default_365 = None
        transpose_int_21 = torch.ops.aten.transpose.int(permute_default_84, -1, -2);  permute_default_84 = None
        expand_default_84 = torch.ops.aten.expand.default(permute_default_86, [64, 16, 128, 64]);  permute_default_86 = None
        clone_default_84 = torch.ops.aten.clone.default(expand_default_84, memory_format = torch.contiguous_format);  expand_default_84 = None
        _unsafe_view_default_105 = torch.ops.aten._unsafe_view.default(clone_default_84, [1024, 128, 64]);  clone_default_84 = None
        expand_default_85 = torch.ops.aten.expand.default(transpose_int_21, [64, 16, 64, 128]);  transpose_int_21 = None
        clone_default_85 = torch.ops.aten.clone.default(expand_default_85, memory_format = torch.contiguous_format);  expand_default_85 = None
        _unsafe_view_default_106 = torch.ops.aten._unsafe_view.default(clone_default_85, [1024, 64, 128]);  clone_default_85 = None
        bmm_default_42 = torch.ops.aten.bmm.default(_unsafe_view_default_105, _unsafe_view_default_106)
        _unsafe_view_default_107 = torch.ops.aten._unsafe_view.default(bmm_default_42, [64, 16, 128, 128]);  bmm_default_42 = None
        div_tensor_21 = torch.ops.aten.div.Tensor(_unsafe_view_default_107, 8.0);  _unsafe_view_default_107 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(div_tensor_21, primals_386);  div_tensor_21 = None
        _softmax_default_21 = torch.ops.aten._softmax.default(add_tensor_63, -1, False);  add_tensor_63 = None
        expand_default_86 = torch.ops.aten.expand.default(_softmax_default_21, [64, 16, 128, 128])
        view_default_366 = torch.ops.aten.view.default(expand_default_86, [1024, 128, 128]);  expand_default_86 = None
        expand_default_87 = torch.ops.aten.expand.default(permute_default_85, [64, 16, 128, 64]);  permute_default_85 = None
        clone_default_86 = torch.ops.aten.clone.default(expand_default_87, memory_format = torch.contiguous_format);  expand_default_87 = None
        _unsafe_view_default_108 = torch.ops.aten._unsafe_view.default(clone_default_86, [1024, 128, 64]);  clone_default_86 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_366, _unsafe_view_default_108)
        _unsafe_view_default_109 = torch.ops.aten._unsafe_view.default(bmm_default_43, [64, 16, 128, 64]);  bmm_default_43 = None
        permute_default_87 = torch.ops.aten.permute.default(_unsafe_view_default_109, [0, 2, 1, 3]);  _unsafe_view_default_109 = None
        clone_default_87 = torch.ops.aten.clone.default(permute_default_87, memory_format = torch.contiguous_format);  permute_default_87 = None
        view_default_367 = torch.ops.aten.view.default(clone_default_87, [64, 128, 1024]);  clone_default_87 = None
        view_default_368 = torch.ops.aten.view.default(view_default_367, [8192, 1024]);  view_default_367 = None
        t_default_129 = torch.ops.aten.t.default(primals_212);  primals_212 = None
        addmm_default_129 = torch.ops.aten.addmm.default(primals_211, view_default_368, t_default_129);  primals_211 = None
        view_default_369 = torch.ops.aten.view.default(addmm_default_129, [64, 128, 1024]);  addmm_default_129 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(view_default_369, getitem_123);  view_default_369 = getitem_123 = None
        native_layer_norm_default_42 = torch.ops.aten.native_layer_norm.default(add_tensor_64, [1024], primals_210, primals_209, 1e-12)
        getitem_126 = native_layer_norm_default_42[0]
        getitem_127 = native_layer_norm_default_42[1]
        getitem_128 = native_layer_norm_default_42[2];  native_layer_norm_default_42 = None
        view_default_370 = torch.ops.aten.view.default(getitem_126, [8192, 1024])
        t_default_130 = torch.ops.aten.t.default(primals_220);  primals_220 = None
        addmm_default_130 = torch.ops.aten.addmm.default(primals_219, view_default_370, t_default_130);  primals_219 = None
        view_default_371 = torch.ops.aten.view.default(addmm_default_130, [64, 128, 4096]);  addmm_default_130 = None
        gelu_default_21 = torch.ops.aten.gelu.default(view_default_371)
        view_default_372 = torch.ops.aten.view.default(gelu_default_21, [8192, 4096]);  gelu_default_21 = None
        t_default_131 = torch.ops.aten.t.default(primals_224);  primals_224 = None
        addmm_default_131 = torch.ops.aten.addmm.default(primals_223, view_default_372, t_default_131);  primals_223 = None
        view_default_373 = torch.ops.aten.view.default(addmm_default_131, [64, 128, 1024]);  addmm_default_131 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(view_default_373, getitem_126);  view_default_373 = getitem_126 = None
        native_layer_norm_default_43 = torch.ops.aten.native_layer_norm.default(add_tensor_65, [1024], primals_222, primals_221, 1e-12)
        getitem_129 = native_layer_norm_default_43[0]
        getitem_130 = native_layer_norm_default_43[1]
        getitem_131 = native_layer_norm_default_43[2];  native_layer_norm_default_43 = None
        view_default_374 = torch.ops.aten.view.default(getitem_129, [8192, 1024])
        t_default_132 = torch.ops.aten.t.default(primals_232);  primals_232 = None
        addmm_default_132 = torch.ops.aten.addmm.default(primals_231, view_default_374, t_default_132);  primals_231 = None
        view_default_375 = torch.ops.aten.view.default(addmm_default_132, [64, 128, 1024]);  addmm_default_132 = None
        view_default_376 = torch.ops.aten.view.default(getitem_129, [8192, 1024])
        t_default_133 = torch.ops.aten.t.default(primals_230);  primals_230 = None
        addmm_default_133 = torch.ops.aten.addmm.default(primals_229, view_default_376, t_default_133);  primals_229 = None
        view_default_377 = torch.ops.aten.view.default(addmm_default_133, [64, 128, 1024]);  addmm_default_133 = None
        view_default_378 = torch.ops.aten.view.default(view_default_377, [64, 128, 16, 64]);  view_default_377 = None
        permute_default_88 = torch.ops.aten.permute.default(view_default_378, [0, 2, 1, 3]);  view_default_378 = None
        view_default_379 = torch.ops.aten.view.default(getitem_129, [8192, 1024])
        t_default_134 = torch.ops.aten.t.default(primals_234);  primals_234 = None
        addmm_default_134 = torch.ops.aten.addmm.default(primals_233, view_default_379, t_default_134);  primals_233 = None
        view_default_380 = torch.ops.aten.view.default(addmm_default_134, [64, 128, 1024]);  addmm_default_134 = None
        view_default_381 = torch.ops.aten.view.default(view_default_380, [64, 128, 16, 64]);  view_default_380 = None
        permute_default_89 = torch.ops.aten.permute.default(view_default_381, [0, 2, 1, 3]);  view_default_381 = None
        view_default_382 = torch.ops.aten.view.default(view_default_375, [64, 128, 16, 64]);  view_default_375 = None
        permute_default_90 = torch.ops.aten.permute.default(view_default_382, [0, 2, 1, 3]);  view_default_382 = None
        transpose_int_22 = torch.ops.aten.transpose.int(permute_default_88, -1, -2);  permute_default_88 = None
        expand_default_88 = torch.ops.aten.expand.default(permute_default_90, [64, 16, 128, 64]);  permute_default_90 = None
        clone_default_88 = torch.ops.aten.clone.default(expand_default_88, memory_format = torch.contiguous_format);  expand_default_88 = None
        _unsafe_view_default_110 = torch.ops.aten._unsafe_view.default(clone_default_88, [1024, 128, 64]);  clone_default_88 = None
        expand_default_89 = torch.ops.aten.expand.default(transpose_int_22, [64, 16, 64, 128]);  transpose_int_22 = None
        clone_default_89 = torch.ops.aten.clone.default(expand_default_89, memory_format = torch.contiguous_format);  expand_default_89 = None
        _unsafe_view_default_111 = torch.ops.aten._unsafe_view.default(clone_default_89, [1024, 64, 128]);  clone_default_89 = None
        bmm_default_44 = torch.ops.aten.bmm.default(_unsafe_view_default_110, _unsafe_view_default_111)
        _unsafe_view_default_112 = torch.ops.aten._unsafe_view.default(bmm_default_44, [64, 16, 128, 128]);  bmm_default_44 = None
        div_tensor_22 = torch.ops.aten.div.Tensor(_unsafe_view_default_112, 8.0);  _unsafe_view_default_112 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(div_tensor_22, primals_386);  div_tensor_22 = None
        _softmax_default_22 = torch.ops.aten._softmax.default(add_tensor_66, -1, False);  add_tensor_66 = None
        expand_default_90 = torch.ops.aten.expand.default(_softmax_default_22, [64, 16, 128, 128])
        view_default_383 = torch.ops.aten.view.default(expand_default_90, [1024, 128, 128]);  expand_default_90 = None
        expand_default_91 = torch.ops.aten.expand.default(permute_default_89, [64, 16, 128, 64]);  permute_default_89 = None
        clone_default_90 = torch.ops.aten.clone.default(expand_default_91, memory_format = torch.contiguous_format);  expand_default_91 = None
        _unsafe_view_default_113 = torch.ops.aten._unsafe_view.default(clone_default_90, [1024, 128, 64]);  clone_default_90 = None
        bmm_default_45 = torch.ops.aten.bmm.default(view_default_383, _unsafe_view_default_113)
        _unsafe_view_default_114 = torch.ops.aten._unsafe_view.default(bmm_default_45, [64, 16, 128, 64]);  bmm_default_45 = None
        permute_default_91 = torch.ops.aten.permute.default(_unsafe_view_default_114, [0, 2, 1, 3]);  _unsafe_view_default_114 = None
        clone_default_91 = torch.ops.aten.clone.default(permute_default_91, memory_format = torch.contiguous_format);  permute_default_91 = None
        view_default_384 = torch.ops.aten.view.default(clone_default_91, [64, 128, 1024]);  clone_default_91 = None
        view_default_385 = torch.ops.aten.view.default(view_default_384, [8192, 1024]);  view_default_384 = None
        t_default_135 = torch.ops.aten.t.default(primals_228);  primals_228 = None
        addmm_default_135 = torch.ops.aten.addmm.default(primals_227, view_default_385, t_default_135);  primals_227 = None
        view_default_386 = torch.ops.aten.view.default(addmm_default_135, [64, 128, 1024]);  addmm_default_135 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(view_default_386, getitem_129);  view_default_386 = getitem_129 = None
        native_layer_norm_default_44 = torch.ops.aten.native_layer_norm.default(add_tensor_67, [1024], primals_226, primals_225, 1e-12)
        getitem_132 = native_layer_norm_default_44[0]
        getitem_133 = native_layer_norm_default_44[1]
        getitem_134 = native_layer_norm_default_44[2];  native_layer_norm_default_44 = None
        view_default_387 = torch.ops.aten.view.default(getitem_132, [8192, 1024])
        t_default_136 = torch.ops.aten.t.default(primals_236);  primals_236 = None
        addmm_default_136 = torch.ops.aten.addmm.default(primals_235, view_default_387, t_default_136);  primals_235 = None
        view_default_388 = torch.ops.aten.view.default(addmm_default_136, [64, 128, 4096]);  addmm_default_136 = None
        gelu_default_22 = torch.ops.aten.gelu.default(view_default_388)
        view_default_389 = torch.ops.aten.view.default(gelu_default_22, [8192, 4096]);  gelu_default_22 = None
        t_default_137 = torch.ops.aten.t.default(primals_240);  primals_240 = None
        addmm_default_137 = torch.ops.aten.addmm.default(primals_239, view_default_389, t_default_137);  primals_239 = None
        view_default_390 = torch.ops.aten.view.default(addmm_default_137, [64, 128, 1024]);  addmm_default_137 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(view_default_390, getitem_132);  view_default_390 = getitem_132 = None
        native_layer_norm_default_45 = torch.ops.aten.native_layer_norm.default(add_tensor_68, [1024], primals_238, primals_237, 1e-12)
        getitem_135 = native_layer_norm_default_45[0]
        getitem_136 = native_layer_norm_default_45[1]
        getitem_137 = native_layer_norm_default_45[2];  native_layer_norm_default_45 = None
        view_default_391 = torch.ops.aten.view.default(getitem_135, [8192, 1024])
        t_default_138 = torch.ops.aten.t.default(primals_248);  primals_248 = None
        addmm_default_138 = torch.ops.aten.addmm.default(primals_247, view_default_391, t_default_138);  primals_247 = None
        view_default_392 = torch.ops.aten.view.default(addmm_default_138, [64, 128, 1024]);  addmm_default_138 = None
        view_default_393 = torch.ops.aten.view.default(getitem_135, [8192, 1024])
        t_default_139 = torch.ops.aten.t.default(primals_246);  primals_246 = None
        addmm_default_139 = torch.ops.aten.addmm.default(primals_245, view_default_393, t_default_139);  primals_245 = None
        view_default_394 = torch.ops.aten.view.default(addmm_default_139, [64, 128, 1024]);  addmm_default_139 = None
        view_default_395 = torch.ops.aten.view.default(view_default_394, [64, 128, 16, 64]);  view_default_394 = None
        permute_default_92 = torch.ops.aten.permute.default(view_default_395, [0, 2, 1, 3]);  view_default_395 = None
        view_default_396 = torch.ops.aten.view.default(getitem_135, [8192, 1024])
        t_default_140 = torch.ops.aten.t.default(primals_250);  primals_250 = None
        addmm_default_140 = torch.ops.aten.addmm.default(primals_249, view_default_396, t_default_140);  primals_249 = None
        view_default_397 = torch.ops.aten.view.default(addmm_default_140, [64, 128, 1024]);  addmm_default_140 = None
        view_default_398 = torch.ops.aten.view.default(view_default_397, [64, 128, 16, 64]);  view_default_397 = None
        permute_default_93 = torch.ops.aten.permute.default(view_default_398, [0, 2, 1, 3]);  view_default_398 = None
        view_default_399 = torch.ops.aten.view.default(view_default_392, [64, 128, 16, 64]);  view_default_392 = None
        permute_default_94 = torch.ops.aten.permute.default(view_default_399, [0, 2, 1, 3]);  view_default_399 = None
        transpose_int_23 = torch.ops.aten.transpose.int(permute_default_92, -1, -2);  permute_default_92 = None
        expand_default_92 = torch.ops.aten.expand.default(permute_default_94, [64, 16, 128, 64]);  permute_default_94 = None
        clone_default_92 = torch.ops.aten.clone.default(expand_default_92, memory_format = torch.contiguous_format);  expand_default_92 = None
        _unsafe_view_default_115 = torch.ops.aten._unsafe_view.default(clone_default_92, [1024, 128, 64]);  clone_default_92 = None
        expand_default_93 = torch.ops.aten.expand.default(transpose_int_23, [64, 16, 64, 128]);  transpose_int_23 = None
        clone_default_93 = torch.ops.aten.clone.default(expand_default_93, memory_format = torch.contiguous_format);  expand_default_93 = None
        _unsafe_view_default_116 = torch.ops.aten._unsafe_view.default(clone_default_93, [1024, 64, 128]);  clone_default_93 = None
        bmm_default_46 = torch.ops.aten.bmm.default(_unsafe_view_default_115, _unsafe_view_default_116)
        _unsafe_view_default_117 = torch.ops.aten._unsafe_view.default(bmm_default_46, [64, 16, 128, 128]);  bmm_default_46 = None
        div_tensor_23 = torch.ops.aten.div.Tensor(_unsafe_view_default_117, 8.0);  _unsafe_view_default_117 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(div_tensor_23, primals_386);  div_tensor_23 = primals_386 = None
        _softmax_default_23 = torch.ops.aten._softmax.default(add_tensor_69, -1, False);  add_tensor_69 = None
        expand_default_94 = torch.ops.aten.expand.default(_softmax_default_23, [64, 16, 128, 128])
        view_default_400 = torch.ops.aten.view.default(expand_default_94, [1024, 128, 128]);  expand_default_94 = None
        expand_default_95 = torch.ops.aten.expand.default(permute_default_93, [64, 16, 128, 64]);  permute_default_93 = None
        clone_default_94 = torch.ops.aten.clone.default(expand_default_95, memory_format = torch.contiguous_format);  expand_default_95 = None
        _unsafe_view_default_118 = torch.ops.aten._unsafe_view.default(clone_default_94, [1024, 128, 64]);  clone_default_94 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_400, _unsafe_view_default_118)
        _unsafe_view_default_119 = torch.ops.aten._unsafe_view.default(bmm_default_47, [64, 16, 128, 64]);  bmm_default_47 = None
        permute_default_95 = torch.ops.aten.permute.default(_unsafe_view_default_119, [0, 2, 1, 3]);  _unsafe_view_default_119 = None
        clone_default_95 = torch.ops.aten.clone.default(permute_default_95, memory_format = torch.contiguous_format);  permute_default_95 = None
        view_default_401 = torch.ops.aten.view.default(clone_default_95, [64, 128, 1024]);  clone_default_95 = None
        view_default_402 = torch.ops.aten.view.default(view_default_401, [8192, 1024]);  view_default_401 = None
        t_default_141 = torch.ops.aten.t.default(primals_244);  primals_244 = None
        addmm_default_141 = torch.ops.aten.addmm.default(primals_243, view_default_402, t_default_141);  primals_243 = None
        view_default_403 = torch.ops.aten.view.default(addmm_default_141, [64, 128, 1024]);  addmm_default_141 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(view_default_403, getitem_135);  view_default_403 = getitem_135 = None
        native_layer_norm_default_46 = torch.ops.aten.native_layer_norm.default(add_tensor_70, [1024], primals_242, primals_241, 1e-12)
        getitem_138 = native_layer_norm_default_46[0]
        getitem_139 = native_layer_norm_default_46[1]
        getitem_140 = native_layer_norm_default_46[2];  native_layer_norm_default_46 = None
        view_default_404 = torch.ops.aten.view.default(getitem_138, [8192, 1024])
        t_default_142 = torch.ops.aten.t.default(primals_252);  primals_252 = None
        addmm_default_142 = torch.ops.aten.addmm.default(primals_251, view_default_404, t_default_142);  primals_251 = None
        view_default_405 = torch.ops.aten.view.default(addmm_default_142, [64, 128, 4096]);  addmm_default_142 = None
        gelu_default_23 = torch.ops.aten.gelu.default(view_default_405)
        view_default_406 = torch.ops.aten.view.default(gelu_default_23, [8192, 4096]);  gelu_default_23 = None
        t_default_143 = torch.ops.aten.t.default(primals_256);  primals_256 = None
        addmm_default_143 = torch.ops.aten.addmm.default(primals_255, view_default_406, t_default_143);  primals_255 = None
        view_default_407 = torch.ops.aten.view.default(addmm_default_143, [64, 128, 1024]);  addmm_default_143 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(view_default_407, getitem_138);  view_default_407 = getitem_138 = None
        native_layer_norm_default_47 = torch.ops.aten.native_layer_norm.default(add_tensor_71, [1024], primals_254, primals_253, 1e-12)
        getitem_141 = native_layer_norm_default_47[0]
        getitem_142 = native_layer_norm_default_47[1]
        getitem_143 = native_layer_norm_default_47[2];  native_layer_norm_default_47 = None
        return [getitem_141, getitem_4, t_default_32, view_default_14, t_default_6, view_default_94, _unsafe_view_default_25, add_tensor_2, view_default_15, getitem_5, t_default_4, add_tensor_16, _unsafe_view_default_26, view_default_17, t_default_31, t_default_5, view_default_90, getitem_79, view_default_269, _unsafe_view_default_65, t_default_81, _unsafe_view_default_71, getitem_85, view_default_232, view_default_266, t_default_93, _unsafe_view_default_73, _unsafe_view_default_78, view_default_247, view_default_234, getitem_86, getitem_92, _unsafe_view_default_70, getitem_91, view_default_249, view_default_251, view_default_268, getitem_80, t_default_94, view_default_230, _unsafe_view_default_68, t_default_87, _unsafe_view_default_76, _unsafe_view_default_66, t_default_7, view_default_19, add_tensor_4, _softmax_default_1, view_default_26, _unsafe_view_default_5, t_default_8, view_default_22, primals_49, t_default_78, view_default_306, t_default_80, t_default_107, view_default_303, t_default_106, t_default_79, getitem_104, primals_50, _softmax_default_13, t_default_108, getitem_107, add_tensor_40, view_default_226, view_default_304, add_tensor_53, primals_98, getitem_106, view_default_223, view_default_187, primals_257, t_default_66, view_default_184, primals_258, t_default, add_tensor_32, t_default_65, getitem_65, view_default, getitem_64, view_default_185, view_default_285, view_default_240, getitem_58, t_default_13, getitem_143, t_default_99, add_tensor_43, _unsafe_view_default_83, t_default_55, _unsafe_view_default_45, t_default_60, view_default_36, view_default_168, getitem_11, view_default_158, getitem_59, t_default_86, add_tensor_28, view_default_243, _softmax_default_14, view_default_283, t_default_12, add_tensor_29, _unsafe_view_default_46, view_default_162, view_default_167, view_default_170, _softmax_default_2, t_default_56, _softmax_default_10, view_default_172, t_default_85, _unsafe_view_default_81, t_default_59, getitem_83, t_default_61, t_default_62, add_tensor_41, t_default_14, _unsafe_view_default_10, view_default_179, t_default_45, getitem_43, getitem_82, view_default_235, view_default_132, view_default_236, _unsafe_view_default_51, t_default_83, view_default_45, t_default_46, add_tensor_7, _unsafe_view_default_50, add_tensor_31, view_default_43, _unsafe_view_default_38, view_default_130, t_default_82, view_default_39, view_default_238, getitem_44, _unsafe_view_default_11, t_default_84, _unsafe_view_default_13, view_default_175, view_default_133, primals_210, _unsafe_view_default_103, primals_209, primals_206, view_default_351, t_default_123, view_default_353, t_default_124, primals_205, view_default_354, getitem_122, getitem_121, view_default_345, view_default_349, add_tensor_61, _unsafe_view_default_101, t_default_122, _unsafe_view_default_100, primals_66, add_tensor_19, _unsafe_view_default_31, view_default_107, primals_61, _unsafe_view_default_6, t_default_37, primals_62, view_default_28, primals_29, _unsafe_view_default_8, t_default_9, _softmax_default_6, primals_65, view_default_111, primals_30, t_default_38, _unsafe_view_default_30, t_default_2, t_default_143, primals_33, _unsafe_view_default, add_tensor_71, _unsafe_view_default_118, view_default_9, getitem_110, _unsafe_view_default_116, view_default_404, view_default_406, t_default_112, t_default_111, view_default_400, view_default_155, t_default_142, view_default_2, getitem_109, view_default_151, t_default_141, view_default_319, getitem_142, add_tensor_26, add_tensor_1, _softmax_default_9, view_default_5, view_default_317, primals_365, _softmax_default, t_default_1, primals_45, primals_370, primals_34, getitem_53, getitem_140, primals_46, _unsafe_view_default_115, t_default_53, getitem_139, getitem_52, view_default_153, _unsafe_view_default_93, view_default_402, t_default_54, _unsafe_view_default_91, primals_369, view_default_150, view_default_405, primals_366, primals_333, primals_322, primals_337, t_default_63, view_default_181, primals_321, view_default_183, getitem_61, _unsafe_view_default_53, t_default_64, primals_334, getitem_62, primals_174, t_default_25, _unsafe_view_default_40, add_tensor_44, t_default_24, view_default_145, getitem_88, t_default_23, getitem_89, view_default_64, t_default_21, getitem_19, primals_173, view_default_252, getitem_23, t_default_49, view_default_255, getitem_22, t_default_22, t_default_90, _softmax_default_4, view_default_65, t_default_50, add_tensor_25, view_default_68, view_default_253, add_tensor_11, getitem_20, primals_178, view_default_141, primals_177, view_default_70, t_default_89, _unsafe_view_default_41, view_default_66, t_default_88, _softmax_default_5, t_default_95, primals_317, view_default_219, getitem_74, primals_305, view_default_218, add_tensor_47, t_default_104, getitem_113, primals_301, primals_306, view_default_291, view_default_85, _softmax_default_17, primals_318, t_default_77, t_default_113, getitem_28, t_default_30, getitem_76, getitem_73, view_default_321, getitem_94, view_default_272, view_default_87, t_default_102, getitem_77, view_default_294, getitem_95, primals_302, t_default_76, add_tensor_56, t_default_29, view_default_270, t_default_96, t_default_114, view_default_323, add_tensor_38, getitem_112, getitem_29, view_default_320, add_tensor_14, t_default_103, view_default_221, view_default_83, view_default_134, _unsafe_view_default_110, t_default_134, _unsafe_view_default_43, view_default_383, _unsafe_view_default_111, getitem_46, getitem_49, add_tensor_23, view_default_149, getitem_50, t_default_47, view_default_147, _softmax_default_8, t_default_52, getitem_47, _unsafe_view_default_113, view_default_136, add_tensor_67, t_default_51, view_default_138, view_default_379, t_default_48, view_default_376, view_default_98, t_default_41, t_default_42, t_default_131, getitem_31, view_default_374, primals_338, getitem_32, _softmax_default_22, view_default_96, t_default_132, t_default_43, add_tensor_65, _softmax_default_7, getitem_131, primals_349, _unsafe_view_default_28, view_default_117, add_tensor_20, view_default_121, t_default_34, getitem_41, getitem_40, t_default_33, getitem_130, t_default_133, primals_353, primals_354, view_default_119, primals_350, t_default_97, view_default_113, t_default_98, _unsafe_view_default_80, _unsafe_view_default_106, view_default_60, view_default_281, view_default_274, t_default_128, t_default_39, _unsafe_view_default_105, view_default_116, t_default_40, _unsafe_view_default_16, getitem_37, view_default_62, getitem_38, _softmax_default_16, add_tensor_10, _unsafe_view_default_33, view_default_366, view_default_362, _unsafe_view_default_18, add_tensor_49, add_tensor_64, view_default_277, view_default_115, _unsafe_view_default_108, _unsafe_view_default_15, view_default_13, view_default_51, getitem_2, primals_77, getitem_16, primals_81, primals_82, getitem_136, t_default_3, view_default_53, _unsafe_view_default_1, _softmax_default_23, view_default_391, view_default_393, t_default_138, t_default_19, view_default_396, primals_78, _unsafe_view_default_3, t_default_20, t_default_18, view_default_11, view_default_56, t_default_139, getitem_137, getitem_1, getitem_17, _softmax_default_3, view_default_387, t_default_136, t_default_137, getitem_134, view_default_389, t_default_135, getitem_133, view_default_385, add_tensor_68, view_default_388, primals_125, primals_1, primals_126, primals_113, primals_114, primals_2, primals_110, add_tensor_52, getitem_103, _unsafe_view_default_63, view_default_300, _unsafe_view_default_86, primals_241, primals_254, _unsafe_view_default_61, primals_253, view_default_215, view_default_217, _unsafe_view_default_88, view_default_302, _unsafe_view_default_60, t_default_105, primals_242, t_default_75, view_default_298, _unsafe_view_default_85, _unsafe_view_default_36, view_default_32, _unsafe_view_default_35, add_tensor_5, add_tensor_22, view_default_34, getitem_7, view_default_124, view_default_30, getitem_8, view_default_128, t_default_44, getitem_10, t_default_11, t_default_10, view_default_31, t_default_15, getitem_70, view_default_370, view_default_204, view_default_201, getitem_127, getitem_128, view_default_202, getitem_71, view_default_47, t_default_16, add_tensor_35, getitem_68, view_default_372, view_default_48, add_tensor_8, view_default_368, view_default_49, t_default_130, t_default_71, view_default_371, t_default_129, t_default_70, t_default_17, getitem_67, getitem_14, getitem_13, view_default_311, _softmax_default_18, t_default_110, _unsafe_view_default_90, add_tensor_55, view_default_308, view_default_315, t_default_109, t_default_69, view_default_334, _unsafe_view_default_98, primals_225, view_default_337, primals_222, view_default_200, primals_237, view_default_336, primals_226, t_default_118, t_default_117, getitem_116, getitem_115, primals_221, _unsafe_view_default_58, view_default_198, primals_238, _unsafe_view_default_56, getitem_34, t_default_36, view_default_206, view_default_104, _softmax_default_12, view_default_209, view_default_102, add_tensor_17, t_default_74, t_default_35, t_default_73, t_default_72, view_default_100, view_default_213, getitem_35, add_tensor_37, view_default_99, _unsafe_view_default_20, primals_285, view_default_77, primals_382, primals_290, primals_286, primals_269, primals_381, primals_274, add_tensor_13, primals_289, _unsafe_view_default_21, view_default_73, t_default_26, primals_273, primals_270, view_default_359, add_tensor_46, getitem_100, t_default_126, getitem_125, view_default_355, _softmax_default_15, t_default_125, view_default_357, primals_194, primals_189, primals_146, primals_129, getitem_98, add_tensor_62, t_default_100, primals_141, primals_190, t_default_91, view_default_257, _softmax_default_21, primals_142, t_default_92, view_default_287, _unsafe_view_default_75, view_default_286, primals_130, t_default_127, getitem_124, view_default_289, primals_145, primals_193, view_default_264, add_tensor_50, view_default_260, getitem_101, t_default_101, getitem_97, t_default_116, _softmax_default_19, primals_18, add_tensor_58, primals_14, _unsafe_view_default_96, view_default_325, _unsafe_view_default_95, primals_162, primals_158, primals_161, primals_17, t_default_115, primals_13, add_tensor_70, t_default_140, view_default_328, primals_157, view_default_332, view_default_166, t_default_121, _unsafe_view_default_48, t_default_58, getitem_119, t_default_120, view_default_340, view_default_164, _softmax_default_20, getitem_56, view_default_338, view_default_342, getitem_118, add_tensor_59, getitem_55, t_default_119, t_default_57, view_default_79, _unsafe_view_default_23, view_default_81, primals_93, getitem_25, _unsafe_view_default_55, add_tensor_34, t_default_68, view_default_192, view_default_196, t_default_27, t_default_67, t_default_28, view_default_189, view_default_82, getitem_26, primals_109, primals_97, primals_94, _softmax_default_11]
        
