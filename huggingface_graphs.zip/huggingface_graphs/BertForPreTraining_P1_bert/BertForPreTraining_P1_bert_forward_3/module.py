
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/BertForPreTraining_P1_bert/BertForPreTraining_P1_bert_forward_3/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10):
        view_default = torch.ops.aten.view.default(primals_9, [8192, 1024]);  primals_9 = None
        t_default = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default = torch.ops.aten.addmm.default(primals_5, view_default, t_default);  primals_5 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [64, 128, 1024]);  addmm_default = None
        gelu_default = torch.ops.aten.gelu.default(view_default_1)
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(gelu_default, [1024], primals_4, primals_3, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [8192, 1024]);  getitem = None
        t_default_1 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_1, view_default_2, t_default_1);  primals_1 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default_1, [64, 128, 30522]);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_7, primals_10, t_default_2);  primals_7 = None
        return [view_default_3, addmm_default_2, primals_10, t_default_2, view_default_1, getitem_1, getitem_2, primals_3, view_default, primals_4, view_default_2, t_default, t_default_1, gelu_default]
        
