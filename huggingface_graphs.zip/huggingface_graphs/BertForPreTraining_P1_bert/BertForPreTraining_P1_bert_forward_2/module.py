
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/BertForPreTraining_P1_bert/BertForPreTraining_P1_bert_forward_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3):
        slice_tensor = torch.ops.aten.slice.Tensor(primals_3, 0, 0, 9223372036854775807);  primals_3 = None
        select_int = torch.ops.aten.select.int(slice_tensor, 1, 0);  slice_tensor = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, select_int, t_default);  primals_1 = None
        tanh_default = torch.ops.aten.tanh.default(addmm_default);  addmm_default = None
        return [tanh_default, t_default, tanh_default, select_int]
        
