
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/XLNetLMHeadModel_xlnet/XLNetLMHeadModel_xlnet_joint_1/state_dict.pt'))

    
    
    def forward(self, primals_1, tangents_1):
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        return [slice_tensor, None]
        
