
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/XLNetLMHeadModel_xlnet/XLNetLMHeadModel_xlnet_joint_20/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, tangents_1):
        unsqueeze_default = torch.ops.aten.unsqueeze.default(primals_16, -1)
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, -1);  unsqueeze_default = None
        permute_default = torch.ops.aten.permute.default(unsqueeze_default_1, [0, 1, 3, 4, 2]);  unsqueeze_default_1 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(primals_11, -1);  primals_11 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default_2, -1);  unsqueeze_default_2 = None
        permute_default_1 = torch.ops.aten.permute.default(unsqueeze_default_3, [3, 4, 1, 2, 0]);  unsqueeze_default_3 = None
        permute_default_2 = torch.ops.aten.permute.default(permute_default, [0, 1, 4, 2, 3]);  permute_default = None
        view_default = torch.ops.aten.view.default(permute_default_2, [1, 1024, 1024]);  permute_default_2 = None
        permute_default_3 = torch.ops.aten.permute.default(permute_default_1, [4, 2, 3, 0, 1]);  permute_default_1 = None
        view_default_1 = torch.ops.aten.view.default(permute_default_3, [1, 1024, 1024]);  permute_default_3 = None
        bmm_default = torch.ops.aten.bmm.default(view_default, view_default_1)
        view_default_2 = torch.ops.aten.view.default(bmm_default, [512, 2, 1, 16, 64]);  bmm_default = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_2, [0, 1, 3, 4, 2]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(permute_default_4, [512, 2, 16, 64]);  permute_default_4 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(primals_16, -1)
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default_4, -1);  unsqueeze_default_4 = None
        permute_default_5 = torch.ops.aten.permute.default(unsqueeze_default_5, [0, 1, 3, 4, 2]);  unsqueeze_default_5 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(primals_7, -1);  primals_7 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default_6, -1);  unsqueeze_default_6 = None
        permute_default_6 = torch.ops.aten.permute.default(unsqueeze_default_7, [3, 4, 1, 2, 0]);  unsqueeze_default_7 = None
        permute_default_7 = torch.ops.aten.permute.default(permute_default_5, [0, 1, 4, 2, 3]);  permute_default_5 = None
        view_default_4 = torch.ops.aten.view.default(permute_default_7, [1, 1024, 1024]);  permute_default_7 = None
        permute_default_8 = torch.ops.aten.permute.default(permute_default_6, [4, 2, 3, 0, 1]);  permute_default_6 = None
        view_default_5 = torch.ops.aten.view.default(permute_default_8, [1, 1024, 1024]);  permute_default_8 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_4, view_default_5)
        view_default_6 = torch.ops.aten.view.default(bmm_default_1, [512, 2, 1, 16, 64]);  bmm_default_1 = None
        permute_default_9 = torch.ops.aten.permute.default(view_default_6, [0, 1, 3, 4, 2]);  view_default_6 = None
        view_default_7 = torch.ops.aten.view.default(permute_default_9, [512, 2, 16, 64]);  permute_default_9 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(primals_16, -1)
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(unsqueeze_default_8, -1);  unsqueeze_default_8 = None
        permute_default_10 = torch.ops.aten.permute.default(unsqueeze_default_9, [0, 1, 3, 4, 2]);  unsqueeze_default_9 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(primals_15, -1);  primals_15 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default_10, -1);  unsqueeze_default_10 = None
        permute_default_11 = torch.ops.aten.permute.default(unsqueeze_default_11, [3, 4, 1, 2, 0]);  unsqueeze_default_11 = None
        permute_default_12 = torch.ops.aten.permute.default(permute_default_10, [0, 1, 4, 2, 3]);  permute_default_10 = None
        view_default_8 = torch.ops.aten.view.default(permute_default_12, [1, 1024, 1024]);  permute_default_12 = None
        permute_default_13 = torch.ops.aten.permute.default(permute_default_11, [4, 2, 3, 0, 1]);  permute_default_11 = None
        view_default_9 = torch.ops.aten.view.default(permute_default_13, [1, 1024, 1024]);  permute_default_13 = None
        bmm_default_2 = torch.ops.aten.bmm.default(view_default_8, view_default_9)
        view_default_10 = torch.ops.aten.view.default(bmm_default_2, [512, 2, 1, 16, 64]);  bmm_default_2 = None
        permute_default_14 = torch.ops.aten.permute.default(view_default_10, [0, 1, 3, 4, 2]);  view_default_10 = None
        view_default_11 = torch.ops.aten.view.default(permute_default_14, [512, 2, 16, 64]);  permute_default_14 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(primals_18, -1);  primals_18 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(unsqueeze_default_12, -1);  unsqueeze_default_12 = None
        permute_default_15 = torch.ops.aten.permute.default(unsqueeze_default_13, [0, 1, 3, 4, 2]);  unsqueeze_default_13 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(primals_12, -1);  primals_12 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(unsqueeze_default_14, -1);  unsqueeze_default_14 = None
        permute_default_16 = torch.ops.aten.permute.default(unsqueeze_default_15, [3, 4, 1, 2, 0]);  unsqueeze_default_15 = None
        permute_default_17 = torch.ops.aten.permute.default(permute_default_15, [0, 1, 4, 2, 3]);  permute_default_15 = None
        view_default_12 = torch.ops.aten.view.default(permute_default_17, [1, 2048, 1024]);  permute_default_17 = None
        permute_default_18 = torch.ops.aten.permute.default(permute_default_16, [4, 2, 3, 0, 1]);  permute_default_16 = None
        view_default_13 = torch.ops.aten.view.default(permute_default_18, [1, 1024, 1024]);  permute_default_18 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_12, view_default_13);  view_default_13 = None
        view_default_14 = torch.ops.aten.view.default(bmm_default_3, [1024, 2, 1, 16, 64]);  bmm_default_3 = None
        permute_default_19 = torch.ops.aten.permute.default(view_default_14, [0, 1, 3, 4, 2]);  view_default_14 = None
        view_default_15 = torch.ops.aten.view.default(permute_default_19, [1024, 2, 16, 64]);  permute_default_19 = None
        add_tensor = torch.ops.aten.add.Tensor(view_default_3, primals_14);  primals_14 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(add_tensor, -1);  add_tensor = None
        permute_default_20 = torch.ops.aten.permute.default(unsqueeze_default_16, [1, 2, 0, 4, 3]);  unsqueeze_default_16 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(view_default_7, -1);  view_default_7 = None
        permute_default_21 = torch.ops.aten.permute.default(unsqueeze_default_17, [1, 2, 4, 0, 3]);  unsqueeze_default_17 = None
        permute_default_22 = torch.ops.aten.permute.default(permute_default_20, [0, 1, 2, 4, 3]);  permute_default_20 = None
        view_default_16 = torch.ops.aten.view.default(permute_default_22, [32, 512, 64]);  permute_default_22 = None
        permute_default_23 = torch.ops.aten.permute.default(permute_default_21, [0, 1, 4, 3, 2]);  permute_default_21 = None
        view_default_17 = torch.ops.aten.view.default(permute_default_23, [32, 64, 512]);  permute_default_23 = None
        bmm_default_4 = torch.ops.aten.bmm.default(view_default_16, view_default_17)
        view_default_18 = torch.ops.aten.view.default(bmm_default_4, [2, 16, 512, 1, 512]);  bmm_default_4 = None
        permute_default_24 = torch.ops.aten.permute.default(view_default_18, [0, 1, 2, 4, 3]);  view_default_18 = None
        view_default_19 = torch.ops.aten.view.default(permute_default_24, [2, 16, 512, 512]);  permute_default_24 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_3, primals_13);  view_default_3 = primals_13 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(add_tensor_1, -1);  add_tensor_1 = None
        permute_default_25 = torch.ops.aten.permute.default(unsqueeze_default_18, [1, 2, 0, 4, 3]);  unsqueeze_default_18 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(view_default_15, -1);  view_default_15 = None
        permute_default_26 = torch.ops.aten.permute.default(unsqueeze_default_19, [1, 2, 4, 0, 3]);  unsqueeze_default_19 = None
        permute_default_27 = torch.ops.aten.permute.default(permute_default_25, [0, 1, 2, 4, 3]);  permute_default_25 = None
        view_default_20 = torch.ops.aten.view.default(permute_default_27, [32, 512, 64]);  permute_default_27 = None
        permute_default_28 = torch.ops.aten.permute.default(permute_default_26, [0, 1, 4, 3, 2]);  permute_default_26 = None
        view_default_21 = torch.ops.aten.view.default(permute_default_28, [32, 64, 1024]);  permute_default_28 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_20, view_default_21)
        view_default_22 = torch.ops.aten.view.default(bmm_default_5, [2, 16, 512, 1, 1024]);  bmm_default_5 = None
        permute_default_29 = torch.ops.aten.permute.default(view_default_22, [0, 1, 2, 4, 3]);  view_default_22 = None
        view_default_23 = torch.ops.aten.view.default(permute_default_29, [2, 16, 512, 1024]);  permute_default_29 = None
        view_default_24 = torch.ops.aten.view.default(view_default_23, [2, 16, 1024, 512]);  view_default_23 = None
        slice_tensor = torch.ops.aten.slice.Tensor(view_default_24, 0, 0, 9223372036854775807);  view_default_24 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 9223372036854775807);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 1, 9223372036854775807);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 9223372036854775807);  slice_tensor_2 = None
        view_default_25 = torch.ops.aten.view.default(slice_tensor_3, [2, 16, 512, 1023]);  slice_tensor_3 = None
        arange = torch.ops.aten.arange.default(512, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        index_select_default = torch.ops.aten.index_select.default(view_default_25, 3, arange);  view_default_25 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_19, index_select_default);  view_default_19 = index_select_default = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, 0);  add_tensor_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(add_tensor_3, 0.125);  add_tensor_3 = None
        permute_default_30 = torch.ops.aten.permute.default(primals_17, [2, 3, 0, 1]);  primals_17 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(permute_default_30, 1e+30);  permute_default_30 = None
        sub_tensor = torch.ops.aten.sub.Tensor(mul_tensor, mul_tensor_1);  mul_tensor = mul_tensor_1 = None
        _softmax_default = torch.ops.aten._softmax.default(sub_tensor, 3, False);  sub_tensor = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(_softmax_default, -1)
        permute_default_31 = torch.ops.aten.permute.default(unsqueeze_default_20, [2, 0, 1, 4, 3]);  unsqueeze_default_20 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(view_default_11, -1);  view_default_11 = None
        permute_default_32 = torch.ops.aten.permute.default(unsqueeze_default_21, [4, 1, 2, 3, 0]);  unsqueeze_default_21 = None
        permute_default_33 = torch.ops.aten.permute.default(permute_default_31, [1, 2, 0, 4, 3]);  permute_default_31 = None
        view_default_26 = torch.ops.aten.view.default(permute_default_33, [32, 512, 512]);  permute_default_33 = None
        permute_default_34 = torch.ops.aten.permute.default(permute_default_32, [1, 2, 4, 3, 0]);  permute_default_32 = None
        view_default_27 = torch.ops.aten.view.default(permute_default_34, [32, 512, 64]);  permute_default_34 = None
        bmm_default_6 = torch.ops.aten.bmm.default(view_default_26, view_default_27)
        view_default_28 = torch.ops.aten.view.default(bmm_default_6, [2, 16, 512, 1, 64]);  bmm_default_6 = None
        permute_default_35 = torch.ops.aten.permute.default(view_default_28, [2, 0, 1, 4, 3]);  view_default_28 = None
        view_default_29 = torch.ops.aten.view.default(permute_default_35, [512, 2, 16, 64]);  permute_default_35 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(view_default_29, -1);  view_default_29 = None
        permute_default_36 = torch.ops.aten.permute.default(unsqueeze_default_22, [0, 1, 4, 3, 2]);  unsqueeze_default_22 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(primals_10, -1);  primals_10 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(unsqueeze_default_23, -1);  unsqueeze_default_23 = None
        permute_default_37 = torch.ops.aten.permute.default(unsqueeze_default_24, [3, 4, 0, 2, 1]);  unsqueeze_default_24 = None
        permute_default_38 = torch.ops.aten.permute.default(permute_default_36, [0, 1, 3, 4, 2]);  permute_default_36 = None
        clone_default = torch.ops.aten.clone.default(permute_default_38, memory_format = torch.contiguous_format);  permute_default_38 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [1, 1024, 1024]);  clone_default = None
        permute_default_39 = torch.ops.aten.permute.default(permute_default_37, [3, 4, 2, 0, 1]);  permute_default_37 = None
        clone_default_1 = torch.ops.aten.clone.default(permute_default_39, memory_format = torch.contiguous_format);  permute_default_39 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [1, 1024, 1024]);  clone_default_1 = None
        bmm_default_7 = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        view_default_30 = torch.ops.aten.view.default(bmm_default_7, [512, 2, 1, 1, 1024]);  bmm_default_7 = None
        permute_default_40 = torch.ops.aten.permute.default(view_default_30, [0, 1, 4, 2, 3]);  view_default_30 = None
        view_default_31 = torch.ops.aten.view.default(permute_default_40, [512, 2, 1024]);  permute_default_40 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(view_default_31, primals_16);  view_default_31 = primals_16 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_4, [1024], primals_9, primals_8, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_32 = torch.ops.aten.view.default(getitem, [1024, 1024])
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default_32, t_default);  primals_1 = None
        view_default_33 = torch.ops.aten.view.default(addmm_default, [512, 2, 4096]);  addmm_default = None
        gelu_default = torch.ops.aten.gelu.default(view_default_33)
        view_default_34 = torch.ops.aten.view.default(gelu_default, [1024, 4096]);  gelu_default = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, view_default_34, t_default_1);  primals_3 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_1, [512, 2, 1024]);  addmm_default_1 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(view_default_35, getitem);  view_default_35 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [1024], primals_6, primals_5, 1e-12)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(getitem_3, tangents_1)
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_5, [1024], getitem_4, getitem_5, primals_6, primals_5, [True, True, True]);  tangents_1 = add_tensor_5 = getitem_4 = getitem_5 = primals_6 = primals_5 = None
        getitem_6 = native_layer_norm_backward_default[0]
        getitem_7 = native_layer_norm_backward_default[1]
        getitem_8 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_36 = torch.ops.aten.view.default(getitem_6, [1024, 1024])
        t_default_2 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default = torch.ops.aten.mm.default(view_default_36, t_default_2);  t_default_2 = None
        t_default_3 = torch.ops.aten.t.default(view_default_36)
        mm_default_1 = torch.ops.aten.mm.default(t_default_3, view_default_34);  t_default_3 = view_default_34 = None
        t_default_4 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_36, [0], True);  view_default_36 = None
        view_default_37 = torch.ops.aten.view.default(sum_dim_int_list, [1024]);  sum_dim_int_list = None
        t_default_5 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        view_default_38 = torch.ops.aten.view.default(mm_default, [512, 2, 4096]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_38, torch.float32);  view_default_38 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_33, torch.float32);  view_default_33 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_2);  mul_tensor_2 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(add_tensor_6, 0.5);  add_tensor_6 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(mul_tensor_4, -0.5);  mul_tensor_4 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_5);  mul_tensor_5 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_6);  to_dtype_1 = mul_tensor_6 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(mul_tensor_3, mul_tensor_7);  mul_tensor_3 = mul_tensor_7 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_7);  to_dtype = add_tensor_7 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_8, torch.float32);  mul_tensor_8 = None
        view_default_39 = torch.ops.aten.view.default(to_dtype_2, [1024, 4096]);  to_dtype_2 = None
        t_default_6 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_39, t_default_6);  t_default_6 = None
        t_default_7 = torch.ops.aten.t.default(view_default_39)
        mm_default_3 = torch.ops.aten.mm.default(t_default_7, view_default_32);  t_default_7 = view_default_32 = None
        t_default_8 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_39, [0], True);  view_default_39 = None
        view_default_40 = torch.ops.aten.view.default(sum_dim_int_list_1, [4096]);  sum_dim_int_list_1 = None
        t_default_9 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        view_default_41 = torch.ops.aten.view.default(mm_default_2, [512, 2, 1024]);  mm_default_2 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_6, view_default_41);  getitem_6 = view_default_41 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_8, add_tensor_4, [1024], getitem_1, getitem_2, primals_9, primals_8, [True, True, True]);  add_tensor_8 = add_tensor_4 = getitem_1 = getitem_2 = primals_9 = primals_8 = None
        getitem_9 = native_layer_norm_backward_default_1[0]
        getitem_10 = native_layer_norm_backward_default_1[1]
        getitem_11 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_42 = torch.ops.aten.view.default(getitem_9, [512, 2, 1024, 1, 1])
        permute_default_41 = torch.ops.aten.permute.default(view_default_42, [0, 1, 3, 4, 2]);  view_default_42 = None
        view_default_43 = torch.ops.aten.view.default(permute_default_41, [1, 1024, 1024]);  permute_default_41 = None
        transpose_int = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_8 = torch.ops.aten.bmm.default(transpose_int, view_default_43);  transpose_int = None
        transpose_int_1 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_43, transpose_int_1);  view_default_43 = transpose_int_1 = None
        view_default_44 = torch.ops.aten.view.default(bmm_default_8, [64, 16, 1024, 1, 1]);  bmm_default_8 = None
        permute_default_42 = torch.ops.aten.permute.default(view_default_44, [3, 4, 2, 0, 1]);  view_default_44 = None
        view_default_45 = torch.ops.aten.view.default(bmm_default_9, [512, 2, 64, 16, 1]);  bmm_default_9 = None
        permute_default_43 = torch.ops.aten.permute.default(view_default_45, [0, 1, 4, 2, 3]);  view_default_45 = None
        permute_default_44 = torch.ops.aten.permute.default(permute_default_42, [2, 4, 3, 0, 1]);  permute_default_42 = None
        squeeze_dim = torch.ops.aten.squeeze.dim(permute_default_44, -1);  permute_default_44 = None
        squeeze_dim_1 = torch.ops.aten.squeeze.dim(squeeze_dim, -1);  squeeze_dim = None
        permute_default_45 = torch.ops.aten.permute.default(permute_default_43, [0, 1, 4, 3, 2]);  permute_default_43 = None
        squeeze_dim_2 = torch.ops.aten.squeeze.dim(permute_default_45, -1);  permute_default_45 = None
        view_default_46 = torch.ops.aten.view.default(squeeze_dim_2, [512, 2, 16, 64, 1]);  squeeze_dim_2 = None
        permute_default_46 = torch.ops.aten.permute.default(view_default_46, [1, 2, 0, 4, 3]);  view_default_46 = None
        clone_default_2 = torch.ops.aten.clone.default(permute_default_46, memory_format = torch.contiguous_format);  permute_default_46 = None
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_2, [32, 512, 64]);  clone_default_2 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        bmm_default_10 = torch.ops.aten.bmm.default(transpose_int_2, _unsafe_view_default_2);  transpose_int_2 = None
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_27, 1, 2);  view_default_27 = None
        bmm_default_11 = torch.ops.aten.bmm.default(_unsafe_view_default_2, transpose_int_3);  _unsafe_view_default_2 = transpose_int_3 = None
        view_default_47 = torch.ops.aten.view.default(bmm_default_10, [2, 16, 512, 64, 1]);  bmm_default_10 = None
        permute_default_47 = torch.ops.aten.permute.default(view_default_47, [4, 0, 1, 3, 2]);  view_default_47 = None
        view_default_48 = torch.ops.aten.view.default(bmm_default_11, [2, 16, 512, 512, 1]);  bmm_default_11 = None
        permute_default_48 = torch.ops.aten.permute.default(view_default_48, [2, 0, 1, 4, 3]);  view_default_48 = None
        permute_default_49 = torch.ops.aten.permute.default(permute_default_47, [4, 1, 2, 3, 0]);  permute_default_47 = None
        squeeze_dim_3 = torch.ops.aten.squeeze.dim(permute_default_49, -1);  permute_default_49 = None
        permute_default_50 = torch.ops.aten.permute.default(permute_default_48, [1, 2, 0, 4, 3]);  permute_default_48 = None
        squeeze_dim_4 = torch.ops.aten.squeeze.dim(permute_default_50, -1);  permute_default_50 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(squeeze_dim_4, _softmax_default, 3, torch.float32);  squeeze_dim_4 = _softmax_default = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default, 0.125);  _softmax_backward_data_default = None
        new_empty_default = torch.ops.aten.new_empty.default(mul_tensor_9, [2, 16, 512, 1023], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        index_add_default = torch.ops.aten.index_add.default(zero__default, 3, arange, mul_tensor_9);  zero__default = arange = None
        view_default_49 = torch.ops.aten.view.default(index_add_default, [2, 16, 1023, 512]);  index_add_default = None
        slice_backward_default = torch.ops.aten.slice_backward.default(view_default_49, [2, 16, 1023, 512], 3, 0, 9223372036854775807, 1);  view_default_49 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(slice_backward_default, [2, 16, 1024, 512], 2, 1, 9223372036854775807, 1);  slice_backward_default = None
        slice_backward_default_2 = torch.ops.aten.slice_backward.default(slice_backward_default_1, [2, 16, 1024, 512], 1, 0, 9223372036854775807, 1);  slice_backward_default_1 = None
        slice_backward_default_3 = torch.ops.aten.slice_backward.default(slice_backward_default_2, [2, 16, 1024, 512], 0, 0, 9223372036854775807, 1);  slice_backward_default_2 = None
        view_default_50 = torch.ops.aten.view.default(slice_backward_default_3, [2, 16, 512, 1024]);  slice_backward_default_3 = None
        view_default_51 = torch.ops.aten.view.default(view_default_50, [2, 16, 512, 1024, 1]);  view_default_50 = None
        permute_default_51 = torch.ops.aten.permute.default(view_default_51, [0, 1, 2, 4, 3]);  view_default_51 = None
        view_default_52 = torch.ops.aten.view.default(permute_default_51, [32, 512, 1024]);  permute_default_51 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default_20, 1, 2);  view_default_20 = None
        bmm_default_12 = torch.ops.aten.bmm.default(transpose_int_4, view_default_52);  transpose_int_4 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_21, 1, 2);  view_default_21 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_52, transpose_int_5);  view_default_52 = transpose_int_5 = None
        view_default_53 = torch.ops.aten.view.default(bmm_default_12, [2, 16, 64, 1024, 1]);  bmm_default_12 = None
        permute_default_52 = torch.ops.aten.permute.default(view_default_53, [0, 1, 4, 3, 2]);  view_default_53 = None
        view_default_54 = torch.ops.aten.view.default(bmm_default_13, [2, 16, 512, 64, 1]);  bmm_default_13 = None
        permute_default_53 = torch.ops.aten.permute.default(view_default_54, [0, 1, 2, 4, 3]);  view_default_54 = None
        permute_default_54 = torch.ops.aten.permute.default(permute_default_52, [3, 0, 1, 4, 2]);  permute_default_52 = None
        squeeze_dim_5 = torch.ops.aten.squeeze.dim(permute_default_54, -1);  permute_default_54 = None
        permute_default_55 = torch.ops.aten.permute.default(permute_default_53, [2, 0, 1, 4, 3]);  permute_default_53 = None
        squeeze_dim_6 = torch.ops.aten.squeeze.dim(permute_default_55, -1);  permute_default_55 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(squeeze_dim_6, [0, 1], True)
        view_default_55 = torch.ops.aten.view.default(sum_dim_int_list_2, [16, 64]);  sum_dim_int_list_2 = None
        view_default_56 = torch.ops.aten.view.default(mul_tensor_9, [2, 16, 512, 512, 1]);  mul_tensor_9 = None
        permute_default_56 = torch.ops.aten.permute.default(view_default_56, [0, 1, 2, 4, 3]);  view_default_56 = None
        view_default_57 = torch.ops.aten.view.default(permute_default_56, [32, 512, 512]);  permute_default_56 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        bmm_default_14 = torch.ops.aten.bmm.default(transpose_int_6, view_default_57);  transpose_int_6 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_17, 1, 2);  view_default_17 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_57, transpose_int_7);  view_default_57 = transpose_int_7 = None
        view_default_58 = torch.ops.aten.view.default(bmm_default_14, [2, 16, 64, 512, 1]);  bmm_default_14 = None
        permute_default_57 = torch.ops.aten.permute.default(view_default_58, [0, 1, 4, 3, 2]);  view_default_58 = None
        view_default_59 = torch.ops.aten.view.default(bmm_default_15, [2, 16, 512, 64, 1]);  bmm_default_15 = None
        permute_default_58 = torch.ops.aten.permute.default(view_default_59, [0, 1, 2, 4, 3]);  view_default_59 = None
        permute_default_59 = torch.ops.aten.permute.default(permute_default_57, [3, 0, 1, 4, 2]);  permute_default_57 = None
        squeeze_dim_7 = torch.ops.aten.squeeze.dim(permute_default_59, -1);  permute_default_59 = None
        permute_default_60 = torch.ops.aten.permute.default(permute_default_58, [2, 0, 1, 4, 3]);  permute_default_58 = None
        squeeze_dim_8 = torch.ops.aten.squeeze.dim(permute_default_60, -1);  permute_default_60 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(squeeze_dim_8, [0, 1], True)
        view_default_60 = torch.ops.aten.view.default(sum_dim_int_list_3, [16, 64]);  sum_dim_int_list_3 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(squeeze_dim_6, squeeze_dim_8);  squeeze_dim_6 = squeeze_dim_8 = None
        view_default_61 = torch.ops.aten.view.default(squeeze_dim_5, [1024, 2, 16, 64, 1]);  squeeze_dim_5 = None
        permute_default_61 = torch.ops.aten.permute.default(view_default_61, [0, 1, 4, 2, 3]);  view_default_61 = None
        clone_default_3 = torch.ops.aten.clone.default(permute_default_61, memory_format = torch.contiguous_format);  permute_default_61 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_3, [1, 2048, 1024]);  clone_default_3 = None
        transpose_int_8 = torch.ops.aten.transpose.int(view_default_12, 1, 2);  view_default_12 = None
        bmm_default_16 = torch.ops.aten.bmm.default(transpose_int_8, _unsafe_view_default_3);  transpose_int_8 = _unsafe_view_default_3 = None
        view_default_62 = torch.ops.aten.view.default(bmm_default_16, [1024, 16, 64, 1, 1]);  bmm_default_16 = None
        permute_default_62 = torch.ops.aten.permute.default(view_default_62, [3, 4, 1, 2, 0]);  view_default_62 = None
        permute_default_63 = torch.ops.aten.permute.default(permute_default_62, [4, 2, 3, 0, 1]);  permute_default_62 = None
        squeeze_dim_9 = torch.ops.aten.squeeze.dim(permute_default_63, -1);  permute_default_63 = None
        squeeze_dim_10 = torch.ops.aten.squeeze.dim(squeeze_dim_9, -1);  squeeze_dim_9 = None
        view_default_63 = torch.ops.aten.view.default(squeeze_dim_3, [512, 2, 16, 64, 1]);  squeeze_dim_3 = None
        permute_default_64 = torch.ops.aten.permute.default(view_default_63, [0, 1, 4, 2, 3]);  view_default_63 = None
        clone_default_4 = torch.ops.aten.clone.default(permute_default_64, memory_format = torch.contiguous_format);  permute_default_64 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_4, [1, 1024, 1024]);  clone_default_4 = None
        transpose_int_9 = torch.ops.aten.transpose.int(view_default_8, 1, 2);  view_default_8 = None
        bmm_default_17 = torch.ops.aten.bmm.default(transpose_int_9, _unsafe_view_default_4);  transpose_int_9 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_9, 1, 2);  view_default_9 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_4, transpose_int_10);  _unsafe_view_default_4 = transpose_int_10 = None
        view_default_64 = torch.ops.aten.view.default(bmm_default_17, [1024, 16, 64, 1, 1]);  bmm_default_17 = None
        permute_default_65 = torch.ops.aten.permute.default(view_default_64, [3, 4, 1, 2, 0]);  view_default_64 = None
        view_default_65 = torch.ops.aten.view.default(bmm_default_18, [512, 2, 1024, 1, 1]);  bmm_default_18 = None
        permute_default_66 = torch.ops.aten.permute.default(view_default_65, [0, 1, 3, 4, 2]);  view_default_65 = None
        permute_default_67 = torch.ops.aten.permute.default(permute_default_65, [4, 2, 3, 0, 1]);  permute_default_65 = None
        squeeze_dim_11 = torch.ops.aten.squeeze.dim(permute_default_67, -1);  permute_default_67 = None
        squeeze_dim_12 = torch.ops.aten.squeeze.dim(squeeze_dim_11, -1);  squeeze_dim_11 = None
        permute_default_68 = torch.ops.aten.permute.default(permute_default_66, [0, 1, 4, 2, 3]);  permute_default_66 = None
        squeeze_dim_13 = torch.ops.aten.squeeze.dim(permute_default_68, -1);  permute_default_68 = None
        squeeze_dim_14 = torch.ops.aten.squeeze.dim(squeeze_dim_13, -1);  squeeze_dim_13 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_9, squeeze_dim_14);  getitem_9 = squeeze_dim_14 = None
        view_default_66 = torch.ops.aten.view.default(squeeze_dim_7, [512, 2, 16, 64, 1]);  squeeze_dim_7 = None
        permute_default_69 = torch.ops.aten.permute.default(view_default_66, [0, 1, 4, 2, 3]);  view_default_66 = None
        clone_default_5 = torch.ops.aten.clone.default(permute_default_69, memory_format = torch.contiguous_format);  permute_default_69 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_5, [1, 1024, 1024]);  clone_default_5 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_4, 1, 2);  view_default_4 = None
        bmm_default_19 = torch.ops.aten.bmm.default(transpose_int_11, _unsafe_view_default_5);  transpose_int_11 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_5, transpose_int_12);  _unsafe_view_default_5 = transpose_int_12 = None
        view_default_67 = torch.ops.aten.view.default(bmm_default_19, [1024, 16, 64, 1, 1]);  bmm_default_19 = None
        permute_default_70 = torch.ops.aten.permute.default(view_default_67, [3, 4, 1, 2, 0]);  view_default_67 = None
        view_default_68 = torch.ops.aten.view.default(bmm_default_20, [512, 2, 1024, 1, 1]);  bmm_default_20 = None
        permute_default_71 = torch.ops.aten.permute.default(view_default_68, [0, 1, 3, 4, 2]);  view_default_68 = None
        permute_default_72 = torch.ops.aten.permute.default(permute_default_70, [4, 2, 3, 0, 1]);  permute_default_70 = None
        squeeze_dim_15 = torch.ops.aten.squeeze.dim(permute_default_72, -1);  permute_default_72 = None
        squeeze_dim_16 = torch.ops.aten.squeeze.dim(squeeze_dim_15, -1);  squeeze_dim_15 = None
        permute_default_73 = torch.ops.aten.permute.default(permute_default_71, [0, 1, 4, 2, 3]);  permute_default_71 = None
        squeeze_dim_17 = torch.ops.aten.squeeze.dim(permute_default_73, -1);  permute_default_73 = None
        squeeze_dim_18 = torch.ops.aten.squeeze.dim(squeeze_dim_17, -1);  squeeze_dim_17 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, squeeze_dim_18);  add_tensor_10 = squeeze_dim_18 = None
        view_default_69 = torch.ops.aten.view.default(add_tensor_9, [512, 2, 16, 64, 1]);  add_tensor_9 = None
        permute_default_74 = torch.ops.aten.permute.default(view_default_69, [0, 1, 4, 2, 3]);  view_default_69 = None
        clone_default_6 = torch.ops.aten.clone.default(permute_default_74, memory_format = torch.contiguous_format);  permute_default_74 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_6, [1, 1024, 1024]);  clone_default_6 = None
        transpose_int_13 = torch.ops.aten.transpose.int(view_default, 1, 2);  view_default = None
        bmm_default_21 = torch.ops.aten.bmm.default(transpose_int_13, _unsafe_view_default_6);  transpose_int_13 = None
        transpose_int_14 = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_6, transpose_int_14);  _unsafe_view_default_6 = transpose_int_14 = None
        view_default_70 = torch.ops.aten.view.default(bmm_default_21, [1024, 16, 64, 1, 1]);  bmm_default_21 = None
        permute_default_75 = torch.ops.aten.permute.default(view_default_70, [3, 4, 1, 2, 0]);  view_default_70 = None
        view_default_71 = torch.ops.aten.view.default(bmm_default_22, [512, 2, 1024, 1, 1]);  bmm_default_22 = None
        permute_default_76 = torch.ops.aten.permute.default(view_default_71, [0, 1, 3, 4, 2]);  view_default_71 = None
        permute_default_77 = torch.ops.aten.permute.default(permute_default_75, [4, 2, 3, 0, 1]);  permute_default_75 = None
        squeeze_dim_19 = torch.ops.aten.squeeze.dim(permute_default_77, -1);  permute_default_77 = None
        squeeze_dim_20 = torch.ops.aten.squeeze.dim(squeeze_dim_19, -1);  squeeze_dim_19 = None
        permute_default_78 = torch.ops.aten.permute.default(permute_default_76, [0, 1, 4, 2, 3]);  permute_default_76 = None
        squeeze_dim_21 = torch.ops.aten.squeeze.dim(permute_default_78, -1);  permute_default_78 = None
        squeeze_dim_22 = torch.ops.aten.squeeze.dim(squeeze_dim_21, -1);  squeeze_dim_21 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, squeeze_dim_22);  add_tensor_11 = squeeze_dim_22 = None
        return [getitem_3, view_default_40, t_default_9, view_default_37, t_default_5, getitem_8, getitem_7, squeeze_dim_16, getitem_11, getitem_10, squeeze_dim_1, squeeze_dim_20, squeeze_dim_10, view_default_55, view_default_60, squeeze_dim_12, add_tensor_12, None, None]
        
