
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/XLNetLMHeadModel_xlnet/XLNetLMHeadModel_xlnet_forward_24/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18):
        unsqueeze_default = torch.ops.aten.unsqueeze.default(primals_16, -1)
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, -1);  unsqueeze_default = None
        permute_default = torch.ops.aten.permute.default(unsqueeze_default_1, [0, 1, 3, 4, 2]);  unsqueeze_default_1 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(primals_11, -1);  primals_11 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default_2, -1);  unsqueeze_default_2 = None
        permute_default_1 = torch.ops.aten.permute.default(unsqueeze_default_3, [3, 4, 1, 2, 0]);  unsqueeze_default_3 = None
        permute_default_2 = torch.ops.aten.permute.default(permute_default, [0, 1, 4, 2, 3]);  permute_default = None
        view_default = torch.ops.aten.view.default(permute_default_2, [1, 1024, 1024]);  permute_default_2 = None
        permute_default_3 = torch.ops.aten.permute.default(permute_default_1, [4, 2, 3, 0, 1]);  permute_default_1 = None
        view_default_1 = torch.ops.aten.view.default(permute_default_3, [1, 1024, 1024]);  permute_default_3 = None
        bmm_default = torch.ops.aten.bmm.default(view_default, view_default_1)
        view_default_2 = torch.ops.aten.view.default(bmm_default, [512, 2, 1, 16, 64]);  bmm_default = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_2, [0, 1, 3, 4, 2]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(permute_default_4, [512, 2, 16, 64]);  permute_default_4 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(primals_16, -1)
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default_4, -1);  unsqueeze_default_4 = None
        permute_default_5 = torch.ops.aten.permute.default(unsqueeze_default_5, [0, 1, 3, 4, 2]);  unsqueeze_default_5 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(primals_7, -1);  primals_7 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default_6, -1);  unsqueeze_default_6 = None
        permute_default_6 = torch.ops.aten.permute.default(unsqueeze_default_7, [3, 4, 1, 2, 0]);  unsqueeze_default_7 = None
        permute_default_7 = torch.ops.aten.permute.default(permute_default_5, [0, 1, 4, 2, 3]);  permute_default_5 = None
        view_default_4 = torch.ops.aten.view.default(permute_default_7, [1, 1024, 1024]);  permute_default_7 = None
        permute_default_8 = torch.ops.aten.permute.default(permute_default_6, [4, 2, 3, 0, 1]);  permute_default_6 = None
        view_default_5 = torch.ops.aten.view.default(permute_default_8, [1, 1024, 1024]);  permute_default_8 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_4, view_default_5)
        view_default_6 = torch.ops.aten.view.default(bmm_default_1, [512, 2, 1, 16, 64]);  bmm_default_1 = None
        permute_default_9 = torch.ops.aten.permute.default(view_default_6, [0, 1, 3, 4, 2]);  view_default_6 = None
        view_default_7 = torch.ops.aten.view.default(permute_default_9, [512, 2, 16, 64]);  permute_default_9 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(primals_16, -1)
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(unsqueeze_default_8, -1);  unsqueeze_default_8 = None
        permute_default_10 = torch.ops.aten.permute.default(unsqueeze_default_9, [0, 1, 3, 4, 2]);  unsqueeze_default_9 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(primals_15, -1);  primals_15 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default_10, -1);  unsqueeze_default_10 = None
        permute_default_11 = torch.ops.aten.permute.default(unsqueeze_default_11, [3, 4, 1, 2, 0]);  unsqueeze_default_11 = None
        permute_default_12 = torch.ops.aten.permute.default(permute_default_10, [0, 1, 4, 2, 3]);  permute_default_10 = None
        view_default_8 = torch.ops.aten.view.default(permute_default_12, [1, 1024, 1024]);  permute_default_12 = None
        permute_default_13 = torch.ops.aten.permute.default(permute_default_11, [4, 2, 3, 0, 1]);  permute_default_11 = None
        view_default_9 = torch.ops.aten.view.default(permute_default_13, [1, 1024, 1024]);  permute_default_13 = None
        bmm_default_2 = torch.ops.aten.bmm.default(view_default_8, view_default_9)
        view_default_10 = torch.ops.aten.view.default(bmm_default_2, [512, 2, 1, 16, 64]);  bmm_default_2 = None
        permute_default_14 = torch.ops.aten.permute.default(view_default_10, [0, 1, 3, 4, 2]);  view_default_10 = None
        view_default_11 = torch.ops.aten.view.default(permute_default_14, [512, 2, 16, 64]);  permute_default_14 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(primals_18, -1);  primals_18 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(unsqueeze_default_12, -1);  unsqueeze_default_12 = None
        permute_default_15 = torch.ops.aten.permute.default(unsqueeze_default_13, [0, 1, 3, 4, 2]);  unsqueeze_default_13 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(primals_12, -1);  primals_12 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(unsqueeze_default_14, -1);  unsqueeze_default_14 = None
        permute_default_16 = torch.ops.aten.permute.default(unsqueeze_default_15, [3, 4, 1, 2, 0]);  unsqueeze_default_15 = None
        permute_default_17 = torch.ops.aten.permute.default(permute_default_15, [0, 1, 4, 2, 3]);  permute_default_15 = None
        view_default_12 = torch.ops.aten.view.default(permute_default_17, [1, 2048, 1024]);  permute_default_17 = None
        permute_default_18 = torch.ops.aten.permute.default(permute_default_16, [4, 2, 3, 0, 1]);  permute_default_16 = None
        view_default_13 = torch.ops.aten.view.default(permute_default_18, [1, 1024, 1024]);  permute_default_18 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_12, view_default_13);  view_default_13 = None
        view_default_14 = torch.ops.aten.view.default(bmm_default_3, [1024, 2, 1, 16, 64]);  bmm_default_3 = None
        permute_default_19 = torch.ops.aten.permute.default(view_default_14, [0, 1, 3, 4, 2]);  view_default_14 = None
        view_default_15 = torch.ops.aten.view.default(permute_default_19, [1024, 2, 16, 64]);  permute_default_19 = None
        add_tensor = torch.ops.aten.add.Tensor(view_default_3, primals_14);  primals_14 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(add_tensor, -1);  add_tensor = None
        permute_default_20 = torch.ops.aten.permute.default(unsqueeze_default_16, [1, 2, 0, 4, 3]);  unsqueeze_default_16 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(view_default_7, -1);  view_default_7 = None
        permute_default_21 = torch.ops.aten.permute.default(unsqueeze_default_17, [1, 2, 4, 0, 3]);  unsqueeze_default_17 = None
        permute_default_22 = torch.ops.aten.permute.default(permute_default_20, [0, 1, 2, 4, 3]);  permute_default_20 = None
        view_default_16 = torch.ops.aten.view.default(permute_default_22, [32, 512, 64]);  permute_default_22 = None
        permute_default_23 = torch.ops.aten.permute.default(permute_default_21, [0, 1, 4, 3, 2]);  permute_default_21 = None
        view_default_17 = torch.ops.aten.view.default(permute_default_23, [32, 64, 512]);  permute_default_23 = None
        bmm_default_4 = torch.ops.aten.bmm.default(view_default_16, view_default_17)
        view_default_18 = torch.ops.aten.view.default(bmm_default_4, [2, 16, 512, 1, 512]);  bmm_default_4 = None
        permute_default_24 = torch.ops.aten.permute.default(view_default_18, [0, 1, 2, 4, 3]);  view_default_18 = None
        view_default_19 = torch.ops.aten.view.default(permute_default_24, [2, 16, 512, 512]);  permute_default_24 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_3, primals_13);  view_default_3 = primals_13 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(add_tensor_1, -1);  add_tensor_1 = None
        permute_default_25 = torch.ops.aten.permute.default(unsqueeze_default_18, [1, 2, 0, 4, 3]);  unsqueeze_default_18 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(view_default_15, -1);  view_default_15 = None
        permute_default_26 = torch.ops.aten.permute.default(unsqueeze_default_19, [1, 2, 4, 0, 3]);  unsqueeze_default_19 = None
        permute_default_27 = torch.ops.aten.permute.default(permute_default_25, [0, 1, 2, 4, 3]);  permute_default_25 = None
        view_default_20 = torch.ops.aten.view.default(permute_default_27, [32, 512, 64]);  permute_default_27 = None
        permute_default_28 = torch.ops.aten.permute.default(permute_default_26, [0, 1, 4, 3, 2]);  permute_default_26 = None
        view_default_21 = torch.ops.aten.view.default(permute_default_28, [32, 64, 1024]);  permute_default_28 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_20, view_default_21)
        view_default_22 = torch.ops.aten.view.default(bmm_default_5, [2, 16, 512, 1, 1024]);  bmm_default_5 = None
        permute_default_29 = torch.ops.aten.permute.default(view_default_22, [0, 1, 2, 4, 3]);  view_default_22 = None
        view_default_23 = torch.ops.aten.view.default(permute_default_29, [2, 16, 512, 1024]);  permute_default_29 = None
        view_default_24 = torch.ops.aten.view.default(view_default_23, [2, 16, 1024, 512]);  view_default_23 = None
        slice_tensor = torch.ops.aten.slice.Tensor(view_default_24, 0, 0, 9223372036854775807);  view_default_24 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 9223372036854775807);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 1, 9223372036854775807);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 9223372036854775807);  slice_tensor_2 = None
        view_default_25 = torch.ops.aten.view.default(slice_tensor_3, [2, 16, 512, 1023]);  slice_tensor_3 = None
        arange = torch.ops.aten.arange.default(512, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        index_select_default = torch.ops.aten.index_select.default(view_default_25, 3, arange);  view_default_25 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_19, index_select_default);  view_default_19 = index_select_default = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, 0);  add_tensor_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(add_tensor_3, 0.125);  add_tensor_3 = None
        permute_default_30 = torch.ops.aten.permute.default(primals_17, [2, 3, 0, 1]);  primals_17 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(permute_default_30, 1e+30);  permute_default_30 = None
        sub_tensor = torch.ops.aten.sub.Tensor(mul_tensor, mul_tensor_1);  mul_tensor = mul_tensor_1 = None
        _softmax_default = torch.ops.aten._softmax.default(sub_tensor, 3, False);  sub_tensor = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(_softmax_default, -1)
        permute_default_31 = torch.ops.aten.permute.default(unsqueeze_default_20, [2, 0, 1, 4, 3]);  unsqueeze_default_20 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(view_default_11, -1);  view_default_11 = None
        permute_default_32 = torch.ops.aten.permute.default(unsqueeze_default_21, [4, 1, 2, 3, 0]);  unsqueeze_default_21 = None
        permute_default_33 = torch.ops.aten.permute.default(permute_default_31, [1, 2, 0, 4, 3]);  permute_default_31 = None
        view_default_26 = torch.ops.aten.view.default(permute_default_33, [32, 512, 512]);  permute_default_33 = None
        permute_default_34 = torch.ops.aten.permute.default(permute_default_32, [1, 2, 4, 3, 0]);  permute_default_32 = None
        view_default_27 = torch.ops.aten.view.default(permute_default_34, [32, 512, 64]);  permute_default_34 = None
        bmm_default_6 = torch.ops.aten.bmm.default(view_default_26, view_default_27)
        view_default_28 = torch.ops.aten.view.default(bmm_default_6, [2, 16, 512, 1, 64]);  bmm_default_6 = None
        permute_default_35 = torch.ops.aten.permute.default(view_default_28, [2, 0, 1, 4, 3]);  view_default_28 = None
        view_default_29 = torch.ops.aten.view.default(permute_default_35, [512, 2, 16, 64]);  permute_default_35 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(view_default_29, -1);  view_default_29 = None
        permute_default_36 = torch.ops.aten.permute.default(unsqueeze_default_22, [0, 1, 4, 3, 2]);  unsqueeze_default_22 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(primals_10, -1);  primals_10 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(unsqueeze_default_23, -1);  unsqueeze_default_23 = None
        permute_default_37 = torch.ops.aten.permute.default(unsqueeze_default_24, [3, 4, 0, 2, 1]);  unsqueeze_default_24 = None
        permute_default_38 = torch.ops.aten.permute.default(permute_default_36, [0, 1, 3, 4, 2]);  permute_default_36 = None
        clone_default = torch.ops.aten.clone.default(permute_default_38, memory_format = torch.contiguous_format);  permute_default_38 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [1, 1024, 1024]);  clone_default = None
        permute_default_39 = torch.ops.aten.permute.default(permute_default_37, [3, 4, 2, 0, 1]);  permute_default_37 = None
        clone_default_1 = torch.ops.aten.clone.default(permute_default_39, memory_format = torch.contiguous_format);  permute_default_39 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [1, 1024, 1024]);  clone_default_1 = None
        bmm_default_7 = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        view_default_30 = torch.ops.aten.view.default(bmm_default_7, [512, 2, 1, 1, 1024]);  bmm_default_7 = None
        permute_default_40 = torch.ops.aten.permute.default(view_default_30, [0, 1, 4, 2, 3]);  view_default_30 = None
        view_default_31 = torch.ops.aten.view.default(permute_default_40, [512, 2, 1024]);  permute_default_40 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(view_default_31, primals_16);  view_default_31 = primals_16 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_4, [1024], primals_9, primals_8, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_32 = torch.ops.aten.view.default(getitem, [1024, 1024])
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default_32, t_default);  primals_1 = None
        view_default_33 = torch.ops.aten.view.default(addmm_default, [512, 2, 4096]);  addmm_default = None
        gelu_default = torch.ops.aten.gelu.default(view_default_33)
        view_default_34 = torch.ops.aten.view.default(gelu_default, [1024, 4096]);  gelu_default = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, view_default_34, t_default_1);  primals_3 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_1, [512, 2, 1024]);  addmm_default_1 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(view_default_35, getitem);  view_default_35 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [1024], primals_6, primals_5, 1e-12)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        return [getitem_3, view_default_21, _unsafe_view_default_1, view_default_32, view_default_1, primals_9, view_default_34, view_default_8, primals_8, _softmax_default, primals_6, primals_5, t_default, getitem_2, view_default, t_default_1, view_default_16, view_default_33, view_default_20, add_tensor_4, arange, getitem_1, view_default_4, getitem_5, _unsafe_view_default, view_default_9, view_default_26, getitem_4, add_tensor_5, view_default_27, view_default_12, view_default_5, view_default_17]
        
