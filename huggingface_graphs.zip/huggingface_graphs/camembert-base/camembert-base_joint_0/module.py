
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/camembert-base/camembert-base_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, tangents_1):
        ne_scalar = torch.ops.aten.ne.Scalar(primals_6, 1)
        _to_copy_default = torch.ops.aten._to_copy.default(ne_scalar, dtype = torch.int32);  ne_scalar = None
        cumsum_default = torch.ops.aten.cumsum.default(_to_copy_default, 1)
        _to_copy_default_1 = torch.ops.aten._to_copy.default(cumsum_default, device = device(type='cuda', index=0), dtype = torch.int32, layout = torch.strided);  cumsum_default = None
        add_tensor = torch.ops.aten.add.Tensor(_to_copy_default_1, 0);  _to_copy_default_1 = None
        mul_tensor = torch.ops.aten.mul.Tensor(add_tensor, _to_copy_default);  add_tensor = _to_copy_default = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(mul_tensor, dtype = torch.int64);  mul_tensor = None
        add_tensor_1 = torch.ops.aten.add.Tensor(_to_copy_default_2, 1);  _to_copy_default_2 = None
        embedding_default = torch.ops.aten.embedding.default(primals_5, primals_6, 1);  primals_5 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_4, primals_7);  primals_4 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(embedding_default, embedding_default_1);  embedding_default = embedding_default_1 = None
        embedding_default_2 = torch.ops.aten.embedding.default(primals_3, add_tensor_1, 1);  primals_3 = None
        add__tensor = torch.ops.aten.add_.Tensor(add_tensor_2, embedding_default_2);  add_tensor_2 = embedding_default_2 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add__tensor, [768], primals_2, primals_1, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        is_same_size_default = torch.ops.aten.is_same_size.default(getitem, tangents_1)
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add__tensor, [768], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  tangents_1 = add__tensor = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_3 = native_layer_norm_backward_default[0]
        getitem_4 = native_layer_norm_backward_default[1]
        getitem_5 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(getitem_3, add_tensor_1, 514, 1, False);  add_tensor_1 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(getitem_3, primals_7, 1, -1, False);  primals_7 = None
        embedding_dense_backward_default_2 = torch.ops.aten.embedding_dense_backward.default(getitem_3, primals_6, 32005, 1, False);  getitem_3 = primals_6 = None
        return [getitem, getitem_5, getitem_4, embedding_dense_backward_default, embedding_dense_backward_default_1, embedding_dense_backward_default_2, None, None]
        
