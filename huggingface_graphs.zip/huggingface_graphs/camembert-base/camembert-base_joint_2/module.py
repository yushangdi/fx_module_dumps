
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/camembert-base/camembert-base_joint_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, tangents_1):
        view_default = torch.ops.aten.view.default(primals_7, [4096, 768]);  primals_7 = None
        t_default = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default = torch.ops.aten.addmm.default(primals_3, view_default, t_default);  primals_3 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [8, 512, 768]);  addmm_default = None
        gelu_default = torch.ops.aten.gelu.default(view_default_1)
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(gelu_default, [768], primals_6, primals_5, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [4096, 768]);  getitem = None
        t_default_1 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_1, view_default_2, t_default_1);  primals_1 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default_1, [8, 512, 32005]);  addmm_default_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(view_default_3, tangents_1)
        view_default_4 = torch.ops.aten.view.default(tangents_1, [4096, 32005]);  tangents_1 = None
        t_default_2 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default = torch.ops.aten.mm.default(view_default_4, t_default_2);  t_default_2 = None
        t_default_3 = torch.ops.aten.t.default(view_default_4)
        mm_default_1 = torch.ops.aten.mm.default(t_default_3, view_default_2);  t_default_3 = view_default_2 = None
        t_default_4 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_4, [0], True);  view_default_4 = None
        view_default_5 = torch.ops.aten.view.default(sum_dim_int_list, [32005]);  sum_dim_int_list = None
        t_default_5 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        view_default_6 = torch.ops.aten.view.default(mm_default, [8, 512, 768]);  mm_default = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(view_default_6, gelu_default, [768], getitem_1, getitem_2, primals_6, primals_5, [True, True, True]);  view_default_6 = gelu_default = getitem_1 = getitem_2 = primals_6 = primals_5 = None
        getitem_3 = native_layer_norm_backward_default[0]
        getitem_4 = native_layer_norm_backward_default[1]
        getitem_5 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        to_dtype = torch.ops.aten.to.dtype(getitem_3, torch.float32);  getitem_3 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_1, torch.float32);  view_default_1 = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor);  mul_tensor = None
        add_tensor = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(add_tensor, 0.5);  add_tensor = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor_2, -0.5);  mul_tensor_2 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_3);  mul_tensor_3 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_4);  to_dtype_1 = mul_tensor_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_1, mul_tensor_5);  mul_tensor_1 = mul_tensor_5 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_1);  to_dtype = add_tensor_1 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_6, torch.float32);  mul_tensor_6 = None
        view_default_7 = torch.ops.aten.view.default(to_dtype_2, [4096, 768]);  to_dtype_2 = None
        t_default_6 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_7, t_default_6);  t_default_6 = None
        t_default_7 = torch.ops.aten.t.default(view_default_7)
        mm_default_3 = torch.ops.aten.mm.default(t_default_7, view_default);  t_default_7 = view_default = None
        t_default_8 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_7, [0], True);  view_default_7 = None
        view_default_8 = torch.ops.aten.view.default(sum_dim_int_list_1, [768]);  sum_dim_int_list_1 = None
        t_default_9 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        view_default_9 = torch.ops.aten.view.default(mm_default_2, [8, 512, 768]);  mm_default_2 = None
        return [view_default_3, view_default_5, t_default_5, view_default_8, t_default_9, getitem_5, getitem_4, view_default_9]
        
