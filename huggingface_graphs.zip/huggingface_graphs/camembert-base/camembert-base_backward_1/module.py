
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/camembert-base/camembert-base_backward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, getitem_14, view_default, getitem_41, view_default_175, view_default_145, _softmax_default_7, primals_2, t_default_41, view_default_2, _unsafe_view_default_41, t_default_49, t_default_16, view_default_119, add_tensor_25, getitem_13, view_default_26, _softmax_default_8, view_default_45, getitem_40, _unsafe_view_default_43, t_default_15, t_default, view_default_47, t_default_50, _unsafe_view_default_40, t_default_1, _unsafe_view_default_13, t_default_42, t_default_48, _unsafe_view_default_35, view_default_116, getitem_47, getitem_46, add_tensor_13, _unsafe_view_default_56, view_default_77, view_default_151, getitem_38, view_default_172, _unsafe_view_default_58, getitem_37, view_default_167, t_default_47, _unsafe_view_default_53, _softmax_default_10, t_default_14, getitem_58, t_default_62, t_default_59, getitem_55, getitem_56, add_tensor_4, primals_33, primals_161, _unsafe_view_default_10, primals_162, view_default_179, view_default_115, primals_157, primals_30, view_default_43, view_default_39, view_default_133, t_default_60, t_default_40, primals_146, t_default_58, t_default_61, primals_29, _unsafe_view_default_51, add_tensor_31, view_default_181, primals_34, view_default_5, view_default_136, view_default_170, view_default_121, view_default_185, t_default_39, view_default_124, _softmax_default, primals_158, _softmax_default_2, getitem_59, view_default_65, getitem_29, primals_62, primals_94, primals_93, view_default_66, t_default_34, getitem_71, t_default_23, getitem_67, primals_66, t_default_71, getitem_70, primals_65, primals_61, view_default_99, getitem_68, add_tensor_11, view_default_68, view_default_201, primals_125, t_default_70, view_default_70, t_default_68, getitem_23, _unsafe_view_default_31, view_default_162, primals_17, getitem_8, view_default_198, view_default_196, primals_49, _softmax_default_4, add_tensor_34, t_default_24, t_default_25, getitem_7, view_default_141, add_tensor_28, primals_14, t_default_26, primals_50, view_default_104, primals_78, add_tensor_5, t_default_37, add_tensor_35, view_default_32, getitem_22, primals_46, view_default_73, t_default_57, primals_18, primals_13, view_default_200, t_default_56, t_default_10, view_default_31, _softmax_default_6, t_default_69, view_default_164, _unsafe_view_default_50, view_default_166, primals_77, primals_141, t_default_63, primals_142, t_default_52, getitem_25, _unsafe_view_default_28, primals_126, view_default_202, view_default_81, add_tensor_20, view_default_158, _unsafe_view_default_6, t_default_33, _unsafe_view_default_36, view_default_15, getitem_62, primals_45, _unsafe_view_default_11, _unsafe_view_default_5, view_default_96, primals_129, _unsafe_view_default_26, getitem_61, _unsafe_view_default_8, getitem_26, getitem_31, t_default_64, _unsafe_view_default_55, primals_130, view_default_17, view_default_28, view_default_183, add_tensor_2, view_default_98, t_default_27, t_default_5, view_default_79, getitem_32, _unsafe_view_default_25, view_default_184, view_default_189, add_tensor_32, primals_145, t_default_22, primals_190, view_default_34, view_default_30, _softmax_default_5, getitem_44, t_default_36, t_default_66, add_tensor_19, view_default_87, add_tensor_16, view_default_107, getitem_20, getitem_5, add_tensor_17, view_default_138, primals_173, add_tensor_23, t_default_32, getitem_65, getitem_4, getitem_34, getitem_35, primals_189, getitem_19, view_default_111, add_tensor_7, view_default_22, t_default_8, _softmax_default_11, t_default_21, getitem_10, view_default_100, t_default_9, view_default_117, t_default_65, primals_177, primals_174, t_default_7, t_default_31, getitem_43, _unsafe_view_default_33, view_default_187, _softmax_default_1, view_default_90, t_default_46, _unsafe_view_default_18, t_default_11, t_default_67, view_default_19, view_default_62, primals_178, t_default_45, t_default_6, view_default_64, view_default_102, t_default_38, _unsafe_view_default_30, view_default_192, getitem_64, t_default_35, view_default_113, view_default_153, getitem_50, view_default_128, view_default_155, _unsafe_view_default_38, t_default_51, view_default_149, getitem_49, t_default_43, add_tensor_22, view_default_130, _unsafe_view_default_46, view_default_132, add_tensor_26, t_default_44, view_default_134, view_default_147, view_default_94, primals_98, _unsafe_view_default_1, view_default_49, primals_113, view_default_9, _unsafe_view_default, view_default_53, t_default_53, view_default_150, getitem_11, t_default_28, _softmax_default_9, view_default_36, _softmax_default_3, view_default_51, getitem_17, _unsafe_view_default_23, add_tensor_10, _unsafe_view_default_21, _unsafe_view_default_48, primals_109, _unsafe_view_default_3, t_default_13, _unsafe_view_default_16, view_default_83, getitem_16, view_default_168, view_default_56, add_tensor_29, primals_81, view_default_13, _unsafe_view_default_45, view_default_60, t_default_55, view_default_82, view_default_48, getitem_53, primals_82, t_default_4, primals_110, getitem_1, add_tensor_8, _unsafe_view_default_15, getitem_28, t_default_19, primals_114, getitem_2, t_default_18, primals_97, view_default_11, t_default_17, t_default_12, view_default_85, getitem_52, add_tensor_14, t_default_30, view_default_14, t_default_29, add_tensor_1, t_default_20, _unsafe_view_default_20, t_default_54, t_default_2, t_default_3, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_35, [768], getitem_70, getitem_71, primals_46, primals_45, [True, True, True]);  tangents_1 = add_tensor_35 = getitem_70 = getitem_71 = primals_46 = primals_45 = None
        getitem_72 = native_layer_norm_backward_default[0]
        getitem_73 = native_layer_norm_backward_default[1]
        getitem_74 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_204 = torch.ops.aten.view.default(getitem_72, [4096, 768])
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default = torch.ops.aten.mm.default(view_default_204, t_default_72);  t_default_72 = None
        t_default_73 = torch.ops.aten.t.default(view_default_204)
        mm_default_1 = torch.ops.aten.mm.default(t_default_73, view_default_202);  t_default_73 = view_default_202 = None
        t_default_74 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_204, [0], True);  view_default_204 = None
        view_default_205 = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        t_default_75 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        view_default_206 = torch.ops.aten.view.default(mm_default, [8, 512, 3072]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_206, torch.float32);  view_default_206 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_201, torch.float32);  view_default_201 = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor);  mul_tensor = None
        add_tensor_36 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(add_tensor_36, 0.5);  add_tensor_36 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor_2, -0.5);  mul_tensor_2 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_3);  mul_tensor_3 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_4);  to_dtype_1 = mul_tensor_4 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(mul_tensor_1, mul_tensor_5);  mul_tensor_1 = mul_tensor_5 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_37);  to_dtype = add_tensor_37 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_6, torch.float32);  mul_tensor_6 = None
        view_default_207 = torch.ops.aten.view.default(to_dtype_2, [4096, 3072]);  to_dtype_2 = None
        t_default_76 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_207, t_default_76);  t_default_76 = None
        t_default_77 = torch.ops.aten.t.default(view_default_207)
        mm_default_3 = torch.ops.aten.mm.default(t_default_77, view_default_200);  t_default_77 = view_default_200 = None
        t_default_78 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_207, [0], True);  view_default_207 = None
        view_default_208 = torch.ops.aten.view.default(sum_dim_int_list_1, [3072]);  sum_dim_int_list_1 = None
        t_default_79 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        view_default_209 = torch.ops.aten.view.default(mm_default_2, [8, 512, 768]);  mm_default_2 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_72, view_default_209);  getitem_72 = view_default_209 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_38, add_tensor_34, [768], getitem_67, getitem_68, primals_34, primals_33, [True, True, True]);  add_tensor_38 = add_tensor_34 = getitem_67 = getitem_68 = primals_34 = primals_33 = None
        getitem_75 = native_layer_norm_backward_default_1[0]
        getitem_76 = native_layer_norm_backward_default_1[1]
        getitem_77 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_210 = torch.ops.aten.view.default(getitem_75, [4096, 768])
        t_default_80 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_210, t_default_80);  t_default_80 = None
        t_default_81 = torch.ops.aten.t.default(view_default_210)
        mm_default_5 = torch.ops.aten.mm.default(t_default_81, view_default_198);  t_default_81 = view_default_198 = None
        t_default_82 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_210, [0], True);  view_default_210 = None
        view_default_211 = torch.ops.aten.view.default(sum_dim_int_list_2, [768]);  sum_dim_int_list_2 = None
        t_default_83 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        view_default_212 = torch.ops.aten.view.default(mm_default_4, [8, 512, 768]);  mm_default_4 = None
        view_default_213 = torch.ops.aten.view.default(view_default_212, [8, 512, 12, 64]);  view_default_212 = None
        permute_default_48 = torch.ops.aten.permute.default(view_default_213, [0, 2, 1, 3]);  view_default_213 = None
        clone_default_48 = torch.ops.aten.clone.default(permute_default_48, memory_format = torch.contiguous_format);  permute_default_48 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_48, [96, 512, 64]);  clone_default_48 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_196, 1, 2);  view_default_196 = None
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_12, _unsafe_view_default_60);  transpose_int_12 = None
        transpose_int_13 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_unsafe_view_default_60, transpose_int_13);  _unsafe_view_default_60 = transpose_int_13 = None
        view_default_214 = torch.ops.aten.view.default(bmm_default_24, [8, 12, 512, 64]);  bmm_default_24 = None
        view_default_215 = torch.ops.aten.view.default(bmm_default_25, [8, 12, 512, 512]);  bmm_default_25 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_215, _softmax_default_11, -1, torch.float32);  view_default_215 = _softmax_default_11 = None
        div_tensor_12 = torch.ops.aten.div.Tensor(_softmax_backward_data_default, 8.0);  _softmax_backward_data_default = None
        view_default_216 = torch.ops.aten.view.default(div_tensor_12, [96, 512, 512]);  div_tensor_12 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_55, 1, 2);  _unsafe_view_default_55 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_14, view_default_216);  transpose_int_14 = None
        transpose_int_15 = torch.ops.aten.transpose.int(_unsafe_view_default_56, 1, 2);  _unsafe_view_default_56 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_216, transpose_int_15);  view_default_216 = transpose_int_15 = None
        view_default_217 = torch.ops.aten.view.default(bmm_default_26, [8, 12, 64, 512]);  bmm_default_26 = None
        view_default_218 = torch.ops.aten.view.default(bmm_default_27, [8, 12, 512, 64]);  bmm_default_27 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_217, -1, -2);  view_default_217 = None
        permute_default_49 = torch.ops.aten.permute.default(view_default_218, [0, 2, 1, 3]);  view_default_218 = None
        clone_default_49 = torch.ops.aten.clone.default(permute_default_49, memory_format = torch.contiguous_format);  permute_default_49 = None
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(clone_default_49, [8, 512, 768]);  clone_default_49 = None
        permute_default_50 = torch.ops.aten.permute.default(view_default_214, [0, 2, 1, 3]);  view_default_214 = None
        clone_default_50 = torch.ops.aten.clone.default(permute_default_50, memory_format = torch.contiguous_format);  permute_default_50 = None
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(clone_default_50, [8, 512, 768]);  clone_default_50 = None
        view_default_219 = torch.ops.aten.view.default(_unsafe_view_default_62, [4096, 768]);  _unsafe_view_default_62 = None
        t_default_84 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_219, t_default_84);  t_default_84 = None
        t_default_85 = torch.ops.aten.t.default(view_default_219)
        mm_default_7 = torch.ops.aten.mm.default(t_default_85, view_default_192);  t_default_85 = view_default_192 = None
        t_default_86 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_219, [0], True);  view_default_219 = None
        view_default_220 = torch.ops.aten.view.default(sum_dim_int_list_3, [768]);  sum_dim_int_list_3 = None
        t_default_87 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        view_default_221 = torch.ops.aten.view.default(mm_default_6, [8, 512, 768]);  mm_default_6 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_75, view_default_221);  getitem_75 = view_default_221 = None
        permute_default_51 = torch.ops.aten.permute.default(transpose_int_16, [0, 2, 1, 3]);  transpose_int_16 = None
        view_default_222 = torch.ops.aten.view.default(permute_default_51, [8, 512, 768]);  permute_default_51 = None
        clone_default_51 = torch.ops.aten.clone.default(view_default_222, memory_format = torch.contiguous_format);  view_default_222 = None
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(clone_default_51, [4096, 768]);  clone_default_51 = None
        t_default_88 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_8 = torch.ops.aten.mm.default(_unsafe_view_default_63, t_default_88);  t_default_88 = None
        t_default_89 = torch.ops.aten.t.default(_unsafe_view_default_63)
        mm_default_9 = torch.ops.aten.mm.default(t_default_89, view_default_189);  t_default_89 = view_default_189 = None
        t_default_90 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_63, [0], True);  _unsafe_view_default_63 = None
        view_default_223 = torch.ops.aten.view.default(sum_dim_int_list_4, [768]);  sum_dim_int_list_4 = None
        t_default_91 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        view_default_224 = torch.ops.aten.view.default(mm_default_8, [8, 512, 768]);  mm_default_8 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, view_default_224);  add_tensor_39 = view_default_224 = None
        view_default_225 = torch.ops.aten.view.default(_unsafe_view_default_61, [4096, 768]);  _unsafe_view_default_61 = None
        t_default_92 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_225, t_default_92);  t_default_92 = None
        t_default_93 = torch.ops.aten.t.default(view_default_225)
        mm_default_11 = torch.ops.aten.mm.default(t_default_93, view_default_187);  t_default_93 = view_default_187 = None
        t_default_94 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_225, [0], True);  view_default_225 = None
        view_default_226 = torch.ops.aten.view.default(sum_dim_int_list_5, [768]);  sum_dim_int_list_5 = None
        t_default_95 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        view_default_227 = torch.ops.aten.view.default(mm_default_10, [8, 512, 768]);  mm_default_10 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, view_default_227);  add_tensor_40 = view_default_227 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_41, add_tensor_32, [768], getitem_64, getitem_65, primals_30, primals_29, [True, True, True]);  add_tensor_41 = add_tensor_32 = getitem_64 = getitem_65 = primals_30 = primals_29 = None
        getitem_78 = native_layer_norm_backward_default_2[0]
        getitem_79 = native_layer_norm_backward_default_2[1]
        getitem_80 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_228 = torch.ops.aten.view.default(getitem_78, [4096, 768])
        t_default_96 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_228, t_default_96);  t_default_96 = None
        t_default_97 = torch.ops.aten.t.default(view_default_228)
        mm_default_13 = torch.ops.aten.mm.default(t_default_97, view_default_185);  t_default_97 = view_default_185 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_228, [0], True);  view_default_228 = None
        view_default_229 = torch.ops.aten.view.default(sum_dim_int_list_6, [768]);  sum_dim_int_list_6 = None
        t_default_99 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        view_default_230 = torch.ops.aten.view.default(mm_default_12, [8, 512, 3072]);  mm_default_12 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_230, torch.float32);  view_default_230 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_184, torch.float32);  view_default_184 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_7);  mul_tensor_7 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(add_tensor_42, 0.5);  add_tensor_42 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(mul_tensor_9, -0.5);  mul_tensor_9 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_10);  mul_tensor_10 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_11);  to_dtype_4 = mul_tensor_11 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(mul_tensor_8, mul_tensor_12);  mul_tensor_8 = mul_tensor_12 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_43);  to_dtype_3 = add_tensor_43 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_13, torch.float32);  mul_tensor_13 = None
        view_default_231 = torch.ops.aten.view.default(to_dtype_5, [4096, 3072]);  to_dtype_5 = None
        t_default_100 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_231, t_default_100);  t_default_100 = None
        t_default_101 = torch.ops.aten.t.default(view_default_231)
        mm_default_15 = torch.ops.aten.mm.default(t_default_101, view_default_183);  t_default_101 = view_default_183 = None
        t_default_102 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_231, [0], True);  view_default_231 = None
        view_default_232 = torch.ops.aten.view.default(sum_dim_int_list_7, [3072]);  sum_dim_int_list_7 = None
        t_default_103 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        view_default_233 = torch.ops.aten.view.default(mm_default_14, [8, 512, 768]);  mm_default_14 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_78, view_default_233);  getitem_78 = view_default_233 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_44, add_tensor_31, [768], getitem_61, getitem_62, primals_18, primals_17, [True, True, True]);  add_tensor_44 = add_tensor_31 = getitem_61 = getitem_62 = primals_18 = primals_17 = None
        getitem_81 = native_layer_norm_backward_default_3[0]
        getitem_82 = native_layer_norm_backward_default_3[1]
        getitem_83 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        view_default_234 = torch.ops.aten.view.default(getitem_81, [4096, 768])
        t_default_104 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_234, t_default_104);  t_default_104 = None
        t_default_105 = torch.ops.aten.t.default(view_default_234)
        mm_default_17 = torch.ops.aten.mm.default(t_default_105, view_default_181);  t_default_105 = view_default_181 = None
        t_default_106 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_234, [0], True);  view_default_234 = None
        view_default_235 = torch.ops.aten.view.default(sum_dim_int_list_8, [768]);  sum_dim_int_list_8 = None
        t_default_107 = torch.ops.aten.t.default(t_default_106);  t_default_106 = None
        view_default_236 = torch.ops.aten.view.default(mm_default_16, [8, 512, 768]);  mm_default_16 = None
        view_default_237 = torch.ops.aten.view.default(view_default_236, [8, 512, 12, 64]);  view_default_236 = None
        permute_default_52 = torch.ops.aten.permute.default(view_default_237, [0, 2, 1, 3]);  view_default_237 = None
        clone_default_52 = torch.ops.aten.clone.default(permute_default_52, memory_format = torch.contiguous_format);  permute_default_52 = None
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(clone_default_52, [96, 512, 64]);  clone_default_52 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_179, 1, 2);  view_default_179 = None
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_17, _unsafe_view_default_64);  transpose_int_17 = None
        transpose_int_18 = torch.ops.aten.transpose.int(_unsafe_view_default_53, 1, 2);  _unsafe_view_default_53 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_unsafe_view_default_64, transpose_int_18);  _unsafe_view_default_64 = transpose_int_18 = None
        view_default_238 = torch.ops.aten.view.default(bmm_default_28, [8, 12, 512, 64]);  bmm_default_28 = None
        view_default_239 = torch.ops.aten.view.default(bmm_default_29, [8, 12, 512, 512]);  bmm_default_29 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_239, _softmax_default_10, -1, torch.float32);  view_default_239 = _softmax_default_10 = None
        div_tensor_13 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_1, 8.0);  _softmax_backward_data_default_1 = None
        view_default_240 = torch.ops.aten.view.default(div_tensor_13, [96, 512, 512]);  div_tensor_13 = None
        transpose_int_19 = torch.ops.aten.transpose.int(_unsafe_view_default_50, 1, 2);  _unsafe_view_default_50 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_19, view_default_240);  transpose_int_19 = None
        transpose_int_20 = torch.ops.aten.transpose.int(_unsafe_view_default_51, 1, 2);  _unsafe_view_default_51 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_240, transpose_int_20);  view_default_240 = transpose_int_20 = None
        view_default_241 = torch.ops.aten.view.default(bmm_default_30, [8, 12, 64, 512]);  bmm_default_30 = None
        view_default_242 = torch.ops.aten.view.default(bmm_default_31, [8, 12, 512, 64]);  bmm_default_31 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_241, -1, -2);  view_default_241 = None
        permute_default_53 = torch.ops.aten.permute.default(view_default_242, [0, 2, 1, 3]);  view_default_242 = None
        clone_default_53 = torch.ops.aten.clone.default(permute_default_53, memory_format = torch.contiguous_format);  permute_default_53 = None
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(clone_default_53, [8, 512, 768]);  clone_default_53 = None
        permute_default_54 = torch.ops.aten.permute.default(view_default_238, [0, 2, 1, 3]);  view_default_238 = None
        clone_default_54 = torch.ops.aten.clone.default(permute_default_54, memory_format = torch.contiguous_format);  permute_default_54 = None
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(clone_default_54, [8, 512, 768]);  clone_default_54 = None
        view_default_243 = torch.ops.aten.view.default(_unsafe_view_default_66, [4096, 768]);  _unsafe_view_default_66 = None
        t_default_108 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_243, t_default_108);  t_default_108 = None
        t_default_109 = torch.ops.aten.t.default(view_default_243)
        mm_default_19 = torch.ops.aten.mm.default(t_default_109, view_default_175);  t_default_109 = view_default_175 = None
        t_default_110 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_243, [0], True);  view_default_243 = None
        view_default_244 = torch.ops.aten.view.default(sum_dim_int_list_9, [768]);  sum_dim_int_list_9 = None
        t_default_111 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        view_default_245 = torch.ops.aten.view.default(mm_default_18, [8, 512, 768]);  mm_default_18 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_81, view_default_245);  getitem_81 = view_default_245 = None
        permute_default_55 = torch.ops.aten.permute.default(transpose_int_21, [0, 2, 1, 3]);  transpose_int_21 = None
        view_default_246 = torch.ops.aten.view.default(permute_default_55, [8, 512, 768]);  permute_default_55 = None
        clone_default_55 = torch.ops.aten.clone.default(view_default_246, memory_format = torch.contiguous_format);  view_default_246 = None
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(clone_default_55, [4096, 768]);  clone_default_55 = None
        t_default_112 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_20 = torch.ops.aten.mm.default(_unsafe_view_default_67, t_default_112);  t_default_112 = None
        t_default_113 = torch.ops.aten.t.default(_unsafe_view_default_67)
        mm_default_21 = torch.ops.aten.mm.default(t_default_113, view_default_172);  t_default_113 = view_default_172 = None
        t_default_114 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_67, [0], True);  _unsafe_view_default_67 = None
        view_default_247 = torch.ops.aten.view.default(sum_dim_int_list_10, [768]);  sum_dim_int_list_10 = None
        t_default_115 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        view_default_248 = torch.ops.aten.view.default(mm_default_20, [8, 512, 768]);  mm_default_20 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, view_default_248);  add_tensor_45 = view_default_248 = None
        view_default_249 = torch.ops.aten.view.default(_unsafe_view_default_65, [4096, 768]);  _unsafe_view_default_65 = None
        t_default_116 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_249, t_default_116);  t_default_116 = None
        t_default_117 = torch.ops.aten.t.default(view_default_249)
        mm_default_23 = torch.ops.aten.mm.default(t_default_117, view_default_170);  t_default_117 = view_default_170 = None
        t_default_118 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_249, [0], True);  view_default_249 = None
        view_default_250 = torch.ops.aten.view.default(sum_dim_int_list_11, [768]);  sum_dim_int_list_11 = None
        t_default_119 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        view_default_251 = torch.ops.aten.view.default(mm_default_22, [8, 512, 768]);  mm_default_22 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_46, view_default_251);  add_tensor_46 = view_default_251 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_47, add_tensor_29, [768], getitem_58, getitem_59, primals_190, primals_189, [True, True, True]);  add_tensor_47 = add_tensor_29 = getitem_58 = getitem_59 = primals_190 = primals_189 = None
        getitem_84 = native_layer_norm_backward_default_4[0]
        getitem_85 = native_layer_norm_backward_default_4[1]
        getitem_86 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_252 = torch.ops.aten.view.default(getitem_84, [4096, 768])
        t_default_120 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_252, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_252)
        mm_default_25 = torch.ops.aten.mm.default(t_default_121, view_default_168);  t_default_121 = view_default_168 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_252, [0], True);  view_default_252 = None
        view_default_253 = torch.ops.aten.view.default(sum_dim_int_list_12, [768]);  sum_dim_int_list_12 = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_254 = torch.ops.aten.view.default(mm_default_24, [8, 512, 3072]);  mm_default_24 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_254, torch.float32);  view_default_254 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_167, torch.float32);  view_default_167 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_14);  mul_tensor_14 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(add_tensor_48, 0.5);  add_tensor_48 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_17 = torch.ops.aten.mul.Tensor(mul_tensor_16, -0.5);  mul_tensor_16 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_17);  mul_tensor_17 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_18);  to_dtype_7 = mul_tensor_18 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(mul_tensor_15, mul_tensor_19);  mul_tensor_15 = mul_tensor_19 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_49);  to_dtype_6 = add_tensor_49 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_20, torch.float32);  mul_tensor_20 = None
        view_default_255 = torch.ops.aten.view.default(to_dtype_8, [4096, 3072]);  to_dtype_8 = None
        t_default_124 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_255, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(view_default_255)
        mm_default_27 = torch.ops.aten.mm.default(t_default_125, view_default_166);  t_default_125 = view_default_166 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_255, [0], True);  view_default_255 = None
        view_default_256 = torch.ops.aten.view.default(sum_dim_int_list_13, [3072]);  sum_dim_int_list_13 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_257 = torch.ops.aten.view.default(mm_default_26, [8, 512, 768]);  mm_default_26 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(getitem_84, view_default_257);  getitem_84 = view_default_257 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_50, add_tensor_28, [768], getitem_55, getitem_56, primals_178, primals_177, [True, True, True]);  add_tensor_50 = add_tensor_28 = getitem_55 = getitem_56 = primals_178 = primals_177 = None
        getitem_87 = native_layer_norm_backward_default_5[0]
        getitem_88 = native_layer_norm_backward_default_5[1]
        getitem_89 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_258 = torch.ops.aten.view.default(getitem_87, [4096, 768])
        t_default_128 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_258, t_default_128);  t_default_128 = None
        t_default_129 = torch.ops.aten.t.default(view_default_258)
        mm_default_29 = torch.ops.aten.mm.default(t_default_129, view_default_164);  t_default_129 = view_default_164 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_258, [0], True);  view_default_258 = None
        view_default_259 = torch.ops.aten.view.default(sum_dim_int_list_14, [768]);  sum_dim_int_list_14 = None
        t_default_131 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_260 = torch.ops.aten.view.default(mm_default_28, [8, 512, 768]);  mm_default_28 = None
        view_default_261 = torch.ops.aten.view.default(view_default_260, [8, 512, 12, 64]);  view_default_260 = None
        permute_default_56 = torch.ops.aten.permute.default(view_default_261, [0, 2, 1, 3]);  view_default_261 = None
        clone_default_56 = torch.ops.aten.clone.default(permute_default_56, memory_format = torch.contiguous_format);  permute_default_56 = None
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(clone_default_56, [96, 512, 64]);  clone_default_56 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_162, 1, 2);  view_default_162 = None
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_22, _unsafe_view_default_68);  transpose_int_22 = None
        transpose_int_23 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_unsafe_view_default_68, transpose_int_23);  _unsafe_view_default_68 = transpose_int_23 = None
        view_default_262 = torch.ops.aten.view.default(bmm_default_32, [8, 12, 512, 64]);  bmm_default_32 = None
        view_default_263 = torch.ops.aten.view.default(bmm_default_33, [8, 12, 512, 512]);  bmm_default_33 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_263, _softmax_default_9, -1, torch.float32);  view_default_263 = _softmax_default_9 = None
        div_tensor_14 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_2, 8.0);  _softmax_backward_data_default_2 = None
        view_default_264 = torch.ops.aten.view.default(div_tensor_14, [96, 512, 512]);  div_tensor_14 = None
        transpose_int_24 = torch.ops.aten.transpose.int(_unsafe_view_default_45, 1, 2);  _unsafe_view_default_45 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_24, view_default_264);  transpose_int_24 = None
        transpose_int_25 = torch.ops.aten.transpose.int(_unsafe_view_default_46, 1, 2);  _unsafe_view_default_46 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_264, transpose_int_25);  view_default_264 = transpose_int_25 = None
        view_default_265 = torch.ops.aten.view.default(bmm_default_34, [8, 12, 64, 512]);  bmm_default_34 = None
        view_default_266 = torch.ops.aten.view.default(bmm_default_35, [8, 12, 512, 64]);  bmm_default_35 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_265, -1, -2);  view_default_265 = None
        permute_default_57 = torch.ops.aten.permute.default(view_default_266, [0, 2, 1, 3]);  view_default_266 = None
        clone_default_57 = torch.ops.aten.clone.default(permute_default_57, memory_format = torch.contiguous_format);  permute_default_57 = None
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(clone_default_57, [8, 512, 768]);  clone_default_57 = None
        permute_default_58 = torch.ops.aten.permute.default(view_default_262, [0, 2, 1, 3]);  view_default_262 = None
        clone_default_58 = torch.ops.aten.clone.default(permute_default_58, memory_format = torch.contiguous_format);  permute_default_58 = None
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(clone_default_58, [8, 512, 768]);  clone_default_58 = None
        view_default_267 = torch.ops.aten.view.default(_unsafe_view_default_70, [4096, 768]);  _unsafe_view_default_70 = None
        t_default_132 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_267, t_default_132);  t_default_132 = None
        t_default_133 = torch.ops.aten.t.default(view_default_267)
        mm_default_31 = torch.ops.aten.mm.default(t_default_133, view_default_158);  t_default_133 = view_default_158 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_267, [0], True);  view_default_267 = None
        view_default_268 = torch.ops.aten.view.default(sum_dim_int_list_15, [768]);  sum_dim_int_list_15 = None
        t_default_135 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        view_default_269 = torch.ops.aten.view.default(mm_default_30, [8, 512, 768]);  mm_default_30 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(getitem_87, view_default_269);  getitem_87 = view_default_269 = None
        permute_default_59 = torch.ops.aten.permute.default(transpose_int_26, [0, 2, 1, 3]);  transpose_int_26 = None
        view_default_270 = torch.ops.aten.view.default(permute_default_59, [8, 512, 768]);  permute_default_59 = None
        clone_default_59 = torch.ops.aten.clone.default(view_default_270, memory_format = torch.contiguous_format);  view_default_270 = None
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(clone_default_59, [4096, 768]);  clone_default_59 = None
        t_default_136 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_32 = torch.ops.aten.mm.default(_unsafe_view_default_71, t_default_136);  t_default_136 = None
        t_default_137 = torch.ops.aten.t.default(_unsafe_view_default_71)
        mm_default_33 = torch.ops.aten.mm.default(t_default_137, view_default_155);  t_default_137 = view_default_155 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_71, [0], True);  _unsafe_view_default_71 = None
        view_default_271 = torch.ops.aten.view.default(sum_dim_int_list_16, [768]);  sum_dim_int_list_16 = None
        t_default_139 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        view_default_272 = torch.ops.aten.view.default(mm_default_32, [8, 512, 768]);  mm_default_32 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, view_default_272);  add_tensor_51 = view_default_272 = None
        view_default_273 = torch.ops.aten.view.default(_unsafe_view_default_69, [4096, 768]);  _unsafe_view_default_69 = None
        t_default_140 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_273, t_default_140);  t_default_140 = None
        t_default_141 = torch.ops.aten.t.default(view_default_273)
        mm_default_35 = torch.ops.aten.mm.default(t_default_141, view_default_153);  t_default_141 = view_default_153 = None
        t_default_142 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_273, [0], True);  view_default_273 = None
        view_default_274 = torch.ops.aten.view.default(sum_dim_int_list_17, [768]);  sum_dim_int_list_17 = None
        t_default_143 = torch.ops.aten.t.default(t_default_142);  t_default_142 = None
        view_default_275 = torch.ops.aten.view.default(mm_default_34, [8, 512, 768]);  mm_default_34 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(add_tensor_52, view_default_275);  add_tensor_52 = view_default_275 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_53, add_tensor_26, [768], getitem_52, getitem_53, primals_174, primals_173, [True, True, True]);  add_tensor_53 = add_tensor_26 = getitem_52 = getitem_53 = primals_174 = primals_173 = None
        getitem_90 = native_layer_norm_backward_default_6[0]
        getitem_91 = native_layer_norm_backward_default_6[1]
        getitem_92 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_276 = torch.ops.aten.view.default(getitem_90, [4096, 768])
        t_default_144 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_276, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_276)
        mm_default_37 = torch.ops.aten.mm.default(t_default_145, view_default_151);  t_default_145 = view_default_151 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_276, [0], True);  view_default_276 = None
        view_default_277 = torch.ops.aten.view.default(sum_dim_int_list_18, [768]);  sum_dim_int_list_18 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_278 = torch.ops.aten.view.default(mm_default_36, [8, 512, 3072]);  mm_default_36 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_278, torch.float32);  view_default_278 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_150, torch.float32);  view_default_150 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_21);  mul_tensor_21 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(add_tensor_54, 0.5);  add_tensor_54 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_24 = torch.ops.aten.mul.Tensor(mul_tensor_23, -0.5);  mul_tensor_23 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_24);  mul_tensor_24 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_25);  to_dtype_10 = mul_tensor_25 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(mul_tensor_22, mul_tensor_26);  mul_tensor_22 = mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_55);  to_dtype_9 = add_tensor_55 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        view_default_279 = torch.ops.aten.view.default(to_dtype_11, [4096, 3072]);  to_dtype_11 = None
        t_default_148 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_279, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(view_default_279)
        mm_default_39 = torch.ops.aten.mm.default(t_default_149, view_default_149);  t_default_149 = view_default_149 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_279, [0], True);  view_default_279 = None
        view_default_280 = torch.ops.aten.view.default(sum_dim_int_list_19, [3072]);  sum_dim_int_list_19 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_281 = torch.ops.aten.view.default(mm_default_38, [8, 512, 768]);  mm_default_38 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_90, view_default_281);  getitem_90 = view_default_281 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_56, add_tensor_25, [768], getitem_49, getitem_50, primals_162, primals_161, [True, True, True]);  add_tensor_56 = add_tensor_25 = getitem_49 = getitem_50 = primals_162 = primals_161 = None
        getitem_93 = native_layer_norm_backward_default_7[0]
        getitem_94 = native_layer_norm_backward_default_7[1]
        getitem_95 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_282 = torch.ops.aten.view.default(getitem_93, [4096, 768])
        t_default_152 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_282, t_default_152);  t_default_152 = None
        t_default_153 = torch.ops.aten.t.default(view_default_282)
        mm_default_41 = torch.ops.aten.mm.default(t_default_153, view_default_147);  t_default_153 = view_default_147 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_282, [0], True);  view_default_282 = None
        view_default_283 = torch.ops.aten.view.default(sum_dim_int_list_20, [768]);  sum_dim_int_list_20 = None
        t_default_155 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_284 = torch.ops.aten.view.default(mm_default_40, [8, 512, 768]);  mm_default_40 = None
        view_default_285 = torch.ops.aten.view.default(view_default_284, [8, 512, 12, 64]);  view_default_284 = None
        permute_default_60 = torch.ops.aten.permute.default(view_default_285, [0, 2, 1, 3]);  view_default_285 = None
        clone_default_60 = torch.ops.aten.clone.default(permute_default_60, memory_format = torch.contiguous_format);  permute_default_60 = None
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(clone_default_60, [96, 512, 64]);  clone_default_60 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_145, 1, 2);  view_default_145 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_27, _unsafe_view_default_72);  transpose_int_27 = None
        transpose_int_28 = torch.ops.aten.transpose.int(_unsafe_view_default_43, 1, 2);  _unsafe_view_default_43 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_unsafe_view_default_72, transpose_int_28);  _unsafe_view_default_72 = transpose_int_28 = None
        view_default_286 = torch.ops.aten.view.default(bmm_default_36, [8, 12, 512, 64]);  bmm_default_36 = None
        view_default_287 = torch.ops.aten.view.default(bmm_default_37, [8, 12, 512, 512]);  bmm_default_37 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_287, _softmax_default_8, -1, torch.float32);  view_default_287 = _softmax_default_8 = None
        div_tensor_15 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_3, 8.0);  _softmax_backward_data_default_3 = None
        view_default_288 = torch.ops.aten.view.default(div_tensor_15, [96, 512, 512]);  div_tensor_15 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_40, 1, 2);  _unsafe_view_default_40 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_29, view_default_288);  transpose_int_29 = None
        transpose_int_30 = torch.ops.aten.transpose.int(_unsafe_view_default_41, 1, 2);  _unsafe_view_default_41 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_288, transpose_int_30);  view_default_288 = transpose_int_30 = None
        view_default_289 = torch.ops.aten.view.default(bmm_default_38, [8, 12, 64, 512]);  bmm_default_38 = None
        view_default_290 = torch.ops.aten.view.default(bmm_default_39, [8, 12, 512, 64]);  bmm_default_39 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_289, -1, -2);  view_default_289 = None
        permute_default_61 = torch.ops.aten.permute.default(view_default_290, [0, 2, 1, 3]);  view_default_290 = None
        clone_default_61 = torch.ops.aten.clone.default(permute_default_61, memory_format = torch.contiguous_format);  permute_default_61 = None
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(clone_default_61, [8, 512, 768]);  clone_default_61 = None
        permute_default_62 = torch.ops.aten.permute.default(view_default_286, [0, 2, 1, 3]);  view_default_286 = None
        clone_default_62 = torch.ops.aten.clone.default(permute_default_62, memory_format = torch.contiguous_format);  permute_default_62 = None
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(clone_default_62, [8, 512, 768]);  clone_default_62 = None
        view_default_291 = torch.ops.aten.view.default(_unsafe_view_default_74, [4096, 768]);  _unsafe_view_default_74 = None
        t_default_156 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_291, t_default_156);  t_default_156 = None
        t_default_157 = torch.ops.aten.t.default(view_default_291)
        mm_default_43 = torch.ops.aten.mm.default(t_default_157, view_default_141);  t_default_157 = view_default_141 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_291, [0], True);  view_default_291 = None
        view_default_292 = torch.ops.aten.view.default(sum_dim_int_list_21, [768]);  sum_dim_int_list_21 = None
        t_default_159 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        view_default_293 = torch.ops.aten.view.default(mm_default_42, [8, 512, 768]);  mm_default_42 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_93, view_default_293);  getitem_93 = view_default_293 = None
        permute_default_63 = torch.ops.aten.permute.default(transpose_int_31, [0, 2, 1, 3]);  transpose_int_31 = None
        view_default_294 = torch.ops.aten.view.default(permute_default_63, [8, 512, 768]);  permute_default_63 = None
        clone_default_63 = torch.ops.aten.clone.default(view_default_294, memory_format = torch.contiguous_format);  view_default_294 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_63, [4096, 768]);  clone_default_63 = None
        t_default_160 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_44 = torch.ops.aten.mm.default(_unsafe_view_default_75, t_default_160);  t_default_160 = None
        t_default_161 = torch.ops.aten.t.default(_unsafe_view_default_75)
        mm_default_45 = torch.ops.aten.mm.default(t_default_161, view_default_138);  t_default_161 = view_default_138 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_75, [0], True);  _unsafe_view_default_75 = None
        view_default_295 = torch.ops.aten.view.default(sum_dim_int_list_22, [768]);  sum_dim_int_list_22 = None
        t_default_163 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        view_default_296 = torch.ops.aten.view.default(mm_default_44, [8, 512, 768]);  mm_default_44 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_57, view_default_296);  add_tensor_57 = view_default_296 = None
        view_default_297 = torch.ops.aten.view.default(_unsafe_view_default_73, [4096, 768]);  _unsafe_view_default_73 = None
        t_default_164 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_297, t_default_164);  t_default_164 = None
        t_default_165 = torch.ops.aten.t.default(view_default_297)
        mm_default_47 = torch.ops.aten.mm.default(t_default_165, view_default_136);  t_default_165 = view_default_136 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_297, [0], True);  view_default_297 = None
        view_default_298 = torch.ops.aten.view.default(sum_dim_int_list_23, [768]);  sum_dim_int_list_23 = None
        t_default_167 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_299 = torch.ops.aten.view.default(mm_default_46, [8, 512, 768]);  mm_default_46 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(add_tensor_58, view_default_299);  add_tensor_58 = view_default_299 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_59, add_tensor_23, [768], getitem_46, getitem_47, primals_158, primals_157, [True, True, True]);  add_tensor_59 = add_tensor_23 = getitem_46 = getitem_47 = primals_158 = primals_157 = None
        getitem_96 = native_layer_norm_backward_default_8[0]
        getitem_97 = native_layer_norm_backward_default_8[1]
        getitem_98 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_300 = torch.ops.aten.view.default(getitem_96, [4096, 768])
        t_default_168 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_300, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_300)
        mm_default_49 = torch.ops.aten.mm.default(t_default_169, view_default_134);  t_default_169 = view_default_134 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_300, [0], True);  view_default_300 = None
        view_default_301 = torch.ops.aten.view.default(sum_dim_int_list_24, [768]);  sum_dim_int_list_24 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_302 = torch.ops.aten.view.default(mm_default_48, [8, 512, 3072]);  mm_default_48 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_302, torch.float32);  view_default_302 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_133, torch.float32);  view_default_133 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_28);  mul_tensor_28 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(add_tensor_60, 0.5);  add_tensor_60 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_30, -0.5);  mul_tensor_30 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_31);  mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_32);  to_dtype_13 = mul_tensor_32 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(mul_tensor_29, mul_tensor_33);  mul_tensor_29 = mul_tensor_33 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_61);  to_dtype_12 = add_tensor_61 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_34, torch.float32);  mul_tensor_34 = None
        view_default_303 = torch.ops.aten.view.default(to_dtype_14, [4096, 3072]);  to_dtype_14 = None
        t_default_172 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_303, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(view_default_303)
        mm_default_51 = torch.ops.aten.mm.default(t_default_173, view_default_132);  t_default_173 = view_default_132 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_303, [0], True);  view_default_303 = None
        view_default_304 = torch.ops.aten.view.default(sum_dim_int_list_25, [3072]);  sum_dim_int_list_25 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_305 = torch.ops.aten.view.default(mm_default_50, [8, 512, 768]);  mm_default_50 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_96, view_default_305);  getitem_96 = view_default_305 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_62, add_tensor_22, [768], getitem_43, getitem_44, primals_146, primals_145, [True, True, True]);  add_tensor_62 = add_tensor_22 = getitem_43 = getitem_44 = primals_146 = primals_145 = None
        getitem_99 = native_layer_norm_backward_default_9[0]
        getitem_100 = native_layer_norm_backward_default_9[1]
        getitem_101 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        view_default_306 = torch.ops.aten.view.default(getitem_99, [4096, 768])
        t_default_176 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_306, t_default_176);  t_default_176 = None
        t_default_177 = torch.ops.aten.t.default(view_default_306)
        mm_default_53 = torch.ops.aten.mm.default(t_default_177, view_default_130);  t_default_177 = view_default_130 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_306, [0], True);  view_default_306 = None
        view_default_307 = torch.ops.aten.view.default(sum_dim_int_list_26, [768]);  sum_dim_int_list_26 = None
        t_default_179 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        view_default_308 = torch.ops.aten.view.default(mm_default_52, [8, 512, 768]);  mm_default_52 = None
        view_default_309 = torch.ops.aten.view.default(view_default_308, [8, 512, 12, 64]);  view_default_308 = None
        permute_default_64 = torch.ops.aten.permute.default(view_default_309, [0, 2, 1, 3]);  view_default_309 = None
        clone_default_64 = torch.ops.aten.clone.default(permute_default_64, memory_format = torch.contiguous_format);  permute_default_64 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_64, [96, 512, 64]);  clone_default_64 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_128, 1, 2);  view_default_128 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_32, _unsafe_view_default_76);  transpose_int_32 = None
        transpose_int_33 = torch.ops.aten.transpose.int(_unsafe_view_default_38, 1, 2);  _unsafe_view_default_38 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_unsafe_view_default_76, transpose_int_33);  _unsafe_view_default_76 = transpose_int_33 = None
        view_default_310 = torch.ops.aten.view.default(bmm_default_40, [8, 12, 512, 64]);  bmm_default_40 = None
        view_default_311 = torch.ops.aten.view.default(bmm_default_41, [8, 12, 512, 512]);  bmm_default_41 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_311, _softmax_default_7, -1, torch.float32);  view_default_311 = _softmax_default_7 = None
        div_tensor_16 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_4, 8.0);  _softmax_backward_data_default_4 = None
        view_default_312 = torch.ops.aten.view.default(div_tensor_16, [96, 512, 512]);  div_tensor_16 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_unsafe_view_default_35, 1, 2);  _unsafe_view_default_35 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_34, view_default_312);  transpose_int_34 = None
        transpose_int_35 = torch.ops.aten.transpose.int(_unsafe_view_default_36, 1, 2);  _unsafe_view_default_36 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_312, transpose_int_35);  view_default_312 = transpose_int_35 = None
        view_default_313 = torch.ops.aten.view.default(bmm_default_42, [8, 12, 64, 512]);  bmm_default_42 = None
        view_default_314 = torch.ops.aten.view.default(bmm_default_43, [8, 12, 512, 64]);  bmm_default_43 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_313, -1, -2);  view_default_313 = None
        permute_default_65 = torch.ops.aten.permute.default(view_default_314, [0, 2, 1, 3]);  view_default_314 = None
        clone_default_65 = torch.ops.aten.clone.default(permute_default_65, memory_format = torch.contiguous_format);  permute_default_65 = None
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(clone_default_65, [8, 512, 768]);  clone_default_65 = None
        permute_default_66 = torch.ops.aten.permute.default(view_default_310, [0, 2, 1, 3]);  view_default_310 = None
        clone_default_66 = torch.ops.aten.clone.default(permute_default_66, memory_format = torch.contiguous_format);  permute_default_66 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_66, [8, 512, 768]);  clone_default_66 = None
        view_default_315 = torch.ops.aten.view.default(_unsafe_view_default_78, [4096, 768]);  _unsafe_view_default_78 = None
        t_default_180 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_315, t_default_180);  t_default_180 = None
        t_default_181 = torch.ops.aten.t.default(view_default_315)
        mm_default_55 = torch.ops.aten.mm.default(t_default_181, view_default_124);  t_default_181 = view_default_124 = None
        t_default_182 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_315, [0], True);  view_default_315 = None
        view_default_316 = torch.ops.aten.view.default(sum_dim_int_list_27, [768]);  sum_dim_int_list_27 = None
        t_default_183 = torch.ops.aten.t.default(t_default_182);  t_default_182 = None
        view_default_317 = torch.ops.aten.view.default(mm_default_54, [8, 512, 768]);  mm_default_54 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_99, view_default_317);  getitem_99 = view_default_317 = None
        permute_default_67 = torch.ops.aten.permute.default(transpose_int_36, [0, 2, 1, 3]);  transpose_int_36 = None
        view_default_318 = torch.ops.aten.view.default(permute_default_67, [8, 512, 768]);  permute_default_67 = None
        clone_default_67 = torch.ops.aten.clone.default(view_default_318, memory_format = torch.contiguous_format);  view_default_318 = None
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(clone_default_67, [4096, 768]);  clone_default_67 = None
        t_default_184 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_56 = torch.ops.aten.mm.default(_unsafe_view_default_79, t_default_184);  t_default_184 = None
        t_default_185 = torch.ops.aten.t.default(_unsafe_view_default_79)
        mm_default_57 = torch.ops.aten.mm.default(t_default_185, view_default_121);  t_default_185 = view_default_121 = None
        t_default_186 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_79, [0], True);  _unsafe_view_default_79 = None
        view_default_319 = torch.ops.aten.view.default(sum_dim_int_list_28, [768]);  sum_dim_int_list_28 = None
        t_default_187 = torch.ops.aten.t.default(t_default_186);  t_default_186 = None
        view_default_320 = torch.ops.aten.view.default(mm_default_56, [8, 512, 768]);  mm_default_56 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, view_default_320);  add_tensor_63 = view_default_320 = None
        view_default_321 = torch.ops.aten.view.default(_unsafe_view_default_77, [4096, 768]);  _unsafe_view_default_77 = None
        t_default_188 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_321, t_default_188);  t_default_188 = None
        t_default_189 = torch.ops.aten.t.default(view_default_321)
        mm_default_59 = torch.ops.aten.mm.default(t_default_189, view_default_119);  t_default_189 = view_default_119 = None
        t_default_190 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_321, [0], True);  view_default_321 = None
        view_default_322 = torch.ops.aten.view.default(sum_dim_int_list_29, [768]);  sum_dim_int_list_29 = None
        t_default_191 = torch.ops.aten.t.default(t_default_190);  t_default_190 = None
        view_default_323 = torch.ops.aten.view.default(mm_default_58, [8, 512, 768]);  mm_default_58 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(add_tensor_64, view_default_323);  add_tensor_64 = view_default_323 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_65, add_tensor_20, [768], getitem_40, getitem_41, primals_142, primals_141, [True, True, True]);  add_tensor_65 = add_tensor_20 = getitem_40 = getitem_41 = primals_142 = primals_141 = None
        getitem_102 = native_layer_norm_backward_default_10[0]
        getitem_103 = native_layer_norm_backward_default_10[1]
        getitem_104 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_324 = torch.ops.aten.view.default(getitem_102, [4096, 768])
        t_default_192 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_324, t_default_192);  t_default_192 = None
        t_default_193 = torch.ops.aten.t.default(view_default_324)
        mm_default_61 = torch.ops.aten.mm.default(t_default_193, view_default_117);  t_default_193 = view_default_117 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_324, [0], True);  view_default_324 = None
        view_default_325 = torch.ops.aten.view.default(sum_dim_int_list_30, [768]);  sum_dim_int_list_30 = None
        t_default_195 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_326 = torch.ops.aten.view.default(mm_default_60, [8, 512, 3072]);  mm_default_60 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_326, torch.float32);  view_default_326 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_116, torch.float32);  view_default_116 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_35);  mul_tensor_35 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(add_tensor_66, 0.5);  add_tensor_66 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(mul_tensor_37, -0.5);  mul_tensor_37 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_38);  mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_39);  to_dtype_16 = mul_tensor_39 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(mul_tensor_36, mul_tensor_40);  mul_tensor_36 = mul_tensor_40 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_67);  to_dtype_15 = add_tensor_67 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_41, torch.float32);  mul_tensor_41 = None
        view_default_327 = torch.ops.aten.view.default(to_dtype_17, [4096, 3072]);  to_dtype_17 = None
        t_default_196 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_327, t_default_196);  t_default_196 = None
        t_default_197 = torch.ops.aten.t.default(view_default_327)
        mm_default_63 = torch.ops.aten.mm.default(t_default_197, view_default_115);  t_default_197 = view_default_115 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_327, [0], True);  view_default_327 = None
        view_default_328 = torch.ops.aten.view.default(sum_dim_int_list_31, [3072]);  sum_dim_int_list_31 = None
        t_default_199 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        view_default_329 = torch.ops.aten.view.default(mm_default_62, [8, 512, 768]);  mm_default_62 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_102, view_default_329);  getitem_102 = view_default_329 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_68, add_tensor_19, [768], getitem_37, getitem_38, primals_130, primals_129, [True, True, True]);  add_tensor_68 = add_tensor_19 = getitem_37 = getitem_38 = primals_130 = primals_129 = None
        getitem_105 = native_layer_norm_backward_default_11[0]
        getitem_106 = native_layer_norm_backward_default_11[1]
        getitem_107 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_330 = torch.ops.aten.view.default(getitem_105, [4096, 768])
        t_default_200 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_330, t_default_200);  t_default_200 = None
        t_default_201 = torch.ops.aten.t.default(view_default_330)
        mm_default_65 = torch.ops.aten.mm.default(t_default_201, view_default_113);  t_default_201 = view_default_113 = None
        t_default_202 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_330, [0], True);  view_default_330 = None
        view_default_331 = torch.ops.aten.view.default(sum_dim_int_list_32, [768]);  sum_dim_int_list_32 = None
        t_default_203 = torch.ops.aten.t.default(t_default_202);  t_default_202 = None
        view_default_332 = torch.ops.aten.view.default(mm_default_64, [8, 512, 768]);  mm_default_64 = None
        view_default_333 = torch.ops.aten.view.default(view_default_332, [8, 512, 12, 64]);  view_default_332 = None
        permute_default_68 = torch.ops.aten.permute.default(view_default_333, [0, 2, 1, 3]);  view_default_333 = None
        clone_default_68 = torch.ops.aten.clone.default(permute_default_68, memory_format = torch.contiguous_format);  permute_default_68 = None
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(clone_default_68, [96, 512, 64]);  clone_default_68 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_111, 1, 2);  view_default_111 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_37, _unsafe_view_default_80);  transpose_int_37 = None
        transpose_int_38 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_unsafe_view_default_80, transpose_int_38);  _unsafe_view_default_80 = transpose_int_38 = None
        view_default_334 = torch.ops.aten.view.default(bmm_default_44, [8, 12, 512, 64]);  bmm_default_44 = None
        view_default_335 = torch.ops.aten.view.default(bmm_default_45, [8, 12, 512, 512]);  bmm_default_45 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_335, _softmax_default_6, -1, torch.float32);  view_default_335 = _softmax_default_6 = None
        div_tensor_17 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_5, 8.0);  _softmax_backward_data_default_5 = None
        view_default_336 = torch.ops.aten.view.default(div_tensor_17, [96, 512, 512]);  div_tensor_17 = None
        transpose_int_39 = torch.ops.aten.transpose.int(_unsafe_view_default_30, 1, 2);  _unsafe_view_default_30 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_39, view_default_336);  transpose_int_39 = None
        transpose_int_40 = torch.ops.aten.transpose.int(_unsafe_view_default_31, 1, 2);  _unsafe_view_default_31 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_336, transpose_int_40);  view_default_336 = transpose_int_40 = None
        view_default_337 = torch.ops.aten.view.default(bmm_default_46, [8, 12, 64, 512]);  bmm_default_46 = None
        view_default_338 = torch.ops.aten.view.default(bmm_default_47, [8, 12, 512, 64]);  bmm_default_47 = None
        transpose_int_41 = torch.ops.aten.transpose.int(view_default_337, -1, -2);  view_default_337 = None
        permute_default_69 = torch.ops.aten.permute.default(view_default_338, [0, 2, 1, 3]);  view_default_338 = None
        clone_default_69 = torch.ops.aten.clone.default(permute_default_69, memory_format = torch.contiguous_format);  permute_default_69 = None
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(clone_default_69, [8, 512, 768]);  clone_default_69 = None
        permute_default_70 = torch.ops.aten.permute.default(view_default_334, [0, 2, 1, 3]);  view_default_334 = None
        clone_default_70 = torch.ops.aten.clone.default(permute_default_70, memory_format = torch.contiguous_format);  permute_default_70 = None
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(clone_default_70, [8, 512, 768]);  clone_default_70 = None
        view_default_339 = torch.ops.aten.view.default(_unsafe_view_default_82, [4096, 768]);  _unsafe_view_default_82 = None
        t_default_204 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_339, t_default_204);  t_default_204 = None
        t_default_205 = torch.ops.aten.t.default(view_default_339)
        mm_default_67 = torch.ops.aten.mm.default(t_default_205, view_default_107);  t_default_205 = view_default_107 = None
        t_default_206 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_339, [0], True);  view_default_339 = None
        view_default_340 = torch.ops.aten.view.default(sum_dim_int_list_33, [768]);  sum_dim_int_list_33 = None
        t_default_207 = torch.ops.aten.t.default(t_default_206);  t_default_206 = None
        view_default_341 = torch.ops.aten.view.default(mm_default_66, [8, 512, 768]);  mm_default_66 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(getitem_105, view_default_341);  getitem_105 = view_default_341 = None
        permute_default_71 = torch.ops.aten.permute.default(transpose_int_41, [0, 2, 1, 3]);  transpose_int_41 = None
        view_default_342 = torch.ops.aten.view.default(permute_default_71, [8, 512, 768]);  permute_default_71 = None
        clone_default_71 = torch.ops.aten.clone.default(view_default_342, memory_format = torch.contiguous_format);  view_default_342 = None
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(clone_default_71, [4096, 768]);  clone_default_71 = None
        t_default_208 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_68 = torch.ops.aten.mm.default(_unsafe_view_default_83, t_default_208);  t_default_208 = None
        t_default_209 = torch.ops.aten.t.default(_unsafe_view_default_83)
        mm_default_69 = torch.ops.aten.mm.default(t_default_209, view_default_104);  t_default_209 = view_default_104 = None
        t_default_210 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_83, [0], True);  _unsafe_view_default_83 = None
        view_default_343 = torch.ops.aten.view.default(sum_dim_int_list_34, [768]);  sum_dim_int_list_34 = None
        t_default_211 = torch.ops.aten.t.default(t_default_210);  t_default_210 = None
        view_default_344 = torch.ops.aten.view.default(mm_default_68, [8, 512, 768]);  mm_default_68 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(add_tensor_69, view_default_344);  add_tensor_69 = view_default_344 = None
        view_default_345 = torch.ops.aten.view.default(_unsafe_view_default_81, [4096, 768]);  _unsafe_view_default_81 = None
        t_default_212 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_345, t_default_212);  t_default_212 = None
        t_default_213 = torch.ops.aten.t.default(view_default_345)
        mm_default_71 = torch.ops.aten.mm.default(t_default_213, view_default_102);  t_default_213 = view_default_102 = None
        t_default_214 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_345, [0], True);  view_default_345 = None
        view_default_346 = torch.ops.aten.view.default(sum_dim_int_list_35, [768]);  sum_dim_int_list_35 = None
        t_default_215 = torch.ops.aten.t.default(t_default_214);  t_default_214 = None
        view_default_347 = torch.ops.aten.view.default(mm_default_70, [8, 512, 768]);  mm_default_70 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(add_tensor_70, view_default_347);  add_tensor_70 = view_default_347 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_71, add_tensor_17, [768], getitem_34, getitem_35, primals_126, primals_125, [True, True, True]);  add_tensor_71 = add_tensor_17 = getitem_34 = getitem_35 = primals_126 = primals_125 = None
        getitem_108 = native_layer_norm_backward_default_12[0]
        getitem_109 = native_layer_norm_backward_default_12[1]
        getitem_110 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        view_default_348 = torch.ops.aten.view.default(getitem_108, [4096, 768])
        t_default_216 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_348, t_default_216);  t_default_216 = None
        t_default_217 = torch.ops.aten.t.default(view_default_348)
        mm_default_73 = torch.ops.aten.mm.default(t_default_217, view_default_100);  t_default_217 = view_default_100 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_348, [0], True);  view_default_348 = None
        view_default_349 = torch.ops.aten.view.default(sum_dim_int_list_36, [768]);  sum_dim_int_list_36 = None
        t_default_219 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        view_default_350 = torch.ops.aten.view.default(mm_default_72, [8, 512, 3072]);  mm_default_72 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_350, torch.float32);  view_default_350 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_99, torch.float32);  view_default_99 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_42);  mul_tensor_42 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(add_tensor_72, 0.5);  add_tensor_72 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(mul_tensor_44, -0.5);  mul_tensor_44 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_45);  mul_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_46);  to_dtype_19 = mul_tensor_46 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_43, mul_tensor_47);  mul_tensor_43 = mul_tensor_47 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_73);  to_dtype_18 = add_tensor_73 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_48, torch.float32);  mul_tensor_48 = None
        view_default_351 = torch.ops.aten.view.default(to_dtype_20, [4096, 3072]);  to_dtype_20 = None
        t_default_220 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_351, t_default_220);  t_default_220 = None
        t_default_221 = torch.ops.aten.t.default(view_default_351)
        mm_default_75 = torch.ops.aten.mm.default(t_default_221, view_default_98);  t_default_221 = view_default_98 = None
        t_default_222 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_351, [0], True);  view_default_351 = None
        view_default_352 = torch.ops.aten.view.default(sum_dim_int_list_37, [3072]);  sum_dim_int_list_37 = None
        t_default_223 = torch.ops.aten.t.default(t_default_222);  t_default_222 = None
        view_default_353 = torch.ops.aten.view.default(mm_default_74, [8, 512, 768]);  mm_default_74 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(getitem_108, view_default_353);  getitem_108 = view_default_353 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_74, add_tensor_16, [768], getitem_31, getitem_32, primals_114, primals_113, [True, True, True]);  add_tensor_74 = add_tensor_16 = getitem_31 = getitem_32 = primals_114 = primals_113 = None
        getitem_111 = native_layer_norm_backward_default_13[0]
        getitem_112 = native_layer_norm_backward_default_13[1]
        getitem_113 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        view_default_354 = torch.ops.aten.view.default(getitem_111, [4096, 768])
        t_default_224 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_76 = torch.ops.aten.mm.default(view_default_354, t_default_224);  t_default_224 = None
        t_default_225 = torch.ops.aten.t.default(view_default_354)
        mm_default_77 = torch.ops.aten.mm.default(t_default_225, view_default_96);  t_default_225 = view_default_96 = None
        t_default_226 = torch.ops.aten.t.default(mm_default_77);  mm_default_77 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(view_default_354, [0], True);  view_default_354 = None
        view_default_355 = torch.ops.aten.view.default(sum_dim_int_list_38, [768]);  sum_dim_int_list_38 = None
        t_default_227 = torch.ops.aten.t.default(t_default_226);  t_default_226 = None
        view_default_356 = torch.ops.aten.view.default(mm_default_76, [8, 512, 768]);  mm_default_76 = None
        view_default_357 = torch.ops.aten.view.default(view_default_356, [8, 512, 12, 64]);  view_default_356 = None
        permute_default_72 = torch.ops.aten.permute.default(view_default_357, [0, 2, 1, 3]);  view_default_357 = None
        clone_default_72 = torch.ops.aten.clone.default(permute_default_72, memory_format = torch.contiguous_format);  permute_default_72 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_72, [96, 512, 64]);  clone_default_72 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_94, 1, 2);  view_default_94 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_42, _unsafe_view_default_84);  transpose_int_42 = None
        transpose_int_43 = torch.ops.aten.transpose.int(_unsafe_view_default_28, 1, 2);  _unsafe_view_default_28 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_84, transpose_int_43);  _unsafe_view_default_84 = transpose_int_43 = None
        view_default_358 = torch.ops.aten.view.default(bmm_default_48, [8, 12, 512, 64]);  bmm_default_48 = None
        view_default_359 = torch.ops.aten.view.default(bmm_default_49, [8, 12, 512, 512]);  bmm_default_49 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_359, _softmax_default_5, -1, torch.float32);  view_default_359 = _softmax_default_5 = None
        div_tensor_18 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_6, 8.0);  _softmax_backward_data_default_6 = None
        view_default_360 = torch.ops.aten.view.default(div_tensor_18, [96, 512, 512]);  div_tensor_18 = None
        transpose_int_44 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_44, view_default_360);  transpose_int_44 = None
        transpose_int_45 = torch.ops.aten.transpose.int(_unsafe_view_default_26, 1, 2);  _unsafe_view_default_26 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_360, transpose_int_45);  view_default_360 = transpose_int_45 = None
        view_default_361 = torch.ops.aten.view.default(bmm_default_50, [8, 12, 64, 512]);  bmm_default_50 = None
        view_default_362 = torch.ops.aten.view.default(bmm_default_51, [8, 12, 512, 64]);  bmm_default_51 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_361, -1, -2);  view_default_361 = None
        permute_default_73 = torch.ops.aten.permute.default(view_default_362, [0, 2, 1, 3]);  view_default_362 = None
        clone_default_73 = torch.ops.aten.clone.default(permute_default_73, memory_format = torch.contiguous_format);  permute_default_73 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_73, [8, 512, 768]);  clone_default_73 = None
        permute_default_74 = torch.ops.aten.permute.default(view_default_358, [0, 2, 1, 3]);  view_default_358 = None
        clone_default_74 = torch.ops.aten.clone.default(permute_default_74, memory_format = torch.contiguous_format);  permute_default_74 = None
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(clone_default_74, [8, 512, 768]);  clone_default_74 = None
        view_default_363 = torch.ops.aten.view.default(_unsafe_view_default_86, [4096, 768]);  _unsafe_view_default_86 = None
        t_default_228 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_78 = torch.ops.aten.mm.default(view_default_363, t_default_228);  t_default_228 = None
        t_default_229 = torch.ops.aten.t.default(view_default_363)
        mm_default_79 = torch.ops.aten.mm.default(t_default_229, view_default_90);  t_default_229 = view_default_90 = None
        t_default_230 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(view_default_363, [0], True);  view_default_363 = None
        view_default_364 = torch.ops.aten.view.default(sum_dim_int_list_39, [768]);  sum_dim_int_list_39 = None
        t_default_231 = torch.ops.aten.t.default(t_default_230);  t_default_230 = None
        view_default_365 = torch.ops.aten.view.default(mm_default_78, [8, 512, 768]);  mm_default_78 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(getitem_111, view_default_365);  getitem_111 = view_default_365 = None
        permute_default_75 = torch.ops.aten.permute.default(transpose_int_46, [0, 2, 1, 3]);  transpose_int_46 = None
        view_default_366 = torch.ops.aten.view.default(permute_default_75, [8, 512, 768]);  permute_default_75 = None
        clone_default_75 = torch.ops.aten.clone.default(view_default_366, memory_format = torch.contiguous_format);  view_default_366 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_75, [4096, 768]);  clone_default_75 = None
        t_default_232 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_80 = torch.ops.aten.mm.default(_unsafe_view_default_87, t_default_232);  t_default_232 = None
        t_default_233 = torch.ops.aten.t.default(_unsafe_view_default_87)
        mm_default_81 = torch.ops.aten.mm.default(t_default_233, view_default_87);  t_default_233 = view_default_87 = None
        t_default_234 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_87, [0], True);  _unsafe_view_default_87 = None
        view_default_367 = torch.ops.aten.view.default(sum_dim_int_list_40, [768]);  sum_dim_int_list_40 = None
        t_default_235 = torch.ops.aten.t.default(t_default_234);  t_default_234 = None
        view_default_368 = torch.ops.aten.view.default(mm_default_80, [8, 512, 768]);  mm_default_80 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(add_tensor_75, view_default_368);  add_tensor_75 = view_default_368 = None
        view_default_369 = torch.ops.aten.view.default(_unsafe_view_default_85, [4096, 768]);  _unsafe_view_default_85 = None
        t_default_236 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_369, t_default_236);  t_default_236 = None
        t_default_237 = torch.ops.aten.t.default(view_default_369)
        mm_default_83 = torch.ops.aten.mm.default(t_default_237, view_default_85);  t_default_237 = view_default_85 = None
        t_default_238 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(view_default_369, [0], True);  view_default_369 = None
        view_default_370 = torch.ops.aten.view.default(sum_dim_int_list_41, [768]);  sum_dim_int_list_41 = None
        t_default_239 = torch.ops.aten.t.default(t_default_238);  t_default_238 = None
        view_default_371 = torch.ops.aten.view.default(mm_default_82, [8, 512, 768]);  mm_default_82 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_76, view_default_371);  add_tensor_76 = view_default_371 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_77, add_tensor_14, [768], getitem_28, getitem_29, primals_110, primals_109, [True, True, True]);  add_tensor_77 = add_tensor_14 = getitem_28 = getitem_29 = primals_110 = primals_109 = None
        getitem_114 = native_layer_norm_backward_default_14[0]
        getitem_115 = native_layer_norm_backward_default_14[1]
        getitem_116 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_372 = torch.ops.aten.view.default(getitem_114, [4096, 768])
        t_default_240 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_372, t_default_240);  t_default_240 = None
        t_default_241 = torch.ops.aten.t.default(view_default_372)
        mm_default_85 = torch.ops.aten.mm.default(t_default_241, view_default_83);  t_default_241 = view_default_83 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_372, [0], True);  view_default_372 = None
        view_default_373 = torch.ops.aten.view.default(sum_dim_int_list_42, [768]);  sum_dim_int_list_42 = None
        t_default_243 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        view_default_374 = torch.ops.aten.view.default(mm_default_84, [8, 512, 3072]);  mm_default_84 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_374, torch.float32);  view_default_374 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_82, torch.float32);  view_default_82 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_49);  mul_tensor_49 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(add_tensor_78, 0.5);  add_tensor_78 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_52 = torch.ops.aten.mul.Tensor(mul_tensor_51, -0.5);  mul_tensor_51 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_52);  mul_tensor_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_53);  to_dtype_22 = mul_tensor_53 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(mul_tensor_50, mul_tensor_54);  mul_tensor_50 = mul_tensor_54 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_79);  to_dtype_21 = add_tensor_79 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_55, torch.float32);  mul_tensor_55 = None
        view_default_375 = torch.ops.aten.view.default(to_dtype_23, [4096, 3072]);  to_dtype_23 = None
        t_default_244 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_375, t_default_244);  t_default_244 = None
        t_default_245 = torch.ops.aten.t.default(view_default_375)
        mm_default_87 = torch.ops.aten.mm.default(t_default_245, view_default_81);  t_default_245 = view_default_81 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_375, [0], True);  view_default_375 = None
        view_default_376 = torch.ops.aten.view.default(sum_dim_int_list_43, [3072]);  sum_dim_int_list_43 = None
        t_default_247 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_377 = torch.ops.aten.view.default(mm_default_86, [8, 512, 768]);  mm_default_86 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_114, view_default_377);  getitem_114 = view_default_377 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_80, add_tensor_13, [768], getitem_25, getitem_26, primals_98, primals_97, [True, True, True]);  add_tensor_80 = add_tensor_13 = getitem_25 = getitem_26 = primals_98 = primals_97 = None
        getitem_117 = native_layer_norm_backward_default_15[0]
        getitem_118 = native_layer_norm_backward_default_15[1]
        getitem_119 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        view_default_378 = torch.ops.aten.view.default(getitem_117, [4096, 768])
        t_default_248 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_378, t_default_248);  t_default_248 = None
        t_default_249 = torch.ops.aten.t.default(view_default_378)
        mm_default_89 = torch.ops.aten.mm.default(t_default_249, view_default_79);  t_default_249 = view_default_79 = None
        t_default_250 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_378, [0], True);  view_default_378 = None
        view_default_379 = torch.ops.aten.view.default(sum_dim_int_list_44, [768]);  sum_dim_int_list_44 = None
        t_default_251 = torch.ops.aten.t.default(t_default_250);  t_default_250 = None
        view_default_380 = torch.ops.aten.view.default(mm_default_88, [8, 512, 768]);  mm_default_88 = None
        view_default_381 = torch.ops.aten.view.default(view_default_380, [8, 512, 12, 64]);  view_default_380 = None
        permute_default_76 = torch.ops.aten.permute.default(view_default_381, [0, 2, 1, 3]);  view_default_381 = None
        clone_default_76 = torch.ops.aten.clone.default(permute_default_76, memory_format = torch.contiguous_format);  permute_default_76 = None
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(clone_default_76, [96, 512, 64]);  clone_default_76 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_77, 1, 2);  view_default_77 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_47, _unsafe_view_default_88);  transpose_int_47 = None
        transpose_int_48 = torch.ops.aten.transpose.int(_unsafe_view_default_23, 1, 2);  _unsafe_view_default_23 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_88, transpose_int_48);  _unsafe_view_default_88 = transpose_int_48 = None
        view_default_382 = torch.ops.aten.view.default(bmm_default_52, [8, 12, 512, 64]);  bmm_default_52 = None
        view_default_383 = torch.ops.aten.view.default(bmm_default_53, [8, 12, 512, 512]);  bmm_default_53 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_383, _softmax_default_4, -1, torch.float32);  view_default_383 = _softmax_default_4 = None
        div_tensor_19 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_7, 8.0);  _softmax_backward_data_default_7 = None
        view_default_384 = torch.ops.aten.view.default(div_tensor_19, [96, 512, 512]);  div_tensor_19 = None
        transpose_int_49 = torch.ops.aten.transpose.int(_unsafe_view_default_20, 1, 2);  _unsafe_view_default_20 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_49, view_default_384);  transpose_int_49 = None
        transpose_int_50 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_384, transpose_int_50);  view_default_384 = transpose_int_50 = None
        view_default_385 = torch.ops.aten.view.default(bmm_default_54, [8, 12, 64, 512]);  bmm_default_54 = None
        view_default_386 = torch.ops.aten.view.default(bmm_default_55, [8, 12, 512, 64]);  bmm_default_55 = None
        transpose_int_51 = torch.ops.aten.transpose.int(view_default_385, -1, -2);  view_default_385 = None
        permute_default_77 = torch.ops.aten.permute.default(view_default_386, [0, 2, 1, 3]);  view_default_386 = None
        clone_default_77 = torch.ops.aten.clone.default(permute_default_77, memory_format = torch.contiguous_format);  permute_default_77 = None
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(clone_default_77, [8, 512, 768]);  clone_default_77 = None
        permute_default_78 = torch.ops.aten.permute.default(view_default_382, [0, 2, 1, 3]);  view_default_382 = None
        clone_default_78 = torch.ops.aten.clone.default(permute_default_78, memory_format = torch.contiguous_format);  permute_default_78 = None
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(clone_default_78, [8, 512, 768]);  clone_default_78 = None
        view_default_387 = torch.ops.aten.view.default(_unsafe_view_default_90, [4096, 768]);  _unsafe_view_default_90 = None
        t_default_252 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_387, t_default_252);  t_default_252 = None
        t_default_253 = torch.ops.aten.t.default(view_default_387)
        mm_default_91 = torch.ops.aten.mm.default(t_default_253, view_default_73);  t_default_253 = view_default_73 = None
        t_default_254 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(view_default_387, [0], True);  view_default_387 = None
        view_default_388 = torch.ops.aten.view.default(sum_dim_int_list_45, [768]);  sum_dim_int_list_45 = None
        t_default_255 = torch.ops.aten.t.default(t_default_254);  t_default_254 = None
        view_default_389 = torch.ops.aten.view.default(mm_default_90, [8, 512, 768]);  mm_default_90 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(getitem_117, view_default_389);  getitem_117 = view_default_389 = None
        permute_default_79 = torch.ops.aten.permute.default(transpose_int_51, [0, 2, 1, 3]);  transpose_int_51 = None
        view_default_390 = torch.ops.aten.view.default(permute_default_79, [8, 512, 768]);  permute_default_79 = None
        clone_default_79 = torch.ops.aten.clone.default(view_default_390, memory_format = torch.contiguous_format);  view_default_390 = None
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(clone_default_79, [4096, 768]);  clone_default_79 = None
        t_default_256 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_92 = torch.ops.aten.mm.default(_unsafe_view_default_91, t_default_256);  t_default_256 = None
        t_default_257 = torch.ops.aten.t.default(_unsafe_view_default_91)
        mm_default_93 = torch.ops.aten.mm.default(t_default_257, view_default_70);  t_default_257 = view_default_70 = None
        t_default_258 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_91, [0], True);  _unsafe_view_default_91 = None
        view_default_391 = torch.ops.aten.view.default(sum_dim_int_list_46, [768]);  sum_dim_int_list_46 = None
        t_default_259 = torch.ops.aten.t.default(t_default_258);  t_default_258 = None
        view_default_392 = torch.ops.aten.view.default(mm_default_92, [8, 512, 768]);  mm_default_92 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(add_tensor_81, view_default_392);  add_tensor_81 = view_default_392 = None
        view_default_393 = torch.ops.aten.view.default(_unsafe_view_default_89, [4096, 768]);  _unsafe_view_default_89 = None
        t_default_260 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_393, t_default_260);  t_default_260 = None
        t_default_261 = torch.ops.aten.t.default(view_default_393)
        mm_default_95 = torch.ops.aten.mm.default(t_default_261, view_default_68);  t_default_261 = view_default_68 = None
        t_default_262 = torch.ops.aten.t.default(mm_default_95);  mm_default_95 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(view_default_393, [0], True);  view_default_393 = None
        view_default_394 = torch.ops.aten.view.default(sum_dim_int_list_47, [768]);  sum_dim_int_list_47 = None
        t_default_263 = torch.ops.aten.t.default(t_default_262);  t_default_262 = None
        view_default_395 = torch.ops.aten.view.default(mm_default_94, [8, 512, 768]);  mm_default_94 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_82, view_default_395);  add_tensor_82 = view_default_395 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_83, add_tensor_11, [768], getitem_22, getitem_23, primals_94, primals_93, [True, True, True]);  add_tensor_83 = add_tensor_11 = getitem_22 = getitem_23 = primals_94 = primals_93 = None
        getitem_120 = native_layer_norm_backward_default_16[0]
        getitem_121 = native_layer_norm_backward_default_16[1]
        getitem_122 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_396 = torch.ops.aten.view.default(getitem_120, [4096, 768])
        t_default_264 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_396, t_default_264);  t_default_264 = None
        t_default_265 = torch.ops.aten.t.default(view_default_396)
        mm_default_97 = torch.ops.aten.mm.default(t_default_265, view_default_66);  t_default_265 = view_default_66 = None
        t_default_266 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_396, [0], True);  view_default_396 = None
        view_default_397 = torch.ops.aten.view.default(sum_dim_int_list_48, [768]);  sum_dim_int_list_48 = None
        t_default_267 = torch.ops.aten.t.default(t_default_266);  t_default_266 = None
        view_default_398 = torch.ops.aten.view.default(mm_default_96, [8, 512, 3072]);  mm_default_96 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_398, torch.float32);  view_default_398 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_65, torch.float32);  view_default_65 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_56);  mul_tensor_56 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(add_tensor_84, 0.5);  add_tensor_84 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_59 = torch.ops.aten.mul.Tensor(mul_tensor_58, -0.5);  mul_tensor_58 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_59);  mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_60);  to_dtype_25 = mul_tensor_60 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(mul_tensor_57, mul_tensor_61);  mul_tensor_57 = mul_tensor_61 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_85);  to_dtype_24 = add_tensor_85 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_62, torch.float32);  mul_tensor_62 = None
        view_default_399 = torch.ops.aten.view.default(to_dtype_26, [4096, 3072]);  to_dtype_26 = None
        t_default_268 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_98 = torch.ops.aten.mm.default(view_default_399, t_default_268);  t_default_268 = None
        t_default_269 = torch.ops.aten.t.default(view_default_399)
        mm_default_99 = torch.ops.aten.mm.default(t_default_269, view_default_64);  t_default_269 = view_default_64 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(view_default_399, [0], True);  view_default_399 = None
        view_default_400 = torch.ops.aten.view.default(sum_dim_int_list_49, [3072]);  sum_dim_int_list_49 = None
        t_default_271 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_401 = torch.ops.aten.view.default(mm_default_98, [8, 512, 768]);  mm_default_98 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(getitem_120, view_default_401);  getitem_120 = view_default_401 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_86, add_tensor_10, [768], getitem_19, getitem_20, primals_82, primals_81, [True, True, True]);  add_tensor_86 = add_tensor_10 = getitem_19 = getitem_20 = primals_82 = primals_81 = None
        getitem_123 = native_layer_norm_backward_default_17[0]
        getitem_124 = native_layer_norm_backward_default_17[1]
        getitem_125 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        view_default_402 = torch.ops.aten.view.default(getitem_123, [4096, 768])
        t_default_272 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_100 = torch.ops.aten.mm.default(view_default_402, t_default_272);  t_default_272 = None
        t_default_273 = torch.ops.aten.t.default(view_default_402)
        mm_default_101 = torch.ops.aten.mm.default(t_default_273, view_default_62);  t_default_273 = view_default_62 = None
        t_default_274 = torch.ops.aten.t.default(mm_default_101);  mm_default_101 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(view_default_402, [0], True);  view_default_402 = None
        view_default_403 = torch.ops.aten.view.default(sum_dim_int_list_50, [768]);  sum_dim_int_list_50 = None
        t_default_275 = torch.ops.aten.t.default(t_default_274);  t_default_274 = None
        view_default_404 = torch.ops.aten.view.default(mm_default_100, [8, 512, 768]);  mm_default_100 = None
        view_default_405 = torch.ops.aten.view.default(view_default_404, [8, 512, 12, 64]);  view_default_404 = None
        permute_default_80 = torch.ops.aten.permute.default(view_default_405, [0, 2, 1, 3]);  view_default_405 = None
        clone_default_80 = torch.ops.aten.clone.default(permute_default_80, memory_format = torch.contiguous_format);  permute_default_80 = None
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(clone_default_80, [96, 512, 64]);  clone_default_80 = None
        transpose_int_52 = torch.ops.aten.transpose.int(view_default_60, 1, 2);  view_default_60 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_52, _unsafe_view_default_92);  transpose_int_52 = None
        transpose_int_53 = torch.ops.aten.transpose.int(_unsafe_view_default_18, 1, 2);  _unsafe_view_default_18 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_92, transpose_int_53);  _unsafe_view_default_92 = transpose_int_53 = None
        view_default_406 = torch.ops.aten.view.default(bmm_default_56, [8, 12, 512, 64]);  bmm_default_56 = None
        view_default_407 = torch.ops.aten.view.default(bmm_default_57, [8, 12, 512, 512]);  bmm_default_57 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_407, _softmax_default_3, -1, torch.float32);  view_default_407 = _softmax_default_3 = None
        div_tensor_20 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_8, 8.0);  _softmax_backward_data_default_8 = None
        view_default_408 = torch.ops.aten.view.default(div_tensor_20, [96, 512, 512]);  div_tensor_20 = None
        transpose_int_54 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_54, view_default_408);  transpose_int_54 = None
        transpose_int_55 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_408, transpose_int_55);  view_default_408 = transpose_int_55 = None
        view_default_409 = torch.ops.aten.view.default(bmm_default_58, [8, 12, 64, 512]);  bmm_default_58 = None
        view_default_410 = torch.ops.aten.view.default(bmm_default_59, [8, 12, 512, 64]);  bmm_default_59 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_409, -1, -2);  view_default_409 = None
        permute_default_81 = torch.ops.aten.permute.default(view_default_410, [0, 2, 1, 3]);  view_default_410 = None
        clone_default_81 = torch.ops.aten.clone.default(permute_default_81, memory_format = torch.contiguous_format);  permute_default_81 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_81, [8, 512, 768]);  clone_default_81 = None
        permute_default_82 = torch.ops.aten.permute.default(view_default_406, [0, 2, 1, 3]);  view_default_406 = None
        clone_default_82 = torch.ops.aten.clone.default(permute_default_82, memory_format = torch.contiguous_format);  permute_default_82 = None
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(clone_default_82, [8, 512, 768]);  clone_default_82 = None
        view_default_411 = torch.ops.aten.view.default(_unsafe_view_default_94, [4096, 768]);  _unsafe_view_default_94 = None
        t_default_276 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_102 = torch.ops.aten.mm.default(view_default_411, t_default_276);  t_default_276 = None
        t_default_277 = torch.ops.aten.t.default(view_default_411)
        mm_default_103 = torch.ops.aten.mm.default(t_default_277, view_default_56);  t_default_277 = view_default_56 = None
        t_default_278 = torch.ops.aten.t.default(mm_default_103);  mm_default_103 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(view_default_411, [0], True);  view_default_411 = None
        view_default_412 = torch.ops.aten.view.default(sum_dim_int_list_51, [768]);  sum_dim_int_list_51 = None
        t_default_279 = torch.ops.aten.t.default(t_default_278);  t_default_278 = None
        view_default_413 = torch.ops.aten.view.default(mm_default_102, [8, 512, 768]);  mm_default_102 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(getitem_123, view_default_413);  getitem_123 = view_default_413 = None
        permute_default_83 = torch.ops.aten.permute.default(transpose_int_56, [0, 2, 1, 3]);  transpose_int_56 = None
        view_default_414 = torch.ops.aten.view.default(permute_default_83, [8, 512, 768]);  permute_default_83 = None
        clone_default_83 = torch.ops.aten.clone.default(view_default_414, memory_format = torch.contiguous_format);  view_default_414 = None
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(clone_default_83, [4096, 768]);  clone_default_83 = None
        t_default_280 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_104 = torch.ops.aten.mm.default(_unsafe_view_default_95, t_default_280);  t_default_280 = None
        t_default_281 = torch.ops.aten.t.default(_unsafe_view_default_95)
        mm_default_105 = torch.ops.aten.mm.default(t_default_281, view_default_53);  t_default_281 = view_default_53 = None
        t_default_282 = torch.ops.aten.t.default(mm_default_105);  mm_default_105 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_95, [0], True);  _unsafe_view_default_95 = None
        view_default_415 = torch.ops.aten.view.default(sum_dim_int_list_52, [768]);  sum_dim_int_list_52 = None
        t_default_283 = torch.ops.aten.t.default(t_default_282);  t_default_282 = None
        view_default_416 = torch.ops.aten.view.default(mm_default_104, [8, 512, 768]);  mm_default_104 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(add_tensor_87, view_default_416);  add_tensor_87 = view_default_416 = None
        view_default_417 = torch.ops.aten.view.default(_unsafe_view_default_93, [4096, 768]);  _unsafe_view_default_93 = None
        t_default_284 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_106 = torch.ops.aten.mm.default(view_default_417, t_default_284);  t_default_284 = None
        t_default_285 = torch.ops.aten.t.default(view_default_417)
        mm_default_107 = torch.ops.aten.mm.default(t_default_285, view_default_51);  t_default_285 = view_default_51 = None
        t_default_286 = torch.ops.aten.t.default(mm_default_107);  mm_default_107 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(view_default_417, [0], True);  view_default_417 = None
        view_default_418 = torch.ops.aten.view.default(sum_dim_int_list_53, [768]);  sum_dim_int_list_53 = None
        t_default_287 = torch.ops.aten.t.default(t_default_286);  t_default_286 = None
        view_default_419 = torch.ops.aten.view.default(mm_default_106, [8, 512, 768]);  mm_default_106 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(add_tensor_88, view_default_419);  add_tensor_88 = view_default_419 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_89, add_tensor_8, [768], getitem_16, getitem_17, primals_78, primals_77, [True, True, True]);  add_tensor_89 = add_tensor_8 = getitem_16 = getitem_17 = primals_78 = primals_77 = None
        getitem_126 = native_layer_norm_backward_default_18[0]
        getitem_127 = native_layer_norm_backward_default_18[1]
        getitem_128 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        view_default_420 = torch.ops.aten.view.default(getitem_126, [4096, 768])
        t_default_288 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_420, t_default_288);  t_default_288 = None
        t_default_289 = torch.ops.aten.t.default(view_default_420)
        mm_default_109 = torch.ops.aten.mm.default(t_default_289, view_default_49);  t_default_289 = view_default_49 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(view_default_420, [0], True);  view_default_420 = None
        view_default_421 = torch.ops.aten.view.default(sum_dim_int_list_54, [768]);  sum_dim_int_list_54 = None
        t_default_291 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_422 = torch.ops.aten.view.default(mm_default_108, [8, 512, 3072]);  mm_default_108 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_422, torch.float32);  view_default_422 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_48, torch.float32);  view_default_48 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_63);  mul_tensor_63 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(add_tensor_90, 0.5);  add_tensor_90 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_66 = torch.ops.aten.mul.Tensor(mul_tensor_65, -0.5);  mul_tensor_65 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_66);  mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_67);  to_dtype_28 = mul_tensor_67 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_64, mul_tensor_68);  mul_tensor_64 = mul_tensor_68 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_91);  to_dtype_27 = add_tensor_91 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_69, torch.float32);  mul_tensor_69 = None
        view_default_423 = torch.ops.aten.view.default(to_dtype_29, [4096, 3072]);  to_dtype_29 = None
        t_default_292 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_423, t_default_292);  t_default_292 = None
        t_default_293 = torch.ops.aten.t.default(view_default_423)
        mm_default_111 = torch.ops.aten.mm.default(t_default_293, view_default_47);  t_default_293 = view_default_47 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(view_default_423, [0], True);  view_default_423 = None
        view_default_424 = torch.ops.aten.view.default(sum_dim_int_list_55, [3072]);  sum_dim_int_list_55 = None
        t_default_295 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        view_default_425 = torch.ops.aten.view.default(mm_default_110, [8, 512, 768]);  mm_default_110 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_126, view_default_425);  getitem_126 = view_default_425 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_92, add_tensor_7, [768], getitem_13, getitem_14, primals_66, primals_65, [True, True, True]);  add_tensor_92 = add_tensor_7 = getitem_13 = getitem_14 = primals_66 = primals_65 = None
        getitem_129 = native_layer_norm_backward_default_19[0]
        getitem_130 = native_layer_norm_backward_default_19[1]
        getitem_131 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        view_default_426 = torch.ops.aten.view.default(getitem_129, [4096, 768])
        t_default_296 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_112 = torch.ops.aten.mm.default(view_default_426, t_default_296);  t_default_296 = None
        t_default_297 = torch.ops.aten.t.default(view_default_426)
        mm_default_113 = torch.ops.aten.mm.default(t_default_297, view_default_45);  t_default_297 = view_default_45 = None
        t_default_298 = torch.ops.aten.t.default(mm_default_113);  mm_default_113 = None
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(view_default_426, [0], True);  view_default_426 = None
        view_default_427 = torch.ops.aten.view.default(sum_dim_int_list_56, [768]);  sum_dim_int_list_56 = None
        t_default_299 = torch.ops.aten.t.default(t_default_298);  t_default_298 = None
        view_default_428 = torch.ops.aten.view.default(mm_default_112, [8, 512, 768]);  mm_default_112 = None
        view_default_429 = torch.ops.aten.view.default(view_default_428, [8, 512, 12, 64]);  view_default_428 = None
        permute_default_84 = torch.ops.aten.permute.default(view_default_429, [0, 2, 1, 3]);  view_default_429 = None
        clone_default_84 = torch.ops.aten.clone.default(permute_default_84, memory_format = torch.contiguous_format);  permute_default_84 = None
        _unsafe_view_default_96 = torch.ops.aten._unsafe_view.default(clone_default_84, [96, 512, 64]);  clone_default_84 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_43, 1, 2);  view_default_43 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_57, _unsafe_view_default_96);  transpose_int_57 = None
        transpose_int_58 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_96, transpose_int_58);  _unsafe_view_default_96 = transpose_int_58 = None
        view_default_430 = torch.ops.aten.view.default(bmm_default_60, [8, 12, 512, 64]);  bmm_default_60 = None
        view_default_431 = torch.ops.aten.view.default(bmm_default_61, [8, 12, 512, 512]);  bmm_default_61 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_431, _softmax_default_2, -1, torch.float32);  view_default_431 = _softmax_default_2 = None
        div_tensor_21 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_9, 8.0);  _softmax_backward_data_default_9 = None
        view_default_432 = torch.ops.aten.view.default(div_tensor_21, [96, 512, 512]);  div_tensor_21 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_10, 1, 2);  _unsafe_view_default_10 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_59, view_default_432);  transpose_int_59 = None
        transpose_int_60 = torch.ops.aten.transpose.int(_unsafe_view_default_11, 1, 2);  _unsafe_view_default_11 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_432, transpose_int_60);  view_default_432 = transpose_int_60 = None
        view_default_433 = torch.ops.aten.view.default(bmm_default_62, [8, 12, 64, 512]);  bmm_default_62 = None
        view_default_434 = torch.ops.aten.view.default(bmm_default_63, [8, 12, 512, 64]);  bmm_default_63 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_433, -1, -2);  view_default_433 = None
        permute_default_85 = torch.ops.aten.permute.default(view_default_434, [0, 2, 1, 3]);  view_default_434 = None
        clone_default_85 = torch.ops.aten.clone.default(permute_default_85, memory_format = torch.contiguous_format);  permute_default_85 = None
        _unsafe_view_default_97 = torch.ops.aten._unsafe_view.default(clone_default_85, [8, 512, 768]);  clone_default_85 = None
        permute_default_86 = torch.ops.aten.permute.default(view_default_430, [0, 2, 1, 3]);  view_default_430 = None
        clone_default_86 = torch.ops.aten.clone.default(permute_default_86, memory_format = torch.contiguous_format);  permute_default_86 = None
        _unsafe_view_default_98 = torch.ops.aten._unsafe_view.default(clone_default_86, [8, 512, 768]);  clone_default_86 = None
        view_default_435 = torch.ops.aten.view.default(_unsafe_view_default_98, [4096, 768]);  _unsafe_view_default_98 = None
        t_default_300 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_114 = torch.ops.aten.mm.default(view_default_435, t_default_300);  t_default_300 = None
        t_default_301 = torch.ops.aten.t.default(view_default_435)
        mm_default_115 = torch.ops.aten.mm.default(t_default_301, view_default_39);  t_default_301 = view_default_39 = None
        t_default_302 = torch.ops.aten.t.default(mm_default_115);  mm_default_115 = None
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(view_default_435, [0], True);  view_default_435 = None
        view_default_436 = torch.ops.aten.view.default(sum_dim_int_list_57, [768]);  sum_dim_int_list_57 = None
        t_default_303 = torch.ops.aten.t.default(t_default_302);  t_default_302 = None
        view_default_437 = torch.ops.aten.view.default(mm_default_114, [8, 512, 768]);  mm_default_114 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(getitem_129, view_default_437);  getitem_129 = view_default_437 = None
        permute_default_87 = torch.ops.aten.permute.default(transpose_int_61, [0, 2, 1, 3]);  transpose_int_61 = None
        view_default_438 = torch.ops.aten.view.default(permute_default_87, [8, 512, 768]);  permute_default_87 = None
        clone_default_87 = torch.ops.aten.clone.default(view_default_438, memory_format = torch.contiguous_format);  view_default_438 = None
        _unsafe_view_default_99 = torch.ops.aten._unsafe_view.default(clone_default_87, [4096, 768]);  clone_default_87 = None
        t_default_304 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_116 = torch.ops.aten.mm.default(_unsafe_view_default_99, t_default_304);  t_default_304 = None
        t_default_305 = torch.ops.aten.t.default(_unsafe_view_default_99)
        mm_default_117 = torch.ops.aten.mm.default(t_default_305, view_default_36);  t_default_305 = view_default_36 = None
        t_default_306 = torch.ops.aten.t.default(mm_default_117);  mm_default_117 = None
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_99, [0], True);  _unsafe_view_default_99 = None
        view_default_439 = torch.ops.aten.view.default(sum_dim_int_list_58, [768]);  sum_dim_int_list_58 = None
        t_default_307 = torch.ops.aten.t.default(t_default_306);  t_default_306 = None
        view_default_440 = torch.ops.aten.view.default(mm_default_116, [8, 512, 768]);  mm_default_116 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(add_tensor_93, view_default_440);  add_tensor_93 = view_default_440 = None
        view_default_441 = torch.ops.aten.view.default(_unsafe_view_default_97, [4096, 768]);  _unsafe_view_default_97 = None
        t_default_308 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_118 = torch.ops.aten.mm.default(view_default_441, t_default_308);  t_default_308 = None
        t_default_309 = torch.ops.aten.t.default(view_default_441)
        mm_default_119 = torch.ops.aten.mm.default(t_default_309, view_default_34);  t_default_309 = view_default_34 = None
        t_default_310 = torch.ops.aten.t.default(mm_default_119);  mm_default_119 = None
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(view_default_441, [0], True);  view_default_441 = None
        view_default_442 = torch.ops.aten.view.default(sum_dim_int_list_59, [768]);  sum_dim_int_list_59 = None
        t_default_311 = torch.ops.aten.t.default(t_default_310);  t_default_310 = None
        view_default_443 = torch.ops.aten.view.default(mm_default_118, [8, 512, 768]);  mm_default_118 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_94, view_default_443);  add_tensor_94 = view_default_443 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_95, add_tensor_5, [768], getitem_10, getitem_11, primals_62, primals_61, [True, True, True]);  add_tensor_95 = add_tensor_5 = getitem_10 = getitem_11 = primals_62 = primals_61 = None
        getitem_132 = native_layer_norm_backward_default_20[0]
        getitem_133 = native_layer_norm_backward_default_20[1]
        getitem_134 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_444 = torch.ops.aten.view.default(getitem_132, [4096, 768])
        t_default_312 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_444, t_default_312);  t_default_312 = None
        t_default_313 = torch.ops.aten.t.default(view_default_444)
        mm_default_121 = torch.ops.aten.mm.default(t_default_313, view_default_32);  t_default_313 = view_default_32 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(view_default_444, [0], True);  view_default_444 = None
        view_default_445 = torch.ops.aten.view.default(sum_dim_int_list_60, [768]);  sum_dim_int_list_60 = None
        t_default_315 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_446 = torch.ops.aten.view.default(mm_default_120, [8, 512, 3072]);  mm_default_120 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_446, torch.float32);  view_default_446 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_31, torch.float32);  view_default_31 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_70);  mul_tensor_70 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(add_tensor_96, 0.5);  add_tensor_96 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_73 = torch.ops.aten.mul.Tensor(mul_tensor_72, -0.5);  mul_tensor_72 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_73);  mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_74);  to_dtype_31 = mul_tensor_74 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_71, mul_tensor_75);  mul_tensor_71 = mul_tensor_75 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_97);  to_dtype_30 = add_tensor_97 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_76, torch.float32);  mul_tensor_76 = None
        view_default_447 = torch.ops.aten.view.default(to_dtype_32, [4096, 3072]);  to_dtype_32 = None
        t_default_316 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_447, t_default_316);  t_default_316 = None
        t_default_317 = torch.ops.aten.t.default(view_default_447)
        mm_default_123 = torch.ops.aten.mm.default(t_default_317, view_default_30);  t_default_317 = view_default_30 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(view_default_447, [0], True);  view_default_447 = None
        view_default_448 = torch.ops.aten.view.default(sum_dim_int_list_61, [3072]);  sum_dim_int_list_61 = None
        t_default_319 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        view_default_449 = torch.ops.aten.view.default(mm_default_122, [8, 512, 768]);  mm_default_122 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_132, view_default_449);  getitem_132 = view_default_449 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_98, add_tensor_4, [768], getitem_7, getitem_8, primals_50, primals_49, [True, True, True]);  add_tensor_98 = add_tensor_4 = getitem_7 = getitem_8 = primals_50 = primals_49 = None
        getitem_135 = native_layer_norm_backward_default_21[0]
        getitem_136 = native_layer_norm_backward_default_21[1]
        getitem_137 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        view_default_450 = torch.ops.aten.view.default(getitem_135, [4096, 768])
        t_default_320 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_124 = torch.ops.aten.mm.default(view_default_450, t_default_320);  t_default_320 = None
        t_default_321 = torch.ops.aten.t.default(view_default_450)
        mm_default_125 = torch.ops.aten.mm.default(t_default_321, view_default_28);  t_default_321 = view_default_28 = None
        t_default_322 = torch.ops.aten.t.default(mm_default_125);  mm_default_125 = None
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(view_default_450, [0], True);  view_default_450 = None
        view_default_451 = torch.ops.aten.view.default(sum_dim_int_list_62, [768]);  sum_dim_int_list_62 = None
        t_default_323 = torch.ops.aten.t.default(t_default_322);  t_default_322 = None
        view_default_452 = torch.ops.aten.view.default(mm_default_124, [8, 512, 768]);  mm_default_124 = None
        view_default_453 = torch.ops.aten.view.default(view_default_452, [8, 512, 12, 64]);  view_default_452 = None
        permute_default_88 = torch.ops.aten.permute.default(view_default_453, [0, 2, 1, 3]);  view_default_453 = None
        clone_default_88 = torch.ops.aten.clone.default(permute_default_88, memory_format = torch.contiguous_format);  permute_default_88 = None
        _unsafe_view_default_100 = torch.ops.aten._unsafe_view.default(clone_default_88, [96, 512, 64]);  clone_default_88 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_62, _unsafe_view_default_100);  transpose_int_62 = None
        transpose_int_63 = torch.ops.aten.transpose.int(_unsafe_view_default_8, 1, 2);  _unsafe_view_default_8 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_100, transpose_int_63);  _unsafe_view_default_100 = transpose_int_63 = None
        view_default_454 = torch.ops.aten.view.default(bmm_default_64, [8, 12, 512, 64]);  bmm_default_64 = None
        view_default_455 = torch.ops.aten.view.default(bmm_default_65, [8, 12, 512, 512]);  bmm_default_65 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_455, _softmax_default_1, -1, torch.float32);  view_default_455 = _softmax_default_1 = None
        div_tensor_22 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_10, 8.0);  _softmax_backward_data_default_10 = None
        view_default_456 = torch.ops.aten.view.default(div_tensor_22, [96, 512, 512]);  div_tensor_22 = None
        transpose_int_64 = torch.ops.aten.transpose.int(_unsafe_view_default_5, 1, 2);  _unsafe_view_default_5 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_64, view_default_456);  transpose_int_64 = None
        transpose_int_65 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_456, transpose_int_65);  view_default_456 = transpose_int_65 = None
        view_default_457 = torch.ops.aten.view.default(bmm_default_66, [8, 12, 64, 512]);  bmm_default_66 = None
        view_default_458 = torch.ops.aten.view.default(bmm_default_67, [8, 12, 512, 64]);  bmm_default_67 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_457, -1, -2);  view_default_457 = None
        permute_default_89 = torch.ops.aten.permute.default(view_default_458, [0, 2, 1, 3]);  view_default_458 = None
        clone_default_89 = torch.ops.aten.clone.default(permute_default_89, memory_format = torch.contiguous_format);  permute_default_89 = None
        _unsafe_view_default_101 = torch.ops.aten._unsafe_view.default(clone_default_89, [8, 512, 768]);  clone_default_89 = None
        permute_default_90 = torch.ops.aten.permute.default(view_default_454, [0, 2, 1, 3]);  view_default_454 = None
        clone_default_90 = torch.ops.aten.clone.default(permute_default_90, memory_format = torch.contiguous_format);  permute_default_90 = None
        _unsafe_view_default_102 = torch.ops.aten._unsafe_view.default(clone_default_90, [8, 512, 768]);  clone_default_90 = None
        view_default_459 = torch.ops.aten.view.default(_unsafe_view_default_102, [4096, 768]);  _unsafe_view_default_102 = None
        t_default_324 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_126 = torch.ops.aten.mm.default(view_default_459, t_default_324);  t_default_324 = None
        t_default_325 = torch.ops.aten.t.default(view_default_459)
        mm_default_127 = torch.ops.aten.mm.default(t_default_325, view_default_22);  t_default_325 = view_default_22 = None
        t_default_326 = torch.ops.aten.t.default(mm_default_127);  mm_default_127 = None
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(view_default_459, [0], True);  view_default_459 = None
        view_default_460 = torch.ops.aten.view.default(sum_dim_int_list_63, [768]);  sum_dim_int_list_63 = None
        t_default_327 = torch.ops.aten.t.default(t_default_326);  t_default_326 = None
        view_default_461 = torch.ops.aten.view.default(mm_default_126, [8, 512, 768]);  mm_default_126 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(getitem_135, view_default_461);  getitem_135 = view_default_461 = None
        permute_default_91 = torch.ops.aten.permute.default(transpose_int_66, [0, 2, 1, 3]);  transpose_int_66 = None
        view_default_462 = torch.ops.aten.view.default(permute_default_91, [8, 512, 768]);  permute_default_91 = None
        clone_default_91 = torch.ops.aten.clone.default(view_default_462, memory_format = torch.contiguous_format);  view_default_462 = None
        _unsafe_view_default_103 = torch.ops.aten._unsafe_view.default(clone_default_91, [4096, 768]);  clone_default_91 = None
        t_default_328 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_128 = torch.ops.aten.mm.default(_unsafe_view_default_103, t_default_328);  t_default_328 = None
        t_default_329 = torch.ops.aten.t.default(_unsafe_view_default_103)
        mm_default_129 = torch.ops.aten.mm.default(t_default_329, view_default_19);  t_default_329 = view_default_19 = None
        t_default_330 = torch.ops.aten.t.default(mm_default_129);  mm_default_129 = None
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_103, [0], True);  _unsafe_view_default_103 = None
        view_default_463 = torch.ops.aten.view.default(sum_dim_int_list_64, [768]);  sum_dim_int_list_64 = None
        t_default_331 = torch.ops.aten.t.default(t_default_330);  t_default_330 = None
        view_default_464 = torch.ops.aten.view.default(mm_default_128, [8, 512, 768]);  mm_default_128 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_99, view_default_464);  add_tensor_99 = view_default_464 = None
        view_default_465 = torch.ops.aten.view.default(_unsafe_view_default_101, [4096, 768]);  _unsafe_view_default_101 = None
        t_default_332 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_130 = torch.ops.aten.mm.default(view_default_465, t_default_332);  t_default_332 = None
        t_default_333 = torch.ops.aten.t.default(view_default_465)
        mm_default_131 = torch.ops.aten.mm.default(t_default_333, view_default_17);  t_default_333 = view_default_17 = None
        t_default_334 = torch.ops.aten.t.default(mm_default_131);  mm_default_131 = None
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(view_default_465, [0], True);  view_default_465 = None
        view_default_466 = torch.ops.aten.view.default(sum_dim_int_list_65, [768]);  sum_dim_int_list_65 = None
        t_default_335 = torch.ops.aten.t.default(t_default_334);  t_default_334 = None
        view_default_467 = torch.ops.aten.view.default(mm_default_130, [8, 512, 768]);  mm_default_130 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_100, view_default_467);  add_tensor_100 = view_default_467 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_101, add_tensor_2, [768], getitem_4, getitem_5, primals_14, primals_13, [True, True, True]);  add_tensor_101 = add_tensor_2 = getitem_4 = getitem_5 = primals_14 = primals_13 = None
        getitem_138 = native_layer_norm_backward_default_22[0]
        getitem_139 = native_layer_norm_backward_default_22[1]
        getitem_140 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_468 = torch.ops.aten.view.default(getitem_138, [4096, 768])
        t_default_336 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_132 = torch.ops.aten.mm.default(view_default_468, t_default_336);  t_default_336 = None
        t_default_337 = torch.ops.aten.t.default(view_default_468)
        mm_default_133 = torch.ops.aten.mm.default(t_default_337, view_default_15);  t_default_337 = view_default_15 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(view_default_468, [0], True);  view_default_468 = None
        view_default_469 = torch.ops.aten.view.default(sum_dim_int_list_66, [768]);  sum_dim_int_list_66 = None
        t_default_339 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        view_default_470 = torch.ops.aten.view.default(mm_default_132, [8, 512, 3072]);  mm_default_132 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_470, torch.float32);  view_default_470 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_14, torch.float32);  view_default_14 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_77);  mul_tensor_77 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(add_tensor_102, 0.5);  add_tensor_102 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_80 = torch.ops.aten.mul.Tensor(mul_tensor_79, -0.5);  mul_tensor_79 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_80);  mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_81);  to_dtype_34 = mul_tensor_81 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(mul_tensor_78, mul_tensor_82);  mul_tensor_78 = mul_tensor_82 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_103);  to_dtype_33 = add_tensor_103 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_83, torch.float32);  mul_tensor_83 = None
        view_default_471 = torch.ops.aten.view.default(to_dtype_35, [4096, 3072]);  to_dtype_35 = None
        t_default_340 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_471, t_default_340);  t_default_340 = None
        t_default_341 = torch.ops.aten.t.default(view_default_471)
        mm_default_135 = torch.ops.aten.mm.default(t_default_341, view_default_13);  t_default_341 = view_default_13 = None
        t_default_342 = torch.ops.aten.t.default(mm_default_135);  mm_default_135 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(view_default_471, [0], True);  view_default_471 = None
        view_default_472 = torch.ops.aten.view.default(sum_dim_int_list_67, [3072]);  sum_dim_int_list_67 = None
        t_default_343 = torch.ops.aten.t.default(t_default_342);  t_default_342 = None
        view_default_473 = torch.ops.aten.view.default(mm_default_134, [8, 512, 768]);  mm_default_134 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(getitem_138, view_default_473);  getitem_138 = view_default_473 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_104, add_tensor_1, [768], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  add_tensor_104 = add_tensor_1 = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_141 = native_layer_norm_backward_default_23[0]
        getitem_142 = native_layer_norm_backward_default_23[1]
        getitem_143 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        view_default_474 = torch.ops.aten.view.default(getitem_141, [4096, 768])
        t_default_344 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_136 = torch.ops.aten.mm.default(view_default_474, t_default_344);  t_default_344 = None
        t_default_345 = torch.ops.aten.t.default(view_default_474)
        mm_default_137 = torch.ops.aten.mm.default(t_default_345, view_default_11);  t_default_345 = view_default_11 = None
        t_default_346 = torch.ops.aten.t.default(mm_default_137);  mm_default_137 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(view_default_474, [0], True);  view_default_474 = None
        view_default_475 = torch.ops.aten.view.default(sum_dim_int_list_68, [768]);  sum_dim_int_list_68 = None
        t_default_347 = torch.ops.aten.t.default(t_default_346);  t_default_346 = None
        view_default_476 = torch.ops.aten.view.default(mm_default_136, [8, 512, 768]);  mm_default_136 = None
        view_default_477 = torch.ops.aten.view.default(view_default_476, [8, 512, 12, 64]);  view_default_476 = None
        permute_default_92 = torch.ops.aten.permute.default(view_default_477, [0, 2, 1, 3]);  view_default_477 = None
        clone_default_92 = torch.ops.aten.clone.default(permute_default_92, memory_format = torch.contiguous_format);  permute_default_92 = None
        _unsafe_view_default_104 = torch.ops.aten._unsafe_view.default(clone_default_92, [96, 512, 64]);  clone_default_92 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_9, 1, 2);  view_default_9 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_67, _unsafe_view_default_104);  transpose_int_67 = None
        transpose_int_68 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_104, transpose_int_68);  _unsafe_view_default_104 = transpose_int_68 = None
        view_default_478 = torch.ops.aten.view.default(bmm_default_68, [8, 12, 512, 64]);  bmm_default_68 = None
        view_default_479 = torch.ops.aten.view.default(bmm_default_69, [8, 12, 512, 512]);  bmm_default_69 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_479, _softmax_default, -1, torch.float32);  view_default_479 = _softmax_default = None
        div_tensor_23 = torch.ops.aten.div.Tensor(_softmax_backward_data_default_11, 8.0);  _softmax_backward_data_default_11 = None
        view_default_480 = torch.ops.aten.view.default(div_tensor_23, [96, 512, 512]);  div_tensor_23 = None
        transpose_int_69 = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_69, view_default_480);  transpose_int_69 = None
        transpose_int_70 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_480, transpose_int_70);  view_default_480 = transpose_int_70 = None
        view_default_481 = torch.ops.aten.view.default(bmm_default_70, [8, 12, 64, 512]);  bmm_default_70 = None
        view_default_482 = torch.ops.aten.view.default(bmm_default_71, [8, 12, 512, 64]);  bmm_default_71 = None
        transpose_int_71 = torch.ops.aten.transpose.int(view_default_481, -1, -2);  view_default_481 = None
        permute_default_93 = torch.ops.aten.permute.default(view_default_482, [0, 2, 1, 3]);  view_default_482 = None
        clone_default_93 = torch.ops.aten.clone.default(permute_default_93, memory_format = torch.contiguous_format);  permute_default_93 = None
        _unsafe_view_default_105 = torch.ops.aten._unsafe_view.default(clone_default_93, [8, 512, 768]);  clone_default_93 = None
        permute_default_94 = torch.ops.aten.permute.default(view_default_478, [0, 2, 1, 3]);  view_default_478 = None
        clone_default_94 = torch.ops.aten.clone.default(permute_default_94, memory_format = torch.contiguous_format);  permute_default_94 = None
        _unsafe_view_default_106 = torch.ops.aten._unsafe_view.default(clone_default_94, [8, 512, 768]);  clone_default_94 = None
        view_default_483 = torch.ops.aten.view.default(_unsafe_view_default_106, [4096, 768]);  _unsafe_view_default_106 = None
        t_default_348 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_138 = torch.ops.aten.mm.default(view_default_483, t_default_348);  t_default_348 = None
        t_default_349 = torch.ops.aten.t.default(view_default_483)
        mm_default_139 = torch.ops.aten.mm.default(t_default_349, view_default_5);  t_default_349 = view_default_5 = None
        t_default_350 = torch.ops.aten.t.default(mm_default_139);  mm_default_139 = None
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(view_default_483, [0], True);  view_default_483 = None
        view_default_484 = torch.ops.aten.view.default(sum_dim_int_list_69, [768]);  sum_dim_int_list_69 = None
        t_default_351 = torch.ops.aten.t.default(t_default_350);  t_default_350 = None
        view_default_485 = torch.ops.aten.view.default(mm_default_138, [8, 512, 768]);  mm_default_138 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(getitem_141, view_default_485);  getitem_141 = view_default_485 = None
        permute_default_95 = torch.ops.aten.permute.default(transpose_int_71, [0, 2, 1, 3]);  transpose_int_71 = None
        view_default_486 = torch.ops.aten.view.default(permute_default_95, [8, 512, 768]);  permute_default_95 = None
        clone_default_95 = torch.ops.aten.clone.default(view_default_486, memory_format = torch.contiguous_format);  view_default_486 = None
        _unsafe_view_default_107 = torch.ops.aten._unsafe_view.default(clone_default_95, [4096, 768]);  clone_default_95 = None
        t_default_352 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_140 = torch.ops.aten.mm.default(_unsafe_view_default_107, t_default_352);  t_default_352 = None
        t_default_353 = torch.ops.aten.t.default(_unsafe_view_default_107)
        mm_default_141 = torch.ops.aten.mm.default(t_default_353, view_default_2);  t_default_353 = view_default_2 = None
        t_default_354 = torch.ops.aten.t.default(mm_default_141);  mm_default_141 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_107, [0], True);  _unsafe_view_default_107 = None
        view_default_487 = torch.ops.aten.view.default(sum_dim_int_list_70, [768]);  sum_dim_int_list_70 = None
        t_default_355 = torch.ops.aten.t.default(t_default_354);  t_default_354 = None
        view_default_488 = torch.ops.aten.view.default(mm_default_140, [8, 512, 768]);  mm_default_140 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_105, view_default_488);  add_tensor_105 = view_default_488 = None
        view_default_489 = torch.ops.aten.view.default(_unsafe_view_default_105, [4096, 768]);  _unsafe_view_default_105 = None
        t_default_356 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_142 = torch.ops.aten.mm.default(view_default_489, t_default_356);  t_default_356 = None
        t_default_357 = torch.ops.aten.t.default(view_default_489)
        mm_default_143 = torch.ops.aten.mm.default(t_default_357, view_default);  t_default_357 = view_default = None
        t_default_358 = torch.ops.aten.t.default(mm_default_143);  mm_default_143 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(view_default_489, [0], True);  view_default_489 = None
        view_default_490 = torch.ops.aten.view.default(sum_dim_int_list_71, [768]);  sum_dim_int_list_71 = None
        t_default_359 = torch.ops.aten.t.default(t_default_358);  t_default_358 = None
        view_default_491 = torch.ops.aten.view.default(mm_default_142, [8, 512, 768]);  mm_default_142 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_106, view_default_491);  add_tensor_106 = view_default_491 = None
        return [getitem_143, getitem_142, view_default_475, t_default_347, view_default_487, t_default_355, view_default_490, t_default_359, view_default_484, t_default_351, view_default_472, t_default_343, getitem_140, getitem_139, view_default_469, t_default_339, getitem_83, getitem_82, view_default_235, t_default_107, view_default_247, t_default_115, view_default_250, t_default_119, view_default_244, t_default_111, view_default_232, t_default_103, getitem_80, getitem_79, view_default_229, t_default_99, getitem_77, getitem_76, view_default_211, t_default_83, view_default_223, t_default_91, view_default_226, t_default_95, view_default_220, t_default_87, view_default_208, t_default_79, getitem_74, getitem_73, view_default_205, t_default_75, getitem_137, getitem_136, view_default_451, t_default_323, view_default_463, t_default_331, view_default_466, t_default_335, view_default_460, t_default_327, view_default_448, t_default_319, getitem_134, getitem_133, view_default_445, t_default_315, getitem_131, getitem_130, view_default_427, t_default_299, view_default_439, t_default_307, view_default_442, t_default_311, view_default_436, t_default_303, view_default_424, t_default_295, getitem_128, getitem_127, view_default_421, t_default_291, getitem_125, getitem_124, view_default_403, t_default_275, view_default_415, t_default_283, view_default_418, t_default_287, view_default_412, t_default_279, view_default_400, t_default_271, getitem_122, getitem_121, view_default_397, t_default_267, getitem_119, getitem_118, view_default_379, t_default_251, view_default_391, t_default_259, view_default_394, t_default_263, view_default_388, t_default_255, view_default_376, t_default_247, getitem_116, getitem_115, view_default_373, t_default_243, getitem_113, getitem_112, view_default_355, t_default_227, view_default_367, t_default_235, view_default_370, t_default_239, view_default_364, t_default_231, view_default_352, t_default_223, getitem_110, getitem_109, view_default_349, t_default_219, getitem_107, getitem_106, view_default_331, t_default_203, view_default_343, t_default_211, view_default_346, t_default_215, view_default_340, t_default_207, view_default_328, t_default_199, getitem_104, getitem_103, view_default_325, t_default_195, getitem_101, getitem_100, view_default_307, t_default_179, view_default_319, t_default_187, view_default_322, t_default_191, view_default_316, t_default_183, view_default_304, t_default_175, getitem_98, getitem_97, view_default_301, t_default_171, getitem_95, getitem_94, view_default_283, t_default_155, view_default_295, t_default_163, view_default_298, t_default_167, view_default_292, t_default_159, view_default_280, t_default_151, getitem_92, getitem_91, view_default_277, t_default_147, getitem_89, getitem_88, view_default_259, t_default_131, view_default_271, t_default_139, view_default_274, t_default_143, view_default_268, t_default_135, view_default_256, t_default_127, getitem_86, getitem_85, view_default_253, t_default_123, add_tensor_107, None]
        
