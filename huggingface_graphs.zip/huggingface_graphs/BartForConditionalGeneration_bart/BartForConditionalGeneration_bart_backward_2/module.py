
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/BartForConditionalGeneration_bart/BartForConditionalGeneration_bart_backward_2/state_dict.pt'))

    
    
    def forward(self, getitem_74, view_default_303, primals_138, view_default_308, t_default_79, t_default_80, view_default_315, view_default_306, t_default_81, getitem_73, primals_137, primals_283, view_default_89, view_default_344, view_default_341, primals_284, getitem_80, view_default_93, getitem_83, view_default_353, view_default_456, transpose_int_23, t_default_23, getitem_82, add_tensor_62, _softmax_default_4, t_default_119, add_tensor_14, primals_279, t_default_88, t_default_89, primals_280, t_default_27, _softmax_default_21, transpose_int_108, add_tensor_16, t_default_19, view_default_110, view_default_410, primals_293, _softmax_default_5, view_default_75, view_default_414, transpose_int_28, t_default_107, view_default_76, add_tensor_12, primals_294, view_default_106, getitem_101, t_default_40, t_default_41, getitem_37, getitem_100, view_default_156, view_default_159, view_default, t_default_42, t_default_111, getitem_38, t_default_110, view_default_180, view_default_256, t_default_46, t_default_25, t_default_61, view_default_97, add_tensor_4, view_default_176, view_default_232, view_default_230, t_default_60, t_default_12, view_default_19, view_default_17, view_default_100, getitem_56, t_default_45, view_default_173, t_default_3, getitem_55, _softmax_default, transpose_int_3, t_default_59, t_default_20, getitem_19, view_default_80, getitem_20, view_default_78, view_default_68, view_default_95, view_default_13, view_default_28, t_default_16, getitem_22, t_default_24, transpose_int_18, getitem_23, getitem_7, view_default_36, getitem_8, t_default_8, primals_123, primals_206, primals_124, primals_127, transpose_int_73, add_tensor_39, primals_128, primals_201, view_default_290, view_default_283, t_default_112, t_default_71, t_default_72, view_default_279, primals_205, primals_112, primals_202, primals_75, primals_76, primals_85, primals_86, primals_72, primals_231, view_default_420, primals_150, getitem_5, primals_267, primals_189, add_tensor_36, primals_241, view_default_376, t_default_4, transpose_int_68, t_default_114, primals_227, view_default_262, t_default_5, getitem_62, t_default_67, primals_149, getitem_85, _softmax_default_18, primals_190, primals_232, view_default_359, getitem_104, primals_268, getitem_61, getitem_4, _softmax_default_13, view_default_361, view_default_264, primals_242, t_default_93, view_default_273, view_default_21, primals_228, view_default_186, _softmax_default_19, primals_19, add_tensor_56, transpose_int_98, view_default_66, add_tensor_52, view_default_37, view_default_188, primals_20, transpose_int_13, view_default_38, _softmax_default_2, _softmax_default_9, getitem_97, t_default_47, view_default_372, view_default_416, add_tensor_51, t_default_108, transpose_int_48, t_default_9, view_default_87, view_default_51, view_default_380, add_tensor_57, t_default_21, view_default_446, add_tensor_7, primals_23, t_default_96, add_tensor_26, view_default_83, getitem_43, getitem_98, t_default_22, primals_24, view_default_118, t_default_26, t_default_31, view_default_437, transpose_int_118, view_default_121, view_default_125, t_default_32, t_default_30, t_default_15, add_tensor_61, view_default_62, view_default_452, view_default_454, view_default_448, _softmax_default_3, view_default_59, t_default_14, _softmax_default_23, t_default_117, transpose_int_63, view_default_245, _softmax_default_12, add_tensor_34, transpose_int_33, view_default_247, view_default_241, getitem_86, view_default_127, t_default_63, view_default_49, view_default_363, view_default_163, t_default_95, t_default_94, getitem_58, view_default_425, t_default_64, t_default_116, view_default_258, getitem_26, view_default_266, add_tensor_37, getitem_25, view_default_112, t_default_65, t_default_66, primals_3, getitem_59, primals_4, primals_7, primals_8, view_default_249, t_default_28, t_default_1, getitem_2, view_default_135, t_default_83, getitem_77, view_default_325, primals_59, view_default_104, view_default_323, primals_60, t_default_84, primals_254, primals_253, t_default_85, view_default_138, t_default, view_default_349, view_default_7, view_default_4, primals_257, t_default_36, t_default_34, getitem_1, primals_258, getitem_76, primals_71, t_default_35, view_default_142, primals_306, getitem_10, t_default_68, getitem_11, view_default_317, view_default_277, view_default_268, t_default_52, view_default_270, primals_305, t_default_10, t_default_82, getitem_64, primals_309, getitem_65, _softmax_default_16, view_default_197, t_default_69, view_default_203, add_tensor_47, t_default_115, add_tensor_29, view_default_328, t_default_2, transpose_int_83, view_default_214, _softmax_default_14, transpose_int_53, view_default_265, t_default_70, add_tensor_44, view_default_391, view_default_182, view_default_40, view_default_342, view_default_370, view_default_455, t_default_86, view_default_55, getitem_14, getitem_13, t_default_13, t_default_97, view_default_379, getitem_88, add_tensor_9, view_default_24, view_default_378, t_default_6, t_default_98, getitem_89, t_default_99, view_default_57, view_default_408, view_default_439, _softmax_default_7, view_default_144, view_default_397, add_tensor_54, view_default_422, _softmax_default_20, t_default_109, view_default_148, add_tensor_21, t_default_103, t_default_37, view_default_393, transpose_int_103, transpose_int_38, t_default_74, view_default_285, primals_33, primals_45, t_default_73, getitem_68, getitem_67, primals_50, primals_46, primals_49, primals_34, view_default_294, primals_175, t_default_56, t_default_118, primals_111, primals_98, primals_97, t_default_7, view_default_220, getitem_106, add_tensor_6, view_default_235, primals_102, transpose_int_58, primals_176, _softmax_default_1, add_tensor_32, add_tensor_31, view_default_228, primals_179, getitem_107, primals_180, view_default_34, primals_310, t_default_55, primals_101, add_tensor_24, getitem_35, getitem_34, t_default_39, add_tensor_2, view_default_169, t_default_43, view_default_151, view_default_165, view_default_45, add_tensor_22, view_default_152, view_default_2, transpose_int_43, view_default_11, _softmax_default_8, view_default_150, t_default_38, add_tensor_1, getitem_103, view_default_332, _softmax_default_10, view_default_300, t_default_49, getitem_70, view_default_194, view_default_302, t_default_50, view_default_418, view_default_321, t_default_51, add_tensor_27, primals_216, view_default_190, getitem_71, getitem_47, _softmax_default_22, view_default_192, t_default_77, getitem_46, primals_215, view_default_201, t_default_78, _softmax_default_15, view_default_211, view_default_218, view_default_72, view_default_171, t_default_75, add_tensor_11, view_default_296, getitem_41, getitem_17, t_default_18, view_default_209, view_default_287, getitem_40, getitem_50, getitem_16, t_default_54, view_default_311, view_default_74, t_default_17, view_default_207, transpose_int_78, t_default_44, t_default_53, getitem_49, add_tensor_42, view_default_304, t_default_76, add_tensor_41, view_default_429, t_default_62, getitem_110, view_default_417, view_default_252, getitem_109, view_default_338, view_default_334, add_tensor_46, getitem_79, transpose_int_88, _softmax_default_17, t_default_87, view_default_340, view_default_114, t_default_11, getitem_29, view_default_116, view_default_42, view_default_113, t_default_29, add_tensor_17, getitem_28, primals_153, t_default_104, primals_164, view_default_442, view_default_404, getitem_94, view_default_224, getitem_52, primals_154, t_default_105, t_default_113, view_default_435, t_default_58, view_default_401, view_default_227, view_default_399, add_tensor_59, t_default_106, getitem_95, _softmax_default_11, primals_163, getitem_53, view_default_226, view_default_239, t_default_57, view_default_384, t_default_102, t_default_101, view_default_387, getitem_91, view_default_382, t_default_100, transpose_int_8, getitem_92, view_default_30, view_default_154, _softmax_default_6, view_default_189, view_default_131, t_default_48, add_tensor_19, view_default_431, getitem_32, t_default_91, transpose_int_113, t_default_92, getitem_31, getitem_44, view_default_133, view_default_355, view_default_346, add_tensor_49, transpose_int_93, t_default_33, view_default_366, t_default_90, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_62, [1024], getitem_109, getitem_110, primals_72, primals_71, [True, True, True]);  tangents_1 = add_tensor_62 = getitem_109 = getitem_110 = primals_72 = primals_71 = None
        getitem_111 = native_layer_norm_backward_default[0]
        getitem_112 = native_layer_norm_backward_default[1]
        getitem_113 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_458 = torch.ops.aten.view.default(getitem_111, [1024, 1024])
        t_default_120 = torch.ops.aten.t.default(t_default_119);  t_default_119 = None
        mm_default = torch.ops.aten.mm.default(view_default_458, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_458)
        mm_default_1 = torch.ops.aten.mm.default(t_default_121, view_default_456);  t_default_121 = view_default_456 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_458, [0], True);  view_default_458 = None
        view_default_459 = torch.ops.aten.view.default(sum_dim_int_list, [1024]);  sum_dim_int_list = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_460 = torch.ops.aten.view.default(mm_default, [8, 128, 4096]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_460, torch.float32);  view_default_460 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_455, torch.float32);  view_default_455 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_25);  mul_tensor_25 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(add_tensor_63, 0.5);  add_tensor_63 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_28 = torch.ops.aten.mul.Tensor(mul_tensor_27, -0.5);  mul_tensor_27 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_28);  mul_tensor_28 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_29);  to_dtype_1 = mul_tensor_29 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_26, mul_tensor_30);  mul_tensor_26 = mul_tensor_30 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_64);  to_dtype = add_tensor_64 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_31, torch.float32);  mul_tensor_31 = None
        view_default_461 = torch.ops.aten.view.default(to_dtype_2, [1024, 4096]);  to_dtype_2 = None
        t_default_124 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_461, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(view_default_461)
        mm_default_3 = torch.ops.aten.mm.default(t_default_125, view_default_454);  t_default_125 = view_default_454 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_461, [0], True);  view_default_461 = None
        view_default_462 = torch.ops.aten.view.default(sum_dim_int_list_1, [4096]);  sum_dim_int_list_1 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_463 = torch.ops.aten.view.default(mm_default_2, [8, 128, 1024]);  mm_default_2 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_111, view_default_463);  getitem_111 = view_default_463 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_65, add_tensor_61, [1024], getitem_106, getitem_107, primals_60, primals_59, [True, True, True]);  add_tensor_65 = add_tensor_61 = getitem_106 = getitem_107 = primals_60 = primals_59 = None
        getitem_114 = native_layer_norm_backward_default_1[0]
        getitem_115 = native_layer_norm_backward_default_1[1]
        getitem_116 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_464 = torch.ops.aten.view.default(getitem_114, [1024, 1024])
        t_default_128 = torch.ops.aten.t.default(t_default_117);  t_default_117 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_464, t_default_128);  t_default_128 = None
        t_default_129 = torch.ops.aten.t.default(view_default_464)
        mm_default_5 = torch.ops.aten.mm.default(t_default_129, view_default_452);  t_default_129 = view_default_452 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_464, [0], True);  view_default_464 = None
        view_default_465 = torch.ops.aten.view.default(sum_dim_int_list_2, [1024]);  sum_dim_int_list_2 = None
        t_default_131 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_466 = torch.ops.aten.view.default(mm_default_4, [8, 128, 1024]);  mm_default_4 = None
        view_default_467 = torch.ops.aten.view.default(view_default_466, [8, 128, 16, 64]);  view_default_466 = None
        transpose_int_120 = torch.ops.aten.transpose.int(view_default_467, 1, 2);  view_default_467 = None
        clone_default_96 = torch.ops.aten.clone.default(transpose_int_120, memory_format = torch.contiguous_format);  transpose_int_120 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_96, [128, 128, 64]);  clone_default_96 = None
        transpose_int_121 = torch.ops.aten.transpose.int(_softmax_default_23, 1, 2)
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_121, _unsafe_view_default_24);  transpose_int_121 = None
        transpose_int_122 = torch.ops.aten.transpose.int(view_default_448, 1, 2);  view_default_448 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_24, transpose_int_122);  _unsafe_view_default_24 = transpose_int_122 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(bmm_default_49, _softmax_default_23, -1, torch.float32);  bmm_default_49 = _softmax_default_23 = None
        view_default_468 = torch.ops.aten.view.default(_softmax_backward_data_default, [8, 16, 128, 1024]);  _softmax_backward_data_default = None
        view_default_469 = torch.ops.aten.view.default(view_default_468, [128, 128, 1024]);  view_default_468 = None
        transpose_int_123 = torch.ops.aten.transpose.int(view_default_446, 1, 2);  view_default_446 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_123, view_default_469);  transpose_int_123 = None
        transpose_int_124 = torch.ops.aten.transpose.int(transpose_int_118, 1, 2);  transpose_int_118 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_469, transpose_int_124);  view_default_469 = transpose_int_124 = None
        transpose_int_125 = torch.ops.aten.transpose.int(bmm_default_50, 1, 2);  bmm_default_50 = None
        view_default_470 = torch.ops.aten.view.default(bmm_default_48, [8, 16, 1024, 64]);  bmm_default_48 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(tangents_49, view_default_470);  tangents_49 = view_default_470 = None
        view_default_471 = torch.ops.aten.view.default(transpose_int_125, [8, 16, 1024, 64]);  transpose_int_125 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(tangents_48, view_default_471);  tangents_48 = view_default_471 = None
        view_default_472 = torch.ops.aten.view.default(bmm_default_51, [8, 16, 128, 64]);  bmm_default_51 = None
        transpose_int_126 = torch.ops.aten.transpose.int(view_default_472, 1, 2);  view_default_472 = None
        clone_default_97 = torch.ops.aten.clone.default(transpose_int_126, memory_format = torch.contiguous_format);  transpose_int_126 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_97, [8, 128, 1024]);  clone_default_97 = None
        transpose_int_127 = torch.ops.aten.transpose.int(add_tensor_66, 1, 2);  add_tensor_66 = None
        clone_default_98 = torch.ops.aten.clone.default(transpose_int_127, memory_format = torch.contiguous_format);  transpose_int_127 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_98, [8, 1024, 1024]);  clone_default_98 = None
        view_default_473 = torch.ops.aten.view.default(_unsafe_view_default_26, [8192, 1024]);  _unsafe_view_default_26 = None
        t_default_132 = torch.ops.aten.t.default(t_default_116);  t_default_116 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_473, t_default_132);  t_default_132 = None
        t_default_133 = torch.ops.aten.t.default(view_default_473)
        mm_default_7 = torch.ops.aten.mm.default(t_default_133, view_default_442);  t_default_133 = view_default_442 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_473, [0], True);  view_default_473 = None
        view_default_474 = torch.ops.aten.view.default(sum_dim_int_list_3, [1024]);  sum_dim_int_list_3 = None
        t_default_135 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        view_default_475 = torch.ops.aten.view.default(mm_default_6, [8, 1024, 1024]);  mm_default_6 = None
        transpose_int_128 = torch.ops.aten.transpose.int(add_tensor_67, 1, 2);  add_tensor_67 = None
        clone_default_99 = torch.ops.aten.clone.default(transpose_int_128, memory_format = torch.contiguous_format);  transpose_int_128 = None
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(clone_default_99, [8, 1024, 1024]);  clone_default_99 = None
        view_default_476 = torch.ops.aten.view.default(_unsafe_view_default_27, [8192, 1024]);  _unsafe_view_default_27 = None
        t_default_136 = torch.ops.aten.t.default(t_default_115);  t_default_115 = None
        mm_default_8 = torch.ops.aten.mm.default(view_default_476, t_default_136);  t_default_136 = None
        t_default_137 = torch.ops.aten.t.default(view_default_476)
        mm_default_9 = torch.ops.aten.mm.default(t_default_137, view_default_439);  t_default_137 = view_default_439 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_476, [0], True);  view_default_476 = None
        view_default_477 = torch.ops.aten.view.default(sum_dim_int_list_4, [1024]);  sum_dim_int_list_4 = None
        t_default_139 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        view_default_478 = torch.ops.aten.view.default(mm_default_8, [8, 1024, 1024]);  mm_default_8 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(view_default_475, view_default_478);  view_default_475 = view_default_478 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(_unsafe_view_default_25, 0.125);  _unsafe_view_default_25 = None
        view_default_479 = torch.ops.aten.view.default(mul_tensor_32, [1024, 1024]);  mul_tensor_32 = None
        t_default_140 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_479, t_default_140);  t_default_140 = None
        t_default_141 = torch.ops.aten.t.default(view_default_479)
        mm_default_11 = torch.ops.aten.mm.default(t_default_141, view_default_437);  t_default_141 = view_default_437 = None
        t_default_142 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_479, [0], True);  view_default_479 = None
        view_default_480 = torch.ops.aten.view.default(sum_dim_int_list_5, [1024]);  sum_dim_int_list_5 = None
        t_default_143 = torch.ops.aten.t.default(t_default_142);  t_default_142 = None
        view_default_481 = torch.ops.aten.view.default(mm_default_10, [8, 128, 1024]);  mm_default_10 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(getitem_114, view_default_481);  getitem_114 = view_default_481 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_69, add_tensor_59, [1024], getitem_103, getitem_104, primals_76, primals_75, [True, True, True]);  add_tensor_69 = add_tensor_59 = getitem_103 = getitem_104 = primals_76 = primals_75 = None
        getitem_117 = native_layer_norm_backward_default_2[0]
        getitem_118 = native_layer_norm_backward_default_2[1]
        getitem_119 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_482 = torch.ops.aten.view.default(getitem_117, [1024, 1024])
        t_default_144 = torch.ops.aten.t.default(t_default_113);  t_default_113 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_482, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_482)
        mm_default_13 = torch.ops.aten.mm.default(t_default_145, view_default_435);  t_default_145 = view_default_435 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_482, [0], True);  view_default_482 = None
        view_default_483 = torch.ops.aten.view.default(sum_dim_int_list_6, [1024]);  sum_dim_int_list_6 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_484 = torch.ops.aten.view.default(mm_default_12, [8, 128, 1024]);  mm_default_12 = None
        view_default_485 = torch.ops.aten.view.default(view_default_484, [8, 128, 16, 64]);  view_default_484 = None
        transpose_int_129 = torch.ops.aten.transpose.int(view_default_485, 1, 2);  view_default_485 = None
        clone_default_100 = torch.ops.aten.clone.default(transpose_int_129, memory_format = torch.contiguous_format);  transpose_int_129 = None
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_100, [128, 128, 64]);  clone_default_100 = None
        transpose_int_130 = torch.ops.aten.transpose.int(_softmax_default_22, 1, 2)
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_130, _unsafe_view_default_28);  transpose_int_130 = None
        transpose_int_131 = torch.ops.aten.transpose.int(view_default_431, 1, 2);  view_default_431 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_28, transpose_int_131);  _unsafe_view_default_28 = transpose_int_131 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(bmm_default_53, _softmax_default_22, -1, torch.float32);  bmm_default_53 = _softmax_default_22 = None
        view_default_486 = torch.ops.aten.view.default(_softmax_backward_data_default_1, [8, 16, 128, 128]);  _softmax_backward_data_default_1 = None
        view_default_487 = torch.ops.aten.view.default(view_default_486, [128, 128, 128]);  view_default_486 = None
        transpose_int_132 = torch.ops.aten.transpose.int(view_default_429, 1, 2);  view_default_429 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_132, view_default_487);  transpose_int_132 = None
        transpose_int_133 = torch.ops.aten.transpose.int(transpose_int_113, 1, 2);  transpose_int_113 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_487, transpose_int_133);  view_default_487 = transpose_int_133 = None
        transpose_int_134 = torch.ops.aten.transpose.int(bmm_default_54, 1, 2);  bmm_default_54 = None
        view_default_488 = torch.ops.aten.view.default(bmm_default_52, [8, 16, 128, 64]);  bmm_default_52 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(tangents_47, view_default_488);  tangents_47 = view_default_488 = None
        view_default_489 = torch.ops.aten.view.default(transpose_int_134, [8, 16, 128, 64]);  transpose_int_134 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(tangents_46, view_default_489);  tangents_46 = view_default_489 = None
        view_default_490 = torch.ops.aten.view.default(bmm_default_55, [8, 16, 128, 64]);  bmm_default_55 = None
        transpose_int_135 = torch.ops.aten.transpose.int(view_default_490, 1, 2);  view_default_490 = None
        clone_default_101 = torch.ops.aten.clone.default(transpose_int_135, memory_format = torch.contiguous_format);  transpose_int_135 = None
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(clone_default_101, [8, 128, 1024]);  clone_default_101 = None
        transpose_int_136 = torch.ops.aten.transpose.int(add_tensor_70, 1, 2);  add_tensor_70 = None
        clone_default_102 = torch.ops.aten.clone.default(transpose_int_136, memory_format = torch.contiguous_format);  transpose_int_136 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_102, [8, 128, 1024]);  clone_default_102 = None
        view_default_491 = torch.ops.aten.view.default(_unsafe_view_default_30, [1024, 1024]);  _unsafe_view_default_30 = None
        t_default_148 = torch.ops.aten.t.default(t_default_112);  t_default_112 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_491, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(view_default_491)
        mm_default_15 = torch.ops.aten.mm.default(t_default_149, view_default_425);  t_default_149 = view_default_425 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_491, [0], True);  view_default_491 = None
        view_default_492 = torch.ops.aten.view.default(sum_dim_int_list_7, [1024]);  sum_dim_int_list_7 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_493 = torch.ops.aten.view.default(mm_default_14, [8, 128, 1024]);  mm_default_14 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(getitem_117, view_default_493);  getitem_117 = view_default_493 = None
        transpose_int_137 = torch.ops.aten.transpose.int(add_tensor_71, 1, 2);  add_tensor_71 = None
        clone_default_103 = torch.ops.aten.clone.default(transpose_int_137, memory_format = torch.contiguous_format);  transpose_int_137 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_103, [8, 128, 1024]);  clone_default_103 = None
        view_default_494 = torch.ops.aten.view.default(_unsafe_view_default_31, [1024, 1024]);  _unsafe_view_default_31 = None
        t_default_152 = torch.ops.aten.t.default(t_default_111);  t_default_111 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_494, t_default_152);  t_default_152 = None
        t_default_153 = torch.ops.aten.t.default(view_default_494)
        mm_default_17 = torch.ops.aten.mm.default(t_default_153, view_default_422);  t_default_153 = view_default_422 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_494, [0], True);  view_default_494 = None
        view_default_495 = torch.ops.aten.view.default(sum_dim_int_list_8, [1024]);  sum_dim_int_list_8 = None
        t_default_155 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_496 = torch.ops.aten.view.default(mm_default_16, [8, 128, 1024]);  mm_default_16 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_72, view_default_496);  add_tensor_72 = view_default_496 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(_unsafe_view_default_29, 0.125);  _unsafe_view_default_29 = None
        view_default_497 = torch.ops.aten.view.default(mul_tensor_33, [1024, 1024]);  mul_tensor_33 = None
        t_default_156 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_497, t_default_156);  t_default_156 = None
        t_default_157 = torch.ops.aten.t.default(view_default_497)
        mm_default_19 = torch.ops.aten.mm.default(t_default_157, view_default_420);  t_default_157 = view_default_420 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_497, [0], True);  view_default_497 = None
        view_default_498 = torch.ops.aten.view.default(sum_dim_int_list_9, [1024]);  sum_dim_int_list_9 = None
        t_default_159 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        view_default_499 = torch.ops.aten.view.default(mm_default_18, [8, 128, 1024]);  mm_default_18 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(add_tensor_73, view_default_499);  add_tensor_73 = view_default_499 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_74, add_tensor_57, [1024], getitem_100, getitem_101, primals_46, primals_45, [True, True, True]);  add_tensor_74 = add_tensor_57 = getitem_100 = getitem_101 = primals_46 = primals_45 = None
        getitem_120 = native_layer_norm_backward_default_3[0]
        getitem_121 = native_layer_norm_backward_default_3[1]
        getitem_122 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        view_default_500 = torch.ops.aten.view.default(getitem_120, [1024, 1024])
        t_default_160 = torch.ops.aten.t.default(t_default_109);  t_default_109 = None
        mm_default_20 = torch.ops.aten.mm.default(view_default_500, t_default_160);  t_default_160 = None
        t_default_161 = torch.ops.aten.t.default(view_default_500)
        mm_default_21 = torch.ops.aten.mm.default(t_default_161, view_default_418);  t_default_161 = view_default_418 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_500, [0], True);  view_default_500 = None
        view_default_501 = torch.ops.aten.view.default(sum_dim_int_list_10, [1024]);  sum_dim_int_list_10 = None
        t_default_163 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        view_default_502 = torch.ops.aten.view.default(mm_default_20, [8, 128, 4096]);  mm_default_20 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_502, torch.float32);  view_default_502 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_417, torch.float32);  view_default_417 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_34);  mul_tensor_34 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(add_tensor_75, 0.5);  add_tensor_75 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_37 = torch.ops.aten.mul.Tensor(mul_tensor_36, -0.5);  mul_tensor_36 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_37);  mul_tensor_37 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_38);  to_dtype_4 = mul_tensor_38 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(mul_tensor_35, mul_tensor_39);  mul_tensor_35 = mul_tensor_39 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_76);  to_dtype_3 = add_tensor_76 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_40, torch.float32);  mul_tensor_40 = None
        view_default_503 = torch.ops.aten.view.default(to_dtype_5, [1024, 4096]);  to_dtype_5 = None
        t_default_164 = torch.ops.aten.t.default(t_default_108);  t_default_108 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_503, t_default_164);  t_default_164 = None
        t_default_165 = torch.ops.aten.t.default(view_default_503)
        mm_default_23 = torch.ops.aten.mm.default(t_default_165, view_default_416);  t_default_165 = view_default_416 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_503, [0], True);  view_default_503 = None
        view_default_504 = torch.ops.aten.view.default(sum_dim_int_list_11, [4096]);  sum_dim_int_list_11 = None
        t_default_167 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_505 = torch.ops.aten.view.default(mm_default_22, [8, 128, 1024]);  mm_default_22 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(getitem_120, view_default_505);  getitem_120 = view_default_505 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_77, add_tensor_56, [1024], getitem_97, getitem_98, primals_34, primals_33, [True, True, True]);  add_tensor_77 = add_tensor_56 = getitem_97 = getitem_98 = primals_34 = primals_33 = None
        getitem_123 = native_layer_norm_backward_default_4[0]
        getitem_124 = native_layer_norm_backward_default_4[1]
        getitem_125 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_506 = torch.ops.aten.view.default(getitem_123, [1024, 1024])
        t_default_168 = torch.ops.aten.t.default(t_default_107);  t_default_107 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_506, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_506)
        mm_default_25 = torch.ops.aten.mm.default(t_default_169, view_default_414);  t_default_169 = view_default_414 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_506, [0], True);  view_default_506 = None
        view_default_507 = torch.ops.aten.view.default(sum_dim_int_list_12, [1024]);  sum_dim_int_list_12 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_508 = torch.ops.aten.view.default(mm_default_24, [8, 128, 1024]);  mm_default_24 = None
        view_default_509 = torch.ops.aten.view.default(view_default_508, [8, 128, 16, 64]);  view_default_508 = None
        transpose_int_138 = torch.ops.aten.transpose.int(view_default_509, 1, 2);  view_default_509 = None
        clone_default_104 = torch.ops.aten.clone.default(transpose_int_138, memory_format = torch.contiguous_format);  transpose_int_138 = None
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(clone_default_104, [128, 128, 64]);  clone_default_104 = None
        transpose_int_139 = torch.ops.aten.transpose.int(_softmax_default_21, 1, 2)
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_139, _unsafe_view_default_32);  transpose_int_139 = None
        transpose_int_140 = torch.ops.aten.transpose.int(view_default_410, 1, 2);  view_default_410 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_32, transpose_int_140);  _unsafe_view_default_32 = transpose_int_140 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(bmm_default_57, _softmax_default_21, -1, torch.float32);  bmm_default_57 = _softmax_default_21 = None
        view_default_510 = torch.ops.aten.view.default(_softmax_backward_data_default_2, [8, 16, 128, 1024]);  _softmax_backward_data_default_2 = None
        view_default_511 = torch.ops.aten.view.default(view_default_510, [128, 128, 1024]);  view_default_510 = None
        transpose_int_141 = torch.ops.aten.transpose.int(view_default_408, 1, 2);  view_default_408 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_141, view_default_511);  transpose_int_141 = None
        transpose_int_142 = torch.ops.aten.transpose.int(transpose_int_108, 1, 2);  transpose_int_108 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_511, transpose_int_142);  view_default_511 = transpose_int_142 = None
        transpose_int_143 = torch.ops.aten.transpose.int(bmm_default_58, 1, 2);  bmm_default_58 = None
        view_default_512 = torch.ops.aten.view.default(bmm_default_56, [8, 16, 1024, 64]);  bmm_default_56 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(tangents_45, view_default_512);  tangents_45 = view_default_512 = None
        view_default_513 = torch.ops.aten.view.default(transpose_int_143, [8, 16, 1024, 64]);  transpose_int_143 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(tangents_44, view_default_513);  tangents_44 = view_default_513 = None
        view_default_514 = torch.ops.aten.view.default(bmm_default_59, [8, 16, 128, 64]);  bmm_default_59 = None
        transpose_int_144 = torch.ops.aten.transpose.int(view_default_514, 1, 2);  view_default_514 = None
        clone_default_105 = torch.ops.aten.clone.default(transpose_int_144, memory_format = torch.contiguous_format);  transpose_int_144 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_105, [8, 128, 1024]);  clone_default_105 = None
        transpose_int_145 = torch.ops.aten.transpose.int(add_tensor_78, 1, 2);  add_tensor_78 = None
        clone_default_106 = torch.ops.aten.clone.default(transpose_int_145, memory_format = torch.contiguous_format);  transpose_int_145 = None
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(clone_default_106, [8, 1024, 1024]);  clone_default_106 = None
        view_default_515 = torch.ops.aten.view.default(_unsafe_view_default_34, [8192, 1024]);  _unsafe_view_default_34 = None
        t_default_172 = torch.ops.aten.t.default(t_default_106);  t_default_106 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_515, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(view_default_515)
        mm_default_27 = torch.ops.aten.mm.default(t_default_173, view_default_404);  t_default_173 = view_default_404 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_515, [0], True);  view_default_515 = None
        view_default_516 = torch.ops.aten.view.default(sum_dim_int_list_13, [1024]);  sum_dim_int_list_13 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_517 = torch.ops.aten.view.default(mm_default_26, [8, 1024, 1024]);  mm_default_26 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(add_tensor_68, view_default_517);  add_tensor_68 = view_default_517 = None
        transpose_int_146 = torch.ops.aten.transpose.int(add_tensor_79, 1, 2);  add_tensor_79 = None
        clone_default_107 = torch.ops.aten.clone.default(transpose_int_146, memory_format = torch.contiguous_format);  transpose_int_146 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_107, [8, 1024, 1024]);  clone_default_107 = None
        view_default_518 = torch.ops.aten.view.default(_unsafe_view_default_35, [8192, 1024]);  _unsafe_view_default_35 = None
        t_default_176 = torch.ops.aten.t.default(t_default_105);  t_default_105 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_518, t_default_176);  t_default_176 = None
        t_default_177 = torch.ops.aten.t.default(view_default_518)
        mm_default_29 = torch.ops.aten.mm.default(t_default_177, view_default_401);  t_default_177 = view_default_401 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_518, [0], True);  view_default_518 = None
        view_default_519 = torch.ops.aten.view.default(sum_dim_int_list_14, [1024]);  sum_dim_int_list_14 = None
        t_default_179 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        view_default_520 = torch.ops.aten.view.default(mm_default_28, [8, 1024, 1024]);  mm_default_28 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(add_tensor_80, view_default_520);  add_tensor_80 = view_default_520 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(_unsafe_view_default_33, 0.125);  _unsafe_view_default_33 = None
        view_default_521 = torch.ops.aten.view.default(mul_tensor_41, [1024, 1024]);  mul_tensor_41 = None
        t_default_180 = torch.ops.aten.t.default(t_default_104);  t_default_104 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_521, t_default_180);  t_default_180 = None
        t_default_181 = torch.ops.aten.t.default(view_default_521)
        mm_default_31 = torch.ops.aten.mm.default(t_default_181, view_default_399);  t_default_181 = view_default_399 = None
        t_default_182 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_521, [0], True);  view_default_521 = None
        view_default_522 = torch.ops.aten.view.default(sum_dim_int_list_15, [1024]);  sum_dim_int_list_15 = None
        t_default_183 = torch.ops.aten.t.default(t_default_182);  t_default_182 = None
        view_default_523 = torch.ops.aten.view.default(mm_default_30, [8, 128, 1024]);  mm_default_30 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(getitem_123, view_default_523);  getitem_123 = view_default_523 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_82, add_tensor_54, [1024], getitem_94, getitem_95, primals_50, primals_49, [True, True, True]);  add_tensor_82 = add_tensor_54 = getitem_94 = getitem_95 = primals_50 = primals_49 = None
        getitem_126 = native_layer_norm_backward_default_5[0]
        getitem_127 = native_layer_norm_backward_default_5[1]
        getitem_128 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_524 = torch.ops.aten.view.default(getitem_126, [1024, 1024])
        t_default_184 = torch.ops.aten.t.default(t_default_103);  t_default_103 = None
        mm_default_32 = torch.ops.aten.mm.default(view_default_524, t_default_184);  t_default_184 = None
        t_default_185 = torch.ops.aten.t.default(view_default_524)
        mm_default_33 = torch.ops.aten.mm.default(t_default_185, view_default_397);  t_default_185 = view_default_397 = None
        t_default_186 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_524, [0], True);  view_default_524 = None
        view_default_525 = torch.ops.aten.view.default(sum_dim_int_list_16, [1024]);  sum_dim_int_list_16 = None
        t_default_187 = torch.ops.aten.t.default(t_default_186);  t_default_186 = None
        view_default_526 = torch.ops.aten.view.default(mm_default_32, [8, 128, 1024]);  mm_default_32 = None
        view_default_527 = torch.ops.aten.view.default(view_default_526, [8, 128, 16, 64]);  view_default_526 = None
        transpose_int_147 = torch.ops.aten.transpose.int(view_default_527, 1, 2);  view_default_527 = None
        clone_default_108 = torch.ops.aten.clone.default(transpose_int_147, memory_format = torch.contiguous_format);  transpose_int_147 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_108, [128, 128, 64]);  clone_default_108 = None
        transpose_int_148 = torch.ops.aten.transpose.int(_softmax_default_20, 1, 2)
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_148, _unsafe_view_default_36);  transpose_int_148 = None
        transpose_int_149 = torch.ops.aten.transpose.int(view_default_393, 1, 2);  view_default_393 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_36, transpose_int_149);  _unsafe_view_default_36 = transpose_int_149 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(bmm_default_61, _softmax_default_20, -1, torch.float32);  bmm_default_61 = _softmax_default_20 = None
        view_default_528 = torch.ops.aten.view.default(_softmax_backward_data_default_3, [8, 16, 128, 128]);  _softmax_backward_data_default_3 = None
        view_default_529 = torch.ops.aten.view.default(view_default_528, [128, 128, 128]);  view_default_528 = None
        transpose_int_150 = torch.ops.aten.transpose.int(view_default_391, 1, 2);  view_default_391 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_150, view_default_529);  transpose_int_150 = None
        transpose_int_151 = torch.ops.aten.transpose.int(transpose_int_103, 1, 2);  transpose_int_103 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_529, transpose_int_151);  view_default_529 = transpose_int_151 = None
        transpose_int_152 = torch.ops.aten.transpose.int(bmm_default_62, 1, 2);  bmm_default_62 = None
        view_default_530 = torch.ops.aten.view.default(bmm_default_60, [8, 16, 128, 64]);  bmm_default_60 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(tangents_43, view_default_530);  tangents_43 = view_default_530 = None
        view_default_531 = torch.ops.aten.view.default(transpose_int_152, [8, 16, 128, 64]);  transpose_int_152 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(tangents_42, view_default_531);  tangents_42 = view_default_531 = None
        view_default_532 = torch.ops.aten.view.default(bmm_default_63, [8, 16, 128, 64]);  bmm_default_63 = None
        transpose_int_153 = torch.ops.aten.transpose.int(view_default_532, 1, 2);  view_default_532 = None
        clone_default_109 = torch.ops.aten.clone.default(transpose_int_153, memory_format = torch.contiguous_format);  transpose_int_153 = None
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(clone_default_109, [8, 128, 1024]);  clone_default_109 = None
        transpose_int_154 = torch.ops.aten.transpose.int(add_tensor_83, 1, 2);  add_tensor_83 = None
        clone_default_110 = torch.ops.aten.clone.default(transpose_int_154, memory_format = torch.contiguous_format);  transpose_int_154 = None
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(clone_default_110, [8, 128, 1024]);  clone_default_110 = None
        view_default_533 = torch.ops.aten.view.default(_unsafe_view_default_38, [1024, 1024]);  _unsafe_view_default_38 = None
        t_default_188 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_533, t_default_188);  t_default_188 = None
        t_default_189 = torch.ops.aten.t.default(view_default_533)
        mm_default_35 = torch.ops.aten.mm.default(t_default_189, view_default_387);  t_default_189 = view_default_387 = None
        t_default_190 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_533, [0], True);  view_default_533 = None
        view_default_534 = torch.ops.aten.view.default(sum_dim_int_list_17, [1024]);  sum_dim_int_list_17 = None
        t_default_191 = torch.ops.aten.t.default(t_default_190);  t_default_190 = None
        view_default_535 = torch.ops.aten.view.default(mm_default_34, [8, 128, 1024]);  mm_default_34 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(getitem_126, view_default_535);  getitem_126 = view_default_535 = None
        transpose_int_155 = torch.ops.aten.transpose.int(add_tensor_84, 1, 2);  add_tensor_84 = None
        clone_default_111 = torch.ops.aten.clone.default(transpose_int_155, memory_format = torch.contiguous_format);  transpose_int_155 = None
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(clone_default_111, [8, 128, 1024]);  clone_default_111 = None
        view_default_536 = torch.ops.aten.view.default(_unsafe_view_default_39, [1024, 1024]);  _unsafe_view_default_39 = None
        t_default_192 = torch.ops.aten.t.default(t_default_101);  t_default_101 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_536, t_default_192);  t_default_192 = None
        t_default_193 = torch.ops.aten.t.default(view_default_536)
        mm_default_37 = torch.ops.aten.mm.default(t_default_193, view_default_384);  t_default_193 = view_default_384 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_536, [0], True);  view_default_536 = None
        view_default_537 = torch.ops.aten.view.default(sum_dim_int_list_18, [1024]);  sum_dim_int_list_18 = None
        t_default_195 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_538 = torch.ops.aten.view.default(mm_default_36, [8, 128, 1024]);  mm_default_36 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(add_tensor_85, view_default_538);  add_tensor_85 = view_default_538 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(_unsafe_view_default_37, 0.125);  _unsafe_view_default_37 = None
        view_default_539 = torch.ops.aten.view.default(mul_tensor_42, [1024, 1024]);  mul_tensor_42 = None
        t_default_196 = torch.ops.aten.t.default(t_default_100);  t_default_100 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_539, t_default_196);  t_default_196 = None
        t_default_197 = torch.ops.aten.t.default(view_default_539)
        mm_default_39 = torch.ops.aten.mm.default(t_default_197, view_default_382);  t_default_197 = view_default_382 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_539, [0], True);  view_default_539 = None
        view_default_540 = torch.ops.aten.view.default(sum_dim_int_list_19, [1024]);  sum_dim_int_list_19 = None
        t_default_199 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        view_default_541 = torch.ops.aten.view.default(mm_default_38, [8, 128, 1024]);  mm_default_38 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(add_tensor_86, view_default_541);  add_tensor_86 = view_default_541 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_87, add_tensor_52, [1024], getitem_91, getitem_92, primals_306, primals_305, [True, True, True]);  add_tensor_87 = add_tensor_52 = getitem_91 = getitem_92 = primals_306 = primals_305 = None
        getitem_129 = native_layer_norm_backward_default_6[0]
        getitem_130 = native_layer_norm_backward_default_6[1]
        getitem_131 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_542 = torch.ops.aten.view.default(getitem_129, [1024, 1024])
        t_default_200 = torch.ops.aten.t.default(t_default_99);  t_default_99 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_542, t_default_200);  t_default_200 = None
        t_default_201 = torch.ops.aten.t.default(view_default_542)
        mm_default_41 = torch.ops.aten.mm.default(t_default_201, view_default_380);  t_default_201 = view_default_380 = None
        t_default_202 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_542, [0], True);  view_default_542 = None
        view_default_543 = torch.ops.aten.view.default(sum_dim_int_list_20, [1024]);  sum_dim_int_list_20 = None
        t_default_203 = torch.ops.aten.t.default(t_default_202);  t_default_202 = None
        view_default_544 = torch.ops.aten.view.default(mm_default_40, [8, 128, 4096]);  mm_default_40 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_544, torch.float32);  view_default_544 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_379, torch.float32);  view_default_379 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_43);  mul_tensor_43 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(add_tensor_88, 0.5);  add_tensor_88 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_46 = torch.ops.aten.mul.Tensor(mul_tensor_45, -0.5);  mul_tensor_45 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_46);  mul_tensor_46 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_47);  to_dtype_7 = mul_tensor_47 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(mul_tensor_44, mul_tensor_48);  mul_tensor_44 = mul_tensor_48 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_89);  to_dtype_6 = add_tensor_89 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_49, torch.float32);  mul_tensor_49 = None
        view_default_545 = torch.ops.aten.view.default(to_dtype_8, [1024, 4096]);  to_dtype_8 = None
        t_default_204 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_545, t_default_204);  t_default_204 = None
        t_default_205 = torch.ops.aten.t.default(view_default_545)
        mm_default_43 = torch.ops.aten.mm.default(t_default_205, view_default_378);  t_default_205 = view_default_378 = None
        t_default_206 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_545, [0], True);  view_default_545 = None
        view_default_546 = torch.ops.aten.view.default(sum_dim_int_list_21, [4096]);  sum_dim_int_list_21 = None
        t_default_207 = torch.ops.aten.t.default(t_default_206);  t_default_206 = None
        view_default_547 = torch.ops.aten.view.default(mm_default_42, [8, 128, 1024]);  mm_default_42 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(getitem_129, view_default_547);  getitem_129 = view_default_547 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_90, add_tensor_51, [1024], getitem_88, getitem_89, primals_294, primals_293, [True, True, True]);  add_tensor_90 = add_tensor_51 = getitem_88 = getitem_89 = primals_294 = primals_293 = None
        getitem_132 = native_layer_norm_backward_default_7[0]
        getitem_133 = native_layer_norm_backward_default_7[1]
        getitem_134 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_548 = torch.ops.aten.view.default(getitem_132, [1024, 1024])
        t_default_208 = torch.ops.aten.t.default(t_default_97);  t_default_97 = None
        mm_default_44 = torch.ops.aten.mm.default(view_default_548, t_default_208);  t_default_208 = None
        t_default_209 = torch.ops.aten.t.default(view_default_548)
        mm_default_45 = torch.ops.aten.mm.default(t_default_209, view_default_376);  t_default_209 = view_default_376 = None
        t_default_210 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_548, [0], True);  view_default_548 = None
        view_default_549 = torch.ops.aten.view.default(sum_dim_int_list_22, [1024]);  sum_dim_int_list_22 = None
        t_default_211 = torch.ops.aten.t.default(t_default_210);  t_default_210 = None
        view_default_550 = torch.ops.aten.view.default(mm_default_44, [8, 128, 1024]);  mm_default_44 = None
        view_default_551 = torch.ops.aten.view.default(view_default_550, [8, 128, 16, 64]);  view_default_550 = None
        transpose_int_156 = torch.ops.aten.transpose.int(view_default_551, 1, 2);  view_default_551 = None
        clone_default_112 = torch.ops.aten.clone.default(transpose_int_156, memory_format = torch.contiguous_format);  transpose_int_156 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_112, [128, 128, 64]);  clone_default_112 = None
        transpose_int_157 = torch.ops.aten.transpose.int(_softmax_default_19, 1, 2)
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_157, _unsafe_view_default_40);  transpose_int_157 = None
        transpose_int_158 = torch.ops.aten.transpose.int(view_default_372, 1, 2);  view_default_372 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_40, transpose_int_158);  _unsafe_view_default_40 = transpose_int_158 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(bmm_default_65, _softmax_default_19, -1, torch.float32);  bmm_default_65 = _softmax_default_19 = None
        view_default_552 = torch.ops.aten.view.default(_softmax_backward_data_default_4, [8, 16, 128, 1024]);  _softmax_backward_data_default_4 = None
        view_default_553 = torch.ops.aten.view.default(view_default_552, [128, 128, 1024]);  view_default_552 = None
        transpose_int_159 = torch.ops.aten.transpose.int(view_default_370, 1, 2);  view_default_370 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_159, view_default_553);  transpose_int_159 = None
        transpose_int_160 = torch.ops.aten.transpose.int(transpose_int_98, 1, 2);  transpose_int_98 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_553, transpose_int_160);  view_default_553 = transpose_int_160 = None
        transpose_int_161 = torch.ops.aten.transpose.int(bmm_default_66, 1, 2);  bmm_default_66 = None
        view_default_554 = torch.ops.aten.view.default(bmm_default_64, [8, 16, 1024, 64]);  bmm_default_64 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(tangents_41, view_default_554);  tangents_41 = view_default_554 = None
        view_default_555 = torch.ops.aten.view.default(transpose_int_161, [8, 16, 1024, 64]);  transpose_int_161 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(tangents_40, view_default_555);  tangents_40 = view_default_555 = None
        view_default_556 = torch.ops.aten.view.default(bmm_default_67, [8, 16, 128, 64]);  bmm_default_67 = None
        transpose_int_162 = torch.ops.aten.transpose.int(view_default_556, 1, 2);  view_default_556 = None
        clone_default_113 = torch.ops.aten.clone.default(transpose_int_162, memory_format = torch.contiguous_format);  transpose_int_162 = None
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_113, [8, 128, 1024]);  clone_default_113 = None
        transpose_int_163 = torch.ops.aten.transpose.int(add_tensor_91, 1, 2);  add_tensor_91 = None
        clone_default_114 = torch.ops.aten.clone.default(transpose_int_163, memory_format = torch.contiguous_format);  transpose_int_163 = None
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(clone_default_114, [8, 1024, 1024]);  clone_default_114 = None
        view_default_557 = torch.ops.aten.view.default(_unsafe_view_default_42, [8192, 1024]);  _unsafe_view_default_42 = None
        t_default_212 = torch.ops.aten.t.default(t_default_96);  t_default_96 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_557, t_default_212);  t_default_212 = None
        t_default_213 = torch.ops.aten.t.default(view_default_557)
        mm_default_47 = torch.ops.aten.mm.default(t_default_213, view_default_366);  t_default_213 = view_default_366 = None
        t_default_214 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_557, [0], True);  view_default_557 = None
        view_default_558 = torch.ops.aten.view.default(sum_dim_int_list_23, [1024]);  sum_dim_int_list_23 = None
        t_default_215 = torch.ops.aten.t.default(t_default_214);  t_default_214 = None
        view_default_559 = torch.ops.aten.view.default(mm_default_46, [8, 1024, 1024]);  mm_default_46 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(add_tensor_81, view_default_559);  add_tensor_81 = view_default_559 = None
        transpose_int_164 = torch.ops.aten.transpose.int(add_tensor_92, 1, 2);  add_tensor_92 = None
        clone_default_115 = torch.ops.aten.clone.default(transpose_int_164, memory_format = torch.contiguous_format);  transpose_int_164 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_115, [8, 1024, 1024]);  clone_default_115 = None
        view_default_560 = torch.ops.aten.view.default(_unsafe_view_default_43, [8192, 1024]);  _unsafe_view_default_43 = None
        t_default_216 = torch.ops.aten.t.default(t_default_95);  t_default_95 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_560, t_default_216);  t_default_216 = None
        t_default_217 = torch.ops.aten.t.default(view_default_560)
        mm_default_49 = torch.ops.aten.mm.default(t_default_217, view_default_363);  t_default_217 = view_default_363 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_560, [0], True);  view_default_560 = None
        view_default_561 = torch.ops.aten.view.default(sum_dim_int_list_24, [1024]);  sum_dim_int_list_24 = None
        t_default_219 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        view_default_562 = torch.ops.aten.view.default(mm_default_48, [8, 1024, 1024]);  mm_default_48 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(add_tensor_93, view_default_562);  add_tensor_93 = view_default_562 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(_unsafe_view_default_41, 0.125);  _unsafe_view_default_41 = None
        view_default_563 = torch.ops.aten.view.default(mul_tensor_50, [1024, 1024]);  mul_tensor_50 = None
        t_default_220 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_563, t_default_220);  t_default_220 = None
        t_default_221 = torch.ops.aten.t.default(view_default_563)
        mm_default_51 = torch.ops.aten.mm.default(t_default_221, view_default_361);  t_default_221 = view_default_361 = None
        t_default_222 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_563, [0], True);  view_default_563 = None
        view_default_564 = torch.ops.aten.view.default(sum_dim_int_list_25, [1024]);  sum_dim_int_list_25 = None
        t_default_223 = torch.ops.aten.t.default(t_default_222);  t_default_222 = None
        view_default_565 = torch.ops.aten.view.default(mm_default_50, [8, 128, 1024]);  mm_default_50 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(getitem_132, view_default_565);  getitem_132 = view_default_565 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_95, add_tensor_49, [1024], getitem_85, getitem_86, primals_310, primals_309, [True, True, True]);  add_tensor_95 = add_tensor_49 = getitem_85 = getitem_86 = primals_310 = primals_309 = None
        getitem_135 = native_layer_norm_backward_default_8[0]
        getitem_136 = native_layer_norm_backward_default_8[1]
        getitem_137 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_566 = torch.ops.aten.view.default(getitem_135, [1024, 1024])
        t_default_224 = torch.ops.aten.t.default(t_default_93);  t_default_93 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_566, t_default_224);  t_default_224 = None
        t_default_225 = torch.ops.aten.t.default(view_default_566)
        mm_default_53 = torch.ops.aten.mm.default(t_default_225, view_default_359);  t_default_225 = view_default_359 = None
        t_default_226 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_566, [0], True);  view_default_566 = None
        view_default_567 = torch.ops.aten.view.default(sum_dim_int_list_26, [1024]);  sum_dim_int_list_26 = None
        t_default_227 = torch.ops.aten.t.default(t_default_226);  t_default_226 = None
        view_default_568 = torch.ops.aten.view.default(mm_default_52, [8, 128, 1024]);  mm_default_52 = None
        view_default_569 = torch.ops.aten.view.default(view_default_568, [8, 128, 16, 64]);  view_default_568 = None
        transpose_int_165 = torch.ops.aten.transpose.int(view_default_569, 1, 2);  view_default_569 = None
        clone_default_116 = torch.ops.aten.clone.default(transpose_int_165, memory_format = torch.contiguous_format);  transpose_int_165 = None
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(clone_default_116, [128, 128, 64]);  clone_default_116 = None
        transpose_int_166 = torch.ops.aten.transpose.int(_softmax_default_18, 1, 2)
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_166, _unsafe_view_default_44);  transpose_int_166 = None
        transpose_int_167 = torch.ops.aten.transpose.int(view_default_355, 1, 2);  view_default_355 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_44, transpose_int_167);  _unsafe_view_default_44 = transpose_int_167 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(bmm_default_69, _softmax_default_18, -1, torch.float32);  bmm_default_69 = _softmax_default_18 = None
        view_default_570 = torch.ops.aten.view.default(_softmax_backward_data_default_5, [8, 16, 128, 128]);  _softmax_backward_data_default_5 = None
        view_default_571 = torch.ops.aten.view.default(view_default_570, [128, 128, 128]);  view_default_570 = None
        transpose_int_168 = torch.ops.aten.transpose.int(view_default_353, 1, 2);  view_default_353 = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_168, view_default_571);  transpose_int_168 = None
        transpose_int_169 = torch.ops.aten.transpose.int(transpose_int_93, 1, 2);  transpose_int_93 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_571, transpose_int_169);  view_default_571 = transpose_int_169 = None
        transpose_int_170 = torch.ops.aten.transpose.int(bmm_default_70, 1, 2);  bmm_default_70 = None
        view_default_572 = torch.ops.aten.view.default(bmm_default_68, [8, 16, 128, 64]);  bmm_default_68 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(tangents_39, view_default_572);  tangents_39 = view_default_572 = None
        view_default_573 = torch.ops.aten.view.default(transpose_int_170, [8, 16, 128, 64]);  transpose_int_170 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(tangents_38, view_default_573);  tangents_38 = view_default_573 = None
        view_default_574 = torch.ops.aten.view.default(bmm_default_71, [8, 16, 128, 64]);  bmm_default_71 = None
        transpose_int_171 = torch.ops.aten.transpose.int(view_default_574, 1, 2);  view_default_574 = None
        clone_default_117 = torch.ops.aten.clone.default(transpose_int_171, memory_format = torch.contiguous_format);  transpose_int_171 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_117, [8, 128, 1024]);  clone_default_117 = None
        transpose_int_172 = torch.ops.aten.transpose.int(add_tensor_96, 1, 2);  add_tensor_96 = None
        clone_default_118 = torch.ops.aten.clone.default(transpose_int_172, memory_format = torch.contiguous_format);  transpose_int_172 = None
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(clone_default_118, [8, 128, 1024]);  clone_default_118 = None
        view_default_575 = torch.ops.aten.view.default(_unsafe_view_default_46, [1024, 1024]);  _unsafe_view_default_46 = None
        t_default_228 = torch.ops.aten.t.default(t_default_92);  t_default_92 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_575, t_default_228);  t_default_228 = None
        t_default_229 = torch.ops.aten.t.default(view_default_575)
        mm_default_55 = torch.ops.aten.mm.default(t_default_229, view_default_349);  t_default_229 = view_default_349 = None
        t_default_230 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_575, [0], True);  view_default_575 = None
        view_default_576 = torch.ops.aten.view.default(sum_dim_int_list_27, [1024]);  sum_dim_int_list_27 = None
        t_default_231 = torch.ops.aten.t.default(t_default_230);  t_default_230 = None
        view_default_577 = torch.ops.aten.view.default(mm_default_54, [8, 128, 1024]);  mm_default_54 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_135, view_default_577);  getitem_135 = view_default_577 = None
        transpose_int_173 = torch.ops.aten.transpose.int(add_tensor_97, 1, 2);  add_tensor_97 = None
        clone_default_119 = torch.ops.aten.clone.default(transpose_int_173, memory_format = torch.contiguous_format);  transpose_int_173 = None
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(clone_default_119, [8, 128, 1024]);  clone_default_119 = None
        view_default_578 = torch.ops.aten.view.default(_unsafe_view_default_47, [1024, 1024]);  _unsafe_view_default_47 = None
        t_default_232 = torch.ops.aten.t.default(t_default_91);  t_default_91 = None
        mm_default_56 = torch.ops.aten.mm.default(view_default_578, t_default_232);  t_default_232 = None
        t_default_233 = torch.ops.aten.t.default(view_default_578)
        mm_default_57 = torch.ops.aten.mm.default(t_default_233, view_default_346);  t_default_233 = view_default_346 = None
        t_default_234 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_578, [0], True);  view_default_578 = None
        view_default_579 = torch.ops.aten.view.default(sum_dim_int_list_28, [1024]);  sum_dim_int_list_28 = None
        t_default_235 = torch.ops.aten.t.default(t_default_234);  t_default_234 = None
        view_default_580 = torch.ops.aten.view.default(mm_default_56, [8, 128, 1024]);  mm_default_56 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(add_tensor_98, view_default_580);  add_tensor_98 = view_default_580 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(_unsafe_view_default_45, 0.125);  _unsafe_view_default_45 = None
        view_default_581 = torch.ops.aten.view.default(mul_tensor_51, [1024, 1024]);  mul_tensor_51 = None
        t_default_236 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_581, t_default_236);  t_default_236 = None
        t_default_237 = torch.ops.aten.t.default(view_default_581)
        mm_default_59 = torch.ops.aten.mm.default(t_default_237, view_default_344);  t_default_237 = view_default_344 = None
        t_default_238 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_581, [0], True);  view_default_581 = None
        view_default_582 = torch.ops.aten.view.default(sum_dim_int_list_29, [1024]);  sum_dim_int_list_29 = None
        t_default_239 = torch.ops.aten.t.default(t_default_238);  t_default_238 = None
        view_default_583 = torch.ops.aten.view.default(mm_default_58, [8, 128, 1024]);  mm_default_58 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_99, view_default_583);  add_tensor_99 = view_default_583 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_100, add_tensor_47, [1024], getitem_82, getitem_83, primals_280, primals_279, [True, True, True]);  add_tensor_100 = add_tensor_47 = getitem_82 = getitem_83 = primals_280 = primals_279 = None
        getitem_138 = native_layer_norm_backward_default_9[0]
        getitem_139 = native_layer_norm_backward_default_9[1]
        getitem_140 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        view_default_584 = torch.ops.aten.view.default(getitem_138, [1024, 1024])
        t_default_240 = torch.ops.aten.t.default(t_default_89);  t_default_89 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_584, t_default_240);  t_default_240 = None
        t_default_241 = torch.ops.aten.t.default(view_default_584)
        mm_default_61 = torch.ops.aten.mm.default(t_default_241, view_default_342);  t_default_241 = view_default_342 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_584, [0], True);  view_default_584 = None
        view_default_585 = torch.ops.aten.view.default(sum_dim_int_list_30, [1024]);  sum_dim_int_list_30 = None
        t_default_243 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        view_default_586 = torch.ops.aten.view.default(mm_default_60, [8, 128, 4096]);  mm_default_60 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_586, torch.float32);  view_default_586 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_341, torch.float32);  view_default_341 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_52);  mul_tensor_52 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(add_tensor_101, 0.5);  add_tensor_101 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(mul_tensor_54, -0.5);  mul_tensor_54 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_55);  mul_tensor_55 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_56);  to_dtype_10 = mul_tensor_56 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(mul_tensor_53, mul_tensor_57);  mul_tensor_53 = mul_tensor_57 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_102);  to_dtype_9 = add_tensor_102 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_58, torch.float32);  mul_tensor_58 = None
        view_default_587 = torch.ops.aten.view.default(to_dtype_11, [1024, 4096]);  to_dtype_11 = None
        t_default_244 = torch.ops.aten.t.default(t_default_88);  t_default_88 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_587, t_default_244);  t_default_244 = None
        t_default_245 = torch.ops.aten.t.default(view_default_587)
        mm_default_63 = torch.ops.aten.mm.default(t_default_245, view_default_340);  t_default_245 = view_default_340 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_587, [0], True);  view_default_587 = None
        view_default_588 = torch.ops.aten.view.default(sum_dim_int_list_31, [4096]);  sum_dim_int_list_31 = None
        t_default_247 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_589 = torch.ops.aten.view.default(mm_default_62, [8, 128, 1024]);  mm_default_62 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(getitem_138, view_default_589);  getitem_138 = view_default_589 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_103, add_tensor_46, [1024], getitem_79, getitem_80, primals_268, primals_267, [True, True, True]);  add_tensor_103 = add_tensor_46 = getitem_79 = getitem_80 = primals_268 = primals_267 = None
        getitem_141 = native_layer_norm_backward_default_10[0]
        getitem_142 = native_layer_norm_backward_default_10[1]
        getitem_143 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_590 = torch.ops.aten.view.default(getitem_141, [1024, 1024])
        t_default_248 = torch.ops.aten.t.default(t_default_87);  t_default_87 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_590, t_default_248);  t_default_248 = None
        t_default_249 = torch.ops.aten.t.default(view_default_590)
        mm_default_65 = torch.ops.aten.mm.default(t_default_249, view_default_338);  t_default_249 = view_default_338 = None
        t_default_250 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_590, [0], True);  view_default_590 = None
        view_default_591 = torch.ops.aten.view.default(sum_dim_int_list_32, [1024]);  sum_dim_int_list_32 = None
        t_default_251 = torch.ops.aten.t.default(t_default_250);  t_default_250 = None
        view_default_592 = torch.ops.aten.view.default(mm_default_64, [8, 128, 1024]);  mm_default_64 = None
        view_default_593 = torch.ops.aten.view.default(view_default_592, [8, 128, 16, 64]);  view_default_592 = None
        transpose_int_174 = torch.ops.aten.transpose.int(view_default_593, 1, 2);  view_default_593 = None
        clone_default_120 = torch.ops.aten.clone.default(transpose_int_174, memory_format = torch.contiguous_format);  transpose_int_174 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_120, [128, 128, 64]);  clone_default_120 = None
        transpose_int_175 = torch.ops.aten.transpose.int(_softmax_default_17, 1, 2)
        bmm_default_72 = torch.ops.aten.bmm.default(transpose_int_175, _unsafe_view_default_48);  transpose_int_175 = None
        transpose_int_176 = torch.ops.aten.transpose.int(view_default_334, 1, 2);  view_default_334 = None
        bmm_default_73 = torch.ops.aten.bmm.default(_unsafe_view_default_48, transpose_int_176);  _unsafe_view_default_48 = transpose_int_176 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(bmm_default_73, _softmax_default_17, -1, torch.float32);  bmm_default_73 = _softmax_default_17 = None
        view_default_594 = torch.ops.aten.view.default(_softmax_backward_data_default_6, [8, 16, 128, 1024]);  _softmax_backward_data_default_6 = None
        view_default_595 = torch.ops.aten.view.default(view_default_594, [128, 128, 1024]);  view_default_594 = None
        transpose_int_177 = torch.ops.aten.transpose.int(view_default_332, 1, 2);  view_default_332 = None
        bmm_default_74 = torch.ops.aten.bmm.default(transpose_int_177, view_default_595);  transpose_int_177 = None
        transpose_int_178 = torch.ops.aten.transpose.int(transpose_int_88, 1, 2);  transpose_int_88 = None
        bmm_default_75 = torch.ops.aten.bmm.default(view_default_595, transpose_int_178);  view_default_595 = transpose_int_178 = None
        transpose_int_179 = torch.ops.aten.transpose.int(bmm_default_74, 1, 2);  bmm_default_74 = None
        view_default_596 = torch.ops.aten.view.default(bmm_default_72, [8, 16, 1024, 64]);  bmm_default_72 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(tangents_37, view_default_596);  tangents_37 = view_default_596 = None
        view_default_597 = torch.ops.aten.view.default(transpose_int_179, [8, 16, 1024, 64]);  transpose_int_179 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(tangents_36, view_default_597);  tangents_36 = view_default_597 = None
        view_default_598 = torch.ops.aten.view.default(bmm_default_75, [8, 16, 128, 64]);  bmm_default_75 = None
        transpose_int_180 = torch.ops.aten.transpose.int(view_default_598, 1, 2);  view_default_598 = None
        clone_default_121 = torch.ops.aten.clone.default(transpose_int_180, memory_format = torch.contiguous_format);  transpose_int_180 = None
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(clone_default_121, [8, 128, 1024]);  clone_default_121 = None
        transpose_int_181 = torch.ops.aten.transpose.int(add_tensor_104, 1, 2);  add_tensor_104 = None
        clone_default_122 = torch.ops.aten.clone.default(transpose_int_181, memory_format = torch.contiguous_format);  transpose_int_181 = None
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(clone_default_122, [8, 1024, 1024]);  clone_default_122 = None
        view_default_599 = torch.ops.aten.view.default(_unsafe_view_default_50, [8192, 1024]);  _unsafe_view_default_50 = None
        t_default_252 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_599, t_default_252);  t_default_252 = None
        t_default_253 = torch.ops.aten.t.default(view_default_599)
        mm_default_67 = torch.ops.aten.mm.default(t_default_253, view_default_328);  t_default_253 = view_default_328 = None
        t_default_254 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_599, [0], True);  view_default_599 = None
        view_default_600 = torch.ops.aten.view.default(sum_dim_int_list_33, [1024]);  sum_dim_int_list_33 = None
        t_default_255 = torch.ops.aten.t.default(t_default_254);  t_default_254 = None
        view_default_601 = torch.ops.aten.view.default(mm_default_66, [8, 1024, 1024]);  mm_default_66 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_94, view_default_601);  add_tensor_94 = view_default_601 = None
        transpose_int_182 = torch.ops.aten.transpose.int(add_tensor_105, 1, 2);  add_tensor_105 = None
        clone_default_123 = torch.ops.aten.clone.default(transpose_int_182, memory_format = torch.contiguous_format);  transpose_int_182 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_123, [8, 1024, 1024]);  clone_default_123 = None
        view_default_602 = torch.ops.aten.view.default(_unsafe_view_default_51, [8192, 1024]);  _unsafe_view_default_51 = None
        t_default_256 = torch.ops.aten.t.default(t_default_85);  t_default_85 = None
        mm_default_68 = torch.ops.aten.mm.default(view_default_602, t_default_256);  t_default_256 = None
        t_default_257 = torch.ops.aten.t.default(view_default_602)
        mm_default_69 = torch.ops.aten.mm.default(t_default_257, view_default_325);  t_default_257 = view_default_325 = None
        t_default_258 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(view_default_602, [0], True);  view_default_602 = None
        view_default_603 = torch.ops.aten.view.default(sum_dim_int_list_34, [1024]);  sum_dim_int_list_34 = None
        t_default_259 = torch.ops.aten.t.default(t_default_258);  t_default_258 = None
        view_default_604 = torch.ops.aten.view.default(mm_default_68, [8, 1024, 1024]);  mm_default_68 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_106, view_default_604);  add_tensor_106 = view_default_604 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(_unsafe_view_default_49, 0.125);  _unsafe_view_default_49 = None
        view_default_605 = torch.ops.aten.view.default(mul_tensor_59, [1024, 1024]);  mul_tensor_59 = None
        t_default_260 = torch.ops.aten.t.default(t_default_84);  t_default_84 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_605, t_default_260);  t_default_260 = None
        t_default_261 = torch.ops.aten.t.default(view_default_605)
        mm_default_71 = torch.ops.aten.mm.default(t_default_261, view_default_323);  t_default_261 = view_default_323 = None
        t_default_262 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_605, [0], True);  view_default_605 = None
        view_default_606 = torch.ops.aten.view.default(sum_dim_int_list_35, [1024]);  sum_dim_int_list_35 = None
        t_default_263 = torch.ops.aten.t.default(t_default_262);  t_default_262 = None
        view_default_607 = torch.ops.aten.view.default(mm_default_70, [8, 128, 1024]);  mm_default_70 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(getitem_141, view_default_607);  getitem_141 = view_default_607 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_108, add_tensor_44, [1024], getitem_76, getitem_77, primals_284, primals_283, [True, True, True]);  add_tensor_108 = add_tensor_44 = getitem_76 = getitem_77 = primals_284 = primals_283 = None
        getitem_144 = native_layer_norm_backward_default_11[0]
        getitem_145 = native_layer_norm_backward_default_11[1]
        getitem_146 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_608 = torch.ops.aten.view.default(getitem_144, [1024, 1024])
        t_default_264 = torch.ops.aten.t.default(t_default_83);  t_default_83 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_608, t_default_264);  t_default_264 = None
        t_default_265 = torch.ops.aten.t.default(view_default_608)
        mm_default_73 = torch.ops.aten.mm.default(t_default_265, view_default_321);  t_default_265 = view_default_321 = None
        t_default_266 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_608, [0], True);  view_default_608 = None
        view_default_609 = torch.ops.aten.view.default(sum_dim_int_list_36, [1024]);  sum_dim_int_list_36 = None
        t_default_267 = torch.ops.aten.t.default(t_default_266);  t_default_266 = None
        view_default_610 = torch.ops.aten.view.default(mm_default_72, [8, 128, 1024]);  mm_default_72 = None
        view_default_611 = torch.ops.aten.view.default(view_default_610, [8, 128, 16, 64]);  view_default_610 = None
        transpose_int_183 = torch.ops.aten.transpose.int(view_default_611, 1, 2);  view_default_611 = None
        clone_default_124 = torch.ops.aten.clone.default(transpose_int_183, memory_format = torch.contiguous_format);  transpose_int_183 = None
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(clone_default_124, [128, 128, 64]);  clone_default_124 = None
        transpose_int_184 = torch.ops.aten.transpose.int(_softmax_default_16, 1, 2)
        bmm_default_76 = torch.ops.aten.bmm.default(transpose_int_184, _unsafe_view_default_52);  transpose_int_184 = None
        transpose_int_185 = torch.ops.aten.transpose.int(view_default_317, 1, 2);  view_default_317 = None
        bmm_default_77 = torch.ops.aten.bmm.default(_unsafe_view_default_52, transpose_int_185);  _unsafe_view_default_52 = transpose_int_185 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(bmm_default_77, _softmax_default_16, -1, torch.float32);  bmm_default_77 = _softmax_default_16 = None
        view_default_612 = torch.ops.aten.view.default(_softmax_backward_data_default_7, [8, 16, 128, 128]);  _softmax_backward_data_default_7 = None
        view_default_613 = torch.ops.aten.view.default(view_default_612, [128, 128, 128]);  view_default_612 = None
        transpose_int_186 = torch.ops.aten.transpose.int(view_default_315, 1, 2);  view_default_315 = None
        bmm_default_78 = torch.ops.aten.bmm.default(transpose_int_186, view_default_613);  transpose_int_186 = None
        transpose_int_187 = torch.ops.aten.transpose.int(transpose_int_83, 1, 2);  transpose_int_83 = None
        bmm_default_79 = torch.ops.aten.bmm.default(view_default_613, transpose_int_187);  view_default_613 = transpose_int_187 = None
        transpose_int_188 = torch.ops.aten.transpose.int(bmm_default_78, 1, 2);  bmm_default_78 = None
        view_default_614 = torch.ops.aten.view.default(bmm_default_76, [8, 16, 128, 64]);  bmm_default_76 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(tangents_35, view_default_614);  tangents_35 = view_default_614 = None
        view_default_615 = torch.ops.aten.view.default(transpose_int_188, [8, 16, 128, 64]);  transpose_int_188 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(tangents_34, view_default_615);  tangents_34 = view_default_615 = None
        view_default_616 = torch.ops.aten.view.default(bmm_default_79, [8, 16, 128, 64]);  bmm_default_79 = None
        transpose_int_189 = torch.ops.aten.transpose.int(view_default_616, 1, 2);  view_default_616 = None
        clone_default_125 = torch.ops.aten.clone.default(transpose_int_189, memory_format = torch.contiguous_format);  transpose_int_189 = None
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(clone_default_125, [8, 128, 1024]);  clone_default_125 = None
        transpose_int_190 = torch.ops.aten.transpose.int(add_tensor_109, 1, 2);  add_tensor_109 = None
        clone_default_126 = torch.ops.aten.clone.default(transpose_int_190, memory_format = torch.contiguous_format);  transpose_int_190 = None
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(clone_default_126, [8, 128, 1024]);  clone_default_126 = None
        view_default_617 = torch.ops.aten.view.default(_unsafe_view_default_54, [1024, 1024]);  _unsafe_view_default_54 = None
        t_default_268 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_617, t_default_268);  t_default_268 = None
        t_default_269 = torch.ops.aten.t.default(view_default_617)
        mm_default_75 = torch.ops.aten.mm.default(t_default_269, view_default_311);  t_default_269 = view_default_311 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_617, [0], True);  view_default_617 = None
        view_default_618 = torch.ops.aten.view.default(sum_dim_int_list_37, [1024]);  sum_dim_int_list_37 = None
        t_default_271 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_619 = torch.ops.aten.view.default(mm_default_74, [8, 128, 1024]);  mm_default_74 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(getitem_144, view_default_619);  getitem_144 = view_default_619 = None
        transpose_int_191 = torch.ops.aten.transpose.int(add_tensor_110, 1, 2);  add_tensor_110 = None
        clone_default_127 = torch.ops.aten.clone.default(transpose_int_191, memory_format = torch.contiguous_format);  transpose_int_191 = None
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(clone_default_127, [8, 128, 1024]);  clone_default_127 = None
        view_default_620 = torch.ops.aten.view.default(_unsafe_view_default_55, [1024, 1024]);  _unsafe_view_default_55 = None
        t_default_272 = torch.ops.aten.t.default(t_default_81);  t_default_81 = None
        mm_default_76 = torch.ops.aten.mm.default(view_default_620, t_default_272);  t_default_272 = None
        t_default_273 = torch.ops.aten.t.default(view_default_620)
        mm_default_77 = torch.ops.aten.mm.default(t_default_273, view_default_308);  t_default_273 = view_default_308 = None
        t_default_274 = torch.ops.aten.t.default(mm_default_77);  mm_default_77 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(view_default_620, [0], True);  view_default_620 = None
        view_default_621 = torch.ops.aten.view.default(sum_dim_int_list_38, [1024]);  sum_dim_int_list_38 = None
        t_default_275 = torch.ops.aten.t.default(t_default_274);  t_default_274 = None
        view_default_622 = torch.ops.aten.view.default(mm_default_76, [8, 128, 1024]);  mm_default_76 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_111, view_default_622);  add_tensor_111 = view_default_622 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(_unsafe_view_default_53, 0.125);  _unsafe_view_default_53 = None
        view_default_623 = torch.ops.aten.view.default(mul_tensor_60, [1024, 1024]);  mul_tensor_60 = None
        t_default_276 = torch.ops.aten.t.default(t_default_80);  t_default_80 = None
        mm_default_78 = torch.ops.aten.mm.default(view_default_623, t_default_276);  t_default_276 = None
        t_default_277 = torch.ops.aten.t.default(view_default_623)
        mm_default_79 = torch.ops.aten.mm.default(t_default_277, view_default_306);  t_default_277 = view_default_306 = None
        t_default_278 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(view_default_623, [0], True);  view_default_623 = None
        view_default_624 = torch.ops.aten.view.default(sum_dim_int_list_39, [1024]);  sum_dim_int_list_39 = None
        t_default_279 = torch.ops.aten.t.default(t_default_278);  t_default_278 = None
        view_default_625 = torch.ops.aten.view.default(mm_default_78, [8, 128, 1024]);  mm_default_78 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_112, view_default_625);  add_tensor_112 = view_default_625 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_113, add_tensor_42, [1024], getitem_73, getitem_74, primals_254, primals_253, [True, True, True]);  add_tensor_113 = add_tensor_42 = getitem_73 = getitem_74 = primals_254 = primals_253 = None
        getitem_147 = native_layer_norm_backward_default_12[0]
        getitem_148 = native_layer_norm_backward_default_12[1]
        getitem_149 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        view_default_626 = torch.ops.aten.view.default(getitem_147, [1024, 1024])
        t_default_280 = torch.ops.aten.t.default(t_default_79);  t_default_79 = None
        mm_default_80 = torch.ops.aten.mm.default(view_default_626, t_default_280);  t_default_280 = None
        t_default_281 = torch.ops.aten.t.default(view_default_626)
        mm_default_81 = torch.ops.aten.mm.default(t_default_281, view_default_304);  t_default_281 = view_default_304 = None
        t_default_282 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(view_default_626, [0], True);  view_default_626 = None
        view_default_627 = torch.ops.aten.view.default(sum_dim_int_list_40, [1024]);  sum_dim_int_list_40 = None
        t_default_283 = torch.ops.aten.t.default(t_default_282);  t_default_282 = None
        view_default_628 = torch.ops.aten.view.default(mm_default_80, [8, 128, 4096]);  mm_default_80 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_628, torch.float32);  view_default_628 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_303, torch.float32);  view_default_303 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_61);  mul_tensor_61 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(add_tensor_114, 0.5);  add_tensor_114 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(mul_tensor_63, -0.5);  mul_tensor_63 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_64);  mul_tensor_64 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_65);  to_dtype_13 = mul_tensor_65 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(mul_tensor_62, mul_tensor_66);  mul_tensor_62 = mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_115);  to_dtype_12 = add_tensor_115 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_67, torch.float32);  mul_tensor_67 = None
        view_default_629 = torch.ops.aten.view.default(to_dtype_14, [1024, 4096]);  to_dtype_14 = None
        t_default_284 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_629, t_default_284);  t_default_284 = None
        t_default_285 = torch.ops.aten.t.default(view_default_629)
        mm_default_83 = torch.ops.aten.mm.default(t_default_285, view_default_302);  t_default_285 = view_default_302 = None
        t_default_286 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(view_default_629, [0], True);  view_default_629 = None
        view_default_630 = torch.ops.aten.view.default(sum_dim_int_list_41, [4096]);  sum_dim_int_list_41 = None
        t_default_287 = torch.ops.aten.t.default(t_default_286);  t_default_286 = None
        view_default_631 = torch.ops.aten.view.default(mm_default_82, [8, 128, 1024]);  mm_default_82 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(getitem_147, view_default_631);  getitem_147 = view_default_631 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_116, add_tensor_41, [1024], getitem_70, getitem_71, primals_242, primals_241, [True, True, True]);  add_tensor_116 = add_tensor_41 = getitem_70 = getitem_71 = primals_242 = primals_241 = None
        getitem_150 = native_layer_norm_backward_default_13[0]
        getitem_151 = native_layer_norm_backward_default_13[1]
        getitem_152 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        view_default_632 = torch.ops.aten.view.default(getitem_150, [1024, 1024])
        t_default_288 = torch.ops.aten.t.default(t_default_77);  t_default_77 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_632, t_default_288);  t_default_288 = None
        t_default_289 = torch.ops.aten.t.default(view_default_632)
        mm_default_85 = torch.ops.aten.mm.default(t_default_289, view_default_300);  t_default_289 = view_default_300 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_632, [0], True);  view_default_632 = None
        view_default_633 = torch.ops.aten.view.default(sum_dim_int_list_42, [1024]);  sum_dim_int_list_42 = None
        t_default_291 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_634 = torch.ops.aten.view.default(mm_default_84, [8, 128, 1024]);  mm_default_84 = None
        view_default_635 = torch.ops.aten.view.default(view_default_634, [8, 128, 16, 64]);  view_default_634 = None
        transpose_int_192 = torch.ops.aten.transpose.int(view_default_635, 1, 2);  view_default_635 = None
        clone_default_128 = torch.ops.aten.clone.default(transpose_int_192, memory_format = torch.contiguous_format);  transpose_int_192 = None
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(clone_default_128, [128, 128, 64]);  clone_default_128 = None
        transpose_int_193 = torch.ops.aten.transpose.int(_softmax_default_15, 1, 2)
        bmm_default_80 = torch.ops.aten.bmm.default(transpose_int_193, _unsafe_view_default_56);  transpose_int_193 = None
        transpose_int_194 = torch.ops.aten.transpose.int(view_default_296, 1, 2);  view_default_296 = None
        bmm_default_81 = torch.ops.aten.bmm.default(_unsafe_view_default_56, transpose_int_194);  _unsafe_view_default_56 = transpose_int_194 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(bmm_default_81, _softmax_default_15, -1, torch.float32);  bmm_default_81 = _softmax_default_15 = None
        view_default_636 = torch.ops.aten.view.default(_softmax_backward_data_default_8, [8, 16, 128, 1024]);  _softmax_backward_data_default_8 = None
        view_default_637 = torch.ops.aten.view.default(view_default_636, [128, 128, 1024]);  view_default_636 = None
        transpose_int_195 = torch.ops.aten.transpose.int(view_default_294, 1, 2);  view_default_294 = None
        bmm_default_82 = torch.ops.aten.bmm.default(transpose_int_195, view_default_637);  transpose_int_195 = None
        transpose_int_196 = torch.ops.aten.transpose.int(transpose_int_78, 1, 2);  transpose_int_78 = None
        bmm_default_83 = torch.ops.aten.bmm.default(view_default_637, transpose_int_196);  view_default_637 = transpose_int_196 = None
        transpose_int_197 = torch.ops.aten.transpose.int(bmm_default_82, 1, 2);  bmm_default_82 = None
        view_default_638 = torch.ops.aten.view.default(bmm_default_80, [8, 16, 1024, 64]);  bmm_default_80 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(tangents_33, view_default_638);  tangents_33 = view_default_638 = None
        view_default_639 = torch.ops.aten.view.default(transpose_int_197, [8, 16, 1024, 64]);  transpose_int_197 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(tangents_32, view_default_639);  tangents_32 = view_default_639 = None
        view_default_640 = torch.ops.aten.view.default(bmm_default_83, [8, 16, 128, 64]);  bmm_default_83 = None
        transpose_int_198 = torch.ops.aten.transpose.int(view_default_640, 1, 2);  view_default_640 = None
        clone_default_129 = torch.ops.aten.clone.default(transpose_int_198, memory_format = torch.contiguous_format);  transpose_int_198 = None
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(clone_default_129, [8, 128, 1024]);  clone_default_129 = None
        transpose_int_199 = torch.ops.aten.transpose.int(add_tensor_117, 1, 2);  add_tensor_117 = None
        clone_default_130 = torch.ops.aten.clone.default(transpose_int_199, memory_format = torch.contiguous_format);  transpose_int_199 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_130, [8, 1024, 1024]);  clone_default_130 = None
        view_default_641 = torch.ops.aten.view.default(_unsafe_view_default_58, [8192, 1024]);  _unsafe_view_default_58 = None
        t_default_292 = torch.ops.aten.t.default(t_default_76);  t_default_76 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_641, t_default_292);  t_default_292 = None
        t_default_293 = torch.ops.aten.t.default(view_default_641)
        mm_default_87 = torch.ops.aten.mm.default(t_default_293, view_default_290);  t_default_293 = view_default_290 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_641, [0], True);  view_default_641 = None
        view_default_642 = torch.ops.aten.view.default(sum_dim_int_list_43, [1024]);  sum_dim_int_list_43 = None
        t_default_295 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        view_default_643 = torch.ops.aten.view.default(mm_default_86, [8, 1024, 1024]);  mm_default_86 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(add_tensor_107, view_default_643);  add_tensor_107 = view_default_643 = None
        transpose_int_200 = torch.ops.aten.transpose.int(add_tensor_118, 1, 2);  add_tensor_118 = None
        clone_default_131 = torch.ops.aten.clone.default(transpose_int_200, memory_format = torch.contiguous_format);  transpose_int_200 = None
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(clone_default_131, [8, 1024, 1024]);  clone_default_131 = None
        view_default_644 = torch.ops.aten.view.default(_unsafe_view_default_59, [8192, 1024]);  _unsafe_view_default_59 = None
        t_default_296 = torch.ops.aten.t.default(t_default_75);  t_default_75 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_644, t_default_296);  t_default_296 = None
        t_default_297 = torch.ops.aten.t.default(view_default_644)
        mm_default_89 = torch.ops.aten.mm.default(t_default_297, view_default_287);  t_default_297 = view_default_287 = None
        t_default_298 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_644, [0], True);  view_default_644 = None
        view_default_645 = torch.ops.aten.view.default(sum_dim_int_list_44, [1024]);  sum_dim_int_list_44 = None
        t_default_299 = torch.ops.aten.t.default(t_default_298);  t_default_298 = None
        view_default_646 = torch.ops.aten.view.default(mm_default_88, [8, 1024, 1024]);  mm_default_88 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(add_tensor_119, view_default_646);  add_tensor_119 = view_default_646 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(_unsafe_view_default_57, 0.125);  _unsafe_view_default_57 = None
        view_default_647 = torch.ops.aten.view.default(mul_tensor_68, [1024, 1024]);  mul_tensor_68 = None
        t_default_300 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_647, t_default_300);  t_default_300 = None
        t_default_301 = torch.ops.aten.t.default(view_default_647)
        mm_default_91 = torch.ops.aten.mm.default(t_default_301, view_default_285);  t_default_301 = view_default_285 = None
        t_default_302 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(view_default_647, [0], True);  view_default_647 = None
        view_default_648 = torch.ops.aten.view.default(sum_dim_int_list_45, [1024]);  sum_dim_int_list_45 = None
        t_default_303 = torch.ops.aten.t.default(t_default_302);  t_default_302 = None
        view_default_649 = torch.ops.aten.view.default(mm_default_90, [8, 128, 1024]);  mm_default_90 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(getitem_150, view_default_649);  getitem_150 = view_default_649 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_121, add_tensor_39, [1024], getitem_67, getitem_68, primals_258, primals_257, [True, True, True]);  add_tensor_121 = add_tensor_39 = getitem_67 = getitem_68 = primals_258 = primals_257 = None
        getitem_153 = native_layer_norm_backward_default_14[0]
        getitem_154 = native_layer_norm_backward_default_14[1]
        getitem_155 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_650 = torch.ops.aten.view.default(getitem_153, [1024, 1024])
        t_default_304 = torch.ops.aten.t.default(t_default_73);  t_default_73 = None
        mm_default_92 = torch.ops.aten.mm.default(view_default_650, t_default_304);  t_default_304 = None
        t_default_305 = torch.ops.aten.t.default(view_default_650)
        mm_default_93 = torch.ops.aten.mm.default(t_default_305, view_default_283);  t_default_305 = view_default_283 = None
        t_default_306 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(view_default_650, [0], True);  view_default_650 = None
        view_default_651 = torch.ops.aten.view.default(sum_dim_int_list_46, [1024]);  sum_dim_int_list_46 = None
        t_default_307 = torch.ops.aten.t.default(t_default_306);  t_default_306 = None
        view_default_652 = torch.ops.aten.view.default(mm_default_92, [8, 128, 1024]);  mm_default_92 = None
        view_default_653 = torch.ops.aten.view.default(view_default_652, [8, 128, 16, 64]);  view_default_652 = None
        transpose_int_201 = torch.ops.aten.transpose.int(view_default_653, 1, 2);  view_default_653 = None
        clone_default_132 = torch.ops.aten.clone.default(transpose_int_201, memory_format = torch.contiguous_format);  transpose_int_201 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_132, [128, 128, 64]);  clone_default_132 = None
        transpose_int_202 = torch.ops.aten.transpose.int(_softmax_default_14, 1, 2)
        bmm_default_84 = torch.ops.aten.bmm.default(transpose_int_202, _unsafe_view_default_60);  transpose_int_202 = None
        transpose_int_203 = torch.ops.aten.transpose.int(view_default_279, 1, 2);  view_default_279 = None
        bmm_default_85 = torch.ops.aten.bmm.default(_unsafe_view_default_60, transpose_int_203);  _unsafe_view_default_60 = transpose_int_203 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(bmm_default_85, _softmax_default_14, -1, torch.float32);  bmm_default_85 = _softmax_default_14 = None
        view_default_654 = torch.ops.aten.view.default(_softmax_backward_data_default_9, [8, 16, 128, 128]);  _softmax_backward_data_default_9 = None
        view_default_655 = torch.ops.aten.view.default(view_default_654, [128, 128, 128]);  view_default_654 = None
        transpose_int_204 = torch.ops.aten.transpose.int(view_default_277, 1, 2);  view_default_277 = None
        bmm_default_86 = torch.ops.aten.bmm.default(transpose_int_204, view_default_655);  transpose_int_204 = None
        transpose_int_205 = torch.ops.aten.transpose.int(transpose_int_73, 1, 2);  transpose_int_73 = None
        bmm_default_87 = torch.ops.aten.bmm.default(view_default_655, transpose_int_205);  view_default_655 = transpose_int_205 = None
        transpose_int_206 = torch.ops.aten.transpose.int(bmm_default_86, 1, 2);  bmm_default_86 = None
        view_default_656 = torch.ops.aten.view.default(bmm_default_84, [8, 16, 128, 64]);  bmm_default_84 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(tangents_31, view_default_656);  tangents_31 = view_default_656 = None
        view_default_657 = torch.ops.aten.view.default(transpose_int_206, [8, 16, 128, 64]);  transpose_int_206 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(tangents_30, view_default_657);  tangents_30 = view_default_657 = None
        view_default_658 = torch.ops.aten.view.default(bmm_default_87, [8, 16, 128, 64]);  bmm_default_87 = None
        transpose_int_207 = torch.ops.aten.transpose.int(view_default_658, 1, 2);  view_default_658 = None
        clone_default_133 = torch.ops.aten.clone.default(transpose_int_207, memory_format = torch.contiguous_format);  transpose_int_207 = None
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(clone_default_133, [8, 128, 1024]);  clone_default_133 = None
        transpose_int_208 = torch.ops.aten.transpose.int(add_tensor_122, 1, 2);  add_tensor_122 = None
        clone_default_134 = torch.ops.aten.clone.default(transpose_int_208, memory_format = torch.contiguous_format);  transpose_int_208 = None
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(clone_default_134, [8, 128, 1024]);  clone_default_134 = None
        view_default_659 = torch.ops.aten.view.default(_unsafe_view_default_62, [1024, 1024]);  _unsafe_view_default_62 = None
        t_default_308 = torch.ops.aten.t.default(t_default_72);  t_default_72 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_659, t_default_308);  t_default_308 = None
        t_default_309 = torch.ops.aten.t.default(view_default_659)
        mm_default_95 = torch.ops.aten.mm.default(t_default_309, view_default_273);  t_default_309 = view_default_273 = None
        t_default_310 = torch.ops.aten.t.default(mm_default_95);  mm_default_95 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(view_default_659, [0], True);  view_default_659 = None
        view_default_660 = torch.ops.aten.view.default(sum_dim_int_list_47, [1024]);  sum_dim_int_list_47 = None
        t_default_311 = torch.ops.aten.t.default(t_default_310);  t_default_310 = None
        view_default_661 = torch.ops.aten.view.default(mm_default_94, [8, 128, 1024]);  mm_default_94 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(getitem_153, view_default_661);  getitem_153 = view_default_661 = None
        transpose_int_209 = torch.ops.aten.transpose.int(add_tensor_123, 1, 2);  add_tensor_123 = None
        clone_default_135 = torch.ops.aten.clone.default(transpose_int_209, memory_format = torch.contiguous_format);  transpose_int_209 = None
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(clone_default_135, [8, 128, 1024]);  clone_default_135 = None
        view_default_662 = torch.ops.aten.view.default(_unsafe_view_default_63, [1024, 1024]);  _unsafe_view_default_63 = None
        t_default_312 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_662, t_default_312);  t_default_312 = None
        t_default_313 = torch.ops.aten.t.default(view_default_662)
        mm_default_97 = torch.ops.aten.mm.default(t_default_313, view_default_270);  t_default_313 = view_default_270 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_662, [0], True);  view_default_662 = None
        view_default_663 = torch.ops.aten.view.default(sum_dim_int_list_48, [1024]);  sum_dim_int_list_48 = None
        t_default_315 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_664 = torch.ops.aten.view.default(mm_default_96, [8, 128, 1024]);  mm_default_96 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(add_tensor_124, view_default_664);  add_tensor_124 = view_default_664 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(_unsafe_view_default_61, 0.125);  _unsafe_view_default_61 = None
        view_default_665 = torch.ops.aten.view.default(mul_tensor_69, [1024, 1024]);  mul_tensor_69 = None
        t_default_316 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_98 = torch.ops.aten.mm.default(view_default_665, t_default_316);  t_default_316 = None
        t_default_317 = torch.ops.aten.t.default(view_default_665)
        mm_default_99 = torch.ops.aten.mm.default(t_default_317, view_default_268);  t_default_317 = view_default_268 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(view_default_665, [0], True);  view_default_665 = None
        view_default_666 = torch.ops.aten.view.default(sum_dim_int_list_49, [1024]);  sum_dim_int_list_49 = None
        t_default_319 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        view_default_667 = torch.ops.aten.view.default(mm_default_98, [8, 128, 1024]);  mm_default_98 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(add_tensor_125, view_default_667);  add_tensor_125 = view_default_667 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_126, add_tensor_37, [1024], getitem_64, getitem_65, primals_228, primals_227, [True, True, True]);  add_tensor_126 = add_tensor_37 = getitem_64 = getitem_65 = primals_228 = primals_227 = None
        getitem_156 = native_layer_norm_backward_default_15[0]
        getitem_157 = native_layer_norm_backward_default_15[1]
        getitem_158 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        view_default_668 = torch.ops.aten.view.default(getitem_156, [1024, 1024])
        t_default_320 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_100 = torch.ops.aten.mm.default(view_default_668, t_default_320);  t_default_320 = None
        t_default_321 = torch.ops.aten.t.default(view_default_668)
        mm_default_101 = torch.ops.aten.mm.default(t_default_321, view_default_266);  t_default_321 = view_default_266 = None
        t_default_322 = torch.ops.aten.t.default(mm_default_101);  mm_default_101 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(view_default_668, [0], True);  view_default_668 = None
        view_default_669 = torch.ops.aten.view.default(sum_dim_int_list_50, [1024]);  sum_dim_int_list_50 = None
        t_default_323 = torch.ops.aten.t.default(t_default_322);  t_default_322 = None
        view_default_670 = torch.ops.aten.view.default(mm_default_100, [8, 128, 4096]);  mm_default_100 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_670, torch.float32);  view_default_670 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_265, torch.float32);  view_default_265 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_70);  mul_tensor_70 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(add_tensor_127, 0.5);  add_tensor_127 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_73 = torch.ops.aten.mul.Tensor(mul_tensor_72, -0.5);  mul_tensor_72 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_73);  mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_74);  to_dtype_16 = mul_tensor_74 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(mul_tensor_71, mul_tensor_75);  mul_tensor_71 = mul_tensor_75 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_128);  to_dtype_15 = add_tensor_128 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_76, torch.float32);  mul_tensor_76 = None
        view_default_671 = torch.ops.aten.view.default(to_dtype_17, [1024, 4096]);  to_dtype_17 = None
        t_default_324 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_102 = torch.ops.aten.mm.default(view_default_671, t_default_324);  t_default_324 = None
        t_default_325 = torch.ops.aten.t.default(view_default_671)
        mm_default_103 = torch.ops.aten.mm.default(t_default_325, view_default_264);  t_default_325 = view_default_264 = None
        t_default_326 = torch.ops.aten.t.default(mm_default_103);  mm_default_103 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(view_default_671, [0], True);  view_default_671 = None
        view_default_672 = torch.ops.aten.view.default(sum_dim_int_list_51, [4096]);  sum_dim_int_list_51 = None
        t_default_327 = torch.ops.aten.t.default(t_default_326);  t_default_326 = None
        view_default_673 = torch.ops.aten.view.default(mm_default_102, [8, 128, 1024]);  mm_default_102 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(getitem_156, view_default_673);  getitem_156 = view_default_673 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_129, add_tensor_36, [1024], getitem_61, getitem_62, primals_216, primals_215, [True, True, True]);  add_tensor_129 = add_tensor_36 = getitem_61 = getitem_62 = primals_216 = primals_215 = None
        getitem_159 = native_layer_norm_backward_default_16[0]
        getitem_160 = native_layer_norm_backward_default_16[1]
        getitem_161 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_674 = torch.ops.aten.view.default(getitem_159, [1024, 1024])
        t_default_328 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_104 = torch.ops.aten.mm.default(view_default_674, t_default_328);  t_default_328 = None
        t_default_329 = torch.ops.aten.t.default(view_default_674)
        mm_default_105 = torch.ops.aten.mm.default(t_default_329, view_default_262);  t_default_329 = view_default_262 = None
        t_default_330 = torch.ops.aten.t.default(mm_default_105);  mm_default_105 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(view_default_674, [0], True);  view_default_674 = None
        view_default_675 = torch.ops.aten.view.default(sum_dim_int_list_52, [1024]);  sum_dim_int_list_52 = None
        t_default_331 = torch.ops.aten.t.default(t_default_330);  t_default_330 = None
        view_default_676 = torch.ops.aten.view.default(mm_default_104, [8, 128, 1024]);  mm_default_104 = None
        view_default_677 = torch.ops.aten.view.default(view_default_676, [8, 128, 16, 64]);  view_default_676 = None
        transpose_int_210 = torch.ops.aten.transpose.int(view_default_677, 1, 2);  view_default_677 = None
        clone_default_136 = torch.ops.aten.clone.default(transpose_int_210, memory_format = torch.contiguous_format);  transpose_int_210 = None
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(clone_default_136, [128, 128, 64]);  clone_default_136 = None
        transpose_int_211 = torch.ops.aten.transpose.int(_softmax_default_13, 1, 2)
        bmm_default_88 = torch.ops.aten.bmm.default(transpose_int_211, _unsafe_view_default_64);  transpose_int_211 = None
        transpose_int_212 = torch.ops.aten.transpose.int(view_default_258, 1, 2);  view_default_258 = None
        bmm_default_89 = torch.ops.aten.bmm.default(_unsafe_view_default_64, transpose_int_212);  _unsafe_view_default_64 = transpose_int_212 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(bmm_default_89, _softmax_default_13, -1, torch.float32);  bmm_default_89 = _softmax_default_13 = None
        view_default_678 = torch.ops.aten.view.default(_softmax_backward_data_default_10, [8, 16, 128, 1024]);  _softmax_backward_data_default_10 = None
        view_default_679 = torch.ops.aten.view.default(view_default_678, [128, 128, 1024]);  view_default_678 = None
        transpose_int_213 = torch.ops.aten.transpose.int(view_default_256, 1, 2);  view_default_256 = None
        bmm_default_90 = torch.ops.aten.bmm.default(transpose_int_213, view_default_679);  transpose_int_213 = None
        transpose_int_214 = torch.ops.aten.transpose.int(transpose_int_68, 1, 2);  transpose_int_68 = None
        bmm_default_91 = torch.ops.aten.bmm.default(view_default_679, transpose_int_214);  view_default_679 = transpose_int_214 = None
        transpose_int_215 = torch.ops.aten.transpose.int(bmm_default_90, 1, 2);  bmm_default_90 = None
        view_default_680 = torch.ops.aten.view.default(bmm_default_88, [8, 16, 1024, 64]);  bmm_default_88 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(tangents_29, view_default_680);  tangents_29 = view_default_680 = None
        view_default_681 = torch.ops.aten.view.default(transpose_int_215, [8, 16, 1024, 64]);  transpose_int_215 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(tangents_28, view_default_681);  tangents_28 = view_default_681 = None
        view_default_682 = torch.ops.aten.view.default(bmm_default_91, [8, 16, 128, 64]);  bmm_default_91 = None
        transpose_int_216 = torch.ops.aten.transpose.int(view_default_682, 1, 2);  view_default_682 = None
        clone_default_137 = torch.ops.aten.clone.default(transpose_int_216, memory_format = torch.contiguous_format);  transpose_int_216 = None
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(clone_default_137, [8, 128, 1024]);  clone_default_137 = None
        transpose_int_217 = torch.ops.aten.transpose.int(add_tensor_130, 1, 2);  add_tensor_130 = None
        clone_default_138 = torch.ops.aten.clone.default(transpose_int_217, memory_format = torch.contiguous_format);  transpose_int_217 = None
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(clone_default_138, [8, 1024, 1024]);  clone_default_138 = None
        view_default_683 = torch.ops.aten.view.default(_unsafe_view_default_66, [8192, 1024]);  _unsafe_view_default_66 = None
        t_default_332 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_106 = torch.ops.aten.mm.default(view_default_683, t_default_332);  t_default_332 = None
        t_default_333 = torch.ops.aten.t.default(view_default_683)
        mm_default_107 = torch.ops.aten.mm.default(t_default_333, view_default_252);  t_default_333 = view_default_252 = None
        t_default_334 = torch.ops.aten.t.default(mm_default_107);  mm_default_107 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(view_default_683, [0], True);  view_default_683 = None
        view_default_684 = torch.ops.aten.view.default(sum_dim_int_list_53, [1024]);  sum_dim_int_list_53 = None
        t_default_335 = torch.ops.aten.t.default(t_default_334);  t_default_334 = None
        view_default_685 = torch.ops.aten.view.default(mm_default_106, [8, 1024, 1024]);  mm_default_106 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(add_tensor_120, view_default_685);  add_tensor_120 = view_default_685 = None
        transpose_int_218 = torch.ops.aten.transpose.int(add_tensor_131, 1, 2);  add_tensor_131 = None
        clone_default_139 = torch.ops.aten.clone.default(transpose_int_218, memory_format = torch.contiguous_format);  transpose_int_218 = None
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(clone_default_139, [8, 1024, 1024]);  clone_default_139 = None
        view_default_686 = torch.ops.aten.view.default(_unsafe_view_default_67, [8192, 1024]);  _unsafe_view_default_67 = None
        t_default_336 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_686, t_default_336);  t_default_336 = None
        t_default_337 = torch.ops.aten.t.default(view_default_686)
        mm_default_109 = torch.ops.aten.mm.default(t_default_337, view_default_249);  t_default_337 = view_default_249 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(view_default_686, [0], True);  view_default_686 = None
        view_default_687 = torch.ops.aten.view.default(sum_dim_int_list_54, [1024]);  sum_dim_int_list_54 = None
        t_default_339 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        view_default_688 = torch.ops.aten.view.default(mm_default_108, [8, 1024, 1024]);  mm_default_108 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_132, view_default_688);  add_tensor_132 = view_default_688 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(_unsafe_view_default_65, 0.125);  _unsafe_view_default_65 = None
        view_default_689 = torch.ops.aten.view.default(mul_tensor_77, [1024, 1024]);  mul_tensor_77 = None
        t_default_340 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_689, t_default_340);  t_default_340 = None
        t_default_341 = torch.ops.aten.t.default(view_default_689)
        mm_default_111 = torch.ops.aten.mm.default(t_default_341, view_default_247);  t_default_341 = view_default_247 = None
        t_default_342 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(view_default_689, [0], True);  view_default_689 = None
        view_default_690 = torch.ops.aten.view.default(sum_dim_int_list_55, [1024]);  sum_dim_int_list_55 = None
        t_default_343 = torch.ops.aten.t.default(t_default_342);  t_default_342 = None
        view_default_691 = torch.ops.aten.view.default(mm_default_110, [8, 128, 1024]);  mm_default_110 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(getitem_159, view_default_691);  getitem_159 = view_default_691 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_134, add_tensor_34, [1024], getitem_58, getitem_59, primals_232, primals_231, [True, True, True]);  add_tensor_134 = add_tensor_34 = getitem_58 = getitem_59 = primals_232 = primals_231 = None
        getitem_162 = native_layer_norm_backward_default_17[0]
        getitem_163 = native_layer_norm_backward_default_17[1]
        getitem_164 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        view_default_692 = torch.ops.aten.view.default(getitem_162, [1024, 1024])
        t_default_344 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_112 = torch.ops.aten.mm.default(view_default_692, t_default_344);  t_default_344 = None
        t_default_345 = torch.ops.aten.t.default(view_default_692)
        mm_default_113 = torch.ops.aten.mm.default(t_default_345, view_default_245);  t_default_345 = view_default_245 = None
        t_default_346 = torch.ops.aten.t.default(mm_default_113);  mm_default_113 = None
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(view_default_692, [0], True);  view_default_692 = None
        view_default_693 = torch.ops.aten.view.default(sum_dim_int_list_56, [1024]);  sum_dim_int_list_56 = None
        t_default_347 = torch.ops.aten.t.default(t_default_346);  t_default_346 = None
        view_default_694 = torch.ops.aten.view.default(mm_default_112, [8, 128, 1024]);  mm_default_112 = None
        view_default_695 = torch.ops.aten.view.default(view_default_694, [8, 128, 16, 64]);  view_default_694 = None
        transpose_int_219 = torch.ops.aten.transpose.int(view_default_695, 1, 2);  view_default_695 = None
        clone_default_140 = torch.ops.aten.clone.default(transpose_int_219, memory_format = torch.contiguous_format);  transpose_int_219 = None
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(clone_default_140, [128, 128, 64]);  clone_default_140 = None
        transpose_int_220 = torch.ops.aten.transpose.int(_softmax_default_12, 1, 2)
        bmm_default_92 = torch.ops.aten.bmm.default(transpose_int_220, _unsafe_view_default_68);  transpose_int_220 = None
        transpose_int_221 = torch.ops.aten.transpose.int(view_default_241, 1, 2);  view_default_241 = None
        bmm_default_93 = torch.ops.aten.bmm.default(_unsafe_view_default_68, transpose_int_221);  _unsafe_view_default_68 = transpose_int_221 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(bmm_default_93, _softmax_default_12, -1, torch.float32);  bmm_default_93 = _softmax_default_12 = None
        view_default_696 = torch.ops.aten.view.default(_softmax_backward_data_default_11, [8, 16, 128, 128]);  _softmax_backward_data_default_11 = None
        view_default_697 = torch.ops.aten.view.default(view_default_696, [128, 128, 128]);  view_default_696 = None
        transpose_int_222 = torch.ops.aten.transpose.int(view_default_239, 1, 2);  view_default_239 = None
        bmm_default_94 = torch.ops.aten.bmm.default(transpose_int_222, view_default_697);  transpose_int_222 = None
        transpose_int_223 = torch.ops.aten.transpose.int(transpose_int_63, 1, 2);  transpose_int_63 = None
        bmm_default_95 = torch.ops.aten.bmm.default(view_default_697, transpose_int_223);  view_default_697 = transpose_int_223 = None
        transpose_int_224 = torch.ops.aten.transpose.int(bmm_default_94, 1, 2);  bmm_default_94 = None
        view_default_698 = torch.ops.aten.view.default(bmm_default_92, [8, 16, 128, 64]);  bmm_default_92 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(tangents_27, view_default_698);  tangents_27 = view_default_698 = None
        view_default_699 = torch.ops.aten.view.default(transpose_int_224, [8, 16, 128, 64]);  transpose_int_224 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(tangents_26, view_default_699);  tangents_26 = view_default_699 = None
        view_default_700 = torch.ops.aten.view.default(bmm_default_95, [8, 16, 128, 64]);  bmm_default_95 = None
        transpose_int_225 = torch.ops.aten.transpose.int(view_default_700, 1, 2);  view_default_700 = None
        clone_default_141 = torch.ops.aten.clone.default(transpose_int_225, memory_format = torch.contiguous_format);  transpose_int_225 = None
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(clone_default_141, [8, 128, 1024]);  clone_default_141 = None
        transpose_int_226 = torch.ops.aten.transpose.int(add_tensor_135, 1, 2);  add_tensor_135 = None
        clone_default_142 = torch.ops.aten.clone.default(transpose_int_226, memory_format = torch.contiguous_format);  transpose_int_226 = None
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(clone_default_142, [8, 128, 1024]);  clone_default_142 = None
        view_default_701 = torch.ops.aten.view.default(_unsafe_view_default_70, [1024, 1024]);  _unsafe_view_default_70 = None
        t_default_348 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_114 = torch.ops.aten.mm.default(view_default_701, t_default_348);  t_default_348 = None
        t_default_349 = torch.ops.aten.t.default(view_default_701)
        mm_default_115 = torch.ops.aten.mm.default(t_default_349, view_default_235);  t_default_349 = view_default_235 = None
        t_default_350 = torch.ops.aten.t.default(mm_default_115);  mm_default_115 = None
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(view_default_701, [0], True);  view_default_701 = None
        view_default_702 = torch.ops.aten.view.default(sum_dim_int_list_57, [1024]);  sum_dim_int_list_57 = None
        t_default_351 = torch.ops.aten.t.default(t_default_350);  t_default_350 = None
        view_default_703 = torch.ops.aten.view.default(mm_default_114, [8, 128, 1024]);  mm_default_114 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(getitem_162, view_default_703);  getitem_162 = view_default_703 = None
        transpose_int_227 = torch.ops.aten.transpose.int(add_tensor_136, 1, 2);  add_tensor_136 = None
        clone_default_143 = torch.ops.aten.clone.default(transpose_int_227, memory_format = torch.contiguous_format);  transpose_int_227 = None
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(clone_default_143, [8, 128, 1024]);  clone_default_143 = None
        view_default_704 = torch.ops.aten.view.default(_unsafe_view_default_71, [1024, 1024]);  _unsafe_view_default_71 = None
        t_default_352 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_116 = torch.ops.aten.mm.default(view_default_704, t_default_352);  t_default_352 = None
        t_default_353 = torch.ops.aten.t.default(view_default_704)
        mm_default_117 = torch.ops.aten.mm.default(t_default_353, view_default_232);  t_default_353 = view_default_232 = None
        t_default_354 = torch.ops.aten.t.default(mm_default_117);  mm_default_117 = None
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(view_default_704, [0], True);  view_default_704 = None
        view_default_705 = torch.ops.aten.view.default(sum_dim_int_list_58, [1024]);  sum_dim_int_list_58 = None
        t_default_355 = torch.ops.aten.t.default(t_default_354);  t_default_354 = None
        view_default_706 = torch.ops.aten.view.default(mm_default_116, [8, 128, 1024]);  mm_default_116 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(add_tensor_137, view_default_706);  add_tensor_137 = view_default_706 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(_unsafe_view_default_69, 0.125);  _unsafe_view_default_69 = None
        view_default_707 = torch.ops.aten.view.default(mul_tensor_78, [1024, 1024]);  mul_tensor_78 = None
        t_default_356 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_118 = torch.ops.aten.mm.default(view_default_707, t_default_356);  t_default_356 = None
        t_default_357 = torch.ops.aten.t.default(view_default_707)
        mm_default_119 = torch.ops.aten.mm.default(t_default_357, view_default_230);  t_default_357 = view_default_230 = None
        t_default_358 = torch.ops.aten.t.default(mm_default_119);  mm_default_119 = None
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(view_default_707, [0], True);  view_default_707 = None
        view_default_708 = torch.ops.aten.view.default(sum_dim_int_list_59, [1024]);  sum_dim_int_list_59 = None
        t_default_359 = torch.ops.aten.t.default(t_default_358);  t_default_358 = None
        view_default_709 = torch.ops.aten.view.default(mm_default_118, [8, 128, 1024]);  mm_default_118 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(add_tensor_138, view_default_709);  add_tensor_138 = view_default_709 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_139, add_tensor_32, [1024], getitem_55, getitem_56, primals_202, primals_201, [True, True, True]);  add_tensor_139 = add_tensor_32 = getitem_55 = getitem_56 = primals_202 = primals_201 = None
        getitem_165 = native_layer_norm_backward_default_18[0]
        getitem_166 = native_layer_norm_backward_default_18[1]
        getitem_167 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        view_default_710 = torch.ops.aten.view.default(getitem_165, [1024, 1024])
        t_default_360 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_710, t_default_360);  t_default_360 = None
        t_default_361 = torch.ops.aten.t.default(view_default_710)
        mm_default_121 = torch.ops.aten.mm.default(t_default_361, view_default_228);  t_default_361 = view_default_228 = None
        t_default_362 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(view_default_710, [0], True);  view_default_710 = None
        view_default_711 = torch.ops.aten.view.default(sum_dim_int_list_60, [1024]);  sum_dim_int_list_60 = None
        t_default_363 = torch.ops.aten.t.default(t_default_362);  t_default_362 = None
        view_default_712 = torch.ops.aten.view.default(mm_default_120, [8, 128, 4096]);  mm_default_120 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_712, torch.float32);  view_default_712 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_227, torch.float32);  view_default_227 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_79);  mul_tensor_79 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(add_tensor_140, 0.5);  add_tensor_140 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_82 = torch.ops.aten.mul.Tensor(mul_tensor_81, -0.5);  mul_tensor_81 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_82);  mul_tensor_82 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_83);  to_dtype_19 = mul_tensor_83 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(mul_tensor_80, mul_tensor_84);  mul_tensor_80 = mul_tensor_84 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_141);  to_dtype_18 = add_tensor_141 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_85, torch.float32);  mul_tensor_85 = None
        view_default_713 = torch.ops.aten.view.default(to_dtype_20, [1024, 4096]);  to_dtype_20 = None
        t_default_364 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_713, t_default_364);  t_default_364 = None
        t_default_365 = torch.ops.aten.t.default(view_default_713)
        mm_default_123 = torch.ops.aten.mm.default(t_default_365, view_default_226);  t_default_365 = view_default_226 = None
        t_default_366 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(view_default_713, [0], True);  view_default_713 = None
        view_default_714 = torch.ops.aten.view.default(sum_dim_int_list_61, [4096]);  sum_dim_int_list_61 = None
        t_default_367 = torch.ops.aten.t.default(t_default_366);  t_default_366 = None
        view_default_715 = torch.ops.aten.view.default(mm_default_122, [8, 128, 1024]);  mm_default_122 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(getitem_165, view_default_715);  getitem_165 = view_default_715 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_142, add_tensor_31, [1024], getitem_52, getitem_53, primals_190, primals_189, [True, True, True]);  add_tensor_142 = add_tensor_31 = getitem_52 = getitem_53 = primals_190 = primals_189 = None
        getitem_168 = native_layer_norm_backward_default_19[0]
        getitem_169 = native_layer_norm_backward_default_19[1]
        getitem_170 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        view_default_716 = torch.ops.aten.view.default(getitem_168, [1024, 1024])
        t_default_368 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_124 = torch.ops.aten.mm.default(view_default_716, t_default_368);  t_default_368 = None
        t_default_369 = torch.ops.aten.t.default(view_default_716)
        mm_default_125 = torch.ops.aten.mm.default(t_default_369, view_default_224);  t_default_369 = view_default_224 = None
        t_default_370 = torch.ops.aten.t.default(mm_default_125);  mm_default_125 = None
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(view_default_716, [0], True);  view_default_716 = None
        view_default_717 = torch.ops.aten.view.default(sum_dim_int_list_62, [1024]);  sum_dim_int_list_62 = None
        t_default_371 = torch.ops.aten.t.default(t_default_370);  t_default_370 = None
        view_default_718 = torch.ops.aten.view.default(mm_default_124, [8, 128, 1024]);  mm_default_124 = None
        view_default_719 = torch.ops.aten.view.default(view_default_718, [8, 128, 16, 64]);  view_default_718 = None
        transpose_int_228 = torch.ops.aten.transpose.int(view_default_719, 1, 2);  view_default_719 = None
        clone_default_144 = torch.ops.aten.clone.default(transpose_int_228, memory_format = torch.contiguous_format);  transpose_int_228 = None
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(clone_default_144, [128, 128, 64]);  clone_default_144 = None
        transpose_int_229 = torch.ops.aten.transpose.int(_softmax_default_11, 1, 2)
        bmm_default_96 = torch.ops.aten.bmm.default(transpose_int_229, _unsafe_view_default_72);  transpose_int_229 = None
        transpose_int_230 = torch.ops.aten.transpose.int(view_default_220, 1, 2);  view_default_220 = None
        bmm_default_97 = torch.ops.aten.bmm.default(_unsafe_view_default_72, transpose_int_230);  _unsafe_view_default_72 = transpose_int_230 = None
        _softmax_backward_data_default_12 = torch.ops.aten._softmax_backward_data.default(bmm_default_97, _softmax_default_11, -1, torch.float32);  bmm_default_97 = _softmax_default_11 = None
        view_default_720 = torch.ops.aten.view.default(_softmax_backward_data_default_12, [8, 16, 128, 1024]);  _softmax_backward_data_default_12 = None
        view_default_721 = torch.ops.aten.view.default(view_default_720, [128, 128, 1024]);  view_default_720 = None
        transpose_int_231 = torch.ops.aten.transpose.int(view_default_218, 1, 2);  view_default_218 = None
        bmm_default_98 = torch.ops.aten.bmm.default(transpose_int_231, view_default_721);  transpose_int_231 = None
        transpose_int_232 = torch.ops.aten.transpose.int(transpose_int_58, 1, 2);  transpose_int_58 = None
        bmm_default_99 = torch.ops.aten.bmm.default(view_default_721, transpose_int_232);  view_default_721 = transpose_int_232 = None
        transpose_int_233 = torch.ops.aten.transpose.int(bmm_default_98, 1, 2);  bmm_default_98 = None
        view_default_722 = torch.ops.aten.view.default(bmm_default_96, [8, 16, 1024, 64]);  bmm_default_96 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(tangents_25, view_default_722);  tangents_25 = view_default_722 = None
        view_default_723 = torch.ops.aten.view.default(transpose_int_233, [8, 16, 1024, 64]);  transpose_int_233 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(tangents_24, view_default_723);  tangents_24 = view_default_723 = None
        view_default_724 = torch.ops.aten.view.default(bmm_default_99, [8, 16, 128, 64]);  bmm_default_99 = None
        transpose_int_234 = torch.ops.aten.transpose.int(view_default_724, 1, 2);  view_default_724 = None
        clone_default_145 = torch.ops.aten.clone.default(transpose_int_234, memory_format = torch.contiguous_format);  transpose_int_234 = None
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(clone_default_145, [8, 128, 1024]);  clone_default_145 = None
        transpose_int_235 = torch.ops.aten.transpose.int(add_tensor_143, 1, 2);  add_tensor_143 = None
        clone_default_146 = torch.ops.aten.clone.default(transpose_int_235, memory_format = torch.contiguous_format);  transpose_int_235 = None
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(clone_default_146, [8, 1024, 1024]);  clone_default_146 = None
        view_default_725 = torch.ops.aten.view.default(_unsafe_view_default_74, [8192, 1024]);  _unsafe_view_default_74 = None
        t_default_372 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_126 = torch.ops.aten.mm.default(view_default_725, t_default_372);  t_default_372 = None
        t_default_373 = torch.ops.aten.t.default(view_default_725)
        mm_default_127 = torch.ops.aten.mm.default(t_default_373, view_default_214);  t_default_373 = view_default_214 = None
        t_default_374 = torch.ops.aten.t.default(mm_default_127);  mm_default_127 = None
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(view_default_725, [0], True);  view_default_725 = None
        view_default_726 = torch.ops.aten.view.default(sum_dim_int_list_63, [1024]);  sum_dim_int_list_63 = None
        t_default_375 = torch.ops.aten.t.default(t_default_374);  t_default_374 = None
        view_default_727 = torch.ops.aten.view.default(mm_default_126, [8, 1024, 1024]);  mm_default_126 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(add_tensor_133, view_default_727);  add_tensor_133 = view_default_727 = None
        transpose_int_236 = torch.ops.aten.transpose.int(add_tensor_144, 1, 2);  add_tensor_144 = None
        clone_default_147 = torch.ops.aten.clone.default(transpose_int_236, memory_format = torch.contiguous_format);  transpose_int_236 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_147, [8, 1024, 1024]);  clone_default_147 = None
        view_default_728 = torch.ops.aten.view.default(_unsafe_view_default_75, [8192, 1024]);  _unsafe_view_default_75 = None
        t_default_376 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_128 = torch.ops.aten.mm.default(view_default_728, t_default_376);  t_default_376 = None
        t_default_377 = torch.ops.aten.t.default(view_default_728)
        mm_default_129 = torch.ops.aten.mm.default(t_default_377, view_default_211);  t_default_377 = view_default_211 = None
        t_default_378 = torch.ops.aten.t.default(mm_default_129);  mm_default_129 = None
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(view_default_728, [0], True);  view_default_728 = None
        view_default_729 = torch.ops.aten.view.default(sum_dim_int_list_64, [1024]);  sum_dim_int_list_64 = None
        t_default_379 = torch.ops.aten.t.default(t_default_378);  t_default_378 = None
        view_default_730 = torch.ops.aten.view.default(mm_default_128, [8, 1024, 1024]);  mm_default_128 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(add_tensor_145, view_default_730);  add_tensor_145 = view_default_730 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(_unsafe_view_default_73, 0.125);  _unsafe_view_default_73 = None
        view_default_731 = torch.ops.aten.view.default(mul_tensor_86, [1024, 1024]);  mul_tensor_86 = None
        t_default_380 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_130 = torch.ops.aten.mm.default(view_default_731, t_default_380);  t_default_380 = None
        t_default_381 = torch.ops.aten.t.default(view_default_731)
        mm_default_131 = torch.ops.aten.mm.default(t_default_381, view_default_209);  t_default_381 = view_default_209 = None
        t_default_382 = torch.ops.aten.t.default(mm_default_131);  mm_default_131 = None
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(view_default_731, [0], True);  view_default_731 = None
        view_default_732 = torch.ops.aten.view.default(sum_dim_int_list_65, [1024]);  sum_dim_int_list_65 = None
        t_default_383 = torch.ops.aten.t.default(t_default_382);  t_default_382 = None
        view_default_733 = torch.ops.aten.view.default(mm_default_130, [8, 128, 1024]);  mm_default_130 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(getitem_168, view_default_733);  getitem_168 = view_default_733 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_147, add_tensor_29, [1024], getitem_49, getitem_50, primals_206, primals_205, [True, True, True]);  add_tensor_147 = add_tensor_29 = getitem_49 = getitem_50 = primals_206 = primals_205 = None
        getitem_171 = native_layer_norm_backward_default_20[0]
        getitem_172 = native_layer_norm_backward_default_20[1]
        getitem_173 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_734 = torch.ops.aten.view.default(getitem_171, [1024, 1024])
        t_default_384 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_132 = torch.ops.aten.mm.default(view_default_734, t_default_384);  t_default_384 = None
        t_default_385 = torch.ops.aten.t.default(view_default_734)
        mm_default_133 = torch.ops.aten.mm.default(t_default_385, view_default_207);  t_default_385 = view_default_207 = None
        t_default_386 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(view_default_734, [0], True);  view_default_734 = None
        view_default_735 = torch.ops.aten.view.default(sum_dim_int_list_66, [1024]);  sum_dim_int_list_66 = None
        t_default_387 = torch.ops.aten.t.default(t_default_386);  t_default_386 = None
        view_default_736 = torch.ops.aten.view.default(mm_default_132, [8, 128, 1024]);  mm_default_132 = None
        view_default_737 = torch.ops.aten.view.default(view_default_736, [8, 128, 16, 64]);  view_default_736 = None
        transpose_int_237 = torch.ops.aten.transpose.int(view_default_737, 1, 2);  view_default_737 = None
        clone_default_148 = torch.ops.aten.clone.default(transpose_int_237, memory_format = torch.contiguous_format);  transpose_int_237 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_148, [128, 128, 64]);  clone_default_148 = None
        transpose_int_238 = torch.ops.aten.transpose.int(_softmax_default_10, 1, 2)
        bmm_default_100 = torch.ops.aten.bmm.default(transpose_int_238, _unsafe_view_default_76);  transpose_int_238 = None
        transpose_int_239 = torch.ops.aten.transpose.int(view_default_203, 1, 2);  view_default_203 = None
        bmm_default_101 = torch.ops.aten.bmm.default(_unsafe_view_default_76, transpose_int_239);  _unsafe_view_default_76 = transpose_int_239 = None
        _softmax_backward_data_default_13 = torch.ops.aten._softmax_backward_data.default(bmm_default_101, _softmax_default_10, -1, torch.float32);  bmm_default_101 = _softmax_default_10 = None
        view_default_738 = torch.ops.aten.view.default(_softmax_backward_data_default_13, [8, 16, 128, 128]);  _softmax_backward_data_default_13 = None
        view_default_739 = torch.ops.aten.view.default(view_default_738, [128, 128, 128]);  view_default_738 = None
        transpose_int_240 = torch.ops.aten.transpose.int(view_default_201, 1, 2);  view_default_201 = None
        bmm_default_102 = torch.ops.aten.bmm.default(transpose_int_240, view_default_739);  transpose_int_240 = None
        transpose_int_241 = torch.ops.aten.transpose.int(transpose_int_53, 1, 2);  transpose_int_53 = None
        bmm_default_103 = torch.ops.aten.bmm.default(view_default_739, transpose_int_241);  view_default_739 = transpose_int_241 = None
        transpose_int_242 = torch.ops.aten.transpose.int(bmm_default_102, 1, 2);  bmm_default_102 = None
        view_default_740 = torch.ops.aten.view.default(bmm_default_100, [8, 16, 128, 64]);  bmm_default_100 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(tangents_23, view_default_740);  tangents_23 = view_default_740 = None
        view_default_741 = torch.ops.aten.view.default(transpose_int_242, [8, 16, 128, 64]);  transpose_int_242 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(tangents_22, view_default_741);  tangents_22 = view_default_741 = None
        view_default_742 = torch.ops.aten.view.default(bmm_default_103, [8, 16, 128, 64]);  bmm_default_103 = None
        transpose_int_243 = torch.ops.aten.transpose.int(view_default_742, 1, 2);  view_default_742 = None
        clone_default_149 = torch.ops.aten.clone.default(transpose_int_243, memory_format = torch.contiguous_format);  transpose_int_243 = None
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(clone_default_149, [8, 128, 1024]);  clone_default_149 = None
        transpose_int_244 = torch.ops.aten.transpose.int(add_tensor_148, 1, 2);  add_tensor_148 = None
        clone_default_150 = torch.ops.aten.clone.default(transpose_int_244, memory_format = torch.contiguous_format);  transpose_int_244 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_150, [8, 128, 1024]);  clone_default_150 = None
        view_default_743 = torch.ops.aten.view.default(_unsafe_view_default_78, [1024, 1024]);  _unsafe_view_default_78 = None
        t_default_388 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_743, t_default_388);  t_default_388 = None
        t_default_389 = torch.ops.aten.t.default(view_default_743)
        mm_default_135 = torch.ops.aten.mm.default(t_default_389, view_default_197);  t_default_389 = view_default_197 = None
        t_default_390 = torch.ops.aten.t.default(mm_default_135);  mm_default_135 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(view_default_743, [0], True);  view_default_743 = None
        view_default_744 = torch.ops.aten.view.default(sum_dim_int_list_67, [1024]);  sum_dim_int_list_67 = None
        t_default_391 = torch.ops.aten.t.default(t_default_390);  t_default_390 = None
        view_default_745 = torch.ops.aten.view.default(mm_default_134, [8, 128, 1024]);  mm_default_134 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(getitem_171, view_default_745);  getitem_171 = view_default_745 = None
        transpose_int_245 = torch.ops.aten.transpose.int(add_tensor_149, 1, 2);  add_tensor_149 = None
        clone_default_151 = torch.ops.aten.clone.default(transpose_int_245, memory_format = torch.contiguous_format);  transpose_int_245 = None
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(clone_default_151, [8, 128, 1024]);  clone_default_151 = None
        view_default_746 = torch.ops.aten.view.default(_unsafe_view_default_79, [1024, 1024]);  _unsafe_view_default_79 = None
        t_default_392 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_136 = torch.ops.aten.mm.default(view_default_746, t_default_392);  t_default_392 = None
        t_default_393 = torch.ops.aten.t.default(view_default_746)
        mm_default_137 = torch.ops.aten.mm.default(t_default_393, view_default_194);  t_default_393 = view_default_194 = None
        t_default_394 = torch.ops.aten.t.default(mm_default_137);  mm_default_137 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(view_default_746, [0], True);  view_default_746 = None
        view_default_747 = torch.ops.aten.view.default(sum_dim_int_list_68, [1024]);  sum_dim_int_list_68 = None
        t_default_395 = torch.ops.aten.t.default(t_default_394);  t_default_394 = None
        view_default_748 = torch.ops.aten.view.default(mm_default_136, [8, 128, 1024]);  mm_default_136 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(add_tensor_150, view_default_748);  add_tensor_150 = view_default_748 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(_unsafe_view_default_77, 0.125);  _unsafe_view_default_77 = None
        view_default_749 = torch.ops.aten.view.default(mul_tensor_87, [1024, 1024]);  mul_tensor_87 = None
        t_default_396 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_138 = torch.ops.aten.mm.default(view_default_749, t_default_396);  t_default_396 = None
        t_default_397 = torch.ops.aten.t.default(view_default_749)
        mm_default_139 = torch.ops.aten.mm.default(t_default_397, view_default_192);  t_default_397 = view_default_192 = None
        t_default_398 = torch.ops.aten.t.default(mm_default_139);  mm_default_139 = None
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(view_default_749, [0], True);  view_default_749 = None
        view_default_750 = torch.ops.aten.view.default(sum_dim_int_list_69, [1024]);  sum_dim_int_list_69 = None
        t_default_399 = torch.ops.aten.t.default(t_default_398);  t_default_398 = None
        view_default_751 = torch.ops.aten.view.default(mm_default_138, [8, 128, 1024]);  mm_default_138 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(add_tensor_151, view_default_751);  add_tensor_151 = view_default_751 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_152, add_tensor_27, [1024], getitem_46, getitem_47, primals_176, primals_175, [True, True, True]);  add_tensor_152 = add_tensor_27 = getitem_46 = getitem_47 = primals_176 = primals_175 = None
        getitem_174 = native_layer_norm_backward_default_21[0]
        getitem_175 = native_layer_norm_backward_default_21[1]
        getitem_176 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        view_default_752 = torch.ops.aten.view.default(getitem_174, [1024, 1024])
        t_default_400 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_140 = torch.ops.aten.mm.default(view_default_752, t_default_400);  t_default_400 = None
        t_default_401 = torch.ops.aten.t.default(view_default_752)
        mm_default_141 = torch.ops.aten.mm.default(t_default_401, view_default_190);  t_default_401 = view_default_190 = None
        t_default_402 = torch.ops.aten.t.default(mm_default_141);  mm_default_141 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(view_default_752, [0], True);  view_default_752 = None
        view_default_753 = torch.ops.aten.view.default(sum_dim_int_list_70, [1024]);  sum_dim_int_list_70 = None
        t_default_403 = torch.ops.aten.t.default(t_default_402);  t_default_402 = None
        view_default_754 = torch.ops.aten.view.default(mm_default_140, [8, 128, 4096]);  mm_default_140 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_754, torch.float32);  view_default_754 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_189, torch.float32);  view_default_189 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_88);  mul_tensor_88 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(add_tensor_153, 0.5);  add_tensor_153 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_91 = torch.ops.aten.mul.Tensor(mul_tensor_90, -0.5);  mul_tensor_90 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_91);  mul_tensor_91 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_92);  to_dtype_22 = mul_tensor_92 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(mul_tensor_89, mul_tensor_93);  mul_tensor_89 = mul_tensor_93 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_154);  to_dtype_21 = add_tensor_154 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_94, torch.float32);  mul_tensor_94 = None
        view_default_755 = torch.ops.aten.view.default(to_dtype_23, [1024, 4096]);  to_dtype_23 = None
        t_default_404 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_142 = torch.ops.aten.mm.default(view_default_755, t_default_404);  t_default_404 = None
        t_default_405 = torch.ops.aten.t.default(view_default_755)
        mm_default_143 = torch.ops.aten.mm.default(t_default_405, view_default_188);  t_default_405 = view_default_188 = None
        t_default_406 = torch.ops.aten.t.default(mm_default_143);  mm_default_143 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(view_default_755, [0], True);  view_default_755 = None
        view_default_756 = torch.ops.aten.view.default(sum_dim_int_list_71, [4096]);  sum_dim_int_list_71 = None
        t_default_407 = torch.ops.aten.t.default(t_default_406);  t_default_406 = None
        view_default_757 = torch.ops.aten.view.default(mm_default_142, [8, 128, 1024]);  mm_default_142 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(getitem_174, view_default_757);  getitem_174 = view_default_757 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_155, add_tensor_26, [1024], getitem_43, getitem_44, primals_164, primals_163, [True, True, True]);  add_tensor_155 = add_tensor_26 = getitem_43 = getitem_44 = primals_164 = primals_163 = None
        getitem_177 = native_layer_norm_backward_default_22[0]
        getitem_178 = native_layer_norm_backward_default_22[1]
        getitem_179 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_758 = torch.ops.aten.view.default(getitem_177, [1024, 1024])
        t_default_408 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_144 = torch.ops.aten.mm.default(view_default_758, t_default_408);  t_default_408 = None
        t_default_409 = torch.ops.aten.t.default(view_default_758)
        mm_default_145 = torch.ops.aten.mm.default(t_default_409, view_default_186);  t_default_409 = view_default_186 = None
        t_default_410 = torch.ops.aten.t.default(mm_default_145);  mm_default_145 = None
        sum_dim_int_list_72 = torch.ops.aten.sum.dim_IntList(view_default_758, [0], True);  view_default_758 = None
        view_default_759 = torch.ops.aten.view.default(sum_dim_int_list_72, [1024]);  sum_dim_int_list_72 = None
        t_default_411 = torch.ops.aten.t.default(t_default_410);  t_default_410 = None
        view_default_760 = torch.ops.aten.view.default(mm_default_144, [8, 128, 1024]);  mm_default_144 = None
        view_default_761 = torch.ops.aten.view.default(view_default_760, [8, 128, 16, 64]);  view_default_760 = None
        transpose_int_246 = torch.ops.aten.transpose.int(view_default_761, 1, 2);  view_default_761 = None
        clone_default_152 = torch.ops.aten.clone.default(transpose_int_246, memory_format = torch.contiguous_format);  transpose_int_246 = None
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(clone_default_152, [128, 128, 64]);  clone_default_152 = None
        transpose_int_247 = torch.ops.aten.transpose.int(_softmax_default_9, 1, 2)
        bmm_default_104 = torch.ops.aten.bmm.default(transpose_int_247, _unsafe_view_default_80);  transpose_int_247 = None
        transpose_int_248 = torch.ops.aten.transpose.int(view_default_182, 1, 2);  view_default_182 = None
        bmm_default_105 = torch.ops.aten.bmm.default(_unsafe_view_default_80, transpose_int_248);  _unsafe_view_default_80 = transpose_int_248 = None
        _softmax_backward_data_default_14 = torch.ops.aten._softmax_backward_data.default(bmm_default_105, _softmax_default_9, -1, torch.float32);  bmm_default_105 = _softmax_default_9 = None
        view_default_762 = torch.ops.aten.view.default(_softmax_backward_data_default_14, [8, 16, 128, 1024]);  _softmax_backward_data_default_14 = None
        view_default_763 = torch.ops.aten.view.default(view_default_762, [128, 128, 1024]);  view_default_762 = None
        transpose_int_249 = torch.ops.aten.transpose.int(view_default_180, 1, 2);  view_default_180 = None
        bmm_default_106 = torch.ops.aten.bmm.default(transpose_int_249, view_default_763);  transpose_int_249 = None
        transpose_int_250 = torch.ops.aten.transpose.int(transpose_int_48, 1, 2);  transpose_int_48 = None
        bmm_default_107 = torch.ops.aten.bmm.default(view_default_763, transpose_int_250);  view_default_763 = transpose_int_250 = None
        transpose_int_251 = torch.ops.aten.transpose.int(bmm_default_106, 1, 2);  bmm_default_106 = None
        view_default_764 = torch.ops.aten.view.default(bmm_default_104, [8, 16, 1024, 64]);  bmm_default_104 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(tangents_21, view_default_764);  tangents_21 = view_default_764 = None
        view_default_765 = torch.ops.aten.view.default(transpose_int_251, [8, 16, 1024, 64]);  transpose_int_251 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(tangents_20, view_default_765);  tangents_20 = view_default_765 = None
        view_default_766 = torch.ops.aten.view.default(bmm_default_107, [8, 16, 128, 64]);  bmm_default_107 = None
        transpose_int_252 = torch.ops.aten.transpose.int(view_default_766, 1, 2);  view_default_766 = None
        clone_default_153 = torch.ops.aten.clone.default(transpose_int_252, memory_format = torch.contiguous_format);  transpose_int_252 = None
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(clone_default_153, [8, 128, 1024]);  clone_default_153 = None
        transpose_int_253 = torch.ops.aten.transpose.int(add_tensor_156, 1, 2);  add_tensor_156 = None
        clone_default_154 = torch.ops.aten.clone.default(transpose_int_253, memory_format = torch.contiguous_format);  transpose_int_253 = None
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(clone_default_154, [8, 1024, 1024]);  clone_default_154 = None
        view_default_767 = torch.ops.aten.view.default(_unsafe_view_default_82, [8192, 1024]);  _unsafe_view_default_82 = None
        t_default_412 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_146 = torch.ops.aten.mm.default(view_default_767, t_default_412);  t_default_412 = None
        t_default_413 = torch.ops.aten.t.default(view_default_767)
        mm_default_147 = torch.ops.aten.mm.default(t_default_413, view_default_176);  t_default_413 = view_default_176 = None
        t_default_414 = torch.ops.aten.t.default(mm_default_147);  mm_default_147 = None
        sum_dim_int_list_73 = torch.ops.aten.sum.dim_IntList(view_default_767, [0], True);  view_default_767 = None
        view_default_768 = torch.ops.aten.view.default(sum_dim_int_list_73, [1024]);  sum_dim_int_list_73 = None
        t_default_415 = torch.ops.aten.t.default(t_default_414);  t_default_414 = None
        view_default_769 = torch.ops.aten.view.default(mm_default_146, [8, 1024, 1024]);  mm_default_146 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_146, view_default_769);  add_tensor_146 = view_default_769 = None
        transpose_int_254 = torch.ops.aten.transpose.int(add_tensor_157, 1, 2);  add_tensor_157 = None
        clone_default_155 = torch.ops.aten.clone.default(transpose_int_254, memory_format = torch.contiguous_format);  transpose_int_254 = None
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(clone_default_155, [8, 1024, 1024]);  clone_default_155 = None
        view_default_770 = torch.ops.aten.view.default(_unsafe_view_default_83, [8192, 1024]);  _unsafe_view_default_83 = None
        t_default_416 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_148 = torch.ops.aten.mm.default(view_default_770, t_default_416);  t_default_416 = None
        t_default_417 = torch.ops.aten.t.default(view_default_770)
        mm_default_149 = torch.ops.aten.mm.default(t_default_417, view_default_173);  t_default_417 = view_default_173 = None
        t_default_418 = torch.ops.aten.t.default(mm_default_149);  mm_default_149 = None
        sum_dim_int_list_74 = torch.ops.aten.sum.dim_IntList(view_default_770, [0], True);  view_default_770 = None
        view_default_771 = torch.ops.aten.view.default(sum_dim_int_list_74, [1024]);  sum_dim_int_list_74 = None
        t_default_419 = torch.ops.aten.t.default(t_default_418);  t_default_418 = None
        view_default_772 = torch.ops.aten.view.default(mm_default_148, [8, 1024, 1024]);  mm_default_148 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(add_tensor_158, view_default_772);  add_tensor_158 = view_default_772 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(_unsafe_view_default_81, 0.125);  _unsafe_view_default_81 = None
        view_default_773 = torch.ops.aten.view.default(mul_tensor_95, [1024, 1024]);  mul_tensor_95 = None
        t_default_420 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_150 = torch.ops.aten.mm.default(view_default_773, t_default_420);  t_default_420 = None
        t_default_421 = torch.ops.aten.t.default(view_default_773)
        mm_default_151 = torch.ops.aten.mm.default(t_default_421, view_default_171);  t_default_421 = view_default_171 = None
        t_default_422 = torch.ops.aten.t.default(mm_default_151);  mm_default_151 = None
        sum_dim_int_list_75 = torch.ops.aten.sum.dim_IntList(view_default_773, [0], True);  view_default_773 = None
        view_default_774 = torch.ops.aten.view.default(sum_dim_int_list_75, [1024]);  sum_dim_int_list_75 = None
        t_default_423 = torch.ops.aten.t.default(t_default_422);  t_default_422 = None
        view_default_775 = torch.ops.aten.view.default(mm_default_150, [8, 128, 1024]);  mm_default_150 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(getitem_177, view_default_775);  getitem_177 = view_default_775 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_160, add_tensor_24, [1024], getitem_40, getitem_41, primals_180, primals_179, [True, True, True]);  add_tensor_160 = add_tensor_24 = getitem_40 = getitem_41 = primals_180 = primals_179 = None
        getitem_180 = native_layer_norm_backward_default_23[0]
        getitem_181 = native_layer_norm_backward_default_23[1]
        getitem_182 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        view_default_776 = torch.ops.aten.view.default(getitem_180, [1024, 1024])
        t_default_424 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_152 = torch.ops.aten.mm.default(view_default_776, t_default_424);  t_default_424 = None
        t_default_425 = torch.ops.aten.t.default(view_default_776)
        mm_default_153 = torch.ops.aten.mm.default(t_default_425, view_default_169);  t_default_425 = view_default_169 = None
        t_default_426 = torch.ops.aten.t.default(mm_default_153);  mm_default_153 = None
        sum_dim_int_list_76 = torch.ops.aten.sum.dim_IntList(view_default_776, [0], True);  view_default_776 = None
        view_default_777 = torch.ops.aten.view.default(sum_dim_int_list_76, [1024]);  sum_dim_int_list_76 = None
        t_default_427 = torch.ops.aten.t.default(t_default_426);  t_default_426 = None
        view_default_778 = torch.ops.aten.view.default(mm_default_152, [8, 128, 1024]);  mm_default_152 = None
        view_default_779 = torch.ops.aten.view.default(view_default_778, [8, 128, 16, 64]);  view_default_778 = None
        transpose_int_255 = torch.ops.aten.transpose.int(view_default_779, 1, 2);  view_default_779 = None
        clone_default_156 = torch.ops.aten.clone.default(transpose_int_255, memory_format = torch.contiguous_format);  transpose_int_255 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_156, [128, 128, 64]);  clone_default_156 = None
        transpose_int_256 = torch.ops.aten.transpose.int(_softmax_default_8, 1, 2)
        bmm_default_108 = torch.ops.aten.bmm.default(transpose_int_256, _unsafe_view_default_84);  transpose_int_256 = None
        transpose_int_257 = torch.ops.aten.transpose.int(view_default_165, 1, 2);  view_default_165 = None
        bmm_default_109 = torch.ops.aten.bmm.default(_unsafe_view_default_84, transpose_int_257);  _unsafe_view_default_84 = transpose_int_257 = None
        _softmax_backward_data_default_15 = torch.ops.aten._softmax_backward_data.default(bmm_default_109, _softmax_default_8, -1, torch.float32);  bmm_default_109 = _softmax_default_8 = None
        view_default_780 = torch.ops.aten.view.default(_softmax_backward_data_default_15, [8, 16, 128, 128]);  _softmax_backward_data_default_15 = None
        view_default_781 = torch.ops.aten.view.default(view_default_780, [128, 128, 128]);  view_default_780 = None
        transpose_int_258 = torch.ops.aten.transpose.int(view_default_163, 1, 2);  view_default_163 = None
        bmm_default_110 = torch.ops.aten.bmm.default(transpose_int_258, view_default_781);  transpose_int_258 = None
        transpose_int_259 = torch.ops.aten.transpose.int(transpose_int_43, 1, 2);  transpose_int_43 = None
        bmm_default_111 = torch.ops.aten.bmm.default(view_default_781, transpose_int_259);  view_default_781 = transpose_int_259 = None
        transpose_int_260 = torch.ops.aten.transpose.int(bmm_default_110, 1, 2);  bmm_default_110 = None
        view_default_782 = torch.ops.aten.view.default(bmm_default_108, [8, 16, 128, 64]);  bmm_default_108 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(tangents_19, view_default_782);  tangents_19 = view_default_782 = None
        view_default_783 = torch.ops.aten.view.default(transpose_int_260, [8, 16, 128, 64]);  transpose_int_260 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(tangents_18, view_default_783);  tangents_18 = view_default_783 = None
        view_default_784 = torch.ops.aten.view.default(bmm_default_111, [8, 16, 128, 64]);  bmm_default_111 = None
        transpose_int_261 = torch.ops.aten.transpose.int(view_default_784, 1, 2);  view_default_784 = None
        clone_default_157 = torch.ops.aten.clone.default(transpose_int_261, memory_format = torch.contiguous_format);  transpose_int_261 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_157, [8, 128, 1024]);  clone_default_157 = None
        transpose_int_262 = torch.ops.aten.transpose.int(add_tensor_161, 1, 2);  add_tensor_161 = None
        clone_default_158 = torch.ops.aten.clone.default(transpose_int_262, memory_format = torch.contiguous_format);  transpose_int_262 = None
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(clone_default_158, [8, 128, 1024]);  clone_default_158 = None
        view_default_785 = torch.ops.aten.view.default(_unsafe_view_default_86, [1024, 1024]);  _unsafe_view_default_86 = None
        t_default_428 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_154 = torch.ops.aten.mm.default(view_default_785, t_default_428);  t_default_428 = None
        t_default_429 = torch.ops.aten.t.default(view_default_785)
        mm_default_155 = torch.ops.aten.mm.default(t_default_429, view_default_159);  t_default_429 = view_default_159 = None
        t_default_430 = torch.ops.aten.t.default(mm_default_155);  mm_default_155 = None
        sum_dim_int_list_77 = torch.ops.aten.sum.dim_IntList(view_default_785, [0], True);  view_default_785 = None
        view_default_786 = torch.ops.aten.view.default(sum_dim_int_list_77, [1024]);  sum_dim_int_list_77 = None
        t_default_431 = torch.ops.aten.t.default(t_default_430);  t_default_430 = None
        view_default_787 = torch.ops.aten.view.default(mm_default_154, [8, 128, 1024]);  mm_default_154 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(getitem_180, view_default_787);  getitem_180 = view_default_787 = None
        transpose_int_263 = torch.ops.aten.transpose.int(add_tensor_162, 1, 2);  add_tensor_162 = None
        clone_default_159 = torch.ops.aten.clone.default(transpose_int_263, memory_format = torch.contiguous_format);  transpose_int_263 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_159, [8, 128, 1024]);  clone_default_159 = None
        view_default_788 = torch.ops.aten.view.default(_unsafe_view_default_87, [1024, 1024]);  _unsafe_view_default_87 = None
        t_default_432 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_156 = torch.ops.aten.mm.default(view_default_788, t_default_432);  t_default_432 = None
        t_default_433 = torch.ops.aten.t.default(view_default_788)
        mm_default_157 = torch.ops.aten.mm.default(t_default_433, view_default_156);  t_default_433 = view_default_156 = None
        t_default_434 = torch.ops.aten.t.default(mm_default_157);  mm_default_157 = None
        sum_dim_int_list_78 = torch.ops.aten.sum.dim_IntList(view_default_788, [0], True);  view_default_788 = None
        view_default_789 = torch.ops.aten.view.default(sum_dim_int_list_78, [1024]);  sum_dim_int_list_78 = None
        t_default_435 = torch.ops.aten.t.default(t_default_434);  t_default_434 = None
        view_default_790 = torch.ops.aten.view.default(mm_default_156, [8, 128, 1024]);  mm_default_156 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(add_tensor_163, view_default_790);  add_tensor_163 = view_default_790 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(_unsafe_view_default_85, 0.125);  _unsafe_view_default_85 = None
        view_default_791 = torch.ops.aten.view.default(mul_tensor_96, [1024, 1024]);  mul_tensor_96 = None
        t_default_436 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_158 = torch.ops.aten.mm.default(view_default_791, t_default_436);  t_default_436 = None
        t_default_437 = torch.ops.aten.t.default(view_default_791)
        mm_default_159 = torch.ops.aten.mm.default(t_default_437, view_default_154);  t_default_437 = view_default_154 = None
        t_default_438 = torch.ops.aten.t.default(mm_default_159);  mm_default_159 = None
        sum_dim_int_list_79 = torch.ops.aten.sum.dim_IntList(view_default_791, [0], True);  view_default_791 = None
        view_default_792 = torch.ops.aten.view.default(sum_dim_int_list_79, [1024]);  sum_dim_int_list_79 = None
        t_default_439 = torch.ops.aten.t.default(t_default_438);  t_default_438 = None
        view_default_793 = torch.ops.aten.view.default(mm_default_158, [8, 128, 1024]);  mm_default_158 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(add_tensor_164, view_default_793);  add_tensor_164 = view_default_793 = None
        native_layer_norm_backward_default_24 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_165, add_tensor_22, [1024], getitem_37, getitem_38, primals_150, primals_149, [True, True, True]);  add_tensor_165 = add_tensor_22 = getitem_37 = getitem_38 = primals_150 = primals_149 = None
        getitem_183 = native_layer_norm_backward_default_24[0]
        getitem_184 = native_layer_norm_backward_default_24[1]
        getitem_185 = native_layer_norm_backward_default_24[2];  native_layer_norm_backward_default_24 = None
        view_default_794 = torch.ops.aten.view.default(getitem_183, [1024, 1024])
        t_default_440 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_160 = torch.ops.aten.mm.default(view_default_794, t_default_440);  t_default_440 = None
        t_default_441 = torch.ops.aten.t.default(view_default_794)
        mm_default_161 = torch.ops.aten.mm.default(t_default_441, view_default_152);  t_default_441 = view_default_152 = None
        t_default_442 = torch.ops.aten.t.default(mm_default_161);  mm_default_161 = None
        sum_dim_int_list_80 = torch.ops.aten.sum.dim_IntList(view_default_794, [0], True);  view_default_794 = None
        view_default_795 = torch.ops.aten.view.default(sum_dim_int_list_80, [1024]);  sum_dim_int_list_80 = None
        t_default_443 = torch.ops.aten.t.default(t_default_442);  t_default_442 = None
        view_default_796 = torch.ops.aten.view.default(mm_default_160, [8, 128, 4096]);  mm_default_160 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_796, torch.float32);  view_default_796 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_151, torch.float32);  view_default_151 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_97);  mul_tensor_97 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(add_tensor_166, 0.5);  add_tensor_166 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_100 = torch.ops.aten.mul.Tensor(mul_tensor_99, -0.5);  mul_tensor_99 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_100);  mul_tensor_100 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_101);  to_dtype_25 = mul_tensor_101 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(mul_tensor_98, mul_tensor_102);  mul_tensor_98 = mul_tensor_102 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_167);  to_dtype_24 = add_tensor_167 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_103, torch.float32);  mul_tensor_103 = None
        view_default_797 = torch.ops.aten.view.default(to_dtype_26, [1024, 4096]);  to_dtype_26 = None
        t_default_444 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_162 = torch.ops.aten.mm.default(view_default_797, t_default_444);  t_default_444 = None
        t_default_445 = torch.ops.aten.t.default(view_default_797)
        mm_default_163 = torch.ops.aten.mm.default(t_default_445, view_default_150);  t_default_445 = view_default_150 = None
        t_default_446 = torch.ops.aten.t.default(mm_default_163);  mm_default_163 = None
        sum_dim_int_list_81 = torch.ops.aten.sum.dim_IntList(view_default_797, [0], True);  view_default_797 = None
        view_default_798 = torch.ops.aten.view.default(sum_dim_int_list_81, [4096]);  sum_dim_int_list_81 = None
        t_default_447 = torch.ops.aten.t.default(t_default_446);  t_default_446 = None
        view_default_799 = torch.ops.aten.view.default(mm_default_162, [8, 128, 1024]);  mm_default_162 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(getitem_183, view_default_799);  getitem_183 = view_default_799 = None
        native_layer_norm_backward_default_25 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_168, add_tensor_21, [1024], getitem_34, getitem_35, primals_138, primals_137, [True, True, True]);  add_tensor_168 = add_tensor_21 = getitem_34 = getitem_35 = primals_138 = primals_137 = None
        getitem_186 = native_layer_norm_backward_default_25[0]
        getitem_187 = native_layer_norm_backward_default_25[1]
        getitem_188 = native_layer_norm_backward_default_25[2];  native_layer_norm_backward_default_25 = None
        view_default_800 = torch.ops.aten.view.default(getitem_186, [1024, 1024])
        t_default_448 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_164 = torch.ops.aten.mm.default(view_default_800, t_default_448);  t_default_448 = None
        t_default_449 = torch.ops.aten.t.default(view_default_800)
        mm_default_165 = torch.ops.aten.mm.default(t_default_449, view_default_148);  t_default_449 = view_default_148 = None
        t_default_450 = torch.ops.aten.t.default(mm_default_165);  mm_default_165 = None
        sum_dim_int_list_82 = torch.ops.aten.sum.dim_IntList(view_default_800, [0], True);  view_default_800 = None
        view_default_801 = torch.ops.aten.view.default(sum_dim_int_list_82, [1024]);  sum_dim_int_list_82 = None
        t_default_451 = torch.ops.aten.t.default(t_default_450);  t_default_450 = None
        view_default_802 = torch.ops.aten.view.default(mm_default_164, [8, 128, 1024]);  mm_default_164 = None
        view_default_803 = torch.ops.aten.view.default(view_default_802, [8, 128, 16, 64]);  view_default_802 = None
        transpose_int_264 = torch.ops.aten.transpose.int(view_default_803, 1, 2);  view_default_803 = None
        clone_default_160 = torch.ops.aten.clone.default(transpose_int_264, memory_format = torch.contiguous_format);  transpose_int_264 = None
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(clone_default_160, [128, 128, 64]);  clone_default_160 = None
        transpose_int_265 = torch.ops.aten.transpose.int(_softmax_default_7, 1, 2)
        bmm_default_112 = torch.ops.aten.bmm.default(transpose_int_265, _unsafe_view_default_88);  transpose_int_265 = None
        transpose_int_266 = torch.ops.aten.transpose.int(view_default_144, 1, 2);  view_default_144 = None
        bmm_default_113 = torch.ops.aten.bmm.default(_unsafe_view_default_88, transpose_int_266);  _unsafe_view_default_88 = transpose_int_266 = None
        _softmax_backward_data_default_16 = torch.ops.aten._softmax_backward_data.default(bmm_default_113, _softmax_default_7, -1, torch.float32);  bmm_default_113 = _softmax_default_7 = None
        view_default_804 = torch.ops.aten.view.default(_softmax_backward_data_default_16, [8, 16, 128, 1024]);  _softmax_backward_data_default_16 = None
        view_default_805 = torch.ops.aten.view.default(view_default_804, [128, 128, 1024]);  view_default_804 = None
        transpose_int_267 = torch.ops.aten.transpose.int(view_default_142, 1, 2);  view_default_142 = None
        bmm_default_114 = torch.ops.aten.bmm.default(transpose_int_267, view_default_805);  transpose_int_267 = None
        transpose_int_268 = torch.ops.aten.transpose.int(transpose_int_38, 1, 2);  transpose_int_38 = None
        bmm_default_115 = torch.ops.aten.bmm.default(view_default_805, transpose_int_268);  view_default_805 = transpose_int_268 = None
        transpose_int_269 = torch.ops.aten.transpose.int(bmm_default_114, 1, 2);  bmm_default_114 = None
        view_default_806 = torch.ops.aten.view.default(bmm_default_112, [8, 16, 1024, 64]);  bmm_default_112 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(tangents_17, view_default_806);  tangents_17 = view_default_806 = None
        view_default_807 = torch.ops.aten.view.default(transpose_int_269, [8, 16, 1024, 64]);  transpose_int_269 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(tangents_16, view_default_807);  tangents_16 = view_default_807 = None
        view_default_808 = torch.ops.aten.view.default(bmm_default_115, [8, 16, 128, 64]);  bmm_default_115 = None
        transpose_int_270 = torch.ops.aten.transpose.int(view_default_808, 1, 2);  view_default_808 = None
        clone_default_161 = torch.ops.aten.clone.default(transpose_int_270, memory_format = torch.contiguous_format);  transpose_int_270 = None
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(clone_default_161, [8, 128, 1024]);  clone_default_161 = None
        transpose_int_271 = torch.ops.aten.transpose.int(add_tensor_169, 1, 2);  add_tensor_169 = None
        clone_default_162 = torch.ops.aten.clone.default(transpose_int_271, memory_format = torch.contiguous_format);  transpose_int_271 = None
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(clone_default_162, [8, 1024, 1024]);  clone_default_162 = None
        view_default_809 = torch.ops.aten.view.default(_unsafe_view_default_90, [8192, 1024]);  _unsafe_view_default_90 = None
        t_default_452 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_166 = torch.ops.aten.mm.default(view_default_809, t_default_452);  t_default_452 = None
        t_default_453 = torch.ops.aten.t.default(view_default_809)
        mm_default_167 = torch.ops.aten.mm.default(t_default_453, view_default_138);  t_default_453 = view_default_138 = None
        t_default_454 = torch.ops.aten.t.default(mm_default_167);  mm_default_167 = None
        sum_dim_int_list_83 = torch.ops.aten.sum.dim_IntList(view_default_809, [0], True);  view_default_809 = None
        view_default_810 = torch.ops.aten.view.default(sum_dim_int_list_83, [1024]);  sum_dim_int_list_83 = None
        t_default_455 = torch.ops.aten.t.default(t_default_454);  t_default_454 = None
        view_default_811 = torch.ops.aten.view.default(mm_default_166, [8, 1024, 1024]);  mm_default_166 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(add_tensor_159, view_default_811);  add_tensor_159 = view_default_811 = None
        transpose_int_272 = torch.ops.aten.transpose.int(add_tensor_170, 1, 2);  add_tensor_170 = None
        clone_default_163 = torch.ops.aten.clone.default(transpose_int_272, memory_format = torch.contiguous_format);  transpose_int_272 = None
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(clone_default_163, [8, 1024, 1024]);  clone_default_163 = None
        view_default_812 = torch.ops.aten.view.default(_unsafe_view_default_91, [8192, 1024]);  _unsafe_view_default_91 = None
        t_default_456 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_168 = torch.ops.aten.mm.default(view_default_812, t_default_456);  t_default_456 = None
        t_default_457 = torch.ops.aten.t.default(view_default_812)
        mm_default_169 = torch.ops.aten.mm.default(t_default_457, view_default_135);  t_default_457 = view_default_135 = None
        t_default_458 = torch.ops.aten.t.default(mm_default_169);  mm_default_169 = None
        sum_dim_int_list_84 = torch.ops.aten.sum.dim_IntList(view_default_812, [0], True);  view_default_812 = None
        view_default_813 = torch.ops.aten.view.default(sum_dim_int_list_84, [1024]);  sum_dim_int_list_84 = None
        t_default_459 = torch.ops.aten.t.default(t_default_458);  t_default_458 = None
        view_default_814 = torch.ops.aten.view.default(mm_default_168, [8, 1024, 1024]);  mm_default_168 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(add_tensor_171, view_default_814);  add_tensor_171 = view_default_814 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(_unsafe_view_default_89, 0.125);  _unsafe_view_default_89 = None
        view_default_815 = torch.ops.aten.view.default(mul_tensor_104, [1024, 1024]);  mul_tensor_104 = None
        t_default_460 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_170 = torch.ops.aten.mm.default(view_default_815, t_default_460);  t_default_460 = None
        t_default_461 = torch.ops.aten.t.default(view_default_815)
        mm_default_171 = torch.ops.aten.mm.default(t_default_461, view_default_133);  t_default_461 = view_default_133 = None
        t_default_462 = torch.ops.aten.t.default(mm_default_171);  mm_default_171 = None
        sum_dim_int_list_85 = torch.ops.aten.sum.dim_IntList(view_default_815, [0], True);  view_default_815 = None
        view_default_816 = torch.ops.aten.view.default(sum_dim_int_list_85, [1024]);  sum_dim_int_list_85 = None
        t_default_463 = torch.ops.aten.t.default(t_default_462);  t_default_462 = None
        view_default_817 = torch.ops.aten.view.default(mm_default_170, [8, 128, 1024]);  mm_default_170 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(getitem_186, view_default_817);  getitem_186 = view_default_817 = None
        native_layer_norm_backward_default_26 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_173, add_tensor_19, [1024], getitem_31, getitem_32, primals_154, primals_153, [True, True, True]);  add_tensor_173 = add_tensor_19 = getitem_31 = getitem_32 = primals_154 = primals_153 = None
        getitem_189 = native_layer_norm_backward_default_26[0]
        getitem_190 = native_layer_norm_backward_default_26[1]
        getitem_191 = native_layer_norm_backward_default_26[2];  native_layer_norm_backward_default_26 = None
        view_default_818 = torch.ops.aten.view.default(getitem_189, [1024, 1024])
        t_default_464 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_172 = torch.ops.aten.mm.default(view_default_818, t_default_464);  t_default_464 = None
        t_default_465 = torch.ops.aten.t.default(view_default_818)
        mm_default_173 = torch.ops.aten.mm.default(t_default_465, view_default_131);  t_default_465 = view_default_131 = None
        t_default_466 = torch.ops.aten.t.default(mm_default_173);  mm_default_173 = None
        sum_dim_int_list_86 = torch.ops.aten.sum.dim_IntList(view_default_818, [0], True);  view_default_818 = None
        view_default_819 = torch.ops.aten.view.default(sum_dim_int_list_86, [1024]);  sum_dim_int_list_86 = None
        t_default_467 = torch.ops.aten.t.default(t_default_466);  t_default_466 = None
        view_default_820 = torch.ops.aten.view.default(mm_default_172, [8, 128, 1024]);  mm_default_172 = None
        view_default_821 = torch.ops.aten.view.default(view_default_820, [8, 128, 16, 64]);  view_default_820 = None
        transpose_int_273 = torch.ops.aten.transpose.int(view_default_821, 1, 2);  view_default_821 = None
        clone_default_164 = torch.ops.aten.clone.default(transpose_int_273, memory_format = torch.contiguous_format);  transpose_int_273 = None
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(clone_default_164, [128, 128, 64]);  clone_default_164 = None
        transpose_int_274 = torch.ops.aten.transpose.int(_softmax_default_6, 1, 2)
        bmm_default_116 = torch.ops.aten.bmm.default(transpose_int_274, _unsafe_view_default_92);  transpose_int_274 = None
        transpose_int_275 = torch.ops.aten.transpose.int(view_default_127, 1, 2);  view_default_127 = None
        bmm_default_117 = torch.ops.aten.bmm.default(_unsafe_view_default_92, transpose_int_275);  _unsafe_view_default_92 = transpose_int_275 = None
        _softmax_backward_data_default_17 = torch.ops.aten._softmax_backward_data.default(bmm_default_117, _softmax_default_6, -1, torch.float32);  bmm_default_117 = _softmax_default_6 = None
        view_default_822 = torch.ops.aten.view.default(_softmax_backward_data_default_17, [8, 16, 128, 128]);  _softmax_backward_data_default_17 = None
        view_default_823 = torch.ops.aten.view.default(view_default_822, [128, 128, 128]);  view_default_822 = None
        transpose_int_276 = torch.ops.aten.transpose.int(view_default_125, 1, 2);  view_default_125 = None
        bmm_default_118 = torch.ops.aten.bmm.default(transpose_int_276, view_default_823);  transpose_int_276 = None
        transpose_int_277 = torch.ops.aten.transpose.int(transpose_int_33, 1, 2);  transpose_int_33 = None
        bmm_default_119 = torch.ops.aten.bmm.default(view_default_823, transpose_int_277);  view_default_823 = transpose_int_277 = None
        transpose_int_278 = torch.ops.aten.transpose.int(bmm_default_118, 1, 2);  bmm_default_118 = None
        view_default_824 = torch.ops.aten.view.default(bmm_default_116, [8, 16, 128, 64]);  bmm_default_116 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(tangents_15, view_default_824);  tangents_15 = view_default_824 = None
        view_default_825 = torch.ops.aten.view.default(transpose_int_278, [8, 16, 128, 64]);  transpose_int_278 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(tangents_14, view_default_825);  tangents_14 = view_default_825 = None
        view_default_826 = torch.ops.aten.view.default(bmm_default_119, [8, 16, 128, 64]);  bmm_default_119 = None
        transpose_int_279 = torch.ops.aten.transpose.int(view_default_826, 1, 2);  view_default_826 = None
        clone_default_165 = torch.ops.aten.clone.default(transpose_int_279, memory_format = torch.contiguous_format);  transpose_int_279 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_165, [8, 128, 1024]);  clone_default_165 = None
        transpose_int_280 = torch.ops.aten.transpose.int(add_tensor_174, 1, 2);  add_tensor_174 = None
        clone_default_166 = torch.ops.aten.clone.default(transpose_int_280, memory_format = torch.contiguous_format);  transpose_int_280 = None
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(clone_default_166, [8, 128, 1024]);  clone_default_166 = None
        view_default_827 = torch.ops.aten.view.default(_unsafe_view_default_94, [1024, 1024]);  _unsafe_view_default_94 = None
        t_default_468 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_174 = torch.ops.aten.mm.default(view_default_827, t_default_468);  t_default_468 = None
        t_default_469 = torch.ops.aten.t.default(view_default_827)
        mm_default_175 = torch.ops.aten.mm.default(t_default_469, view_default_121);  t_default_469 = view_default_121 = None
        t_default_470 = torch.ops.aten.t.default(mm_default_175);  mm_default_175 = None
        sum_dim_int_list_87 = torch.ops.aten.sum.dim_IntList(view_default_827, [0], True);  view_default_827 = None
        view_default_828 = torch.ops.aten.view.default(sum_dim_int_list_87, [1024]);  sum_dim_int_list_87 = None
        t_default_471 = torch.ops.aten.t.default(t_default_470);  t_default_470 = None
        view_default_829 = torch.ops.aten.view.default(mm_default_174, [8, 128, 1024]);  mm_default_174 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(getitem_189, view_default_829);  getitem_189 = view_default_829 = None
        transpose_int_281 = torch.ops.aten.transpose.int(add_tensor_175, 1, 2);  add_tensor_175 = None
        clone_default_167 = torch.ops.aten.clone.default(transpose_int_281, memory_format = torch.contiguous_format);  transpose_int_281 = None
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(clone_default_167, [8, 128, 1024]);  clone_default_167 = None
        view_default_830 = torch.ops.aten.view.default(_unsafe_view_default_95, [1024, 1024]);  _unsafe_view_default_95 = None
        t_default_472 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_176 = torch.ops.aten.mm.default(view_default_830, t_default_472);  t_default_472 = None
        t_default_473 = torch.ops.aten.t.default(view_default_830)
        mm_default_177 = torch.ops.aten.mm.default(t_default_473, view_default_118);  t_default_473 = view_default_118 = None
        t_default_474 = torch.ops.aten.t.default(mm_default_177);  mm_default_177 = None
        sum_dim_int_list_88 = torch.ops.aten.sum.dim_IntList(view_default_830, [0], True);  view_default_830 = None
        view_default_831 = torch.ops.aten.view.default(sum_dim_int_list_88, [1024]);  sum_dim_int_list_88 = None
        t_default_475 = torch.ops.aten.t.default(t_default_474);  t_default_474 = None
        view_default_832 = torch.ops.aten.view.default(mm_default_176, [8, 128, 1024]);  mm_default_176 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(add_tensor_176, view_default_832);  add_tensor_176 = view_default_832 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(_unsafe_view_default_93, 0.125);  _unsafe_view_default_93 = None
        view_default_833 = torch.ops.aten.view.default(mul_tensor_105, [1024, 1024]);  mul_tensor_105 = None
        t_default_476 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_178 = torch.ops.aten.mm.default(view_default_833, t_default_476);  t_default_476 = None
        t_default_477 = torch.ops.aten.t.default(view_default_833)
        mm_default_179 = torch.ops.aten.mm.default(t_default_477, view_default_116);  t_default_477 = view_default_116 = None
        t_default_478 = torch.ops.aten.t.default(mm_default_179);  mm_default_179 = None
        sum_dim_int_list_89 = torch.ops.aten.sum.dim_IntList(view_default_833, [0], True);  view_default_833 = None
        view_default_834 = torch.ops.aten.view.default(sum_dim_int_list_89, [1024]);  sum_dim_int_list_89 = None
        t_default_479 = torch.ops.aten.t.default(t_default_478);  t_default_478 = None
        view_default_835 = torch.ops.aten.view.default(mm_default_178, [8, 128, 1024]);  mm_default_178 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(add_tensor_177, view_default_835);  add_tensor_177 = view_default_835 = None
        native_layer_norm_backward_default_27 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_178, add_tensor_17, [1024], getitem_28, getitem_29, primals_124, primals_123, [True, True, True]);  add_tensor_178 = add_tensor_17 = getitem_28 = getitem_29 = primals_124 = primals_123 = None
        getitem_192 = native_layer_norm_backward_default_27[0]
        getitem_193 = native_layer_norm_backward_default_27[1]
        getitem_194 = native_layer_norm_backward_default_27[2];  native_layer_norm_backward_default_27 = None
        view_default_836 = torch.ops.aten.view.default(getitem_192, [1024, 1024])
        t_default_480 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_180 = torch.ops.aten.mm.default(view_default_836, t_default_480);  t_default_480 = None
        t_default_481 = torch.ops.aten.t.default(view_default_836)
        mm_default_181 = torch.ops.aten.mm.default(t_default_481, view_default_114);  t_default_481 = view_default_114 = None
        t_default_482 = torch.ops.aten.t.default(mm_default_181);  mm_default_181 = None
        sum_dim_int_list_90 = torch.ops.aten.sum.dim_IntList(view_default_836, [0], True);  view_default_836 = None
        view_default_837 = torch.ops.aten.view.default(sum_dim_int_list_90, [1024]);  sum_dim_int_list_90 = None
        t_default_483 = torch.ops.aten.t.default(t_default_482);  t_default_482 = None
        view_default_838 = torch.ops.aten.view.default(mm_default_180, [8, 128, 4096]);  mm_default_180 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_838, torch.float32);  view_default_838 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_113, torch.float32);  view_default_113 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_106);  mul_tensor_106 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(add_tensor_179, 0.5);  add_tensor_179 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_109 = torch.ops.aten.mul.Tensor(mul_tensor_108, -0.5);  mul_tensor_108 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_109);  mul_tensor_109 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_110);  to_dtype_28 = mul_tensor_110 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(mul_tensor_107, mul_tensor_111);  mul_tensor_107 = mul_tensor_111 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_180);  to_dtype_27 = add_tensor_180 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_112, torch.float32);  mul_tensor_112 = None
        view_default_839 = torch.ops.aten.view.default(to_dtype_29, [1024, 4096]);  to_dtype_29 = None
        t_default_484 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_182 = torch.ops.aten.mm.default(view_default_839, t_default_484);  t_default_484 = None
        t_default_485 = torch.ops.aten.t.default(view_default_839)
        mm_default_183 = torch.ops.aten.mm.default(t_default_485, view_default_112);  t_default_485 = view_default_112 = None
        t_default_486 = torch.ops.aten.t.default(mm_default_183);  mm_default_183 = None
        sum_dim_int_list_91 = torch.ops.aten.sum.dim_IntList(view_default_839, [0], True);  view_default_839 = None
        view_default_840 = torch.ops.aten.view.default(sum_dim_int_list_91, [4096]);  sum_dim_int_list_91 = None
        t_default_487 = torch.ops.aten.t.default(t_default_486);  t_default_486 = None
        view_default_841 = torch.ops.aten.view.default(mm_default_182, [8, 128, 1024]);  mm_default_182 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(getitem_192, view_default_841);  getitem_192 = view_default_841 = None
        native_layer_norm_backward_default_28 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_181, add_tensor_16, [1024], getitem_25, getitem_26, primals_112, primals_111, [True, True, True]);  add_tensor_181 = add_tensor_16 = getitem_25 = getitem_26 = primals_112 = primals_111 = None
        getitem_195 = native_layer_norm_backward_default_28[0]
        getitem_196 = native_layer_norm_backward_default_28[1]
        getitem_197 = native_layer_norm_backward_default_28[2];  native_layer_norm_backward_default_28 = None
        view_default_842 = torch.ops.aten.view.default(getitem_195, [1024, 1024])
        t_default_488 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_184 = torch.ops.aten.mm.default(view_default_842, t_default_488);  t_default_488 = None
        t_default_489 = torch.ops.aten.t.default(view_default_842)
        mm_default_185 = torch.ops.aten.mm.default(t_default_489, view_default_110);  t_default_489 = view_default_110 = None
        t_default_490 = torch.ops.aten.t.default(mm_default_185);  mm_default_185 = None
        sum_dim_int_list_92 = torch.ops.aten.sum.dim_IntList(view_default_842, [0], True);  view_default_842 = None
        view_default_843 = torch.ops.aten.view.default(sum_dim_int_list_92, [1024]);  sum_dim_int_list_92 = None
        t_default_491 = torch.ops.aten.t.default(t_default_490);  t_default_490 = None
        view_default_844 = torch.ops.aten.view.default(mm_default_184, [8, 128, 1024]);  mm_default_184 = None
        view_default_845 = torch.ops.aten.view.default(view_default_844, [8, 128, 16, 64]);  view_default_844 = None
        transpose_int_282 = torch.ops.aten.transpose.int(view_default_845, 1, 2);  view_default_845 = None
        clone_default_168 = torch.ops.aten.clone.default(transpose_int_282, memory_format = torch.contiguous_format);  transpose_int_282 = None
        _unsafe_view_default_96 = torch.ops.aten._unsafe_view.default(clone_default_168, [128, 128, 64]);  clone_default_168 = None
        transpose_int_283 = torch.ops.aten.transpose.int(_softmax_default_5, 1, 2)
        bmm_default_120 = torch.ops.aten.bmm.default(transpose_int_283, _unsafe_view_default_96);  transpose_int_283 = None
        transpose_int_284 = torch.ops.aten.transpose.int(view_default_106, 1, 2);  view_default_106 = None
        bmm_default_121 = torch.ops.aten.bmm.default(_unsafe_view_default_96, transpose_int_284);  _unsafe_view_default_96 = transpose_int_284 = None
        _softmax_backward_data_default_18 = torch.ops.aten._softmax_backward_data.default(bmm_default_121, _softmax_default_5, -1, torch.float32);  bmm_default_121 = _softmax_default_5 = None
        view_default_846 = torch.ops.aten.view.default(_softmax_backward_data_default_18, [8, 16, 128, 1024]);  _softmax_backward_data_default_18 = None
        view_default_847 = torch.ops.aten.view.default(view_default_846, [128, 128, 1024]);  view_default_846 = None
        transpose_int_285 = torch.ops.aten.transpose.int(view_default_104, 1, 2);  view_default_104 = None
        bmm_default_122 = torch.ops.aten.bmm.default(transpose_int_285, view_default_847);  transpose_int_285 = None
        transpose_int_286 = torch.ops.aten.transpose.int(transpose_int_28, 1, 2);  transpose_int_28 = None
        bmm_default_123 = torch.ops.aten.bmm.default(view_default_847, transpose_int_286);  view_default_847 = transpose_int_286 = None
        transpose_int_287 = torch.ops.aten.transpose.int(bmm_default_122, 1, 2);  bmm_default_122 = None
        view_default_848 = torch.ops.aten.view.default(bmm_default_120, [8, 16, 1024, 64]);  bmm_default_120 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(tangents_13, view_default_848);  tangents_13 = view_default_848 = None
        view_default_849 = torch.ops.aten.view.default(transpose_int_287, [8, 16, 1024, 64]);  transpose_int_287 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(tangents_12, view_default_849);  tangents_12 = view_default_849 = None
        view_default_850 = torch.ops.aten.view.default(bmm_default_123, [8, 16, 128, 64]);  bmm_default_123 = None
        transpose_int_288 = torch.ops.aten.transpose.int(view_default_850, 1, 2);  view_default_850 = None
        clone_default_169 = torch.ops.aten.clone.default(transpose_int_288, memory_format = torch.contiguous_format);  transpose_int_288 = None
        _unsafe_view_default_97 = torch.ops.aten._unsafe_view.default(clone_default_169, [8, 128, 1024]);  clone_default_169 = None
        transpose_int_289 = torch.ops.aten.transpose.int(add_tensor_182, 1, 2);  add_tensor_182 = None
        clone_default_170 = torch.ops.aten.clone.default(transpose_int_289, memory_format = torch.contiguous_format);  transpose_int_289 = None
        _unsafe_view_default_98 = torch.ops.aten._unsafe_view.default(clone_default_170, [8, 1024, 1024]);  clone_default_170 = None
        view_default_851 = torch.ops.aten.view.default(_unsafe_view_default_98, [8192, 1024]);  _unsafe_view_default_98 = None
        t_default_492 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_186 = torch.ops.aten.mm.default(view_default_851, t_default_492);  t_default_492 = None
        t_default_493 = torch.ops.aten.t.default(view_default_851)
        mm_default_187 = torch.ops.aten.mm.default(t_default_493, view_default_100);  t_default_493 = view_default_100 = None
        t_default_494 = torch.ops.aten.t.default(mm_default_187);  mm_default_187 = None
        sum_dim_int_list_93 = torch.ops.aten.sum.dim_IntList(view_default_851, [0], True);  view_default_851 = None
        view_default_852 = torch.ops.aten.view.default(sum_dim_int_list_93, [1024]);  sum_dim_int_list_93 = None
        t_default_495 = torch.ops.aten.t.default(t_default_494);  t_default_494 = None
        view_default_853 = torch.ops.aten.view.default(mm_default_186, [8, 1024, 1024]);  mm_default_186 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(add_tensor_172, view_default_853);  add_tensor_172 = view_default_853 = None
        transpose_int_290 = torch.ops.aten.transpose.int(add_tensor_183, 1, 2);  add_tensor_183 = None
        clone_default_171 = torch.ops.aten.clone.default(transpose_int_290, memory_format = torch.contiguous_format);  transpose_int_290 = None
        _unsafe_view_default_99 = torch.ops.aten._unsafe_view.default(clone_default_171, [8, 1024, 1024]);  clone_default_171 = None
        view_default_854 = torch.ops.aten.view.default(_unsafe_view_default_99, [8192, 1024]);  _unsafe_view_default_99 = None
        t_default_496 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_188 = torch.ops.aten.mm.default(view_default_854, t_default_496);  t_default_496 = None
        t_default_497 = torch.ops.aten.t.default(view_default_854)
        mm_default_189 = torch.ops.aten.mm.default(t_default_497, view_default_97);  t_default_497 = view_default_97 = None
        t_default_498 = torch.ops.aten.t.default(mm_default_189);  mm_default_189 = None
        sum_dim_int_list_94 = torch.ops.aten.sum.dim_IntList(view_default_854, [0], True);  view_default_854 = None
        view_default_855 = torch.ops.aten.view.default(sum_dim_int_list_94, [1024]);  sum_dim_int_list_94 = None
        t_default_499 = torch.ops.aten.t.default(t_default_498);  t_default_498 = None
        view_default_856 = torch.ops.aten.view.default(mm_default_188, [8, 1024, 1024]);  mm_default_188 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(add_tensor_184, view_default_856);  add_tensor_184 = view_default_856 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(_unsafe_view_default_97, 0.125);  _unsafe_view_default_97 = None
        view_default_857 = torch.ops.aten.view.default(mul_tensor_113, [1024, 1024]);  mul_tensor_113 = None
        t_default_500 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_190 = torch.ops.aten.mm.default(view_default_857, t_default_500);  t_default_500 = None
        t_default_501 = torch.ops.aten.t.default(view_default_857)
        mm_default_191 = torch.ops.aten.mm.default(t_default_501, view_default_95);  t_default_501 = view_default_95 = None
        t_default_502 = torch.ops.aten.t.default(mm_default_191);  mm_default_191 = None
        sum_dim_int_list_95 = torch.ops.aten.sum.dim_IntList(view_default_857, [0], True);  view_default_857 = None
        view_default_858 = torch.ops.aten.view.default(sum_dim_int_list_95, [1024]);  sum_dim_int_list_95 = None
        t_default_503 = torch.ops.aten.t.default(t_default_502);  t_default_502 = None
        view_default_859 = torch.ops.aten.view.default(mm_default_190, [8, 128, 1024]);  mm_default_190 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(getitem_195, view_default_859);  getitem_195 = view_default_859 = None
        native_layer_norm_backward_default_29 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_186, add_tensor_14, [1024], getitem_22, getitem_23, primals_128, primals_127, [True, True, True]);  add_tensor_186 = add_tensor_14 = getitem_22 = getitem_23 = primals_128 = primals_127 = None
        getitem_198 = native_layer_norm_backward_default_29[0]
        getitem_199 = native_layer_norm_backward_default_29[1]
        getitem_200 = native_layer_norm_backward_default_29[2];  native_layer_norm_backward_default_29 = None
        view_default_860 = torch.ops.aten.view.default(getitem_198, [1024, 1024])
        t_default_504 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_192 = torch.ops.aten.mm.default(view_default_860, t_default_504);  t_default_504 = None
        t_default_505 = torch.ops.aten.t.default(view_default_860)
        mm_default_193 = torch.ops.aten.mm.default(t_default_505, view_default_93);  t_default_505 = view_default_93 = None
        t_default_506 = torch.ops.aten.t.default(mm_default_193);  mm_default_193 = None
        sum_dim_int_list_96 = torch.ops.aten.sum.dim_IntList(view_default_860, [0], True);  view_default_860 = None
        view_default_861 = torch.ops.aten.view.default(sum_dim_int_list_96, [1024]);  sum_dim_int_list_96 = None
        t_default_507 = torch.ops.aten.t.default(t_default_506);  t_default_506 = None
        view_default_862 = torch.ops.aten.view.default(mm_default_192, [8, 128, 1024]);  mm_default_192 = None
        view_default_863 = torch.ops.aten.view.default(view_default_862, [8, 128, 16, 64]);  view_default_862 = None
        transpose_int_291 = torch.ops.aten.transpose.int(view_default_863, 1, 2);  view_default_863 = None
        clone_default_172 = torch.ops.aten.clone.default(transpose_int_291, memory_format = torch.contiguous_format);  transpose_int_291 = None
        _unsafe_view_default_100 = torch.ops.aten._unsafe_view.default(clone_default_172, [128, 128, 64]);  clone_default_172 = None
        transpose_int_292 = torch.ops.aten.transpose.int(_softmax_default_4, 1, 2)
        bmm_default_124 = torch.ops.aten.bmm.default(transpose_int_292, _unsafe_view_default_100);  transpose_int_292 = None
        transpose_int_293 = torch.ops.aten.transpose.int(view_default_89, 1, 2);  view_default_89 = None
        bmm_default_125 = torch.ops.aten.bmm.default(_unsafe_view_default_100, transpose_int_293);  _unsafe_view_default_100 = transpose_int_293 = None
        _softmax_backward_data_default_19 = torch.ops.aten._softmax_backward_data.default(bmm_default_125, _softmax_default_4, -1, torch.float32);  bmm_default_125 = _softmax_default_4 = None
        view_default_864 = torch.ops.aten.view.default(_softmax_backward_data_default_19, [8, 16, 128, 128]);  _softmax_backward_data_default_19 = None
        view_default_865 = torch.ops.aten.view.default(view_default_864, [128, 128, 128]);  view_default_864 = None
        transpose_int_294 = torch.ops.aten.transpose.int(view_default_87, 1, 2);  view_default_87 = None
        bmm_default_126 = torch.ops.aten.bmm.default(transpose_int_294, view_default_865);  transpose_int_294 = None
        transpose_int_295 = torch.ops.aten.transpose.int(transpose_int_23, 1, 2);  transpose_int_23 = None
        bmm_default_127 = torch.ops.aten.bmm.default(view_default_865, transpose_int_295);  view_default_865 = transpose_int_295 = None
        transpose_int_296 = torch.ops.aten.transpose.int(bmm_default_126, 1, 2);  bmm_default_126 = None
        view_default_866 = torch.ops.aten.view.default(bmm_default_124, [8, 16, 128, 64]);  bmm_default_124 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(tangents_11, view_default_866);  tangents_11 = view_default_866 = None
        view_default_867 = torch.ops.aten.view.default(transpose_int_296, [8, 16, 128, 64]);  transpose_int_296 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(tangents_10, view_default_867);  tangents_10 = view_default_867 = None
        view_default_868 = torch.ops.aten.view.default(bmm_default_127, [8, 16, 128, 64]);  bmm_default_127 = None
        transpose_int_297 = torch.ops.aten.transpose.int(view_default_868, 1, 2);  view_default_868 = None
        clone_default_173 = torch.ops.aten.clone.default(transpose_int_297, memory_format = torch.contiguous_format);  transpose_int_297 = None
        _unsafe_view_default_101 = torch.ops.aten._unsafe_view.default(clone_default_173, [8, 128, 1024]);  clone_default_173 = None
        transpose_int_298 = torch.ops.aten.transpose.int(add_tensor_187, 1, 2);  add_tensor_187 = None
        clone_default_174 = torch.ops.aten.clone.default(transpose_int_298, memory_format = torch.contiguous_format);  transpose_int_298 = None
        _unsafe_view_default_102 = torch.ops.aten._unsafe_view.default(clone_default_174, [8, 128, 1024]);  clone_default_174 = None
        view_default_869 = torch.ops.aten.view.default(_unsafe_view_default_102, [1024, 1024]);  _unsafe_view_default_102 = None
        t_default_508 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_194 = torch.ops.aten.mm.default(view_default_869, t_default_508);  t_default_508 = None
        t_default_509 = torch.ops.aten.t.default(view_default_869)
        mm_default_195 = torch.ops.aten.mm.default(t_default_509, view_default_83);  t_default_509 = view_default_83 = None
        t_default_510 = torch.ops.aten.t.default(mm_default_195);  mm_default_195 = None
        sum_dim_int_list_97 = torch.ops.aten.sum.dim_IntList(view_default_869, [0], True);  view_default_869 = None
        view_default_870 = torch.ops.aten.view.default(sum_dim_int_list_97, [1024]);  sum_dim_int_list_97 = None
        t_default_511 = torch.ops.aten.t.default(t_default_510);  t_default_510 = None
        view_default_871 = torch.ops.aten.view.default(mm_default_194, [8, 128, 1024]);  mm_default_194 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(getitem_198, view_default_871);  getitem_198 = view_default_871 = None
        transpose_int_299 = torch.ops.aten.transpose.int(add_tensor_188, 1, 2);  add_tensor_188 = None
        clone_default_175 = torch.ops.aten.clone.default(transpose_int_299, memory_format = torch.contiguous_format);  transpose_int_299 = None
        _unsafe_view_default_103 = torch.ops.aten._unsafe_view.default(clone_default_175, [8, 128, 1024]);  clone_default_175 = None
        view_default_872 = torch.ops.aten.view.default(_unsafe_view_default_103, [1024, 1024]);  _unsafe_view_default_103 = None
        t_default_512 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_196 = torch.ops.aten.mm.default(view_default_872, t_default_512);  t_default_512 = None
        t_default_513 = torch.ops.aten.t.default(view_default_872)
        mm_default_197 = torch.ops.aten.mm.default(t_default_513, view_default_80);  t_default_513 = view_default_80 = None
        t_default_514 = torch.ops.aten.t.default(mm_default_197);  mm_default_197 = None
        sum_dim_int_list_98 = torch.ops.aten.sum.dim_IntList(view_default_872, [0], True);  view_default_872 = None
        view_default_873 = torch.ops.aten.view.default(sum_dim_int_list_98, [1024]);  sum_dim_int_list_98 = None
        t_default_515 = torch.ops.aten.t.default(t_default_514);  t_default_514 = None
        view_default_874 = torch.ops.aten.view.default(mm_default_196, [8, 128, 1024]);  mm_default_196 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(add_tensor_189, view_default_874);  add_tensor_189 = view_default_874 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(_unsafe_view_default_101, 0.125);  _unsafe_view_default_101 = None
        view_default_875 = torch.ops.aten.view.default(mul_tensor_114, [1024, 1024]);  mul_tensor_114 = None
        t_default_516 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_198 = torch.ops.aten.mm.default(view_default_875, t_default_516);  t_default_516 = None
        t_default_517 = torch.ops.aten.t.default(view_default_875)
        mm_default_199 = torch.ops.aten.mm.default(t_default_517, view_default_78);  t_default_517 = view_default_78 = None
        t_default_518 = torch.ops.aten.t.default(mm_default_199);  mm_default_199 = None
        sum_dim_int_list_99 = torch.ops.aten.sum.dim_IntList(view_default_875, [0], True);  view_default_875 = None
        view_default_876 = torch.ops.aten.view.default(sum_dim_int_list_99, [1024]);  sum_dim_int_list_99 = None
        t_default_519 = torch.ops.aten.t.default(t_default_518);  t_default_518 = None
        view_default_877 = torch.ops.aten.view.default(mm_default_198, [8, 128, 1024]);  mm_default_198 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(add_tensor_190, view_default_877);  add_tensor_190 = view_default_877 = None
        native_layer_norm_backward_default_30 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_191, add_tensor_12, [1024], getitem_19, getitem_20, primals_98, primals_97, [True, True, True]);  add_tensor_191 = add_tensor_12 = getitem_19 = getitem_20 = primals_98 = primals_97 = None
        getitem_201 = native_layer_norm_backward_default_30[0]
        getitem_202 = native_layer_norm_backward_default_30[1]
        getitem_203 = native_layer_norm_backward_default_30[2];  native_layer_norm_backward_default_30 = None
        view_default_878 = torch.ops.aten.view.default(getitem_201, [1024, 1024])
        t_default_520 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_200 = torch.ops.aten.mm.default(view_default_878, t_default_520);  t_default_520 = None
        t_default_521 = torch.ops.aten.t.default(view_default_878)
        mm_default_201 = torch.ops.aten.mm.default(t_default_521, view_default_76);  t_default_521 = view_default_76 = None
        t_default_522 = torch.ops.aten.t.default(mm_default_201);  mm_default_201 = None
        sum_dim_int_list_100 = torch.ops.aten.sum.dim_IntList(view_default_878, [0], True);  view_default_878 = None
        view_default_879 = torch.ops.aten.view.default(sum_dim_int_list_100, [1024]);  sum_dim_int_list_100 = None
        t_default_523 = torch.ops.aten.t.default(t_default_522);  t_default_522 = None
        view_default_880 = torch.ops.aten.view.default(mm_default_200, [8, 128, 4096]);  mm_default_200 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_880, torch.float32);  view_default_880 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_75, torch.float32);  view_default_75 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_115);  mul_tensor_115 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(add_tensor_192, 0.5);  add_tensor_192 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_118 = torch.ops.aten.mul.Tensor(mul_tensor_117, -0.5);  mul_tensor_117 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_118);  mul_tensor_118 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_119);  to_dtype_31 = mul_tensor_119 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(mul_tensor_116, mul_tensor_120);  mul_tensor_116 = mul_tensor_120 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_193);  to_dtype_30 = add_tensor_193 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_121, torch.float32);  mul_tensor_121 = None
        view_default_881 = torch.ops.aten.view.default(to_dtype_32, [1024, 4096]);  to_dtype_32 = None
        t_default_524 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_202 = torch.ops.aten.mm.default(view_default_881, t_default_524);  t_default_524 = None
        t_default_525 = torch.ops.aten.t.default(view_default_881)
        mm_default_203 = torch.ops.aten.mm.default(t_default_525, view_default_74);  t_default_525 = view_default_74 = None
        t_default_526 = torch.ops.aten.t.default(mm_default_203);  mm_default_203 = None
        sum_dim_int_list_101 = torch.ops.aten.sum.dim_IntList(view_default_881, [0], True);  view_default_881 = None
        view_default_882 = torch.ops.aten.view.default(sum_dim_int_list_101, [4096]);  sum_dim_int_list_101 = None
        t_default_527 = torch.ops.aten.t.default(t_default_526);  t_default_526 = None
        view_default_883 = torch.ops.aten.view.default(mm_default_202, [8, 128, 1024]);  mm_default_202 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(getitem_201, view_default_883);  getitem_201 = view_default_883 = None
        native_layer_norm_backward_default_31 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_194, add_tensor_11, [1024], getitem_16, getitem_17, primals_86, primals_85, [True, True, True]);  add_tensor_194 = add_tensor_11 = getitem_16 = getitem_17 = primals_86 = primals_85 = None
        getitem_204 = native_layer_norm_backward_default_31[0]
        getitem_205 = native_layer_norm_backward_default_31[1]
        getitem_206 = native_layer_norm_backward_default_31[2];  native_layer_norm_backward_default_31 = None
        view_default_884 = torch.ops.aten.view.default(getitem_204, [1024, 1024])
        t_default_528 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_204 = torch.ops.aten.mm.default(view_default_884, t_default_528);  t_default_528 = None
        t_default_529 = torch.ops.aten.t.default(view_default_884)
        mm_default_205 = torch.ops.aten.mm.default(t_default_529, view_default_72);  t_default_529 = view_default_72 = None
        t_default_530 = torch.ops.aten.t.default(mm_default_205);  mm_default_205 = None
        sum_dim_int_list_102 = torch.ops.aten.sum.dim_IntList(view_default_884, [0], True);  view_default_884 = None
        view_default_885 = torch.ops.aten.view.default(sum_dim_int_list_102, [1024]);  sum_dim_int_list_102 = None
        t_default_531 = torch.ops.aten.t.default(t_default_530);  t_default_530 = None
        view_default_886 = torch.ops.aten.view.default(mm_default_204, [8, 128, 1024]);  mm_default_204 = None
        view_default_887 = torch.ops.aten.view.default(view_default_886, [8, 128, 16, 64]);  view_default_886 = None
        transpose_int_300 = torch.ops.aten.transpose.int(view_default_887, 1, 2);  view_default_887 = None
        clone_default_176 = torch.ops.aten.clone.default(transpose_int_300, memory_format = torch.contiguous_format);  transpose_int_300 = None
        _unsafe_view_default_104 = torch.ops.aten._unsafe_view.default(clone_default_176, [128, 128, 64]);  clone_default_176 = None
        transpose_int_301 = torch.ops.aten.transpose.int(_softmax_default_3, 1, 2)
        bmm_default_128 = torch.ops.aten.bmm.default(transpose_int_301, _unsafe_view_default_104);  transpose_int_301 = None
        transpose_int_302 = torch.ops.aten.transpose.int(view_default_68, 1, 2);  view_default_68 = None
        bmm_default_129 = torch.ops.aten.bmm.default(_unsafe_view_default_104, transpose_int_302);  _unsafe_view_default_104 = transpose_int_302 = None
        _softmax_backward_data_default_20 = torch.ops.aten._softmax_backward_data.default(bmm_default_129, _softmax_default_3, -1, torch.float32);  bmm_default_129 = _softmax_default_3 = None
        view_default_888 = torch.ops.aten.view.default(_softmax_backward_data_default_20, [8, 16, 128, 1024]);  _softmax_backward_data_default_20 = None
        view_default_889 = torch.ops.aten.view.default(view_default_888, [128, 128, 1024]);  view_default_888 = None
        transpose_int_303 = torch.ops.aten.transpose.int(view_default_66, 1, 2);  view_default_66 = None
        bmm_default_130 = torch.ops.aten.bmm.default(transpose_int_303, view_default_889);  transpose_int_303 = None
        transpose_int_304 = torch.ops.aten.transpose.int(transpose_int_18, 1, 2);  transpose_int_18 = None
        bmm_default_131 = torch.ops.aten.bmm.default(view_default_889, transpose_int_304);  view_default_889 = transpose_int_304 = None
        transpose_int_305 = torch.ops.aten.transpose.int(bmm_default_130, 1, 2);  bmm_default_130 = None
        view_default_890 = torch.ops.aten.view.default(bmm_default_128, [8, 16, 1024, 64]);  bmm_default_128 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(tangents_9, view_default_890);  tangents_9 = view_default_890 = None
        view_default_891 = torch.ops.aten.view.default(transpose_int_305, [8, 16, 1024, 64]);  transpose_int_305 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(tangents_8, view_default_891);  tangents_8 = view_default_891 = None
        view_default_892 = torch.ops.aten.view.default(bmm_default_131, [8, 16, 128, 64]);  bmm_default_131 = None
        transpose_int_306 = torch.ops.aten.transpose.int(view_default_892, 1, 2);  view_default_892 = None
        clone_default_177 = torch.ops.aten.clone.default(transpose_int_306, memory_format = torch.contiguous_format);  transpose_int_306 = None
        _unsafe_view_default_105 = torch.ops.aten._unsafe_view.default(clone_default_177, [8, 128, 1024]);  clone_default_177 = None
        transpose_int_307 = torch.ops.aten.transpose.int(add_tensor_195, 1, 2);  add_tensor_195 = None
        clone_default_178 = torch.ops.aten.clone.default(transpose_int_307, memory_format = torch.contiguous_format);  transpose_int_307 = None
        _unsafe_view_default_106 = torch.ops.aten._unsafe_view.default(clone_default_178, [8, 1024, 1024]);  clone_default_178 = None
        view_default_893 = torch.ops.aten.view.default(_unsafe_view_default_106, [8192, 1024]);  _unsafe_view_default_106 = None
        t_default_532 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_206 = torch.ops.aten.mm.default(view_default_893, t_default_532);  t_default_532 = None
        t_default_533 = torch.ops.aten.t.default(view_default_893)
        mm_default_207 = torch.ops.aten.mm.default(t_default_533, view_default_62);  t_default_533 = view_default_62 = None
        t_default_534 = torch.ops.aten.t.default(mm_default_207);  mm_default_207 = None
        sum_dim_int_list_103 = torch.ops.aten.sum.dim_IntList(view_default_893, [0], True);  view_default_893 = None
        view_default_894 = torch.ops.aten.view.default(sum_dim_int_list_103, [1024]);  sum_dim_int_list_103 = None
        t_default_535 = torch.ops.aten.t.default(t_default_534);  t_default_534 = None
        view_default_895 = torch.ops.aten.view.default(mm_default_206, [8, 1024, 1024]);  mm_default_206 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(add_tensor_185, view_default_895);  add_tensor_185 = view_default_895 = None
        transpose_int_308 = torch.ops.aten.transpose.int(add_tensor_196, 1, 2);  add_tensor_196 = None
        clone_default_179 = torch.ops.aten.clone.default(transpose_int_308, memory_format = torch.contiguous_format);  transpose_int_308 = None
        _unsafe_view_default_107 = torch.ops.aten._unsafe_view.default(clone_default_179, [8, 1024, 1024]);  clone_default_179 = None
        view_default_896 = torch.ops.aten.view.default(_unsafe_view_default_107, [8192, 1024]);  _unsafe_view_default_107 = None
        t_default_536 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_208 = torch.ops.aten.mm.default(view_default_896, t_default_536);  t_default_536 = None
        t_default_537 = torch.ops.aten.t.default(view_default_896)
        mm_default_209 = torch.ops.aten.mm.default(t_default_537, view_default_59);  t_default_537 = view_default_59 = None
        t_default_538 = torch.ops.aten.t.default(mm_default_209);  mm_default_209 = None
        sum_dim_int_list_104 = torch.ops.aten.sum.dim_IntList(view_default_896, [0], True);  view_default_896 = None
        view_default_897 = torch.ops.aten.view.default(sum_dim_int_list_104, [1024]);  sum_dim_int_list_104 = None
        t_default_539 = torch.ops.aten.t.default(t_default_538);  t_default_538 = None
        view_default_898 = torch.ops.aten.view.default(mm_default_208, [8, 1024, 1024]);  mm_default_208 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(add_tensor_197, view_default_898);  add_tensor_197 = view_default_898 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(_unsafe_view_default_105, 0.125);  _unsafe_view_default_105 = None
        view_default_899 = torch.ops.aten.view.default(mul_tensor_122, [1024, 1024]);  mul_tensor_122 = None
        t_default_540 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_210 = torch.ops.aten.mm.default(view_default_899, t_default_540);  t_default_540 = None
        t_default_541 = torch.ops.aten.t.default(view_default_899)
        mm_default_211 = torch.ops.aten.mm.default(t_default_541, view_default_57);  t_default_541 = view_default_57 = None
        t_default_542 = torch.ops.aten.t.default(mm_default_211);  mm_default_211 = None
        sum_dim_int_list_105 = torch.ops.aten.sum.dim_IntList(view_default_899, [0], True);  view_default_899 = None
        view_default_900 = torch.ops.aten.view.default(sum_dim_int_list_105, [1024]);  sum_dim_int_list_105 = None
        t_default_543 = torch.ops.aten.t.default(t_default_542);  t_default_542 = None
        view_default_901 = torch.ops.aten.view.default(mm_default_210, [8, 128, 1024]);  mm_default_210 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(getitem_204, view_default_901);  getitem_204 = view_default_901 = None
        native_layer_norm_backward_default_32 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_199, add_tensor_9, [1024], getitem_13, getitem_14, primals_102, primals_101, [True, True, True]);  add_tensor_199 = add_tensor_9 = getitem_13 = getitem_14 = primals_102 = primals_101 = None
        getitem_207 = native_layer_norm_backward_default_32[0]
        getitem_208 = native_layer_norm_backward_default_32[1]
        getitem_209 = native_layer_norm_backward_default_32[2];  native_layer_norm_backward_default_32 = None
        view_default_902 = torch.ops.aten.view.default(getitem_207, [1024, 1024])
        t_default_544 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_212 = torch.ops.aten.mm.default(view_default_902, t_default_544);  t_default_544 = None
        t_default_545 = torch.ops.aten.t.default(view_default_902)
        mm_default_213 = torch.ops.aten.mm.default(t_default_545, view_default_55);  t_default_545 = view_default_55 = None
        t_default_546 = torch.ops.aten.t.default(mm_default_213);  mm_default_213 = None
        sum_dim_int_list_106 = torch.ops.aten.sum.dim_IntList(view_default_902, [0], True);  view_default_902 = None
        view_default_903 = torch.ops.aten.view.default(sum_dim_int_list_106, [1024]);  sum_dim_int_list_106 = None
        t_default_547 = torch.ops.aten.t.default(t_default_546);  t_default_546 = None
        view_default_904 = torch.ops.aten.view.default(mm_default_212, [8, 128, 1024]);  mm_default_212 = None
        view_default_905 = torch.ops.aten.view.default(view_default_904, [8, 128, 16, 64]);  view_default_904 = None
        transpose_int_309 = torch.ops.aten.transpose.int(view_default_905, 1, 2);  view_default_905 = None
        clone_default_180 = torch.ops.aten.clone.default(transpose_int_309, memory_format = torch.contiguous_format);  transpose_int_309 = None
        _unsafe_view_default_108 = torch.ops.aten._unsafe_view.default(clone_default_180, [128, 128, 64]);  clone_default_180 = None
        transpose_int_310 = torch.ops.aten.transpose.int(_softmax_default_2, 1, 2)
        bmm_default_132 = torch.ops.aten.bmm.default(transpose_int_310, _unsafe_view_default_108);  transpose_int_310 = None
        transpose_int_311 = torch.ops.aten.transpose.int(view_default_51, 1, 2);  view_default_51 = None
        bmm_default_133 = torch.ops.aten.bmm.default(_unsafe_view_default_108, transpose_int_311);  _unsafe_view_default_108 = transpose_int_311 = None
        _softmax_backward_data_default_21 = torch.ops.aten._softmax_backward_data.default(bmm_default_133, _softmax_default_2, -1, torch.float32);  bmm_default_133 = _softmax_default_2 = None
        view_default_906 = torch.ops.aten.view.default(_softmax_backward_data_default_21, [8, 16, 128, 128]);  _softmax_backward_data_default_21 = None
        view_default_907 = torch.ops.aten.view.default(view_default_906, [128, 128, 128]);  view_default_906 = None
        transpose_int_312 = torch.ops.aten.transpose.int(view_default_49, 1, 2);  view_default_49 = None
        bmm_default_134 = torch.ops.aten.bmm.default(transpose_int_312, view_default_907);  transpose_int_312 = None
        transpose_int_313 = torch.ops.aten.transpose.int(transpose_int_13, 1, 2);  transpose_int_13 = None
        bmm_default_135 = torch.ops.aten.bmm.default(view_default_907, transpose_int_313);  view_default_907 = transpose_int_313 = None
        transpose_int_314 = torch.ops.aten.transpose.int(bmm_default_134, 1, 2);  bmm_default_134 = None
        view_default_908 = torch.ops.aten.view.default(bmm_default_132, [8, 16, 128, 64]);  bmm_default_132 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(tangents_7, view_default_908);  tangents_7 = view_default_908 = None
        view_default_909 = torch.ops.aten.view.default(transpose_int_314, [8, 16, 128, 64]);  transpose_int_314 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(tangents_6, view_default_909);  tangents_6 = view_default_909 = None
        view_default_910 = torch.ops.aten.view.default(bmm_default_135, [8, 16, 128, 64]);  bmm_default_135 = None
        transpose_int_315 = torch.ops.aten.transpose.int(view_default_910, 1, 2);  view_default_910 = None
        clone_default_181 = torch.ops.aten.clone.default(transpose_int_315, memory_format = torch.contiguous_format);  transpose_int_315 = None
        _unsafe_view_default_109 = torch.ops.aten._unsafe_view.default(clone_default_181, [8, 128, 1024]);  clone_default_181 = None
        transpose_int_316 = torch.ops.aten.transpose.int(add_tensor_200, 1, 2);  add_tensor_200 = None
        clone_default_182 = torch.ops.aten.clone.default(transpose_int_316, memory_format = torch.contiguous_format);  transpose_int_316 = None
        _unsafe_view_default_110 = torch.ops.aten._unsafe_view.default(clone_default_182, [8, 128, 1024]);  clone_default_182 = None
        view_default_911 = torch.ops.aten.view.default(_unsafe_view_default_110, [1024, 1024]);  _unsafe_view_default_110 = None
        t_default_548 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_214 = torch.ops.aten.mm.default(view_default_911, t_default_548);  t_default_548 = None
        t_default_549 = torch.ops.aten.t.default(view_default_911)
        mm_default_215 = torch.ops.aten.mm.default(t_default_549, view_default_45);  t_default_549 = view_default_45 = None
        t_default_550 = torch.ops.aten.t.default(mm_default_215);  mm_default_215 = None
        sum_dim_int_list_107 = torch.ops.aten.sum.dim_IntList(view_default_911, [0], True);  view_default_911 = None
        view_default_912 = torch.ops.aten.view.default(sum_dim_int_list_107, [1024]);  sum_dim_int_list_107 = None
        t_default_551 = torch.ops.aten.t.default(t_default_550);  t_default_550 = None
        view_default_913 = torch.ops.aten.view.default(mm_default_214, [8, 128, 1024]);  mm_default_214 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(getitem_207, view_default_913);  getitem_207 = view_default_913 = None
        transpose_int_317 = torch.ops.aten.transpose.int(add_tensor_201, 1, 2);  add_tensor_201 = None
        clone_default_183 = torch.ops.aten.clone.default(transpose_int_317, memory_format = torch.contiguous_format);  transpose_int_317 = None
        _unsafe_view_default_111 = torch.ops.aten._unsafe_view.default(clone_default_183, [8, 128, 1024]);  clone_default_183 = None
        view_default_914 = torch.ops.aten.view.default(_unsafe_view_default_111, [1024, 1024]);  _unsafe_view_default_111 = None
        t_default_552 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_216 = torch.ops.aten.mm.default(view_default_914, t_default_552);  t_default_552 = None
        t_default_553 = torch.ops.aten.t.default(view_default_914)
        mm_default_217 = torch.ops.aten.mm.default(t_default_553, view_default_42);  t_default_553 = view_default_42 = None
        t_default_554 = torch.ops.aten.t.default(mm_default_217);  mm_default_217 = None
        sum_dim_int_list_108 = torch.ops.aten.sum.dim_IntList(view_default_914, [0], True);  view_default_914 = None
        view_default_915 = torch.ops.aten.view.default(sum_dim_int_list_108, [1024]);  sum_dim_int_list_108 = None
        t_default_555 = torch.ops.aten.t.default(t_default_554);  t_default_554 = None
        view_default_916 = torch.ops.aten.view.default(mm_default_216, [8, 128, 1024]);  mm_default_216 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(add_tensor_202, view_default_916);  add_tensor_202 = view_default_916 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(_unsafe_view_default_109, 0.125);  _unsafe_view_default_109 = None
        view_default_917 = torch.ops.aten.view.default(mul_tensor_123, [1024, 1024]);  mul_tensor_123 = None
        t_default_556 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_218 = torch.ops.aten.mm.default(view_default_917, t_default_556);  t_default_556 = None
        t_default_557 = torch.ops.aten.t.default(view_default_917)
        mm_default_219 = torch.ops.aten.mm.default(t_default_557, view_default_40);  t_default_557 = view_default_40 = None
        t_default_558 = torch.ops.aten.t.default(mm_default_219);  mm_default_219 = None
        sum_dim_int_list_109 = torch.ops.aten.sum.dim_IntList(view_default_917, [0], True);  view_default_917 = None
        view_default_918 = torch.ops.aten.view.default(sum_dim_int_list_109, [1024]);  sum_dim_int_list_109 = None
        t_default_559 = torch.ops.aten.t.default(t_default_558);  t_default_558 = None
        view_default_919 = torch.ops.aten.view.default(mm_default_218, [8, 128, 1024]);  mm_default_218 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(add_tensor_203, view_default_919);  add_tensor_203 = view_default_919 = None
        native_layer_norm_backward_default_33 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_204, add_tensor_7, [1024], getitem_10, getitem_11, primals_20, primals_19, [True, True, True]);  add_tensor_204 = add_tensor_7 = getitem_10 = getitem_11 = primals_20 = primals_19 = None
        getitem_210 = native_layer_norm_backward_default_33[0]
        getitem_211 = native_layer_norm_backward_default_33[1]
        getitem_212 = native_layer_norm_backward_default_33[2];  native_layer_norm_backward_default_33 = None
        view_default_920 = torch.ops.aten.view.default(getitem_210, [1024, 1024])
        t_default_560 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_220 = torch.ops.aten.mm.default(view_default_920, t_default_560);  t_default_560 = None
        t_default_561 = torch.ops.aten.t.default(view_default_920)
        mm_default_221 = torch.ops.aten.mm.default(t_default_561, view_default_38);  t_default_561 = view_default_38 = None
        t_default_562 = torch.ops.aten.t.default(mm_default_221);  mm_default_221 = None
        sum_dim_int_list_110 = torch.ops.aten.sum.dim_IntList(view_default_920, [0], True);  view_default_920 = None
        view_default_921 = torch.ops.aten.view.default(sum_dim_int_list_110, [1024]);  sum_dim_int_list_110 = None
        t_default_563 = torch.ops.aten.t.default(t_default_562);  t_default_562 = None
        view_default_922 = torch.ops.aten.view.default(mm_default_220, [8, 128, 4096]);  mm_default_220 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_922, torch.float32);  view_default_922 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_37, torch.float32);  view_default_37 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_124);  mul_tensor_124 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(add_tensor_205, 0.5);  add_tensor_205 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_127 = torch.ops.aten.mul.Tensor(mul_tensor_126, -0.5);  mul_tensor_126 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_127);  mul_tensor_127 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_128);  to_dtype_34 = mul_tensor_128 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(mul_tensor_125, mul_tensor_129);  mul_tensor_125 = mul_tensor_129 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_206);  to_dtype_33 = add_tensor_206 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_130, torch.float32);  mul_tensor_130 = None
        view_default_923 = torch.ops.aten.view.default(to_dtype_35, [1024, 4096]);  to_dtype_35 = None
        t_default_564 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_222 = torch.ops.aten.mm.default(view_default_923, t_default_564);  t_default_564 = None
        t_default_565 = torch.ops.aten.t.default(view_default_923)
        mm_default_223 = torch.ops.aten.mm.default(t_default_565, view_default_36);  t_default_565 = view_default_36 = None
        t_default_566 = torch.ops.aten.t.default(mm_default_223);  mm_default_223 = None
        sum_dim_int_list_111 = torch.ops.aten.sum.dim_IntList(view_default_923, [0], True);  view_default_923 = None
        view_default_924 = torch.ops.aten.view.default(sum_dim_int_list_111, [4096]);  sum_dim_int_list_111 = None
        t_default_567 = torch.ops.aten.t.default(t_default_566);  t_default_566 = None
        view_default_925 = torch.ops.aten.view.default(mm_default_222, [8, 128, 1024]);  mm_default_222 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(getitem_210, view_default_925);  getitem_210 = view_default_925 = None
        native_layer_norm_backward_default_34 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_207, add_tensor_6, [1024], getitem_7, getitem_8, primals_8, primals_7, [True, True, True]);  add_tensor_207 = add_tensor_6 = getitem_7 = getitem_8 = primals_8 = primals_7 = None
        getitem_213 = native_layer_norm_backward_default_34[0]
        getitem_214 = native_layer_norm_backward_default_34[1]
        getitem_215 = native_layer_norm_backward_default_34[2];  native_layer_norm_backward_default_34 = None
        view_default_926 = torch.ops.aten.view.default(getitem_213, [1024, 1024])
        t_default_568 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_224 = torch.ops.aten.mm.default(view_default_926, t_default_568);  t_default_568 = None
        t_default_569 = torch.ops.aten.t.default(view_default_926)
        mm_default_225 = torch.ops.aten.mm.default(t_default_569, view_default_34);  t_default_569 = view_default_34 = None
        t_default_570 = torch.ops.aten.t.default(mm_default_225);  mm_default_225 = None
        sum_dim_int_list_112 = torch.ops.aten.sum.dim_IntList(view_default_926, [0], True);  view_default_926 = None
        view_default_927 = torch.ops.aten.view.default(sum_dim_int_list_112, [1024]);  sum_dim_int_list_112 = None
        t_default_571 = torch.ops.aten.t.default(t_default_570);  t_default_570 = None
        view_default_928 = torch.ops.aten.view.default(mm_default_224, [8, 128, 1024]);  mm_default_224 = None
        view_default_929 = torch.ops.aten.view.default(view_default_928, [8, 128, 16, 64]);  view_default_928 = None
        transpose_int_318 = torch.ops.aten.transpose.int(view_default_929, 1, 2);  view_default_929 = None
        clone_default_184 = torch.ops.aten.clone.default(transpose_int_318, memory_format = torch.contiguous_format);  transpose_int_318 = None
        _unsafe_view_default_112 = torch.ops.aten._unsafe_view.default(clone_default_184, [128, 128, 64]);  clone_default_184 = None
        transpose_int_319 = torch.ops.aten.transpose.int(_softmax_default_1, 1, 2)
        bmm_default_136 = torch.ops.aten.bmm.default(transpose_int_319, _unsafe_view_default_112);  transpose_int_319 = None
        transpose_int_320 = torch.ops.aten.transpose.int(view_default_30, 1, 2);  view_default_30 = None
        bmm_default_137 = torch.ops.aten.bmm.default(_unsafe_view_default_112, transpose_int_320);  _unsafe_view_default_112 = transpose_int_320 = None
        _softmax_backward_data_default_22 = torch.ops.aten._softmax_backward_data.default(bmm_default_137, _softmax_default_1, -1, torch.float32);  bmm_default_137 = _softmax_default_1 = None
        view_default_930 = torch.ops.aten.view.default(_softmax_backward_data_default_22, [8, 16, 128, 1024]);  _softmax_backward_data_default_22 = None
        view_default_931 = torch.ops.aten.view.default(view_default_930, [128, 128, 1024]);  view_default_930 = None
        transpose_int_321 = torch.ops.aten.transpose.int(view_default_28, 1, 2);  view_default_28 = None
        bmm_default_138 = torch.ops.aten.bmm.default(transpose_int_321, view_default_931);  transpose_int_321 = None
        transpose_int_322 = torch.ops.aten.transpose.int(transpose_int_8, 1, 2);  transpose_int_8 = None
        bmm_default_139 = torch.ops.aten.bmm.default(view_default_931, transpose_int_322);  view_default_931 = transpose_int_322 = None
        transpose_int_323 = torch.ops.aten.transpose.int(bmm_default_138, 1, 2);  bmm_default_138 = None
        view_default_932 = torch.ops.aten.view.default(bmm_default_136, [8, 16, 1024, 64]);  bmm_default_136 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(tangents_5, view_default_932);  tangents_5 = view_default_932 = None
        view_default_933 = torch.ops.aten.view.default(transpose_int_323, [8, 16, 1024, 64]);  transpose_int_323 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(tangents_4, view_default_933);  tangents_4 = view_default_933 = None
        view_default_934 = torch.ops.aten.view.default(bmm_default_139, [8, 16, 128, 64]);  bmm_default_139 = None
        transpose_int_324 = torch.ops.aten.transpose.int(view_default_934, 1, 2);  view_default_934 = None
        clone_default_185 = torch.ops.aten.clone.default(transpose_int_324, memory_format = torch.contiguous_format);  transpose_int_324 = None
        _unsafe_view_default_113 = torch.ops.aten._unsafe_view.default(clone_default_185, [8, 128, 1024]);  clone_default_185 = None
        transpose_int_325 = torch.ops.aten.transpose.int(add_tensor_208, 1, 2);  add_tensor_208 = None
        clone_default_186 = torch.ops.aten.clone.default(transpose_int_325, memory_format = torch.contiguous_format);  transpose_int_325 = None
        _unsafe_view_default_114 = torch.ops.aten._unsafe_view.default(clone_default_186, [8, 1024, 1024]);  clone_default_186 = None
        view_default_935 = torch.ops.aten.view.default(_unsafe_view_default_114, [8192, 1024]);  _unsafe_view_default_114 = None
        t_default_572 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_226 = torch.ops.aten.mm.default(view_default_935, t_default_572);  t_default_572 = None
        t_default_573 = torch.ops.aten.t.default(view_default_935)
        mm_default_227 = torch.ops.aten.mm.default(t_default_573, view_default_24);  t_default_573 = view_default_24 = None
        t_default_574 = torch.ops.aten.t.default(mm_default_227);  mm_default_227 = None
        sum_dim_int_list_113 = torch.ops.aten.sum.dim_IntList(view_default_935, [0], True);  view_default_935 = None
        view_default_936 = torch.ops.aten.view.default(sum_dim_int_list_113, [1024]);  sum_dim_int_list_113 = None
        t_default_575 = torch.ops.aten.t.default(t_default_574);  t_default_574 = None
        view_default_937 = torch.ops.aten.view.default(mm_default_226, [8, 1024, 1024]);  mm_default_226 = None
        add_tensor_210 = torch.ops.aten.add.Tensor(add_tensor_198, view_default_937);  add_tensor_198 = view_default_937 = None
        transpose_int_326 = torch.ops.aten.transpose.int(add_tensor_209, 1, 2);  add_tensor_209 = None
        clone_default_187 = torch.ops.aten.clone.default(transpose_int_326, memory_format = torch.contiguous_format);  transpose_int_326 = None
        _unsafe_view_default_115 = torch.ops.aten._unsafe_view.default(clone_default_187, [8, 1024, 1024]);  clone_default_187 = None
        view_default_938 = torch.ops.aten.view.default(_unsafe_view_default_115, [8192, 1024]);  _unsafe_view_default_115 = None
        t_default_576 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_228 = torch.ops.aten.mm.default(view_default_938, t_default_576);  t_default_576 = None
        t_default_577 = torch.ops.aten.t.default(view_default_938)
        mm_default_229 = torch.ops.aten.mm.default(t_default_577, view_default_21);  t_default_577 = view_default_21 = None
        t_default_578 = torch.ops.aten.t.default(mm_default_229);  mm_default_229 = None
        sum_dim_int_list_114 = torch.ops.aten.sum.dim_IntList(view_default_938, [0], True);  view_default_938 = None
        view_default_939 = torch.ops.aten.view.default(sum_dim_int_list_114, [1024]);  sum_dim_int_list_114 = None
        t_default_579 = torch.ops.aten.t.default(t_default_578);  t_default_578 = None
        view_default_940 = torch.ops.aten.view.default(mm_default_228, [8, 1024, 1024]);  mm_default_228 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(add_tensor_210, view_default_940);  add_tensor_210 = view_default_940 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(_unsafe_view_default_113, 0.125);  _unsafe_view_default_113 = None
        view_default_941 = torch.ops.aten.view.default(mul_tensor_131, [1024, 1024]);  mul_tensor_131 = None
        t_default_580 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_230 = torch.ops.aten.mm.default(view_default_941, t_default_580);  t_default_580 = None
        t_default_581 = torch.ops.aten.t.default(view_default_941)
        mm_default_231 = torch.ops.aten.mm.default(t_default_581, view_default_19);  t_default_581 = view_default_19 = None
        t_default_582 = torch.ops.aten.t.default(mm_default_231);  mm_default_231 = None
        sum_dim_int_list_115 = torch.ops.aten.sum.dim_IntList(view_default_941, [0], True);  view_default_941 = None
        view_default_942 = torch.ops.aten.view.default(sum_dim_int_list_115, [1024]);  sum_dim_int_list_115 = None
        t_default_583 = torch.ops.aten.t.default(t_default_582);  t_default_582 = None
        view_default_943 = torch.ops.aten.view.default(mm_default_230, [8, 128, 1024]);  mm_default_230 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(getitem_213, view_default_943);  getitem_213 = view_default_943 = None
        native_layer_norm_backward_default_35 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_212, add_tensor_4, [1024], getitem_4, getitem_5, primals_24, primals_23, [True, True, True]);  add_tensor_212 = add_tensor_4 = getitem_4 = getitem_5 = primals_24 = primals_23 = None
        getitem_216 = native_layer_norm_backward_default_35[0]
        getitem_217 = native_layer_norm_backward_default_35[1]
        getitem_218 = native_layer_norm_backward_default_35[2];  native_layer_norm_backward_default_35 = None
        view_default_944 = torch.ops.aten.view.default(getitem_216, [1024, 1024])
        t_default_584 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_232 = torch.ops.aten.mm.default(view_default_944, t_default_584);  t_default_584 = None
        t_default_585 = torch.ops.aten.t.default(view_default_944)
        mm_default_233 = torch.ops.aten.mm.default(t_default_585, view_default_17);  t_default_585 = view_default_17 = None
        t_default_586 = torch.ops.aten.t.default(mm_default_233);  mm_default_233 = None
        sum_dim_int_list_116 = torch.ops.aten.sum.dim_IntList(view_default_944, [0], True);  view_default_944 = None
        view_default_945 = torch.ops.aten.view.default(sum_dim_int_list_116, [1024]);  sum_dim_int_list_116 = None
        t_default_587 = torch.ops.aten.t.default(t_default_586);  t_default_586 = None
        view_default_946 = torch.ops.aten.view.default(mm_default_232, [8, 128, 1024]);  mm_default_232 = None
        view_default_947 = torch.ops.aten.view.default(view_default_946, [8, 128, 16, 64]);  view_default_946 = None
        transpose_int_327 = torch.ops.aten.transpose.int(view_default_947, 1, 2);  view_default_947 = None
        clone_default_188 = torch.ops.aten.clone.default(transpose_int_327, memory_format = torch.contiguous_format);  transpose_int_327 = None
        _unsafe_view_default_116 = torch.ops.aten._unsafe_view.default(clone_default_188, [128, 128, 64]);  clone_default_188 = None
        transpose_int_328 = torch.ops.aten.transpose.int(_softmax_default, 1, 2)
        bmm_default_140 = torch.ops.aten.bmm.default(transpose_int_328, _unsafe_view_default_116);  transpose_int_328 = None
        transpose_int_329 = torch.ops.aten.transpose.int(view_default_13, 1, 2);  view_default_13 = None
        bmm_default_141 = torch.ops.aten.bmm.default(_unsafe_view_default_116, transpose_int_329);  _unsafe_view_default_116 = transpose_int_329 = None
        _softmax_backward_data_default_23 = torch.ops.aten._softmax_backward_data.default(bmm_default_141, _softmax_default, -1, torch.float32);  bmm_default_141 = _softmax_default = None
        view_default_948 = torch.ops.aten.view.default(_softmax_backward_data_default_23, [8, 16, 128, 128]);  _softmax_backward_data_default_23 = None
        view_default_949 = torch.ops.aten.view.default(view_default_948, [128, 128, 128]);  view_default_948 = None
        transpose_int_330 = torch.ops.aten.transpose.int(view_default_11, 1, 2);  view_default_11 = None
        bmm_default_142 = torch.ops.aten.bmm.default(transpose_int_330, view_default_949);  transpose_int_330 = None
        transpose_int_331 = torch.ops.aten.transpose.int(transpose_int_3, 1, 2);  transpose_int_3 = None
        bmm_default_143 = torch.ops.aten.bmm.default(view_default_949, transpose_int_331);  view_default_949 = transpose_int_331 = None
        transpose_int_332 = torch.ops.aten.transpose.int(bmm_default_142, 1, 2);  bmm_default_142 = None
        view_default_950 = torch.ops.aten.view.default(bmm_default_140, [8, 16, 128, 64]);  bmm_default_140 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(tangents_3, view_default_950);  tangents_3 = view_default_950 = None
        view_default_951 = torch.ops.aten.view.default(transpose_int_332, [8, 16, 128, 64]);  transpose_int_332 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(tangents_2, view_default_951);  tangents_2 = view_default_951 = None
        view_default_952 = torch.ops.aten.view.default(bmm_default_143, [8, 16, 128, 64]);  bmm_default_143 = None
        transpose_int_333 = torch.ops.aten.transpose.int(view_default_952, 1, 2);  view_default_952 = None
        clone_default_189 = torch.ops.aten.clone.default(transpose_int_333, memory_format = torch.contiguous_format);  transpose_int_333 = None
        _unsafe_view_default_117 = torch.ops.aten._unsafe_view.default(clone_default_189, [8, 128, 1024]);  clone_default_189 = None
        transpose_int_334 = torch.ops.aten.transpose.int(add_tensor_213, 1, 2);  add_tensor_213 = None
        clone_default_190 = torch.ops.aten.clone.default(transpose_int_334, memory_format = torch.contiguous_format);  transpose_int_334 = None
        _unsafe_view_default_118 = torch.ops.aten._unsafe_view.default(clone_default_190, [8, 128, 1024]);  clone_default_190 = None
        view_default_953 = torch.ops.aten.view.default(_unsafe_view_default_118, [1024, 1024]);  _unsafe_view_default_118 = None
        t_default_588 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_234 = torch.ops.aten.mm.default(view_default_953, t_default_588);  t_default_588 = None
        t_default_589 = torch.ops.aten.t.default(view_default_953)
        mm_default_235 = torch.ops.aten.mm.default(t_default_589, view_default_7);  t_default_589 = view_default_7 = None
        t_default_590 = torch.ops.aten.t.default(mm_default_235);  mm_default_235 = None
        sum_dim_int_list_117 = torch.ops.aten.sum.dim_IntList(view_default_953, [0], True);  view_default_953 = None
        view_default_954 = torch.ops.aten.view.default(sum_dim_int_list_117, [1024]);  sum_dim_int_list_117 = None
        t_default_591 = torch.ops.aten.t.default(t_default_590);  t_default_590 = None
        view_default_955 = torch.ops.aten.view.default(mm_default_234, [8, 128, 1024]);  mm_default_234 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(getitem_216, view_default_955);  getitem_216 = view_default_955 = None
        transpose_int_335 = torch.ops.aten.transpose.int(add_tensor_214, 1, 2);  add_tensor_214 = None
        clone_default_191 = torch.ops.aten.clone.default(transpose_int_335, memory_format = torch.contiguous_format);  transpose_int_335 = None
        _unsafe_view_default_119 = torch.ops.aten._unsafe_view.default(clone_default_191, [8, 128, 1024]);  clone_default_191 = None
        view_default_956 = torch.ops.aten.view.default(_unsafe_view_default_119, [1024, 1024]);  _unsafe_view_default_119 = None
        t_default_592 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_236 = torch.ops.aten.mm.default(view_default_956, t_default_592);  t_default_592 = None
        t_default_593 = torch.ops.aten.t.default(view_default_956)
        mm_default_237 = torch.ops.aten.mm.default(t_default_593, view_default_4);  t_default_593 = view_default_4 = None
        t_default_594 = torch.ops.aten.t.default(mm_default_237);  mm_default_237 = None
        sum_dim_int_list_118 = torch.ops.aten.sum.dim_IntList(view_default_956, [0], True);  view_default_956 = None
        view_default_957 = torch.ops.aten.view.default(sum_dim_int_list_118, [1024]);  sum_dim_int_list_118 = None
        t_default_595 = torch.ops.aten.t.default(t_default_594);  t_default_594 = None
        view_default_958 = torch.ops.aten.view.default(mm_default_236, [8, 128, 1024]);  mm_default_236 = None
        add_tensor_216 = torch.ops.aten.add.Tensor(add_tensor_215, view_default_958);  add_tensor_215 = view_default_958 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(_unsafe_view_default_117, 0.125);  _unsafe_view_default_117 = None
        view_default_959 = torch.ops.aten.view.default(mul_tensor_132, [1024, 1024]);  mul_tensor_132 = None
        t_default_596 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_238 = torch.ops.aten.mm.default(view_default_959, t_default_596);  t_default_596 = None
        t_default_597 = torch.ops.aten.t.default(view_default_959)
        mm_default_239 = torch.ops.aten.mm.default(t_default_597, view_default_2);  t_default_597 = view_default_2 = None
        t_default_598 = torch.ops.aten.t.default(mm_default_239);  mm_default_239 = None
        sum_dim_int_list_119 = torch.ops.aten.sum.dim_IntList(view_default_959, [0], True);  view_default_959 = None
        view_default_960 = torch.ops.aten.view.default(sum_dim_int_list_119, [1024]);  sum_dim_int_list_119 = None
        t_default_599 = torch.ops.aten.t.default(t_default_598);  t_default_598 = None
        view_default_961 = torch.ops.aten.view.default(mm_default_238, [8, 128, 1024]);  mm_default_238 = None
        add_tensor_217 = torch.ops.aten.add.Tensor(add_tensor_216, view_default_961);  add_tensor_216 = view_default_961 = None
        native_layer_norm_backward_default_36 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_217, add_tensor_2, [1024], getitem_1, getitem_2, primals_4, primals_3, [True, True, True]);  add_tensor_217 = add_tensor_2 = getitem_1 = getitem_2 = primals_4 = primals_3 = None
        getitem_219 = native_layer_norm_backward_default_36[0]
        getitem_220 = native_layer_norm_backward_default_36[1]
        getitem_221 = native_layer_norm_backward_default_36[2];  native_layer_norm_backward_default_36 = None
        sum_dim_int_list_120 = torch.ops.aten.sum.dim_IntList(getitem_219, [0], True)
        view_default_962 = torch.ops.aten.view.default(sum_dim_int_list_120, [128, 1024]);  sum_dim_int_list_120 = None
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(view_default_962, add_tensor_1, 1026, -1, False);  view_default_962 = add_tensor_1 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(getitem_219, 1.0);  getitem_219 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(mul_tensor_133, view_default, 50265, 1, False);  mul_tensor_133 = view_default = None
        return [embedding_dense_backward_default, embedding_dense_backward_default_1, getitem_221, getitem_220, view_default_939, t_default_579, getitem_215, getitem_214, view_default_927, t_default_571, view_default_942, t_default_583, view_default_936, t_default_575, view_default_924, t_default_567, view_default_921, t_default_563, getitem_212, getitem_211, view_default_957, t_default_595, getitem_218, getitem_217, view_default_945, t_default_587, view_default_960, t_default_599, view_default_954, t_default_591, view_default_519, t_default_179, getitem_125, getitem_124, view_default_507, t_default_171, view_default_522, t_default_183, view_default_516, t_default_175, view_default_504, t_default_167, view_default_501, t_default_163, getitem_122, getitem_121, view_default_537, t_default_195, getitem_128, getitem_127, view_default_525, t_default_187, view_default_540, t_default_199, view_default_534, t_default_191, view_default_477, t_default_139, getitem_116, getitem_115, view_default_465, t_default_131, view_default_480, t_default_143, view_default_474, t_default_135, view_default_462, t_default_127, view_default_459, t_default_123, getitem_113, getitem_112, view_default_495, t_default_155, getitem_119, getitem_118, view_default_483, t_default_147, view_default_498, t_default_159, view_default_492, t_default_151, view_default_897, t_default_539, getitem_206, getitem_205, view_default_885, t_default_531, view_default_900, t_default_543, view_default_894, t_default_535, view_default_882, t_default_527, view_default_879, t_default_523, getitem_203, getitem_202, view_default_915, t_default_555, getitem_209, getitem_208, view_default_903, t_default_547, view_default_918, t_default_559, view_default_912, t_default_551, view_default_855, t_default_499, getitem_197, getitem_196, view_default_843, t_default_491, view_default_858, t_default_503, view_default_852, t_default_495, view_default_840, t_default_487, view_default_837, t_default_483, getitem_194, getitem_193, view_default_873, t_default_515, getitem_200, getitem_199, view_default_861, t_default_507, view_default_876, t_default_519, view_default_870, t_default_511, view_default_813, t_default_459, getitem_188, getitem_187, view_default_801, t_default_451, view_default_816, t_default_463, view_default_810, t_default_455, view_default_798, t_default_447, view_default_795, t_default_443, getitem_185, getitem_184, view_default_831, t_default_475, getitem_191, getitem_190, view_default_819, t_default_467, view_default_834, t_default_479, view_default_828, t_default_471, view_default_771, t_default_419, getitem_179, getitem_178, view_default_759, t_default_411, view_default_774, t_default_423, view_default_768, t_default_415, view_default_756, t_default_407, view_default_753, t_default_403, getitem_176, getitem_175, view_default_789, t_default_435, getitem_182, getitem_181, view_default_777, t_default_427, view_default_792, t_default_439, view_default_786, t_default_431, view_default_729, t_default_379, getitem_170, getitem_169, view_default_717, t_default_371, view_default_732, t_default_383, view_default_726, t_default_375, view_default_714, t_default_367, view_default_711, t_default_363, getitem_167, getitem_166, view_default_747, t_default_395, getitem_173, getitem_172, view_default_735, t_default_387, view_default_750, t_default_399, view_default_744, t_default_391, view_default_687, t_default_339, getitem_161, getitem_160, view_default_675, t_default_331, view_default_690, t_default_343, view_default_684, t_default_335, view_default_672, t_default_327, view_default_669, t_default_323, getitem_158, getitem_157, view_default_705, t_default_355, getitem_164, getitem_163, view_default_693, t_default_347, view_default_708, t_default_359, view_default_702, t_default_351, view_default_645, t_default_299, getitem_152, getitem_151, view_default_633, t_default_291, view_default_648, t_default_303, view_default_642, t_default_295, view_default_630, t_default_287, view_default_627, t_default_283, getitem_149, getitem_148, view_default_663, t_default_315, getitem_155, getitem_154, view_default_651, t_default_307, view_default_666, t_default_319, view_default_660, t_default_311, view_default_603, t_default_259, getitem_143, getitem_142, view_default_591, t_default_251, view_default_606, t_default_263, view_default_600, t_default_255, view_default_588, t_default_247, view_default_585, t_default_243, getitem_140, getitem_139, view_default_621, t_default_275, getitem_146, getitem_145, view_default_609, t_default_267, view_default_624, t_default_279, view_default_618, t_default_271, view_default_561, t_default_219, getitem_134, getitem_133, view_default_549, t_default_211, view_default_564, t_default_223, view_default_558, t_default_215, view_default_546, t_default_207, view_default_543, t_default_203, getitem_131, getitem_130, view_default_579, t_default_235, getitem_137, getitem_136, view_default_567, t_default_227, view_default_582, t_default_239, view_default_576, t_default_231, None, add_tensor_211, None]
        
