
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/BartForConditionalGeneration_bart/BartForConditionalGeneration_bart_backward_1/state_dict.pt'))

    
    
    def forward(self, t_default_39, getitem_40, view_default_144, view_default_230, view_default_232, getitem_71, t_default_40, view_default_229, getitem_41, t_default_41, transpose_int_3, view_default_142, t_default_70, view_default_145, getitem_70, add_tensor_34, _softmax_default_6, t_default_65, getitem_32, getitem_62, view_default_10, view_default_157, add_tensor_25, getitem_61, view_default_148, getitem_43, t_default_47, view_default_27, view_default_104, getitem_44, t_default_29, getitem_49, t_default_37, view_default_169, view_default_150, getitem_50, t_default_61, t_default_42, view_default_159, add_tensor_22, view_default_213, t_default_43, getitem_31, view_default_167, transpose_int_33, t_default_48, t_default_8, view_default_171, view_default_146, t_default_49, add_tensor_28, t_default_60, t_default_38, t_default_44, t_default_28, getitem_29, view_default_174, view_default_132, view_default_138, view_default_178, add_tensor_21, view_default_103, add_tensor_16, t_default_50, view_default_106, getitem_7, add_tensor_31, t_default_6, getitem_58, primals_189, getitem_26, primals_77, getitem_8, primals_157, add_tensor_4, t_default_5, view_default_211, t_default_9, view_default_45, primals_158, t_default_26, view_default_39, view_default_190, view_default_20, t_default_7, view_default_94, view_default_48, view_default_31, view_default_52, view_default_209, view_default_207, view_default_12, view_default_90, t_default_58, view_default, t_default_14, view_default_33, t_default_25, getitem_56, getitem_59, view_default_19, getitem_55, primals_190, primals_73, add_tensor_6, view_default_208, t_default_24, primals_74, t_default_59, transpose_int_8, view_default_24, _softmax_default_1, view_default_37, view_default_22, primals_78, t_default_13, t_default_4, view_default_87, t_default_10, add_tensor_12, view_default_187, transpose_int_18, t_default_11, getitem_35, view_default_81, t_default_53, getitem_14, primals_169, view_default_6, t_default_15, t_default_1, t_default_21, add_tensor_7, add_tensor_3, _softmax_default, getitem_13, _softmax_default_5, view_default_16, view_default_41, view_default_79, view_default_117, view_default_121, transpose_int_28, add_tensor_18, primals_90, primals_170, t_default_3, primals_89, primals_173, t_default_12, view_default_123, view_default_43, view_default_75, getitem_34, getitem_10, view_default_153, view_default_40, _softmax_default_3, t_default_33, getitem_11, view_default_241, view_default_82, t_default_23, getitem_67, primals_61, primals_153, transpose_int_38, add_tensor_19, _softmax_default_7, t_default_63, getitem_37, getitem_38, getitem_64, view_default_129, primals_46, primals_41, view_default_85, t_default_66, view_default_163, t_default_35, add_tensor_13, view_default_127, primals_62, view_default_234, primals_154, view_default_125, t_default_68, primals_138, view_default_188, primals_137, primals_141, t_default_22, t_default_45, t_default_67, getitem_65, view_default_228, getitem_46, getitem_23, view_default_165, primals_58, view_default_83, getitem_47, getitem_5, add_tensor_24, primals_105, getitem_25, view_default_124, getitem_22, primals_45, t_default_34, t_default_64, primals_110, t_default_2, primals_109, view_default_237, primals_142, t_default_46, primals_106, primals_42, t_default_36, primals_57, add_tensor_33, view_default_166, transpose_int_53, _softmax_default_8, primals_174, add_tensor_30, t_default_55, view_default_96, view_default_201, view_default_100, view_default_226, view_default_216, _softmax_default_9, view_default_180, getitem_2, transpose_int_43, primals_186, add_tensor_1, view_default_195, t_default, getitem_28, view_default_192, view_default_184, t_default_54, view_default_199, view_default_136, primals_185, t_default_51, view_default_222, view_default_1, getitem_53, transpose_int_48, _softmax_default_4, view_default_205, t_default_27, getitem_1, transpose_int_23, add_tensor_15, view_default_102, add_tensor_27, t_default_57, t_default_56, _softmax_default_10, view_default_3, getitem_52, t_default_62, view_default_220, t_default_52, view_default_186, getitem_4, getitem_16, add_tensor_36, t_default_19, primals_126, getitem_73, view_default_69, transpose_int_58, _softmax_default_11, getitem_19, t_default_18, primals_94, view_default_64, add_tensor_37, primals_121, view_default_249, t_default_69, getitem_74, getitem_17, view_default_251, view_default_62, view_default_243, view_default_250, primals_93, getitem_20, t_default_17, add_tensor, t_default_16, primals_125, view_default_66, view_default_61, t_default_71, view_default_247, primals_122, add_tensor_10, view_default_73, t_default_20, view_default_58, transpose_int_13, view_default_54, primals_4, view_default_60, view_default_111, primals_14, primals_3, _softmax_default_2, view_default_115, primals_25, primals_26, add_tensor_9, t_default_32, t_default_30, primals_30, primals_29, primals_10, t_default_31, primals_9, view_default_108, getitem_68, view_default_18, primals_13, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_37, [1024], getitem_73, getitem_74, primals_42, primals_41, [True, True, True]);  tangents_1 = add_tensor_37 = getitem_73 = getitem_74 = primals_42 = primals_41 = None
        getitem_75 = native_layer_norm_backward_default[0]
        getitem_76 = native_layer_norm_backward_default[1]
        getitem_77 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_253 = torch.ops.aten.view.default(getitem_75, [8192, 1024])
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default = torch.ops.aten.mm.default(view_default_253, t_default_72);  t_default_72 = None
        t_default_73 = torch.ops.aten.t.default(view_default_253)
        mm_default_1 = torch.ops.aten.mm.default(t_default_73, view_default_251);  t_default_73 = view_default_251 = None
        t_default_74 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_253, [0], True);  view_default_253 = None
        view_default_254 = torch.ops.aten.view.default(sum_dim_int_list, [1024]);  sum_dim_int_list = None
        t_default_75 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        view_default_255 = torch.ops.aten.view.default(mm_default, [8, 1024, 4096]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_255, torch.float32);  view_default_255 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_250, torch.float32);  view_default_250 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_13);  mul_tensor_13 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(add_tensor_38, 0.5);  add_tensor_38 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_16 = torch.ops.aten.mul.Tensor(mul_tensor_15, -0.5);  mul_tensor_15 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_16);  mul_tensor_16 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_17);  to_dtype_1 = mul_tensor_17 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_14, mul_tensor_18);  mul_tensor_14 = mul_tensor_18 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_39);  to_dtype = add_tensor_39 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_19, torch.float32);  mul_tensor_19 = None
        view_default_256 = torch.ops.aten.view.default(to_dtype_2, [8192, 4096]);  to_dtype_2 = None
        t_default_76 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_256, t_default_76);  t_default_76 = None
        t_default_77 = torch.ops.aten.t.default(view_default_256)
        mm_default_3 = torch.ops.aten.mm.default(t_default_77, view_default_249);  t_default_77 = view_default_249 = None
        t_default_78 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_256, [0], True);  view_default_256 = None
        view_default_257 = torch.ops.aten.view.default(sum_dim_int_list_1, [4096]);  sum_dim_int_list_1 = None
        t_default_79 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        view_default_258 = torch.ops.aten.view.default(mm_default_2, [8, 1024, 1024]);  mm_default_2 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_75, view_default_258);  getitem_75 = view_default_258 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_40, add_tensor_36, [1024], getitem_70, getitem_71, primals_46, primals_45, [True, True, True]);  add_tensor_40 = add_tensor_36 = getitem_70 = getitem_71 = primals_46 = primals_45 = None
        getitem_78 = native_layer_norm_backward_default_1[0]
        getitem_79 = native_layer_norm_backward_default_1[1]
        getitem_80 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_259 = torch.ops.aten.view.default(getitem_78, [8192, 1024])
        t_default_80 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_259, t_default_80);  t_default_80 = None
        t_default_81 = torch.ops.aten.t.default(view_default_259)
        mm_default_5 = torch.ops.aten.mm.default(t_default_81, view_default_247);  t_default_81 = view_default_247 = None
        t_default_82 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_259, [0], True);  view_default_259 = None
        view_default_260 = torch.ops.aten.view.default(sum_dim_int_list_2, [1024]);  sum_dim_int_list_2 = None
        t_default_83 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        view_default_261 = torch.ops.aten.view.default(mm_default_4, [8, 1024, 1024]);  mm_default_4 = None
        view_default_262 = torch.ops.aten.view.default(view_default_261, [8, 1024, 16, 64]);  view_default_261 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_262, 1, 2);  view_default_262 = None
        clone_default_48 = torch.ops.aten.clone.default(transpose_int_60, memory_format = torch.contiguous_format);  transpose_int_60 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_48, [128, 1024, 64]);  clone_default_48 = None
        transpose_int_61 = torch.ops.aten.transpose.int(_softmax_default_11, 1, 2)
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_61, _unsafe_view_default_12);  transpose_int_61 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_243, 1, 2);  view_default_243 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_unsafe_view_default_12, transpose_int_62);  _unsafe_view_default_12 = transpose_int_62 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(bmm_default_25, _softmax_default_11, -1, torch.float32);  bmm_default_25 = _softmax_default_11 = None
        view_default_263 = torch.ops.aten.view.default(_softmax_backward_data_default, [8, 16, 1024, 1024]);  _softmax_backward_data_default = None
        view_default_264 = torch.ops.aten.view.default(view_default_263, [128, 1024, 1024]);  view_default_263 = None
        transpose_int_63 = torch.ops.aten.transpose.int(view_default_241, 1, 2);  view_default_241 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_63, view_default_264);  transpose_int_63 = None
        transpose_int_64 = torch.ops.aten.transpose.int(transpose_int_58, 1, 2);  transpose_int_58 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_264, transpose_int_64);  view_default_264 = transpose_int_64 = None
        transpose_int_65 = torch.ops.aten.transpose.int(bmm_default_26, 1, 2);  bmm_default_26 = None
        view_default_265 = torch.ops.aten.view.default(bmm_default_24, [8, 16, 1024, 64]);  bmm_default_24 = None
        view_default_266 = torch.ops.aten.view.default(transpose_int_65, [8, 16, 1024, 64]);  transpose_int_65 = None
        view_default_267 = torch.ops.aten.view.default(bmm_default_27, [8, 16, 1024, 64]);  bmm_default_27 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_267, 1, 2);  view_default_267 = None
        clone_default_49 = torch.ops.aten.clone.default(transpose_int_66, memory_format = torch.contiguous_format);  transpose_int_66 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_49, [8, 1024, 1024]);  clone_default_49 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_265, 1, 2);  view_default_265 = None
        clone_default_50 = torch.ops.aten.clone.default(transpose_int_67, memory_format = torch.contiguous_format);  transpose_int_67 = None
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(clone_default_50, [8, 1024, 1024]);  clone_default_50 = None
        view_default_268 = torch.ops.aten.view.default(_unsafe_view_default_14, [8192, 1024]);  _unsafe_view_default_14 = None
        t_default_84 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_268, t_default_84);  t_default_84 = None
        t_default_85 = torch.ops.aten.t.default(view_default_268)
        mm_default_7 = torch.ops.aten.mm.default(t_default_85, view_default_237);  t_default_85 = view_default_237 = None
        t_default_86 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_268, [0], True);  view_default_268 = None
        view_default_269 = torch.ops.aten.view.default(sum_dim_int_list_3, [1024]);  sum_dim_int_list_3 = None
        t_default_87 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        view_default_270 = torch.ops.aten.view.default(mm_default_6, [8, 1024, 1024]);  mm_default_6 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_78, view_default_270);  getitem_78 = view_default_270 = None
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_266, 1, 2);  view_default_266 = None
        view_default_271 = torch.ops.aten.view.default(transpose_int_68, [8, 1024, 1024]);  transpose_int_68 = None
        clone_default_51 = torch.ops.aten.clone.default(view_default_271, memory_format = torch.contiguous_format);  view_default_271 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_51, [8192, 1024]);  clone_default_51 = None
        t_default_88 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_8 = torch.ops.aten.mm.default(_unsafe_view_default_15, t_default_88);  t_default_88 = None
        t_default_89 = torch.ops.aten.t.default(_unsafe_view_default_15)
        mm_default_9 = torch.ops.aten.mm.default(t_default_89, view_default_234);  t_default_89 = view_default_234 = None
        t_default_90 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_15, [0], True);  _unsafe_view_default_15 = None
        view_default_272 = torch.ops.aten.view.default(sum_dim_int_list_4, [1024]);  sum_dim_int_list_4 = None
        t_default_91 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        view_default_273 = torch.ops.aten.view.default(mm_default_8, [8, 1024, 1024]);  mm_default_8 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, view_default_273);  add_tensor_41 = view_default_273 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(_unsafe_view_default_13, 0.125);  _unsafe_view_default_13 = None
        view_default_274 = torch.ops.aten.view.default(mul_tensor_20, [8192, 1024]);  mul_tensor_20 = None
        t_default_92 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_274, t_default_92);  t_default_92 = None
        t_default_93 = torch.ops.aten.t.default(view_default_274)
        mm_default_11 = torch.ops.aten.mm.default(t_default_93, view_default_232);  t_default_93 = view_default_232 = None
        t_default_94 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_274, [0], True);  view_default_274 = None
        view_default_275 = torch.ops.aten.view.default(sum_dim_int_list_5, [1024]);  sum_dim_int_list_5 = None
        t_default_95 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        view_default_276 = torch.ops.aten.view.default(mm_default_10, [8, 1024, 1024]);  mm_default_10 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_42, view_default_276);  add_tensor_42 = view_default_276 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_43, add_tensor_34, [1024], getitem_67, getitem_68, primals_26, primals_25, [True, True, True]);  add_tensor_43 = add_tensor_34 = getitem_67 = getitem_68 = primals_26 = primals_25 = None
        getitem_81 = native_layer_norm_backward_default_2[0]
        getitem_82 = native_layer_norm_backward_default_2[1]
        getitem_83 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_277 = torch.ops.aten.view.default(getitem_81, [8192, 1024])
        t_default_96 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_277, t_default_96);  t_default_96 = None
        t_default_97 = torch.ops.aten.t.default(view_default_277)
        mm_default_13 = torch.ops.aten.mm.default(t_default_97, view_default_230);  t_default_97 = view_default_230 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_277, [0], True);  view_default_277 = None
        view_default_278 = torch.ops.aten.view.default(sum_dim_int_list_6, [1024]);  sum_dim_int_list_6 = None
        t_default_99 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        view_default_279 = torch.ops.aten.view.default(mm_default_12, [8, 1024, 4096]);  mm_default_12 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_279, torch.float32);  view_default_279 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_229, torch.float32);  view_default_229 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_21);  mul_tensor_21 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(add_tensor_44, 0.5);  add_tensor_44 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_24 = torch.ops.aten.mul.Tensor(mul_tensor_23, -0.5);  mul_tensor_23 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_24);  mul_tensor_24 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_25);  to_dtype_4 = mul_tensor_25 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(mul_tensor_22, mul_tensor_26);  mul_tensor_22 = mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_45);  to_dtype_3 = add_tensor_45 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        view_default_280 = torch.ops.aten.view.default(to_dtype_5, [8192, 4096]);  to_dtype_5 = None
        t_default_100 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_280, t_default_100);  t_default_100 = None
        t_default_101 = torch.ops.aten.t.default(view_default_280)
        mm_default_15 = torch.ops.aten.mm.default(t_default_101, view_default_228);  t_default_101 = view_default_228 = None
        t_default_102 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_280, [0], True);  view_default_280 = None
        view_default_281 = torch.ops.aten.view.default(sum_dim_int_list_7, [4096]);  sum_dim_int_list_7 = None
        t_default_103 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        view_default_282 = torch.ops.aten.view.default(mm_default_14, [8, 1024, 1024]);  mm_default_14 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(getitem_81, view_default_282);  getitem_81 = view_default_282 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_46, add_tensor_33, [1024], getitem_64, getitem_65, primals_30, primals_29, [True, True, True]);  add_tensor_46 = add_tensor_33 = getitem_64 = getitem_65 = primals_30 = primals_29 = None
        getitem_84 = native_layer_norm_backward_default_3[0]
        getitem_85 = native_layer_norm_backward_default_3[1]
        getitem_86 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        view_default_283 = torch.ops.aten.view.default(getitem_84, [8192, 1024])
        t_default_104 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_283, t_default_104);  t_default_104 = None
        t_default_105 = torch.ops.aten.t.default(view_default_283)
        mm_default_17 = torch.ops.aten.mm.default(t_default_105, view_default_226);  t_default_105 = view_default_226 = None
        t_default_106 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_283, [0], True);  view_default_283 = None
        view_default_284 = torch.ops.aten.view.default(sum_dim_int_list_8, [1024]);  sum_dim_int_list_8 = None
        t_default_107 = torch.ops.aten.t.default(t_default_106);  t_default_106 = None
        view_default_285 = torch.ops.aten.view.default(mm_default_16, [8, 1024, 1024]);  mm_default_16 = None
        view_default_286 = torch.ops.aten.view.default(view_default_285, [8, 1024, 16, 64]);  view_default_285 = None
        transpose_int_69 = torch.ops.aten.transpose.int(view_default_286, 1, 2);  view_default_286 = None
        clone_default_52 = torch.ops.aten.clone.default(transpose_int_69, memory_format = torch.contiguous_format);  transpose_int_69 = None
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(clone_default_52, [128, 1024, 64]);  clone_default_52 = None
        transpose_int_70 = torch.ops.aten.transpose.int(_softmax_default_10, 1, 2)
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_70, _unsafe_view_default_16);  transpose_int_70 = None
        transpose_int_71 = torch.ops.aten.transpose.int(view_default_222, 1, 2);  view_default_222 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_unsafe_view_default_16, transpose_int_71);  _unsafe_view_default_16 = transpose_int_71 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(bmm_default_29, _softmax_default_10, -1, torch.float32);  bmm_default_29 = _softmax_default_10 = None
        view_default_287 = torch.ops.aten.view.default(_softmax_backward_data_default_1, [8, 16, 1024, 1024]);  _softmax_backward_data_default_1 = None
        view_default_288 = torch.ops.aten.view.default(view_default_287, [128, 1024, 1024]);  view_default_287 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_220, 1, 2);  view_default_220 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_72, view_default_288);  transpose_int_72 = None
        transpose_int_73 = torch.ops.aten.transpose.int(transpose_int_53, 1, 2);  transpose_int_53 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_288, transpose_int_73);  view_default_288 = transpose_int_73 = None
        transpose_int_74 = torch.ops.aten.transpose.int(bmm_default_30, 1, 2);  bmm_default_30 = None
        view_default_289 = torch.ops.aten.view.default(bmm_default_28, [8, 16, 1024, 64]);  bmm_default_28 = None
        view_default_290 = torch.ops.aten.view.default(transpose_int_74, [8, 16, 1024, 64]);  transpose_int_74 = None
        view_default_291 = torch.ops.aten.view.default(bmm_default_31, [8, 16, 1024, 64]);  bmm_default_31 = None
        transpose_int_75 = torch.ops.aten.transpose.int(view_default_291, 1, 2);  view_default_291 = None
        clone_default_53 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format);  transpose_int_75 = None
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(clone_default_53, [8, 1024, 1024]);  clone_default_53 = None
        transpose_int_76 = torch.ops.aten.transpose.int(view_default_289, 1, 2);  view_default_289 = None
        clone_default_54 = torch.ops.aten.clone.default(transpose_int_76, memory_format = torch.contiguous_format);  transpose_int_76 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_54, [8, 1024, 1024]);  clone_default_54 = None
        view_default_292 = torch.ops.aten.view.default(_unsafe_view_default_18, [8192, 1024]);  _unsafe_view_default_18 = None
        t_default_108 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_292, t_default_108);  t_default_108 = None
        t_default_109 = torch.ops.aten.t.default(view_default_292)
        mm_default_19 = torch.ops.aten.mm.default(t_default_109, view_default_216);  t_default_109 = view_default_216 = None
        t_default_110 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_292, [0], True);  view_default_292 = None
        view_default_293 = torch.ops.aten.view.default(sum_dim_int_list_9, [1024]);  sum_dim_int_list_9 = None
        t_default_111 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        view_default_294 = torch.ops.aten.view.default(mm_default_18, [8, 1024, 1024]);  mm_default_18 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_84, view_default_294);  getitem_84 = view_default_294 = None
        transpose_int_77 = torch.ops.aten.transpose.int(view_default_290, 1, 2);  view_default_290 = None
        view_default_295 = torch.ops.aten.view.default(transpose_int_77, [8, 1024, 1024]);  transpose_int_77 = None
        clone_default_55 = torch.ops.aten.clone.default(view_default_295, memory_format = torch.contiguous_format);  view_default_295 = None
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(clone_default_55, [8192, 1024]);  clone_default_55 = None
        t_default_112 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_20 = torch.ops.aten.mm.default(_unsafe_view_default_19, t_default_112);  t_default_112 = None
        t_default_113 = torch.ops.aten.t.default(_unsafe_view_default_19)
        mm_default_21 = torch.ops.aten.mm.default(t_default_113, view_default_213);  t_default_113 = view_default_213 = None
        t_default_114 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_19, [0], True);  _unsafe_view_default_19 = None
        view_default_296 = torch.ops.aten.view.default(sum_dim_int_list_10, [1024]);  sum_dim_int_list_10 = None
        t_default_115 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        view_default_297 = torch.ops.aten.view.default(mm_default_20, [8, 1024, 1024]);  mm_default_20 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, view_default_297);  add_tensor_47 = view_default_297 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(_unsafe_view_default_17, 0.125);  _unsafe_view_default_17 = None
        view_default_298 = torch.ops.aten.view.default(mul_tensor_28, [8192, 1024]);  mul_tensor_28 = None
        t_default_116 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_298, t_default_116);  t_default_116 = None
        t_default_117 = torch.ops.aten.t.default(view_default_298)
        mm_default_23 = torch.ops.aten.mm.default(t_default_117, view_default_211);  t_default_117 = view_default_211 = None
        t_default_118 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_298, [0], True);  view_default_298 = None
        view_default_299 = torch.ops.aten.view.default(sum_dim_int_list_11, [1024]);  sum_dim_int_list_11 = None
        t_default_119 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        view_default_300 = torch.ops.aten.view.default(mm_default_22, [8, 1024, 1024]);  mm_default_22 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, view_default_300);  add_tensor_48 = view_default_300 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_49, add_tensor_31, [1024], getitem_61, getitem_62, primals_186, primals_185, [True, True, True]);  add_tensor_49 = add_tensor_31 = getitem_61 = getitem_62 = primals_186 = primals_185 = None
        getitem_87 = native_layer_norm_backward_default_4[0]
        getitem_88 = native_layer_norm_backward_default_4[1]
        getitem_89 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_301 = torch.ops.aten.view.default(getitem_87, [8192, 1024])
        t_default_120 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_301, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_301)
        mm_default_25 = torch.ops.aten.mm.default(t_default_121, view_default_209);  t_default_121 = view_default_209 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_301, [0], True);  view_default_301 = None
        view_default_302 = torch.ops.aten.view.default(sum_dim_int_list_12, [1024]);  sum_dim_int_list_12 = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_303 = torch.ops.aten.view.default(mm_default_24, [8, 1024, 4096]);  mm_default_24 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_303, torch.float32);  view_default_303 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_208, torch.float32);  view_default_208 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_29);  mul_tensor_29 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(add_tensor_50, 0.5);  add_tensor_50 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_32 = torch.ops.aten.mul.Tensor(mul_tensor_31, -0.5);  mul_tensor_31 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_32);  mul_tensor_32 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_33);  to_dtype_7 = mul_tensor_33 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(mul_tensor_30, mul_tensor_34);  mul_tensor_30 = mul_tensor_34 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_51);  to_dtype_6 = add_tensor_51 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_35, torch.float32);  mul_tensor_35 = None
        view_default_304 = torch.ops.aten.view.default(to_dtype_8, [8192, 4096]);  to_dtype_8 = None
        t_default_124 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_304, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(view_default_304)
        mm_default_27 = torch.ops.aten.mm.default(t_default_125, view_default_207);  t_default_125 = view_default_207 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_304, [0], True);  view_default_304 = None
        view_default_305 = torch.ops.aten.view.default(sum_dim_int_list_13, [4096]);  sum_dim_int_list_13 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_306 = torch.ops.aten.view.default(mm_default_26, [8, 1024, 1024]);  mm_default_26 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_87, view_default_306);  getitem_87 = view_default_306 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_52, add_tensor_30, [1024], getitem_58, getitem_59, primals_190, primals_189, [True, True, True]);  add_tensor_52 = add_tensor_30 = getitem_58 = getitem_59 = primals_190 = primals_189 = None
        getitem_90 = native_layer_norm_backward_default_5[0]
        getitem_91 = native_layer_norm_backward_default_5[1]
        getitem_92 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_307 = torch.ops.aten.view.default(getitem_90, [8192, 1024])
        t_default_128 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_307, t_default_128);  t_default_128 = None
        t_default_129 = torch.ops.aten.t.default(view_default_307)
        mm_default_29 = torch.ops.aten.mm.default(t_default_129, view_default_205);  t_default_129 = view_default_205 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_307, [0], True);  view_default_307 = None
        view_default_308 = torch.ops.aten.view.default(sum_dim_int_list_14, [1024]);  sum_dim_int_list_14 = None
        t_default_131 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_309 = torch.ops.aten.view.default(mm_default_28, [8, 1024, 1024]);  mm_default_28 = None
        view_default_310 = torch.ops.aten.view.default(view_default_309, [8, 1024, 16, 64]);  view_default_309 = None
        transpose_int_78 = torch.ops.aten.transpose.int(view_default_310, 1, 2);  view_default_310 = None
        clone_default_56 = torch.ops.aten.clone.default(transpose_int_78, memory_format = torch.contiguous_format);  transpose_int_78 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_56, [128, 1024, 64]);  clone_default_56 = None
        transpose_int_79 = torch.ops.aten.transpose.int(_softmax_default_9, 1, 2)
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_79, _unsafe_view_default_20);  transpose_int_79 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_201, 1, 2);  view_default_201 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_unsafe_view_default_20, transpose_int_80);  _unsafe_view_default_20 = transpose_int_80 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(bmm_default_33, _softmax_default_9, -1, torch.float32);  bmm_default_33 = _softmax_default_9 = None
        view_default_311 = torch.ops.aten.view.default(_softmax_backward_data_default_2, [8, 16, 1024, 1024]);  _softmax_backward_data_default_2 = None
        view_default_312 = torch.ops.aten.view.default(view_default_311, [128, 1024, 1024]);  view_default_311 = None
        transpose_int_81 = torch.ops.aten.transpose.int(view_default_199, 1, 2);  view_default_199 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_81, view_default_312);  transpose_int_81 = None
        transpose_int_82 = torch.ops.aten.transpose.int(transpose_int_48, 1, 2);  transpose_int_48 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_312, transpose_int_82);  view_default_312 = transpose_int_82 = None
        transpose_int_83 = torch.ops.aten.transpose.int(bmm_default_34, 1, 2);  bmm_default_34 = None
        view_default_313 = torch.ops.aten.view.default(bmm_default_32, [8, 16, 1024, 64]);  bmm_default_32 = None
        view_default_314 = torch.ops.aten.view.default(transpose_int_83, [8, 16, 1024, 64]);  transpose_int_83 = None
        view_default_315 = torch.ops.aten.view.default(bmm_default_35, [8, 16, 1024, 64]);  bmm_default_35 = None
        transpose_int_84 = torch.ops.aten.transpose.int(view_default_315, 1, 2);  view_default_315 = None
        clone_default_57 = torch.ops.aten.clone.default(transpose_int_84, memory_format = torch.contiguous_format);  transpose_int_84 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_57, [8, 1024, 1024]);  clone_default_57 = None
        transpose_int_85 = torch.ops.aten.transpose.int(view_default_313, 1, 2);  view_default_313 = None
        clone_default_58 = torch.ops.aten.clone.default(transpose_int_85, memory_format = torch.contiguous_format);  transpose_int_85 = None
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(clone_default_58, [8, 1024, 1024]);  clone_default_58 = None
        view_default_316 = torch.ops.aten.view.default(_unsafe_view_default_22, [8192, 1024]);  _unsafe_view_default_22 = None
        t_default_132 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_316, t_default_132);  t_default_132 = None
        t_default_133 = torch.ops.aten.t.default(view_default_316)
        mm_default_31 = torch.ops.aten.mm.default(t_default_133, view_default_195);  t_default_133 = view_default_195 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_316, [0], True);  view_default_316 = None
        view_default_317 = torch.ops.aten.view.default(sum_dim_int_list_15, [1024]);  sum_dim_int_list_15 = None
        t_default_135 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        view_default_318 = torch.ops.aten.view.default(mm_default_30, [8, 1024, 1024]);  mm_default_30 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_90, view_default_318);  getitem_90 = view_default_318 = None
        transpose_int_86 = torch.ops.aten.transpose.int(view_default_314, 1, 2);  view_default_314 = None
        view_default_319 = torch.ops.aten.view.default(transpose_int_86, [8, 1024, 1024]);  transpose_int_86 = None
        clone_default_59 = torch.ops.aten.clone.default(view_default_319, memory_format = torch.contiguous_format);  view_default_319 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_59, [8192, 1024]);  clone_default_59 = None
        t_default_136 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_32 = torch.ops.aten.mm.default(_unsafe_view_default_23, t_default_136);  t_default_136 = None
        t_default_137 = torch.ops.aten.t.default(_unsafe_view_default_23)
        mm_default_33 = torch.ops.aten.mm.default(t_default_137, view_default_192);  t_default_137 = view_default_192 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_23, [0], True);  _unsafe_view_default_23 = None
        view_default_320 = torch.ops.aten.view.default(sum_dim_int_list_16, [1024]);  sum_dim_int_list_16 = None
        t_default_139 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        view_default_321 = torch.ops.aten.view.default(mm_default_32, [8, 1024, 1024]);  mm_default_32 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, view_default_321);  add_tensor_53 = view_default_321 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(_unsafe_view_default_21, 0.125);  _unsafe_view_default_21 = None
        view_default_322 = torch.ops.aten.view.default(mul_tensor_36, [8192, 1024]);  mul_tensor_36 = None
        t_default_140 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_322, t_default_140);  t_default_140 = None
        t_default_141 = torch.ops.aten.t.default(view_default_322)
        mm_default_35 = torch.ops.aten.mm.default(t_default_141, view_default_190);  t_default_141 = view_default_190 = None
        t_default_142 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_322, [0], True);  view_default_322 = None
        view_default_323 = torch.ops.aten.view.default(sum_dim_int_list_17, [1024]);  sum_dim_int_list_17 = None
        t_default_143 = torch.ops.aten.t.default(t_default_142);  t_default_142 = None
        view_default_324 = torch.ops.aten.view.default(mm_default_34, [8, 1024, 1024]);  mm_default_34 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(add_tensor_54, view_default_324);  add_tensor_54 = view_default_324 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_55, add_tensor_28, [1024], getitem_55, getitem_56, primals_170, primals_169, [True, True, True]);  add_tensor_55 = add_tensor_28 = getitem_55 = getitem_56 = primals_170 = primals_169 = None
        getitem_93 = native_layer_norm_backward_default_6[0]
        getitem_94 = native_layer_norm_backward_default_6[1]
        getitem_95 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_325 = torch.ops.aten.view.default(getitem_93, [8192, 1024])
        t_default_144 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_325, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_325)
        mm_default_37 = torch.ops.aten.mm.default(t_default_145, view_default_188);  t_default_145 = view_default_188 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_325, [0], True);  view_default_325 = None
        view_default_326 = torch.ops.aten.view.default(sum_dim_int_list_18, [1024]);  sum_dim_int_list_18 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_327 = torch.ops.aten.view.default(mm_default_36, [8, 1024, 4096]);  mm_default_36 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_327, torch.float32);  view_default_327 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_187, torch.float32);  view_default_187 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_37);  mul_tensor_37 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(add_tensor_56, 0.5);  add_tensor_56 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_40 = torch.ops.aten.mul.Tensor(mul_tensor_39, -0.5);  mul_tensor_39 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_40);  mul_tensor_40 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_41);  to_dtype_10 = mul_tensor_41 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(mul_tensor_38, mul_tensor_42);  mul_tensor_38 = mul_tensor_42 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_57);  to_dtype_9 = add_tensor_57 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_43, torch.float32);  mul_tensor_43 = None
        view_default_328 = torch.ops.aten.view.default(to_dtype_11, [8192, 4096]);  to_dtype_11 = None
        t_default_148 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_328, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(view_default_328)
        mm_default_39 = torch.ops.aten.mm.default(t_default_149, view_default_186);  t_default_149 = view_default_186 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_328, [0], True);  view_default_328 = None
        view_default_329 = torch.ops.aten.view.default(sum_dim_int_list_19, [4096]);  sum_dim_int_list_19 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_330 = torch.ops.aten.view.default(mm_default_38, [8, 1024, 1024]);  mm_default_38 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(getitem_93, view_default_330);  getitem_93 = view_default_330 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_58, add_tensor_27, [1024], getitem_52, getitem_53, primals_174, primals_173, [True, True, True]);  add_tensor_58 = add_tensor_27 = getitem_52 = getitem_53 = primals_174 = primals_173 = None
        getitem_96 = native_layer_norm_backward_default_7[0]
        getitem_97 = native_layer_norm_backward_default_7[1]
        getitem_98 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_331 = torch.ops.aten.view.default(getitem_96, [8192, 1024])
        t_default_152 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_331, t_default_152);  t_default_152 = None
        t_default_153 = torch.ops.aten.t.default(view_default_331)
        mm_default_41 = torch.ops.aten.mm.default(t_default_153, view_default_184);  t_default_153 = view_default_184 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_331, [0], True);  view_default_331 = None
        view_default_332 = torch.ops.aten.view.default(sum_dim_int_list_20, [1024]);  sum_dim_int_list_20 = None
        t_default_155 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_333 = torch.ops.aten.view.default(mm_default_40, [8, 1024, 1024]);  mm_default_40 = None
        view_default_334 = torch.ops.aten.view.default(view_default_333, [8, 1024, 16, 64]);  view_default_333 = None
        transpose_int_87 = torch.ops.aten.transpose.int(view_default_334, 1, 2);  view_default_334 = None
        clone_default_60 = torch.ops.aten.clone.default(transpose_int_87, memory_format = torch.contiguous_format);  transpose_int_87 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_60, [128, 1024, 64]);  clone_default_60 = None
        transpose_int_88 = torch.ops.aten.transpose.int(_softmax_default_8, 1, 2)
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_88, _unsafe_view_default_24);  transpose_int_88 = None
        transpose_int_89 = torch.ops.aten.transpose.int(view_default_180, 1, 2);  view_default_180 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_unsafe_view_default_24, transpose_int_89);  _unsafe_view_default_24 = transpose_int_89 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(bmm_default_37, _softmax_default_8, -1, torch.float32);  bmm_default_37 = _softmax_default_8 = None
        view_default_335 = torch.ops.aten.view.default(_softmax_backward_data_default_3, [8, 16, 1024, 1024]);  _softmax_backward_data_default_3 = None
        view_default_336 = torch.ops.aten.view.default(view_default_335, [128, 1024, 1024]);  view_default_335 = None
        transpose_int_90 = torch.ops.aten.transpose.int(view_default_178, 1, 2);  view_default_178 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_90, view_default_336);  transpose_int_90 = None
        transpose_int_91 = torch.ops.aten.transpose.int(transpose_int_43, 1, 2);  transpose_int_43 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_336, transpose_int_91);  view_default_336 = transpose_int_91 = None
        transpose_int_92 = torch.ops.aten.transpose.int(bmm_default_38, 1, 2);  bmm_default_38 = None
        view_default_337 = torch.ops.aten.view.default(bmm_default_36, [8, 16, 1024, 64]);  bmm_default_36 = None
        view_default_338 = torch.ops.aten.view.default(transpose_int_92, [8, 16, 1024, 64]);  transpose_int_92 = None
        view_default_339 = torch.ops.aten.view.default(bmm_default_39, [8, 16, 1024, 64]);  bmm_default_39 = None
        transpose_int_93 = torch.ops.aten.transpose.int(view_default_339, 1, 2);  view_default_339 = None
        clone_default_61 = torch.ops.aten.clone.default(transpose_int_93, memory_format = torch.contiguous_format);  transpose_int_93 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_61, [8, 1024, 1024]);  clone_default_61 = None
        transpose_int_94 = torch.ops.aten.transpose.int(view_default_337, 1, 2);  view_default_337 = None
        clone_default_62 = torch.ops.aten.clone.default(transpose_int_94, memory_format = torch.contiguous_format);  transpose_int_94 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_62, [8, 1024, 1024]);  clone_default_62 = None
        view_default_340 = torch.ops.aten.view.default(_unsafe_view_default_26, [8192, 1024]);  _unsafe_view_default_26 = None
        t_default_156 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_340, t_default_156);  t_default_156 = None
        t_default_157 = torch.ops.aten.t.default(view_default_340)
        mm_default_43 = torch.ops.aten.mm.default(t_default_157, view_default_174);  t_default_157 = view_default_174 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_340, [0], True);  view_default_340 = None
        view_default_341 = torch.ops.aten.view.default(sum_dim_int_list_21, [1024]);  sum_dim_int_list_21 = None
        t_default_159 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        view_default_342 = torch.ops.aten.view.default(mm_default_42, [8, 1024, 1024]);  mm_default_42 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_96, view_default_342);  getitem_96 = view_default_342 = None
        transpose_int_95 = torch.ops.aten.transpose.int(view_default_338, 1, 2);  view_default_338 = None
        view_default_343 = torch.ops.aten.view.default(transpose_int_95, [8, 1024, 1024]);  transpose_int_95 = None
        clone_default_63 = torch.ops.aten.clone.default(view_default_343, memory_format = torch.contiguous_format);  view_default_343 = None
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(clone_default_63, [8192, 1024]);  clone_default_63 = None
        t_default_160 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_44 = torch.ops.aten.mm.default(_unsafe_view_default_27, t_default_160);  t_default_160 = None
        t_default_161 = torch.ops.aten.t.default(_unsafe_view_default_27)
        mm_default_45 = torch.ops.aten.mm.default(t_default_161, view_default_171);  t_default_161 = view_default_171 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_27, [0], True);  _unsafe_view_default_27 = None
        view_default_344 = torch.ops.aten.view.default(sum_dim_int_list_22, [1024]);  sum_dim_int_list_22 = None
        t_default_163 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        view_default_345 = torch.ops.aten.view.default(mm_default_44, [8, 1024, 1024]);  mm_default_44 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, view_default_345);  add_tensor_59 = view_default_345 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(_unsafe_view_default_25, 0.125);  _unsafe_view_default_25 = None
        view_default_346 = torch.ops.aten.view.default(mul_tensor_44, [8192, 1024]);  mul_tensor_44 = None
        t_default_164 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_346, t_default_164);  t_default_164 = None
        t_default_165 = torch.ops.aten.t.default(view_default_346)
        mm_default_47 = torch.ops.aten.mm.default(t_default_165, view_default_169);  t_default_165 = view_default_169 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_346, [0], True);  view_default_346 = None
        view_default_347 = torch.ops.aten.view.default(sum_dim_int_list_23, [1024]);  sum_dim_int_list_23 = None
        t_default_167 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_348 = torch.ops.aten.view.default(mm_default_46, [8, 1024, 1024]);  mm_default_46 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_60, view_default_348);  add_tensor_60 = view_default_348 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_61, add_tensor_25, [1024], getitem_49, getitem_50, primals_154, primals_153, [True, True, True]);  add_tensor_61 = add_tensor_25 = getitem_49 = getitem_50 = primals_154 = primals_153 = None
        getitem_99 = native_layer_norm_backward_default_8[0]
        getitem_100 = native_layer_norm_backward_default_8[1]
        getitem_101 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_349 = torch.ops.aten.view.default(getitem_99, [8192, 1024])
        t_default_168 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_349, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_349)
        mm_default_49 = torch.ops.aten.mm.default(t_default_169, view_default_167);  t_default_169 = view_default_167 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_349, [0], True);  view_default_349 = None
        view_default_350 = torch.ops.aten.view.default(sum_dim_int_list_24, [1024]);  sum_dim_int_list_24 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_351 = torch.ops.aten.view.default(mm_default_48, [8, 1024, 4096]);  mm_default_48 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_351, torch.float32);  view_default_351 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_166, torch.float32);  view_default_166 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_45);  mul_tensor_45 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(add_tensor_62, 0.5);  add_tensor_62 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_48 = torch.ops.aten.mul.Tensor(mul_tensor_47, -0.5);  mul_tensor_47 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_48);  mul_tensor_48 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_49);  to_dtype_13 = mul_tensor_49 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(mul_tensor_46, mul_tensor_50);  mul_tensor_46 = mul_tensor_50 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_63);  to_dtype_12 = add_tensor_63 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_51, torch.float32);  mul_tensor_51 = None
        view_default_352 = torch.ops.aten.view.default(to_dtype_14, [8192, 4096]);  to_dtype_14 = None
        t_default_172 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_352, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(view_default_352)
        mm_default_51 = torch.ops.aten.mm.default(t_default_173, view_default_165);  t_default_173 = view_default_165 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_352, [0], True);  view_default_352 = None
        view_default_353 = torch.ops.aten.view.default(sum_dim_int_list_25, [4096]);  sum_dim_int_list_25 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_354 = torch.ops.aten.view.default(mm_default_50, [8, 1024, 1024]);  mm_default_50 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_99, view_default_354);  getitem_99 = view_default_354 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_64, add_tensor_24, [1024], getitem_46, getitem_47, primals_158, primals_157, [True, True, True]);  add_tensor_64 = add_tensor_24 = getitem_46 = getitem_47 = primals_158 = primals_157 = None
        getitem_102 = native_layer_norm_backward_default_9[0]
        getitem_103 = native_layer_norm_backward_default_9[1]
        getitem_104 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        view_default_355 = torch.ops.aten.view.default(getitem_102, [8192, 1024])
        t_default_176 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_355, t_default_176);  t_default_176 = None
        t_default_177 = torch.ops.aten.t.default(view_default_355)
        mm_default_53 = torch.ops.aten.mm.default(t_default_177, view_default_163);  t_default_177 = view_default_163 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_355, [0], True);  view_default_355 = None
        view_default_356 = torch.ops.aten.view.default(sum_dim_int_list_26, [1024]);  sum_dim_int_list_26 = None
        t_default_179 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        view_default_357 = torch.ops.aten.view.default(mm_default_52, [8, 1024, 1024]);  mm_default_52 = None
        view_default_358 = torch.ops.aten.view.default(view_default_357, [8, 1024, 16, 64]);  view_default_357 = None
        transpose_int_96 = torch.ops.aten.transpose.int(view_default_358, 1, 2);  view_default_358 = None
        clone_default_64 = torch.ops.aten.clone.default(transpose_int_96, memory_format = torch.contiguous_format);  transpose_int_96 = None
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_64, [128, 1024, 64]);  clone_default_64 = None
        transpose_int_97 = torch.ops.aten.transpose.int(_softmax_default_7, 1, 2)
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_97, _unsafe_view_default_28);  transpose_int_97 = None
        transpose_int_98 = torch.ops.aten.transpose.int(view_default_159, 1, 2);  view_default_159 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_unsafe_view_default_28, transpose_int_98);  _unsafe_view_default_28 = transpose_int_98 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(bmm_default_41, _softmax_default_7, -1, torch.float32);  bmm_default_41 = _softmax_default_7 = None
        view_default_359 = torch.ops.aten.view.default(_softmax_backward_data_default_4, [8, 16, 1024, 1024]);  _softmax_backward_data_default_4 = None
        view_default_360 = torch.ops.aten.view.default(view_default_359, [128, 1024, 1024]);  view_default_359 = None
        transpose_int_99 = torch.ops.aten.transpose.int(view_default_157, 1, 2);  view_default_157 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_99, view_default_360);  transpose_int_99 = None
        transpose_int_100 = torch.ops.aten.transpose.int(transpose_int_38, 1, 2);  transpose_int_38 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_360, transpose_int_100);  view_default_360 = transpose_int_100 = None
        transpose_int_101 = torch.ops.aten.transpose.int(bmm_default_42, 1, 2);  bmm_default_42 = None
        view_default_361 = torch.ops.aten.view.default(bmm_default_40, [8, 16, 1024, 64]);  bmm_default_40 = None
        view_default_362 = torch.ops.aten.view.default(transpose_int_101, [8, 16, 1024, 64]);  transpose_int_101 = None
        view_default_363 = torch.ops.aten.view.default(bmm_default_43, [8, 16, 1024, 64]);  bmm_default_43 = None
        transpose_int_102 = torch.ops.aten.transpose.int(view_default_363, 1, 2);  view_default_363 = None
        clone_default_65 = torch.ops.aten.clone.default(transpose_int_102, memory_format = torch.contiguous_format);  transpose_int_102 = None
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(clone_default_65, [8, 1024, 1024]);  clone_default_65 = None
        transpose_int_103 = torch.ops.aten.transpose.int(view_default_361, 1, 2);  view_default_361 = None
        clone_default_66 = torch.ops.aten.clone.default(transpose_int_103, memory_format = torch.contiguous_format);  transpose_int_103 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_66, [8, 1024, 1024]);  clone_default_66 = None
        view_default_364 = torch.ops.aten.view.default(_unsafe_view_default_30, [8192, 1024]);  _unsafe_view_default_30 = None
        t_default_180 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_364, t_default_180);  t_default_180 = None
        t_default_181 = torch.ops.aten.t.default(view_default_364)
        mm_default_55 = torch.ops.aten.mm.default(t_default_181, view_default_153);  t_default_181 = view_default_153 = None
        t_default_182 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_364, [0], True);  view_default_364 = None
        view_default_365 = torch.ops.aten.view.default(sum_dim_int_list_27, [1024]);  sum_dim_int_list_27 = None
        t_default_183 = torch.ops.aten.t.default(t_default_182);  t_default_182 = None
        view_default_366 = torch.ops.aten.view.default(mm_default_54, [8, 1024, 1024]);  mm_default_54 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_102, view_default_366);  getitem_102 = view_default_366 = None
        transpose_int_104 = torch.ops.aten.transpose.int(view_default_362, 1, 2);  view_default_362 = None
        view_default_367 = torch.ops.aten.view.default(transpose_int_104, [8, 1024, 1024]);  transpose_int_104 = None
        clone_default_67 = torch.ops.aten.clone.default(view_default_367, memory_format = torch.contiguous_format);  view_default_367 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_67, [8192, 1024]);  clone_default_67 = None
        t_default_184 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_56 = torch.ops.aten.mm.default(_unsafe_view_default_31, t_default_184);  t_default_184 = None
        t_default_185 = torch.ops.aten.t.default(_unsafe_view_default_31)
        mm_default_57 = torch.ops.aten.mm.default(t_default_185, view_default_150);  t_default_185 = view_default_150 = None
        t_default_186 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_31, [0], True);  _unsafe_view_default_31 = None
        view_default_368 = torch.ops.aten.view.default(sum_dim_int_list_28, [1024]);  sum_dim_int_list_28 = None
        t_default_187 = torch.ops.aten.t.default(t_default_186);  t_default_186 = None
        view_default_369 = torch.ops.aten.view.default(mm_default_56, [8, 1024, 1024]);  mm_default_56 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(add_tensor_65, view_default_369);  add_tensor_65 = view_default_369 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(_unsafe_view_default_29, 0.125);  _unsafe_view_default_29 = None
        view_default_370 = torch.ops.aten.view.default(mul_tensor_52, [8192, 1024]);  mul_tensor_52 = None
        t_default_188 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_370, t_default_188);  t_default_188 = None
        t_default_189 = torch.ops.aten.t.default(view_default_370)
        mm_default_59 = torch.ops.aten.mm.default(t_default_189, view_default_148);  t_default_189 = view_default_148 = None
        t_default_190 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_370, [0], True);  view_default_370 = None
        view_default_371 = torch.ops.aten.view.default(sum_dim_int_list_29, [1024]);  sum_dim_int_list_29 = None
        t_default_191 = torch.ops.aten.t.default(t_default_190);  t_default_190 = None
        view_default_372 = torch.ops.aten.view.default(mm_default_58, [8, 1024, 1024]);  mm_default_58 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(add_tensor_66, view_default_372);  add_tensor_66 = view_default_372 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_67, add_tensor_22, [1024], getitem_43, getitem_44, primals_138, primals_137, [True, True, True]);  add_tensor_67 = add_tensor_22 = getitem_43 = getitem_44 = primals_138 = primals_137 = None
        getitem_105 = native_layer_norm_backward_default_10[0]
        getitem_106 = native_layer_norm_backward_default_10[1]
        getitem_107 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_373 = torch.ops.aten.view.default(getitem_105, [8192, 1024])
        t_default_192 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_373, t_default_192);  t_default_192 = None
        t_default_193 = torch.ops.aten.t.default(view_default_373)
        mm_default_61 = torch.ops.aten.mm.default(t_default_193, view_default_146);  t_default_193 = view_default_146 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_373, [0], True);  view_default_373 = None
        view_default_374 = torch.ops.aten.view.default(sum_dim_int_list_30, [1024]);  sum_dim_int_list_30 = None
        t_default_195 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_375 = torch.ops.aten.view.default(mm_default_60, [8, 1024, 4096]);  mm_default_60 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_375, torch.float32);  view_default_375 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_145, torch.float32);  view_default_145 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_53);  mul_tensor_53 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(add_tensor_68, 0.5);  add_tensor_68 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_56 = torch.ops.aten.mul.Tensor(mul_tensor_55, -0.5);  mul_tensor_55 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_56);  mul_tensor_56 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_57);  to_dtype_16 = mul_tensor_57 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(mul_tensor_54, mul_tensor_58);  mul_tensor_54 = mul_tensor_58 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_69);  to_dtype_15 = add_tensor_69 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_59, torch.float32);  mul_tensor_59 = None
        view_default_376 = torch.ops.aten.view.default(to_dtype_17, [8192, 4096]);  to_dtype_17 = None
        t_default_196 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_376, t_default_196);  t_default_196 = None
        t_default_197 = torch.ops.aten.t.default(view_default_376)
        mm_default_63 = torch.ops.aten.mm.default(t_default_197, view_default_144);  t_default_197 = view_default_144 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_376, [0], True);  view_default_376 = None
        view_default_377 = torch.ops.aten.view.default(sum_dim_int_list_31, [4096]);  sum_dim_int_list_31 = None
        t_default_199 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        view_default_378 = torch.ops.aten.view.default(mm_default_62, [8, 1024, 1024]);  mm_default_62 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_105, view_default_378);  getitem_105 = view_default_378 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_70, add_tensor_21, [1024], getitem_40, getitem_41, primals_142, primals_141, [True, True, True]);  add_tensor_70 = add_tensor_21 = getitem_40 = getitem_41 = primals_142 = primals_141 = None
        getitem_108 = native_layer_norm_backward_default_11[0]
        getitem_109 = native_layer_norm_backward_default_11[1]
        getitem_110 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_379 = torch.ops.aten.view.default(getitem_108, [8192, 1024])
        t_default_200 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_379, t_default_200);  t_default_200 = None
        t_default_201 = torch.ops.aten.t.default(view_default_379)
        mm_default_65 = torch.ops.aten.mm.default(t_default_201, view_default_142);  t_default_201 = view_default_142 = None
        t_default_202 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_379, [0], True);  view_default_379 = None
        view_default_380 = torch.ops.aten.view.default(sum_dim_int_list_32, [1024]);  sum_dim_int_list_32 = None
        t_default_203 = torch.ops.aten.t.default(t_default_202);  t_default_202 = None
        view_default_381 = torch.ops.aten.view.default(mm_default_64, [8, 1024, 1024]);  mm_default_64 = None
        view_default_382 = torch.ops.aten.view.default(view_default_381, [8, 1024, 16, 64]);  view_default_381 = None
        transpose_int_105 = torch.ops.aten.transpose.int(view_default_382, 1, 2);  view_default_382 = None
        clone_default_68 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format);  transpose_int_105 = None
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(clone_default_68, [128, 1024, 64]);  clone_default_68 = None
        transpose_int_106 = torch.ops.aten.transpose.int(_softmax_default_6, 1, 2)
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_106, _unsafe_view_default_32);  transpose_int_106 = None
        transpose_int_107 = torch.ops.aten.transpose.int(view_default_138, 1, 2);  view_default_138 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_unsafe_view_default_32, transpose_int_107);  _unsafe_view_default_32 = transpose_int_107 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(bmm_default_45, _softmax_default_6, -1, torch.float32);  bmm_default_45 = _softmax_default_6 = None
        view_default_383 = torch.ops.aten.view.default(_softmax_backward_data_default_5, [8, 16, 1024, 1024]);  _softmax_backward_data_default_5 = None
        view_default_384 = torch.ops.aten.view.default(view_default_383, [128, 1024, 1024]);  view_default_383 = None
        transpose_int_108 = torch.ops.aten.transpose.int(view_default_136, 1, 2);  view_default_136 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_108, view_default_384);  transpose_int_108 = None
        transpose_int_109 = torch.ops.aten.transpose.int(transpose_int_33, 1, 2);  transpose_int_33 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_384, transpose_int_109);  view_default_384 = transpose_int_109 = None
        transpose_int_110 = torch.ops.aten.transpose.int(bmm_default_46, 1, 2);  bmm_default_46 = None
        view_default_385 = torch.ops.aten.view.default(bmm_default_44, [8, 16, 1024, 64]);  bmm_default_44 = None
        view_default_386 = torch.ops.aten.view.default(transpose_int_110, [8, 16, 1024, 64]);  transpose_int_110 = None
        view_default_387 = torch.ops.aten.view.default(bmm_default_47, [8, 16, 1024, 64]);  bmm_default_47 = None
        transpose_int_111 = torch.ops.aten.transpose.int(view_default_387, 1, 2);  view_default_387 = None
        clone_default_69 = torch.ops.aten.clone.default(transpose_int_111, memory_format = torch.contiguous_format);  transpose_int_111 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_69, [8, 1024, 1024]);  clone_default_69 = None
        transpose_int_112 = torch.ops.aten.transpose.int(view_default_385, 1, 2);  view_default_385 = None
        clone_default_70 = torch.ops.aten.clone.default(transpose_int_112, memory_format = torch.contiguous_format);  transpose_int_112 = None
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(clone_default_70, [8, 1024, 1024]);  clone_default_70 = None
        view_default_388 = torch.ops.aten.view.default(_unsafe_view_default_34, [8192, 1024]);  _unsafe_view_default_34 = None
        t_default_204 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_388, t_default_204);  t_default_204 = None
        t_default_205 = torch.ops.aten.t.default(view_default_388)
        mm_default_67 = torch.ops.aten.mm.default(t_default_205, view_default_132);  t_default_205 = view_default_132 = None
        t_default_206 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_388, [0], True);  view_default_388 = None
        view_default_389 = torch.ops.aten.view.default(sum_dim_int_list_33, [1024]);  sum_dim_int_list_33 = None
        t_default_207 = torch.ops.aten.t.default(t_default_206);  t_default_206 = None
        view_default_390 = torch.ops.aten.view.default(mm_default_66, [8, 1024, 1024]);  mm_default_66 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(getitem_108, view_default_390);  getitem_108 = view_default_390 = None
        transpose_int_113 = torch.ops.aten.transpose.int(view_default_386, 1, 2);  view_default_386 = None
        view_default_391 = torch.ops.aten.view.default(transpose_int_113, [8, 1024, 1024]);  transpose_int_113 = None
        clone_default_71 = torch.ops.aten.clone.default(view_default_391, memory_format = torch.contiguous_format);  view_default_391 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_71, [8192, 1024]);  clone_default_71 = None
        t_default_208 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_68 = torch.ops.aten.mm.default(_unsafe_view_default_35, t_default_208);  t_default_208 = None
        t_default_209 = torch.ops.aten.t.default(_unsafe_view_default_35)
        mm_default_69 = torch.ops.aten.mm.default(t_default_209, view_default_129);  t_default_209 = view_default_129 = None
        t_default_210 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_35, [0], True);  _unsafe_view_default_35 = None
        view_default_392 = torch.ops.aten.view.default(sum_dim_int_list_34, [1024]);  sum_dim_int_list_34 = None
        t_default_211 = torch.ops.aten.t.default(t_default_210);  t_default_210 = None
        view_default_393 = torch.ops.aten.view.default(mm_default_68, [8, 1024, 1024]);  mm_default_68 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(add_tensor_71, view_default_393);  add_tensor_71 = view_default_393 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(_unsafe_view_default_33, 0.125);  _unsafe_view_default_33 = None
        view_default_394 = torch.ops.aten.view.default(mul_tensor_60, [8192, 1024]);  mul_tensor_60 = None
        t_default_212 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_394, t_default_212);  t_default_212 = None
        t_default_213 = torch.ops.aten.t.default(view_default_394)
        mm_default_71 = torch.ops.aten.mm.default(t_default_213, view_default_127);  t_default_213 = view_default_127 = None
        t_default_214 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_394, [0], True);  view_default_394 = None
        view_default_395 = torch.ops.aten.view.default(sum_dim_int_list_35, [1024]);  sum_dim_int_list_35 = None
        t_default_215 = torch.ops.aten.t.default(t_default_214);  t_default_214 = None
        view_default_396 = torch.ops.aten.view.default(mm_default_70, [8, 1024, 1024]);  mm_default_70 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_72, view_default_396);  add_tensor_72 = view_default_396 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_73, add_tensor_19, [1024], getitem_37, getitem_38, primals_122, primals_121, [True, True, True]);  add_tensor_73 = add_tensor_19 = getitem_37 = getitem_38 = primals_122 = primals_121 = None
        getitem_111 = native_layer_norm_backward_default_12[0]
        getitem_112 = native_layer_norm_backward_default_12[1]
        getitem_113 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        view_default_397 = torch.ops.aten.view.default(getitem_111, [8192, 1024])
        t_default_216 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_397, t_default_216);  t_default_216 = None
        t_default_217 = torch.ops.aten.t.default(view_default_397)
        mm_default_73 = torch.ops.aten.mm.default(t_default_217, view_default_125);  t_default_217 = view_default_125 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_397, [0], True);  view_default_397 = None
        view_default_398 = torch.ops.aten.view.default(sum_dim_int_list_36, [1024]);  sum_dim_int_list_36 = None
        t_default_219 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        view_default_399 = torch.ops.aten.view.default(mm_default_72, [8, 1024, 4096]);  mm_default_72 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_399, torch.float32);  view_default_399 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_124, torch.float32);  view_default_124 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_61);  mul_tensor_61 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(add_tensor_74, 0.5);  add_tensor_74 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(mul_tensor_63, -0.5);  mul_tensor_63 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_64);  mul_tensor_64 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_65);  to_dtype_19 = mul_tensor_65 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(mul_tensor_62, mul_tensor_66);  mul_tensor_62 = mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_75);  to_dtype_18 = add_tensor_75 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_67, torch.float32);  mul_tensor_67 = None
        view_default_400 = torch.ops.aten.view.default(to_dtype_20, [8192, 4096]);  to_dtype_20 = None
        t_default_220 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_400, t_default_220);  t_default_220 = None
        t_default_221 = torch.ops.aten.t.default(view_default_400)
        mm_default_75 = torch.ops.aten.mm.default(t_default_221, view_default_123);  t_default_221 = view_default_123 = None
        t_default_222 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_400, [0], True);  view_default_400 = None
        view_default_401 = torch.ops.aten.view.default(sum_dim_int_list_37, [4096]);  sum_dim_int_list_37 = None
        t_default_223 = torch.ops.aten.t.default(t_default_222);  t_default_222 = None
        view_default_402 = torch.ops.aten.view.default(mm_default_74, [8, 1024, 1024]);  mm_default_74 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(getitem_111, view_default_402);  getitem_111 = view_default_402 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_76, add_tensor_18, [1024], getitem_34, getitem_35, primals_126, primals_125, [True, True, True]);  add_tensor_76 = add_tensor_18 = getitem_34 = getitem_35 = primals_126 = primals_125 = None
        getitem_114 = native_layer_norm_backward_default_13[0]
        getitem_115 = native_layer_norm_backward_default_13[1]
        getitem_116 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        view_default_403 = torch.ops.aten.view.default(getitem_114, [8192, 1024])
        t_default_224 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_76 = torch.ops.aten.mm.default(view_default_403, t_default_224);  t_default_224 = None
        t_default_225 = torch.ops.aten.t.default(view_default_403)
        mm_default_77 = torch.ops.aten.mm.default(t_default_225, view_default_121);  t_default_225 = view_default_121 = None
        t_default_226 = torch.ops.aten.t.default(mm_default_77);  mm_default_77 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(view_default_403, [0], True);  view_default_403 = None
        view_default_404 = torch.ops.aten.view.default(sum_dim_int_list_38, [1024]);  sum_dim_int_list_38 = None
        t_default_227 = torch.ops.aten.t.default(t_default_226);  t_default_226 = None
        view_default_405 = torch.ops.aten.view.default(mm_default_76, [8, 1024, 1024]);  mm_default_76 = None
        view_default_406 = torch.ops.aten.view.default(view_default_405, [8, 1024, 16, 64]);  view_default_405 = None
        transpose_int_114 = torch.ops.aten.transpose.int(view_default_406, 1, 2);  view_default_406 = None
        clone_default_72 = torch.ops.aten.clone.default(transpose_int_114, memory_format = torch.contiguous_format);  transpose_int_114 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_72, [128, 1024, 64]);  clone_default_72 = None
        transpose_int_115 = torch.ops.aten.transpose.int(_softmax_default_5, 1, 2)
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_115, _unsafe_view_default_36);  transpose_int_115 = None
        transpose_int_116 = torch.ops.aten.transpose.int(view_default_117, 1, 2);  view_default_117 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_36, transpose_int_116);  _unsafe_view_default_36 = transpose_int_116 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(bmm_default_49, _softmax_default_5, -1, torch.float32);  bmm_default_49 = _softmax_default_5 = None
        view_default_407 = torch.ops.aten.view.default(_softmax_backward_data_default_6, [8, 16, 1024, 1024]);  _softmax_backward_data_default_6 = None
        view_default_408 = torch.ops.aten.view.default(view_default_407, [128, 1024, 1024]);  view_default_407 = None
        transpose_int_117 = torch.ops.aten.transpose.int(view_default_115, 1, 2);  view_default_115 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_117, view_default_408);  transpose_int_117 = None
        transpose_int_118 = torch.ops.aten.transpose.int(transpose_int_28, 1, 2);  transpose_int_28 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_408, transpose_int_118);  view_default_408 = transpose_int_118 = None
        transpose_int_119 = torch.ops.aten.transpose.int(bmm_default_50, 1, 2);  bmm_default_50 = None
        view_default_409 = torch.ops.aten.view.default(bmm_default_48, [8, 16, 1024, 64]);  bmm_default_48 = None
        view_default_410 = torch.ops.aten.view.default(transpose_int_119, [8, 16, 1024, 64]);  transpose_int_119 = None
        view_default_411 = torch.ops.aten.view.default(bmm_default_51, [8, 16, 1024, 64]);  bmm_default_51 = None
        transpose_int_120 = torch.ops.aten.transpose.int(view_default_411, 1, 2);  view_default_411 = None
        clone_default_73 = torch.ops.aten.clone.default(transpose_int_120, memory_format = torch.contiguous_format);  transpose_int_120 = None
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(clone_default_73, [8, 1024, 1024]);  clone_default_73 = None
        transpose_int_121 = torch.ops.aten.transpose.int(view_default_409, 1, 2);  view_default_409 = None
        clone_default_74 = torch.ops.aten.clone.default(transpose_int_121, memory_format = torch.contiguous_format);  transpose_int_121 = None
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(clone_default_74, [8, 1024, 1024]);  clone_default_74 = None
        view_default_412 = torch.ops.aten.view.default(_unsafe_view_default_38, [8192, 1024]);  _unsafe_view_default_38 = None
        t_default_228 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_78 = torch.ops.aten.mm.default(view_default_412, t_default_228);  t_default_228 = None
        t_default_229 = torch.ops.aten.t.default(view_default_412)
        mm_default_79 = torch.ops.aten.mm.default(t_default_229, view_default_111);  t_default_229 = view_default_111 = None
        t_default_230 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(view_default_412, [0], True);  view_default_412 = None
        view_default_413 = torch.ops.aten.view.default(sum_dim_int_list_39, [1024]);  sum_dim_int_list_39 = None
        t_default_231 = torch.ops.aten.t.default(t_default_230);  t_default_230 = None
        view_default_414 = torch.ops.aten.view.default(mm_default_78, [8, 1024, 1024]);  mm_default_78 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(getitem_114, view_default_414);  getitem_114 = view_default_414 = None
        transpose_int_122 = torch.ops.aten.transpose.int(view_default_410, 1, 2);  view_default_410 = None
        view_default_415 = torch.ops.aten.view.default(transpose_int_122, [8, 1024, 1024]);  transpose_int_122 = None
        clone_default_75 = torch.ops.aten.clone.default(view_default_415, memory_format = torch.contiguous_format);  view_default_415 = None
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(clone_default_75, [8192, 1024]);  clone_default_75 = None
        t_default_232 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_80 = torch.ops.aten.mm.default(_unsafe_view_default_39, t_default_232);  t_default_232 = None
        t_default_233 = torch.ops.aten.t.default(_unsafe_view_default_39)
        mm_default_81 = torch.ops.aten.mm.default(t_default_233, view_default_108);  t_default_233 = view_default_108 = None
        t_default_234 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_39, [0], True);  _unsafe_view_default_39 = None
        view_default_416 = torch.ops.aten.view.default(sum_dim_int_list_40, [1024]);  sum_dim_int_list_40 = None
        t_default_235 = torch.ops.aten.t.default(t_default_234);  t_default_234 = None
        view_default_417 = torch.ops.aten.view.default(mm_default_80, [8, 1024, 1024]);  mm_default_80 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(add_tensor_77, view_default_417);  add_tensor_77 = view_default_417 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(_unsafe_view_default_37, 0.125);  _unsafe_view_default_37 = None
        view_default_418 = torch.ops.aten.view.default(mul_tensor_68, [8192, 1024]);  mul_tensor_68 = None
        t_default_236 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_418, t_default_236);  t_default_236 = None
        t_default_237 = torch.ops.aten.t.default(view_default_418)
        mm_default_83 = torch.ops.aten.mm.default(t_default_237, view_default_106);  t_default_237 = view_default_106 = None
        t_default_238 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(view_default_418, [0], True);  view_default_418 = None
        view_default_419 = torch.ops.aten.view.default(sum_dim_int_list_41, [1024]);  sum_dim_int_list_41 = None
        t_default_239 = torch.ops.aten.t.default(t_default_238);  t_default_238 = None
        view_default_420 = torch.ops.aten.view.default(mm_default_82, [8, 1024, 1024]);  mm_default_82 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(add_tensor_78, view_default_420);  add_tensor_78 = view_default_420 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_79, add_tensor_16, [1024], getitem_31, getitem_32, primals_106, primals_105, [True, True, True]);  add_tensor_79 = add_tensor_16 = getitem_31 = getitem_32 = primals_106 = primals_105 = None
        getitem_117 = native_layer_norm_backward_default_14[0]
        getitem_118 = native_layer_norm_backward_default_14[1]
        getitem_119 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_421 = torch.ops.aten.view.default(getitem_117, [8192, 1024])
        t_default_240 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_421, t_default_240);  t_default_240 = None
        t_default_241 = torch.ops.aten.t.default(view_default_421)
        mm_default_85 = torch.ops.aten.mm.default(t_default_241, view_default_104);  t_default_241 = view_default_104 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_421, [0], True);  view_default_421 = None
        view_default_422 = torch.ops.aten.view.default(sum_dim_int_list_42, [1024]);  sum_dim_int_list_42 = None
        t_default_243 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        view_default_423 = torch.ops.aten.view.default(mm_default_84, [8, 1024, 4096]);  mm_default_84 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_423, torch.float32);  view_default_423 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_103, torch.float32);  view_default_103 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_69);  mul_tensor_69 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(add_tensor_80, 0.5);  add_tensor_80 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_72 = torch.ops.aten.mul.Tensor(mul_tensor_71, -0.5);  mul_tensor_71 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_72);  mul_tensor_72 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_73);  to_dtype_22 = mul_tensor_73 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(mul_tensor_70, mul_tensor_74);  mul_tensor_70 = mul_tensor_74 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_81);  to_dtype_21 = add_tensor_81 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_75, torch.float32);  mul_tensor_75 = None
        view_default_424 = torch.ops.aten.view.default(to_dtype_23, [8192, 4096]);  to_dtype_23 = None
        t_default_244 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_424, t_default_244);  t_default_244 = None
        t_default_245 = torch.ops.aten.t.default(view_default_424)
        mm_default_87 = torch.ops.aten.mm.default(t_default_245, view_default_102);  t_default_245 = view_default_102 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_424, [0], True);  view_default_424 = None
        view_default_425 = torch.ops.aten.view.default(sum_dim_int_list_43, [4096]);  sum_dim_int_list_43 = None
        t_default_247 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_426 = torch.ops.aten.view.default(mm_default_86, [8, 1024, 1024]);  mm_default_86 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(getitem_117, view_default_426);  getitem_117 = view_default_426 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_82, add_tensor_15, [1024], getitem_28, getitem_29, primals_110, primals_109, [True, True, True]);  add_tensor_82 = add_tensor_15 = getitem_28 = getitem_29 = primals_110 = primals_109 = None
        getitem_120 = native_layer_norm_backward_default_15[0]
        getitem_121 = native_layer_norm_backward_default_15[1]
        getitem_122 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        view_default_427 = torch.ops.aten.view.default(getitem_120, [8192, 1024])
        t_default_248 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_427, t_default_248);  t_default_248 = None
        t_default_249 = torch.ops.aten.t.default(view_default_427)
        mm_default_89 = torch.ops.aten.mm.default(t_default_249, view_default_100);  t_default_249 = view_default_100 = None
        t_default_250 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_427, [0], True);  view_default_427 = None
        view_default_428 = torch.ops.aten.view.default(sum_dim_int_list_44, [1024]);  sum_dim_int_list_44 = None
        t_default_251 = torch.ops.aten.t.default(t_default_250);  t_default_250 = None
        view_default_429 = torch.ops.aten.view.default(mm_default_88, [8, 1024, 1024]);  mm_default_88 = None
        view_default_430 = torch.ops.aten.view.default(view_default_429, [8, 1024, 16, 64]);  view_default_429 = None
        transpose_int_123 = torch.ops.aten.transpose.int(view_default_430, 1, 2);  view_default_430 = None
        clone_default_76 = torch.ops.aten.clone.default(transpose_int_123, memory_format = torch.contiguous_format);  transpose_int_123 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_76, [128, 1024, 64]);  clone_default_76 = None
        transpose_int_124 = torch.ops.aten.transpose.int(_softmax_default_4, 1, 2)
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_124, _unsafe_view_default_40);  transpose_int_124 = None
        transpose_int_125 = torch.ops.aten.transpose.int(view_default_96, 1, 2);  view_default_96 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_40, transpose_int_125);  _unsafe_view_default_40 = transpose_int_125 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(bmm_default_53, _softmax_default_4, -1, torch.float32);  bmm_default_53 = _softmax_default_4 = None
        view_default_431 = torch.ops.aten.view.default(_softmax_backward_data_default_7, [8, 16, 1024, 1024]);  _softmax_backward_data_default_7 = None
        view_default_432 = torch.ops.aten.view.default(view_default_431, [128, 1024, 1024]);  view_default_431 = None
        transpose_int_126 = torch.ops.aten.transpose.int(view_default_94, 1, 2);  view_default_94 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_126, view_default_432);  transpose_int_126 = None
        transpose_int_127 = torch.ops.aten.transpose.int(transpose_int_23, 1, 2);  transpose_int_23 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_432, transpose_int_127);  view_default_432 = transpose_int_127 = None
        transpose_int_128 = torch.ops.aten.transpose.int(bmm_default_54, 1, 2);  bmm_default_54 = None
        view_default_433 = torch.ops.aten.view.default(bmm_default_52, [8, 16, 1024, 64]);  bmm_default_52 = None
        view_default_434 = torch.ops.aten.view.default(transpose_int_128, [8, 16, 1024, 64]);  transpose_int_128 = None
        view_default_435 = torch.ops.aten.view.default(bmm_default_55, [8, 16, 1024, 64]);  bmm_default_55 = None
        transpose_int_129 = torch.ops.aten.transpose.int(view_default_435, 1, 2);  view_default_435 = None
        clone_default_77 = torch.ops.aten.clone.default(transpose_int_129, memory_format = torch.contiguous_format);  transpose_int_129 = None
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_77, [8, 1024, 1024]);  clone_default_77 = None
        transpose_int_130 = torch.ops.aten.transpose.int(view_default_433, 1, 2);  view_default_433 = None
        clone_default_78 = torch.ops.aten.clone.default(transpose_int_130, memory_format = torch.contiguous_format);  transpose_int_130 = None
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(clone_default_78, [8, 1024, 1024]);  clone_default_78 = None
        view_default_436 = torch.ops.aten.view.default(_unsafe_view_default_42, [8192, 1024]);  _unsafe_view_default_42 = None
        t_default_252 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_436, t_default_252);  t_default_252 = None
        t_default_253 = torch.ops.aten.t.default(view_default_436)
        mm_default_91 = torch.ops.aten.mm.default(t_default_253, view_default_90);  t_default_253 = view_default_90 = None
        t_default_254 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(view_default_436, [0], True);  view_default_436 = None
        view_default_437 = torch.ops.aten.view.default(sum_dim_int_list_45, [1024]);  sum_dim_int_list_45 = None
        t_default_255 = torch.ops.aten.t.default(t_default_254);  t_default_254 = None
        view_default_438 = torch.ops.aten.view.default(mm_default_90, [8, 1024, 1024]);  mm_default_90 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(getitem_120, view_default_438);  getitem_120 = view_default_438 = None
        transpose_int_131 = torch.ops.aten.transpose.int(view_default_434, 1, 2);  view_default_434 = None
        view_default_439 = torch.ops.aten.view.default(transpose_int_131, [8, 1024, 1024]);  transpose_int_131 = None
        clone_default_79 = torch.ops.aten.clone.default(view_default_439, memory_format = torch.contiguous_format);  view_default_439 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_79, [8192, 1024]);  clone_default_79 = None
        t_default_256 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_92 = torch.ops.aten.mm.default(_unsafe_view_default_43, t_default_256);  t_default_256 = None
        t_default_257 = torch.ops.aten.t.default(_unsafe_view_default_43)
        mm_default_93 = torch.ops.aten.mm.default(t_default_257, view_default_87);  t_default_257 = view_default_87 = None
        t_default_258 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_43, [0], True);  _unsafe_view_default_43 = None
        view_default_440 = torch.ops.aten.view.default(sum_dim_int_list_46, [1024]);  sum_dim_int_list_46 = None
        t_default_259 = torch.ops.aten.t.default(t_default_258);  t_default_258 = None
        view_default_441 = torch.ops.aten.view.default(mm_default_92, [8, 1024, 1024]);  mm_default_92 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(add_tensor_83, view_default_441);  add_tensor_83 = view_default_441 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(_unsafe_view_default_41, 0.125);  _unsafe_view_default_41 = None
        view_default_442 = torch.ops.aten.view.default(mul_tensor_76, [8192, 1024]);  mul_tensor_76 = None
        t_default_260 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_442, t_default_260);  t_default_260 = None
        t_default_261 = torch.ops.aten.t.default(view_default_442)
        mm_default_95 = torch.ops.aten.mm.default(t_default_261, view_default_85);  t_default_261 = view_default_85 = None
        t_default_262 = torch.ops.aten.t.default(mm_default_95);  mm_default_95 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(view_default_442, [0], True);  view_default_442 = None
        view_default_443 = torch.ops.aten.view.default(sum_dim_int_list_47, [1024]);  sum_dim_int_list_47 = None
        t_default_263 = torch.ops.aten.t.default(t_default_262);  t_default_262 = None
        view_default_444 = torch.ops.aten.view.default(mm_default_94, [8, 1024, 1024]);  mm_default_94 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(add_tensor_84, view_default_444);  add_tensor_84 = view_default_444 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_85, add_tensor_13, [1024], getitem_25, getitem_26, primals_90, primals_89, [True, True, True]);  add_tensor_85 = add_tensor_13 = getitem_25 = getitem_26 = primals_90 = primals_89 = None
        getitem_123 = native_layer_norm_backward_default_16[0]
        getitem_124 = native_layer_norm_backward_default_16[1]
        getitem_125 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_445 = torch.ops.aten.view.default(getitem_123, [8192, 1024])
        t_default_264 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_445, t_default_264);  t_default_264 = None
        t_default_265 = torch.ops.aten.t.default(view_default_445)
        mm_default_97 = torch.ops.aten.mm.default(t_default_265, view_default_83);  t_default_265 = view_default_83 = None
        t_default_266 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_445, [0], True);  view_default_445 = None
        view_default_446 = torch.ops.aten.view.default(sum_dim_int_list_48, [1024]);  sum_dim_int_list_48 = None
        t_default_267 = torch.ops.aten.t.default(t_default_266);  t_default_266 = None
        view_default_447 = torch.ops.aten.view.default(mm_default_96, [8, 1024, 4096]);  mm_default_96 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_447, torch.float32);  view_default_447 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_82, torch.float32);  view_default_82 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_77);  mul_tensor_77 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(add_tensor_86, 0.5);  add_tensor_86 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_80 = torch.ops.aten.mul.Tensor(mul_tensor_79, -0.5);  mul_tensor_79 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_80);  mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_81);  to_dtype_25 = mul_tensor_81 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(mul_tensor_78, mul_tensor_82);  mul_tensor_78 = mul_tensor_82 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_87);  to_dtype_24 = add_tensor_87 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_83, torch.float32);  mul_tensor_83 = None
        view_default_448 = torch.ops.aten.view.default(to_dtype_26, [8192, 4096]);  to_dtype_26 = None
        t_default_268 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_98 = torch.ops.aten.mm.default(view_default_448, t_default_268);  t_default_268 = None
        t_default_269 = torch.ops.aten.t.default(view_default_448)
        mm_default_99 = torch.ops.aten.mm.default(t_default_269, view_default_81);  t_default_269 = view_default_81 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(view_default_448, [0], True);  view_default_448 = None
        view_default_449 = torch.ops.aten.view.default(sum_dim_int_list_49, [4096]);  sum_dim_int_list_49 = None
        t_default_271 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_450 = torch.ops.aten.view.default(mm_default_98, [8, 1024, 1024]);  mm_default_98 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(getitem_123, view_default_450);  getitem_123 = view_default_450 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_88, add_tensor_12, [1024], getitem_22, getitem_23, primals_94, primals_93, [True, True, True]);  add_tensor_88 = add_tensor_12 = getitem_22 = getitem_23 = primals_94 = primals_93 = None
        getitem_126 = native_layer_norm_backward_default_17[0]
        getitem_127 = native_layer_norm_backward_default_17[1]
        getitem_128 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        view_default_451 = torch.ops.aten.view.default(getitem_126, [8192, 1024])
        t_default_272 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_100 = torch.ops.aten.mm.default(view_default_451, t_default_272);  t_default_272 = None
        t_default_273 = torch.ops.aten.t.default(view_default_451)
        mm_default_101 = torch.ops.aten.mm.default(t_default_273, view_default_79);  t_default_273 = view_default_79 = None
        t_default_274 = torch.ops.aten.t.default(mm_default_101);  mm_default_101 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(view_default_451, [0], True);  view_default_451 = None
        view_default_452 = torch.ops.aten.view.default(sum_dim_int_list_50, [1024]);  sum_dim_int_list_50 = None
        t_default_275 = torch.ops.aten.t.default(t_default_274);  t_default_274 = None
        view_default_453 = torch.ops.aten.view.default(mm_default_100, [8, 1024, 1024]);  mm_default_100 = None
        view_default_454 = torch.ops.aten.view.default(view_default_453, [8, 1024, 16, 64]);  view_default_453 = None
        transpose_int_132 = torch.ops.aten.transpose.int(view_default_454, 1, 2);  view_default_454 = None
        clone_default_80 = torch.ops.aten.clone.default(transpose_int_132, memory_format = torch.contiguous_format);  transpose_int_132 = None
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(clone_default_80, [128, 1024, 64]);  clone_default_80 = None
        transpose_int_133 = torch.ops.aten.transpose.int(_softmax_default_3, 1, 2)
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_133, _unsafe_view_default_44);  transpose_int_133 = None
        transpose_int_134 = torch.ops.aten.transpose.int(view_default_75, 1, 2);  view_default_75 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_44, transpose_int_134);  _unsafe_view_default_44 = transpose_int_134 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(bmm_default_57, _softmax_default_3, -1, torch.float32);  bmm_default_57 = _softmax_default_3 = None
        view_default_455 = torch.ops.aten.view.default(_softmax_backward_data_default_8, [8, 16, 1024, 1024]);  _softmax_backward_data_default_8 = None
        view_default_456 = torch.ops.aten.view.default(view_default_455, [128, 1024, 1024]);  view_default_455 = None
        transpose_int_135 = torch.ops.aten.transpose.int(view_default_73, 1, 2);  view_default_73 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_135, view_default_456);  transpose_int_135 = None
        transpose_int_136 = torch.ops.aten.transpose.int(transpose_int_18, 1, 2);  transpose_int_18 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_456, transpose_int_136);  view_default_456 = transpose_int_136 = None
        transpose_int_137 = torch.ops.aten.transpose.int(bmm_default_58, 1, 2);  bmm_default_58 = None
        view_default_457 = torch.ops.aten.view.default(bmm_default_56, [8, 16, 1024, 64]);  bmm_default_56 = None
        view_default_458 = torch.ops.aten.view.default(transpose_int_137, [8, 16, 1024, 64]);  transpose_int_137 = None
        view_default_459 = torch.ops.aten.view.default(bmm_default_59, [8, 16, 1024, 64]);  bmm_default_59 = None
        transpose_int_138 = torch.ops.aten.transpose.int(view_default_459, 1, 2);  view_default_459 = None
        clone_default_81 = torch.ops.aten.clone.default(transpose_int_138, memory_format = torch.contiguous_format);  transpose_int_138 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_81, [8, 1024, 1024]);  clone_default_81 = None
        transpose_int_139 = torch.ops.aten.transpose.int(view_default_457, 1, 2);  view_default_457 = None
        clone_default_82 = torch.ops.aten.clone.default(transpose_int_139, memory_format = torch.contiguous_format);  transpose_int_139 = None
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(clone_default_82, [8, 1024, 1024]);  clone_default_82 = None
        view_default_460 = torch.ops.aten.view.default(_unsafe_view_default_46, [8192, 1024]);  _unsafe_view_default_46 = None
        t_default_276 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_102 = torch.ops.aten.mm.default(view_default_460, t_default_276);  t_default_276 = None
        t_default_277 = torch.ops.aten.t.default(view_default_460)
        mm_default_103 = torch.ops.aten.mm.default(t_default_277, view_default_69);  t_default_277 = view_default_69 = None
        t_default_278 = torch.ops.aten.t.default(mm_default_103);  mm_default_103 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(view_default_460, [0], True);  view_default_460 = None
        view_default_461 = torch.ops.aten.view.default(sum_dim_int_list_51, [1024]);  sum_dim_int_list_51 = None
        t_default_279 = torch.ops.aten.t.default(t_default_278);  t_default_278 = None
        view_default_462 = torch.ops.aten.view.default(mm_default_102, [8, 1024, 1024]);  mm_default_102 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(getitem_126, view_default_462);  getitem_126 = view_default_462 = None
        transpose_int_140 = torch.ops.aten.transpose.int(view_default_458, 1, 2);  view_default_458 = None
        view_default_463 = torch.ops.aten.view.default(transpose_int_140, [8, 1024, 1024]);  transpose_int_140 = None
        clone_default_83 = torch.ops.aten.clone.default(view_default_463, memory_format = torch.contiguous_format);  view_default_463 = None
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(clone_default_83, [8192, 1024]);  clone_default_83 = None
        t_default_280 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_104 = torch.ops.aten.mm.default(_unsafe_view_default_47, t_default_280);  t_default_280 = None
        t_default_281 = torch.ops.aten.t.default(_unsafe_view_default_47)
        mm_default_105 = torch.ops.aten.mm.default(t_default_281, view_default_66);  t_default_281 = view_default_66 = None
        t_default_282 = torch.ops.aten.t.default(mm_default_105);  mm_default_105 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_47, [0], True);  _unsafe_view_default_47 = None
        view_default_464 = torch.ops.aten.view.default(sum_dim_int_list_52, [1024]);  sum_dim_int_list_52 = None
        t_default_283 = torch.ops.aten.t.default(t_default_282);  t_default_282 = None
        view_default_465 = torch.ops.aten.view.default(mm_default_104, [8, 1024, 1024]);  mm_default_104 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_89, view_default_465);  add_tensor_89 = view_default_465 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(_unsafe_view_default_45, 0.125);  _unsafe_view_default_45 = None
        view_default_466 = torch.ops.aten.view.default(mul_tensor_84, [8192, 1024]);  mul_tensor_84 = None
        t_default_284 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_106 = torch.ops.aten.mm.default(view_default_466, t_default_284);  t_default_284 = None
        t_default_285 = torch.ops.aten.t.default(view_default_466)
        mm_default_107 = torch.ops.aten.mm.default(t_default_285, view_default_64);  t_default_285 = view_default_64 = None
        t_default_286 = torch.ops.aten.t.default(mm_default_107);  mm_default_107 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(view_default_466, [0], True);  view_default_466 = None
        view_default_467 = torch.ops.aten.view.default(sum_dim_int_list_53, [1024]);  sum_dim_int_list_53 = None
        t_default_287 = torch.ops.aten.t.default(t_default_286);  t_default_286 = None
        view_default_468 = torch.ops.aten.view.default(mm_default_106, [8, 1024, 1024]);  mm_default_106 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(add_tensor_90, view_default_468);  add_tensor_90 = view_default_468 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_91, add_tensor_10, [1024], getitem_19, getitem_20, primals_74, primals_73, [True, True, True]);  add_tensor_91 = add_tensor_10 = getitem_19 = getitem_20 = primals_74 = primals_73 = None
        getitem_129 = native_layer_norm_backward_default_18[0]
        getitem_130 = native_layer_norm_backward_default_18[1]
        getitem_131 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        view_default_469 = torch.ops.aten.view.default(getitem_129, [8192, 1024])
        t_default_288 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_469, t_default_288);  t_default_288 = None
        t_default_289 = torch.ops.aten.t.default(view_default_469)
        mm_default_109 = torch.ops.aten.mm.default(t_default_289, view_default_62);  t_default_289 = view_default_62 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(view_default_469, [0], True);  view_default_469 = None
        view_default_470 = torch.ops.aten.view.default(sum_dim_int_list_54, [1024]);  sum_dim_int_list_54 = None
        t_default_291 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_471 = torch.ops.aten.view.default(mm_default_108, [8, 1024, 4096]);  mm_default_108 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_471, torch.float32);  view_default_471 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_61, torch.float32);  view_default_61 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_85);  mul_tensor_85 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(add_tensor_92, 0.5);  add_tensor_92 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_88 = torch.ops.aten.mul.Tensor(mul_tensor_87, -0.5);  mul_tensor_87 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_88);  mul_tensor_88 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_89);  to_dtype_28 = mul_tensor_89 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(mul_tensor_86, mul_tensor_90);  mul_tensor_86 = mul_tensor_90 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_93);  to_dtype_27 = add_tensor_93 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_91, torch.float32);  mul_tensor_91 = None
        view_default_472 = torch.ops.aten.view.default(to_dtype_29, [8192, 4096]);  to_dtype_29 = None
        t_default_292 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_472, t_default_292);  t_default_292 = None
        t_default_293 = torch.ops.aten.t.default(view_default_472)
        mm_default_111 = torch.ops.aten.mm.default(t_default_293, view_default_60);  t_default_293 = view_default_60 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(view_default_472, [0], True);  view_default_472 = None
        view_default_473 = torch.ops.aten.view.default(sum_dim_int_list_55, [4096]);  sum_dim_int_list_55 = None
        t_default_295 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        view_default_474 = torch.ops.aten.view.default(mm_default_110, [8, 1024, 1024]);  mm_default_110 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(getitem_129, view_default_474);  getitem_129 = view_default_474 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_94, add_tensor_9, [1024], getitem_16, getitem_17, primals_78, primals_77, [True, True, True]);  add_tensor_94 = add_tensor_9 = getitem_16 = getitem_17 = primals_78 = primals_77 = None
        getitem_132 = native_layer_norm_backward_default_19[0]
        getitem_133 = native_layer_norm_backward_default_19[1]
        getitem_134 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        view_default_475 = torch.ops.aten.view.default(getitem_132, [8192, 1024])
        t_default_296 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_112 = torch.ops.aten.mm.default(view_default_475, t_default_296);  t_default_296 = None
        t_default_297 = torch.ops.aten.t.default(view_default_475)
        mm_default_113 = torch.ops.aten.mm.default(t_default_297, view_default_58);  t_default_297 = view_default_58 = None
        t_default_298 = torch.ops.aten.t.default(mm_default_113);  mm_default_113 = None
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(view_default_475, [0], True);  view_default_475 = None
        view_default_476 = torch.ops.aten.view.default(sum_dim_int_list_56, [1024]);  sum_dim_int_list_56 = None
        t_default_299 = torch.ops.aten.t.default(t_default_298);  t_default_298 = None
        view_default_477 = torch.ops.aten.view.default(mm_default_112, [8, 1024, 1024]);  mm_default_112 = None
        view_default_478 = torch.ops.aten.view.default(view_default_477, [8, 1024, 16, 64]);  view_default_477 = None
        transpose_int_141 = torch.ops.aten.transpose.int(view_default_478, 1, 2);  view_default_478 = None
        clone_default_84 = torch.ops.aten.clone.default(transpose_int_141, memory_format = torch.contiguous_format);  transpose_int_141 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_84, [128, 1024, 64]);  clone_default_84 = None
        transpose_int_142 = torch.ops.aten.transpose.int(_softmax_default_2, 1, 2)
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_142, _unsafe_view_default_48);  transpose_int_142 = None
        transpose_int_143 = torch.ops.aten.transpose.int(view_default_54, 1, 2);  view_default_54 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_48, transpose_int_143);  _unsafe_view_default_48 = transpose_int_143 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(bmm_default_61, _softmax_default_2, -1, torch.float32);  bmm_default_61 = _softmax_default_2 = None
        view_default_479 = torch.ops.aten.view.default(_softmax_backward_data_default_9, [8, 16, 1024, 1024]);  _softmax_backward_data_default_9 = None
        view_default_480 = torch.ops.aten.view.default(view_default_479, [128, 1024, 1024]);  view_default_479 = None
        transpose_int_144 = torch.ops.aten.transpose.int(view_default_52, 1, 2);  view_default_52 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_144, view_default_480);  transpose_int_144 = None
        transpose_int_145 = torch.ops.aten.transpose.int(transpose_int_13, 1, 2);  transpose_int_13 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_480, transpose_int_145);  view_default_480 = transpose_int_145 = None
        transpose_int_146 = torch.ops.aten.transpose.int(bmm_default_62, 1, 2);  bmm_default_62 = None
        view_default_481 = torch.ops.aten.view.default(bmm_default_60, [8, 16, 1024, 64]);  bmm_default_60 = None
        view_default_482 = torch.ops.aten.view.default(transpose_int_146, [8, 16, 1024, 64]);  transpose_int_146 = None
        view_default_483 = torch.ops.aten.view.default(bmm_default_63, [8, 16, 1024, 64]);  bmm_default_63 = None
        transpose_int_147 = torch.ops.aten.transpose.int(view_default_483, 1, 2);  view_default_483 = None
        clone_default_85 = torch.ops.aten.clone.default(transpose_int_147, memory_format = torch.contiguous_format);  transpose_int_147 = None
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(clone_default_85, [8, 1024, 1024]);  clone_default_85 = None
        transpose_int_148 = torch.ops.aten.transpose.int(view_default_481, 1, 2);  view_default_481 = None
        clone_default_86 = torch.ops.aten.clone.default(transpose_int_148, memory_format = torch.contiguous_format);  transpose_int_148 = None
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(clone_default_86, [8, 1024, 1024]);  clone_default_86 = None
        view_default_484 = torch.ops.aten.view.default(_unsafe_view_default_50, [8192, 1024]);  _unsafe_view_default_50 = None
        t_default_300 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_114 = torch.ops.aten.mm.default(view_default_484, t_default_300);  t_default_300 = None
        t_default_301 = torch.ops.aten.t.default(view_default_484)
        mm_default_115 = torch.ops.aten.mm.default(t_default_301, view_default_48);  t_default_301 = view_default_48 = None
        t_default_302 = torch.ops.aten.t.default(mm_default_115);  mm_default_115 = None
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(view_default_484, [0], True);  view_default_484 = None
        view_default_485 = torch.ops.aten.view.default(sum_dim_int_list_57, [1024]);  sum_dim_int_list_57 = None
        t_default_303 = torch.ops.aten.t.default(t_default_302);  t_default_302 = None
        view_default_486 = torch.ops.aten.view.default(mm_default_114, [8, 1024, 1024]);  mm_default_114 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(getitem_132, view_default_486);  getitem_132 = view_default_486 = None
        transpose_int_149 = torch.ops.aten.transpose.int(view_default_482, 1, 2);  view_default_482 = None
        view_default_487 = torch.ops.aten.view.default(transpose_int_149, [8, 1024, 1024]);  transpose_int_149 = None
        clone_default_87 = torch.ops.aten.clone.default(view_default_487, memory_format = torch.contiguous_format);  view_default_487 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_87, [8192, 1024]);  clone_default_87 = None
        t_default_304 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_116 = torch.ops.aten.mm.default(_unsafe_view_default_51, t_default_304);  t_default_304 = None
        t_default_305 = torch.ops.aten.t.default(_unsafe_view_default_51)
        mm_default_117 = torch.ops.aten.mm.default(t_default_305, view_default_45);  t_default_305 = view_default_45 = None
        t_default_306 = torch.ops.aten.t.default(mm_default_117);  mm_default_117 = None
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_51, [0], True);  _unsafe_view_default_51 = None
        view_default_488 = torch.ops.aten.view.default(sum_dim_int_list_58, [1024]);  sum_dim_int_list_58 = None
        t_default_307 = torch.ops.aten.t.default(t_default_306);  t_default_306 = None
        view_default_489 = torch.ops.aten.view.default(mm_default_116, [8, 1024, 1024]);  mm_default_116 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(add_tensor_95, view_default_489);  add_tensor_95 = view_default_489 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(_unsafe_view_default_49, 0.125);  _unsafe_view_default_49 = None
        view_default_490 = torch.ops.aten.view.default(mul_tensor_92, [8192, 1024]);  mul_tensor_92 = None
        t_default_308 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_118 = torch.ops.aten.mm.default(view_default_490, t_default_308);  t_default_308 = None
        t_default_309 = torch.ops.aten.t.default(view_default_490)
        mm_default_119 = torch.ops.aten.mm.default(t_default_309, view_default_43);  t_default_309 = view_default_43 = None
        t_default_310 = torch.ops.aten.t.default(mm_default_119);  mm_default_119 = None
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(view_default_490, [0], True);  view_default_490 = None
        view_default_491 = torch.ops.aten.view.default(sum_dim_int_list_59, [1024]);  sum_dim_int_list_59 = None
        t_default_311 = torch.ops.aten.t.default(t_default_310);  t_default_310 = None
        view_default_492 = torch.ops.aten.view.default(mm_default_118, [8, 1024, 1024]);  mm_default_118 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(add_tensor_96, view_default_492);  add_tensor_96 = view_default_492 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_97, add_tensor_7, [1024], getitem_13, getitem_14, primals_58, primals_57, [True, True, True]);  add_tensor_97 = add_tensor_7 = getitem_13 = getitem_14 = primals_58 = primals_57 = None
        getitem_135 = native_layer_norm_backward_default_20[0]
        getitem_136 = native_layer_norm_backward_default_20[1]
        getitem_137 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_493 = torch.ops.aten.view.default(getitem_135, [8192, 1024])
        t_default_312 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_493, t_default_312);  t_default_312 = None
        t_default_313 = torch.ops.aten.t.default(view_default_493)
        mm_default_121 = torch.ops.aten.mm.default(t_default_313, view_default_41);  t_default_313 = view_default_41 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(view_default_493, [0], True);  view_default_493 = None
        view_default_494 = torch.ops.aten.view.default(sum_dim_int_list_60, [1024]);  sum_dim_int_list_60 = None
        t_default_315 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_495 = torch.ops.aten.view.default(mm_default_120, [8, 1024, 4096]);  mm_default_120 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_495, torch.float32);  view_default_495 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_40, torch.float32);  view_default_40 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_93);  mul_tensor_93 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(add_tensor_98, 0.5);  add_tensor_98 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_96 = torch.ops.aten.mul.Tensor(mul_tensor_95, -0.5);  mul_tensor_95 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_96);  mul_tensor_96 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_97);  to_dtype_31 = mul_tensor_97 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(mul_tensor_94, mul_tensor_98);  mul_tensor_94 = mul_tensor_98 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_99);  to_dtype_30 = add_tensor_99 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_99, torch.float32);  mul_tensor_99 = None
        view_default_496 = torch.ops.aten.view.default(to_dtype_32, [8192, 4096]);  to_dtype_32 = None
        t_default_316 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_496, t_default_316);  t_default_316 = None
        t_default_317 = torch.ops.aten.t.default(view_default_496)
        mm_default_123 = torch.ops.aten.mm.default(t_default_317, view_default_39);  t_default_317 = view_default_39 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(view_default_496, [0], True);  view_default_496 = None
        view_default_497 = torch.ops.aten.view.default(sum_dim_int_list_61, [4096]);  sum_dim_int_list_61 = None
        t_default_319 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        view_default_498 = torch.ops.aten.view.default(mm_default_122, [8, 1024, 1024]);  mm_default_122 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(getitem_135, view_default_498);  getitem_135 = view_default_498 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_100, add_tensor_6, [1024], getitem_10, getitem_11, primals_62, primals_61, [True, True, True]);  add_tensor_100 = add_tensor_6 = getitem_10 = getitem_11 = primals_62 = primals_61 = None
        getitem_138 = native_layer_norm_backward_default_21[0]
        getitem_139 = native_layer_norm_backward_default_21[1]
        getitem_140 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        view_default_499 = torch.ops.aten.view.default(getitem_138, [8192, 1024])
        t_default_320 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_124 = torch.ops.aten.mm.default(view_default_499, t_default_320);  t_default_320 = None
        t_default_321 = torch.ops.aten.t.default(view_default_499)
        mm_default_125 = torch.ops.aten.mm.default(t_default_321, view_default_37);  t_default_321 = view_default_37 = None
        t_default_322 = torch.ops.aten.t.default(mm_default_125);  mm_default_125 = None
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(view_default_499, [0], True);  view_default_499 = None
        view_default_500 = torch.ops.aten.view.default(sum_dim_int_list_62, [1024]);  sum_dim_int_list_62 = None
        t_default_323 = torch.ops.aten.t.default(t_default_322);  t_default_322 = None
        view_default_501 = torch.ops.aten.view.default(mm_default_124, [8, 1024, 1024]);  mm_default_124 = None
        view_default_502 = torch.ops.aten.view.default(view_default_501, [8, 1024, 16, 64]);  view_default_501 = None
        transpose_int_150 = torch.ops.aten.transpose.int(view_default_502, 1, 2);  view_default_502 = None
        clone_default_88 = torch.ops.aten.clone.default(transpose_int_150, memory_format = torch.contiguous_format);  transpose_int_150 = None
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(clone_default_88, [128, 1024, 64]);  clone_default_88 = None
        transpose_int_151 = torch.ops.aten.transpose.int(_softmax_default_1, 1, 2)
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_151, _unsafe_view_default_52);  transpose_int_151 = None
        transpose_int_152 = torch.ops.aten.transpose.int(view_default_33, 1, 2);  view_default_33 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_52, transpose_int_152);  _unsafe_view_default_52 = transpose_int_152 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(bmm_default_65, _softmax_default_1, -1, torch.float32);  bmm_default_65 = _softmax_default_1 = None
        view_default_503 = torch.ops.aten.view.default(_softmax_backward_data_default_10, [8, 16, 1024, 1024]);  _softmax_backward_data_default_10 = None
        view_default_504 = torch.ops.aten.view.default(view_default_503, [128, 1024, 1024]);  view_default_503 = None
        transpose_int_153 = torch.ops.aten.transpose.int(view_default_31, 1, 2);  view_default_31 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_153, view_default_504);  transpose_int_153 = None
        transpose_int_154 = torch.ops.aten.transpose.int(transpose_int_8, 1, 2);  transpose_int_8 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_504, transpose_int_154);  view_default_504 = transpose_int_154 = None
        transpose_int_155 = torch.ops.aten.transpose.int(bmm_default_66, 1, 2);  bmm_default_66 = None
        view_default_505 = torch.ops.aten.view.default(bmm_default_64, [8, 16, 1024, 64]);  bmm_default_64 = None
        view_default_506 = torch.ops.aten.view.default(transpose_int_155, [8, 16, 1024, 64]);  transpose_int_155 = None
        view_default_507 = torch.ops.aten.view.default(bmm_default_67, [8, 16, 1024, 64]);  bmm_default_67 = None
        transpose_int_156 = torch.ops.aten.transpose.int(view_default_507, 1, 2);  view_default_507 = None
        clone_default_89 = torch.ops.aten.clone.default(transpose_int_156, memory_format = torch.contiguous_format);  transpose_int_156 = None
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(clone_default_89, [8, 1024, 1024]);  clone_default_89 = None
        transpose_int_157 = torch.ops.aten.transpose.int(view_default_505, 1, 2);  view_default_505 = None
        clone_default_90 = torch.ops.aten.clone.default(transpose_int_157, memory_format = torch.contiguous_format);  transpose_int_157 = None
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(clone_default_90, [8, 1024, 1024]);  clone_default_90 = None
        view_default_508 = torch.ops.aten.view.default(_unsafe_view_default_54, [8192, 1024]);  _unsafe_view_default_54 = None
        t_default_324 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_126 = torch.ops.aten.mm.default(view_default_508, t_default_324);  t_default_324 = None
        t_default_325 = torch.ops.aten.t.default(view_default_508)
        mm_default_127 = torch.ops.aten.mm.default(t_default_325, view_default_27);  t_default_325 = view_default_27 = None
        t_default_326 = torch.ops.aten.t.default(mm_default_127);  mm_default_127 = None
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(view_default_508, [0], True);  view_default_508 = None
        view_default_509 = torch.ops.aten.view.default(sum_dim_int_list_63, [1024]);  sum_dim_int_list_63 = None
        t_default_327 = torch.ops.aten.t.default(t_default_326);  t_default_326 = None
        view_default_510 = torch.ops.aten.view.default(mm_default_126, [8, 1024, 1024]);  mm_default_126 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(getitem_138, view_default_510);  getitem_138 = view_default_510 = None
        transpose_int_158 = torch.ops.aten.transpose.int(view_default_506, 1, 2);  view_default_506 = None
        view_default_511 = torch.ops.aten.view.default(transpose_int_158, [8, 1024, 1024]);  transpose_int_158 = None
        clone_default_91 = torch.ops.aten.clone.default(view_default_511, memory_format = torch.contiguous_format);  view_default_511 = None
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(clone_default_91, [8192, 1024]);  clone_default_91 = None
        t_default_328 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_128 = torch.ops.aten.mm.default(_unsafe_view_default_55, t_default_328);  t_default_328 = None
        t_default_329 = torch.ops.aten.t.default(_unsafe_view_default_55)
        mm_default_129 = torch.ops.aten.mm.default(t_default_329, view_default_24);  t_default_329 = view_default_24 = None
        t_default_330 = torch.ops.aten.t.default(mm_default_129);  mm_default_129 = None
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_55, [0], True);  _unsafe_view_default_55 = None
        view_default_512 = torch.ops.aten.view.default(sum_dim_int_list_64, [1024]);  sum_dim_int_list_64 = None
        t_default_331 = torch.ops.aten.t.default(t_default_330);  t_default_330 = None
        view_default_513 = torch.ops.aten.view.default(mm_default_128, [8, 1024, 1024]);  mm_default_128 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(add_tensor_101, view_default_513);  add_tensor_101 = view_default_513 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(_unsafe_view_default_53, 0.125);  _unsafe_view_default_53 = None
        view_default_514 = torch.ops.aten.view.default(mul_tensor_100, [8192, 1024]);  mul_tensor_100 = None
        t_default_332 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_130 = torch.ops.aten.mm.default(view_default_514, t_default_332);  t_default_332 = None
        t_default_333 = torch.ops.aten.t.default(view_default_514)
        mm_default_131 = torch.ops.aten.mm.default(t_default_333, view_default_22);  t_default_333 = view_default_22 = None
        t_default_334 = torch.ops.aten.t.default(mm_default_131);  mm_default_131 = None
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(view_default_514, [0], True);  view_default_514 = None
        view_default_515 = torch.ops.aten.view.default(sum_dim_int_list_65, [1024]);  sum_dim_int_list_65 = None
        t_default_335 = torch.ops.aten.t.default(t_default_334);  t_default_334 = None
        view_default_516 = torch.ops.aten.view.default(mm_default_130, [8, 1024, 1024]);  mm_default_130 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_102, view_default_516);  add_tensor_102 = view_default_516 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_103, add_tensor_4, [1024], getitem_7, getitem_8, primals_10, primals_9, [True, True, True]);  add_tensor_103 = add_tensor_4 = getitem_7 = getitem_8 = primals_10 = primals_9 = None
        getitem_141 = native_layer_norm_backward_default_22[0]
        getitem_142 = native_layer_norm_backward_default_22[1]
        getitem_143 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_517 = torch.ops.aten.view.default(getitem_141, [8192, 1024])
        t_default_336 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_132 = torch.ops.aten.mm.default(view_default_517, t_default_336);  t_default_336 = None
        t_default_337 = torch.ops.aten.t.default(view_default_517)
        mm_default_133 = torch.ops.aten.mm.default(t_default_337, view_default_20);  t_default_337 = view_default_20 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(view_default_517, [0], True);  view_default_517 = None
        view_default_518 = torch.ops.aten.view.default(sum_dim_int_list_66, [1024]);  sum_dim_int_list_66 = None
        t_default_339 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        view_default_519 = torch.ops.aten.view.default(mm_default_132, [8, 1024, 4096]);  mm_default_132 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_519, torch.float32);  view_default_519 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_19, torch.float32);  view_default_19 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_101);  mul_tensor_101 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(add_tensor_104, 0.5);  add_tensor_104 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_104 = torch.ops.aten.mul.Tensor(mul_tensor_103, -0.5);  mul_tensor_103 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_104);  mul_tensor_104 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_105);  to_dtype_34 = mul_tensor_105 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(mul_tensor_102, mul_tensor_106);  mul_tensor_102 = mul_tensor_106 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_105);  to_dtype_33 = add_tensor_105 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_107, torch.float32);  mul_tensor_107 = None
        view_default_520 = torch.ops.aten.view.default(to_dtype_35, [8192, 4096]);  to_dtype_35 = None
        t_default_340 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_520, t_default_340);  t_default_340 = None
        t_default_341 = torch.ops.aten.t.default(view_default_520)
        mm_default_135 = torch.ops.aten.mm.default(t_default_341, view_default_18);  t_default_341 = view_default_18 = None
        t_default_342 = torch.ops.aten.t.default(mm_default_135);  mm_default_135 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(view_default_520, [0], True);  view_default_520 = None
        view_default_521 = torch.ops.aten.view.default(sum_dim_int_list_67, [4096]);  sum_dim_int_list_67 = None
        t_default_343 = torch.ops.aten.t.default(t_default_342);  t_default_342 = None
        view_default_522 = torch.ops.aten.view.default(mm_default_134, [8, 1024, 1024]);  mm_default_134 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(getitem_141, view_default_522);  getitem_141 = view_default_522 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_106, add_tensor_3, [1024], getitem_4, getitem_5, primals_14, primals_13, [True, True, True]);  add_tensor_106 = add_tensor_3 = getitem_4 = getitem_5 = primals_14 = primals_13 = None
        getitem_144 = native_layer_norm_backward_default_23[0]
        getitem_145 = native_layer_norm_backward_default_23[1]
        getitem_146 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        view_default_523 = torch.ops.aten.view.default(getitem_144, [8192, 1024])
        t_default_344 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_136 = torch.ops.aten.mm.default(view_default_523, t_default_344);  t_default_344 = None
        t_default_345 = torch.ops.aten.t.default(view_default_523)
        mm_default_137 = torch.ops.aten.mm.default(t_default_345, view_default_16);  t_default_345 = view_default_16 = None
        t_default_346 = torch.ops.aten.t.default(mm_default_137);  mm_default_137 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(view_default_523, [0], True);  view_default_523 = None
        view_default_524 = torch.ops.aten.view.default(sum_dim_int_list_68, [1024]);  sum_dim_int_list_68 = None
        t_default_347 = torch.ops.aten.t.default(t_default_346);  t_default_346 = None
        view_default_525 = torch.ops.aten.view.default(mm_default_136, [8, 1024, 1024]);  mm_default_136 = None
        view_default_526 = torch.ops.aten.view.default(view_default_525, [8, 1024, 16, 64]);  view_default_525 = None
        transpose_int_159 = torch.ops.aten.transpose.int(view_default_526, 1, 2);  view_default_526 = None
        clone_default_92 = torch.ops.aten.clone.default(transpose_int_159, memory_format = torch.contiguous_format);  transpose_int_159 = None
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(clone_default_92, [128, 1024, 64]);  clone_default_92 = None
        transpose_int_160 = torch.ops.aten.transpose.int(_softmax_default, 1, 2)
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_160, _unsafe_view_default_56);  transpose_int_160 = None
        transpose_int_161 = torch.ops.aten.transpose.int(view_default_12, 1, 2);  view_default_12 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_56, transpose_int_161);  _unsafe_view_default_56 = transpose_int_161 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(bmm_default_69, _softmax_default, -1, torch.float32);  bmm_default_69 = _softmax_default = None
        view_default_527 = torch.ops.aten.view.default(_softmax_backward_data_default_11, [8, 16, 1024, 1024]);  _softmax_backward_data_default_11 = None
        view_default_528 = torch.ops.aten.view.default(view_default_527, [128, 1024, 1024]);  view_default_527 = None
        transpose_int_162 = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_162, view_default_528);  transpose_int_162 = None
        transpose_int_163 = torch.ops.aten.transpose.int(transpose_int_3, 1, 2);  transpose_int_3 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_528, transpose_int_163);  view_default_528 = transpose_int_163 = None
        transpose_int_164 = torch.ops.aten.transpose.int(bmm_default_70, 1, 2);  bmm_default_70 = None
        view_default_529 = torch.ops.aten.view.default(bmm_default_68, [8, 16, 1024, 64]);  bmm_default_68 = None
        view_default_530 = torch.ops.aten.view.default(transpose_int_164, [8, 16, 1024, 64]);  transpose_int_164 = None
        view_default_531 = torch.ops.aten.view.default(bmm_default_71, [8, 16, 1024, 64]);  bmm_default_71 = None
        transpose_int_165 = torch.ops.aten.transpose.int(view_default_531, 1, 2);  view_default_531 = None
        clone_default_93 = torch.ops.aten.clone.default(transpose_int_165, memory_format = torch.contiguous_format);  transpose_int_165 = None
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(clone_default_93, [8, 1024, 1024]);  clone_default_93 = None
        transpose_int_166 = torch.ops.aten.transpose.int(view_default_529, 1, 2);  view_default_529 = None
        clone_default_94 = torch.ops.aten.clone.default(transpose_int_166, memory_format = torch.contiguous_format);  transpose_int_166 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_94, [8, 1024, 1024]);  clone_default_94 = None
        view_default_532 = torch.ops.aten.view.default(_unsafe_view_default_58, [8192, 1024]);  _unsafe_view_default_58 = None
        t_default_348 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_138 = torch.ops.aten.mm.default(view_default_532, t_default_348);  t_default_348 = None
        t_default_349 = torch.ops.aten.t.default(view_default_532)
        mm_default_139 = torch.ops.aten.mm.default(t_default_349, view_default_6);  t_default_349 = view_default_6 = None
        t_default_350 = torch.ops.aten.t.default(mm_default_139);  mm_default_139 = None
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(view_default_532, [0], True);  view_default_532 = None
        view_default_533 = torch.ops.aten.view.default(sum_dim_int_list_69, [1024]);  sum_dim_int_list_69 = None
        t_default_351 = torch.ops.aten.t.default(t_default_350);  t_default_350 = None
        view_default_534 = torch.ops.aten.view.default(mm_default_138, [8, 1024, 1024]);  mm_default_138 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(getitem_144, view_default_534);  getitem_144 = view_default_534 = None
        transpose_int_167 = torch.ops.aten.transpose.int(view_default_530, 1, 2);  view_default_530 = None
        view_default_535 = torch.ops.aten.view.default(transpose_int_167, [8, 1024, 1024]);  transpose_int_167 = None
        clone_default_95 = torch.ops.aten.clone.default(view_default_535, memory_format = torch.contiguous_format);  view_default_535 = None
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(clone_default_95, [8192, 1024]);  clone_default_95 = None
        t_default_352 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_140 = torch.ops.aten.mm.default(_unsafe_view_default_59, t_default_352);  t_default_352 = None
        t_default_353 = torch.ops.aten.t.default(_unsafe_view_default_59)
        mm_default_141 = torch.ops.aten.mm.default(t_default_353, view_default_3);  t_default_353 = view_default_3 = None
        t_default_354 = torch.ops.aten.t.default(mm_default_141);  mm_default_141 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_59, [0], True);  _unsafe_view_default_59 = None
        view_default_536 = torch.ops.aten.view.default(sum_dim_int_list_70, [1024]);  sum_dim_int_list_70 = None
        t_default_355 = torch.ops.aten.t.default(t_default_354);  t_default_354 = None
        view_default_537 = torch.ops.aten.view.default(mm_default_140, [8, 1024, 1024]);  mm_default_140 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(add_tensor_107, view_default_537);  add_tensor_107 = view_default_537 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(_unsafe_view_default_57, 0.125);  _unsafe_view_default_57 = None
        view_default_538 = torch.ops.aten.view.default(mul_tensor_108, [8192, 1024]);  mul_tensor_108 = None
        t_default_356 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_142 = torch.ops.aten.mm.default(view_default_538, t_default_356);  t_default_356 = None
        t_default_357 = torch.ops.aten.t.default(view_default_538)
        mm_default_143 = torch.ops.aten.mm.default(t_default_357, view_default_1);  t_default_357 = view_default_1 = None
        t_default_358 = torch.ops.aten.t.default(mm_default_143);  mm_default_143 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(view_default_538, [0], True);  view_default_538 = None
        view_default_539 = torch.ops.aten.view.default(sum_dim_int_list_71, [1024]);  sum_dim_int_list_71 = None
        t_default_359 = torch.ops.aten.t.default(t_default_358);  t_default_358 = None
        view_default_540 = torch.ops.aten.view.default(mm_default_142, [8, 1024, 1024]);  mm_default_142 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(add_tensor_108, view_default_540);  add_tensor_108 = view_default_540 = None
        native_layer_norm_backward_default_24 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_109, add_tensor_1, [1024], getitem_1, getitem_2, primals_4, primals_3, [True, True, True]);  add_tensor_109 = add_tensor_1 = getitem_1 = getitem_2 = primals_4 = primals_3 = None
        getitem_147 = native_layer_norm_backward_default_24[0]
        getitem_148 = native_layer_norm_backward_default_24[1]
        getitem_149 = native_layer_norm_backward_default_24[2];  native_layer_norm_backward_default_24 = None
        sum_dim_int_list_72 = torch.ops.aten.sum.dim_IntList(getitem_147, [0], True)
        view_default_541 = torch.ops.aten.view.default(sum_dim_int_list_72, [1024, 1024]);  sum_dim_int_list_72 = None
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(view_default_541, add_tensor, 1026, -1, False);  view_default_541 = add_tensor = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(getitem_147, 1.0);  getitem_147 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(mul_tensor_109, view_default, 50265, 1, False);  mul_tensor_109 = view_default = None
        return [embedding_dense_backward_default, embedding_dense_backward_default_1, getitem_149, getitem_148, view_default_521, t_default_343, view_default_518, t_default_339, getitem_143, getitem_142, view_default_536, t_default_355, getitem_146, getitem_145, view_default_524, t_default_347, view_default_539, t_default_359, view_default_533, t_default_351, view_default_281, t_default_103, view_default_278, t_default_99, getitem_83, getitem_82, view_default_296, t_default_115, getitem_86, getitem_85, view_default_284, t_default_107, view_default_299, t_default_119, view_default_293, t_default_111, view_default_257, t_default_79, view_default_254, t_default_75, getitem_77, getitem_76, view_default_272, t_default_91, getitem_80, getitem_79, view_default_260, t_default_83, view_default_275, t_default_95, view_default_269, t_default_87, view_default_497, t_default_319, view_default_494, t_default_315, getitem_137, getitem_136, view_default_512, t_default_331, getitem_140, getitem_139, view_default_500, t_default_323, view_default_515, t_default_335, view_default_509, t_default_327, view_default_473, t_default_295, view_default_470, t_default_291, getitem_131, getitem_130, view_default_488, t_default_307, getitem_134, getitem_133, view_default_476, t_default_299, view_default_491, t_default_311, view_default_485, t_default_303, view_default_449, t_default_271, view_default_446, t_default_267, getitem_125, getitem_124, view_default_464, t_default_283, getitem_128, getitem_127, view_default_452, t_default_275, view_default_467, t_default_287, view_default_461, t_default_279, view_default_425, t_default_247, view_default_422, t_default_243, getitem_119, getitem_118, view_default_440, t_default_259, getitem_122, getitem_121, view_default_428, t_default_251, view_default_443, t_default_263, view_default_437, t_default_255, view_default_401, t_default_223, view_default_398, t_default_219, getitem_113, getitem_112, view_default_416, t_default_235, getitem_116, getitem_115, view_default_404, t_default_227, view_default_419, t_default_239, view_default_413, t_default_231, view_default_377, t_default_199, view_default_374, t_default_195, getitem_107, getitem_106, view_default_392, t_default_211, getitem_110, getitem_109, view_default_380, t_default_203, view_default_395, t_default_215, view_default_389, t_default_207, view_default_353, t_default_175, view_default_350, t_default_171, getitem_101, getitem_100, view_default_368, t_default_187, getitem_104, getitem_103, view_default_356, t_default_179, view_default_371, t_default_191, view_default_365, t_default_183, view_default_329, t_default_151, view_default_326, t_default_147, getitem_95, getitem_94, view_default_344, t_default_163, getitem_98, getitem_97, view_default_332, t_default_155, view_default_347, t_default_167, view_default_341, t_default_159, view_default_305, t_default_127, view_default_302, t_default_123, getitem_89, getitem_88, view_default_320, t_default_139, getitem_92, getitem_91, view_default_308, t_default_131, view_default_323, t_default_143, view_default_317, t_default_135, None, None]
        
