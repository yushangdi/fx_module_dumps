
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer('_tensor_constant0', torch.empty([], dtype=torch.int64))
        self.load_state_dict(torch.load(r'huggingface_graphs/BartForConditionalGeneration_bart/BartForConditionalGeneration_bart_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, tangents_1):
        new_empty_default = torch.ops.aten.new_empty.default(primals_1, [8, 128], device = device(type='cuda', index=0), dtype = torch.int64, layout = torch.strided, pin_memory = False)
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, -1);  slice_tensor = None
        clone_default = torch.ops.aten.clone.default(slice_tensor_1);  slice_tensor_1 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(zero__default, 0, 0, 9223372036854775807)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 1, 1, 9223372036854775807);  slice_tensor_2 = None
        copy__default = torch.ops.aten.copy_.default(slice_tensor_3, clone_default);  slice_tensor_3 = clone_default = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(zero__default, 0, 0, 9223372036854775807)
        select_int = torch.ops.aten.select.int(slice_tensor_4, 1, 0);  slice_tensor_4 = None
        _tensor_constant0 = self._tensor_constant0
        fill__tensor = torch.ops.aten.fill_.Tensor(select_int, _tensor_constant0);  select_int = _tensor_constant0 = None
        eq_scalar = torch.ops.aten.eq.Scalar(zero__default, -100)
        masked_fill__scalar = torch.ops.aten.masked_fill_.Scalar(zero__default, eq_scalar, 1);  zero__default = eq_scalar = None
        return [masked_fill__scalar, None]
        
