
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/BartForConditionalGeneration_bart/BartForConditionalGeneration_bart_forward_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319):
        view_default = torch.ops.aten.view.default(primals_317, [-1, 128]);  primals_317 = None
        embedding_default = torch.ops.aten.embedding.default(primals_2, view_default, 1);  primals_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(embedding_default, 1.0);  embedding_default = None
        full = torch.ops.aten.full.default([128, 128], -inf, layout = torch.strided, device = device(type='cpu'), pin_memory = False)
        arange = torch.ops.aten.arange.default(128, layout = torch.strided, device = device(type='cpu'), pin_memory = False)
        add_tensor = torch.ops.aten.add.Tensor(arange, 1)
        view_default_1 = torch.ops.aten.view.default(add_tensor, [128, 1]);  add_tensor = None
        lt_tensor = torch.ops.aten.lt.Tensor(arange, view_default_1);  arange = view_default_1 = None
        masked_fill__scalar = torch.ops.aten.masked_fill_.Scalar(full, lt_tensor, 0);  full = lt_tensor = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(masked_fill__scalar, 0);  masked_fill__scalar = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1);  unsqueeze_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(unsqueeze_default_1, 2, 0, 9223372036854775807);  unsqueeze_default_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 3, 0, 9223372036854775807);  slice_tensor = None
        expand_sym_int = torch.ops.aten.expand.SymInt(slice_tensor_1, [8, 1, 128, 128]);  slice_tensor_1 = None
        _to_copy_default = torch.ops.aten._to_copy.default(expand_sym_int, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  expand_sym_int = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(primals_319, 0, 0, 9223372036854775807);  primals_319 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(slice_tensor_2, 1);  slice_tensor_2 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default_2, 2);  unsqueeze_default_2 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(unsqueeze_default_3, 3, 0, 9223372036854775807);  unsqueeze_default_3 = None
        expand_sym_int_1 = torch.ops.aten.expand.SymInt(slice_tensor_3, [8, 1, 128, 1024]);  slice_tensor_3 = None
        _to_copy_default_1 = torch.ops.aten._to_copy.default(expand_sym_int_1, dtype = torch.float32);  expand_sym_int_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(_to_copy_default_1, 1.0);  _to_copy_default_1 = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(rsub_scalar, dtype = torch.bool)
        where_scalar_self = torch.ops.aten.where.ScalarSelf(_to_copy_default_2, -3.4028234663852886e+38, rsub_scalar);  _to_copy_default_2 = rsub_scalar = None
        arange_1 = torch.ops.aten.arange.start_step(0, 128, 1, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        add_tensor_1 = torch.ops.aten.add.Tensor(arange_1, 2);  arange_1 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_1, add_tensor_1);  primals_1 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor, embedding_default_1);  mul_tensor = embedding_default_1 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_2, [1024], primals_4, primals_3, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [1024, 1024])
        t_default = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default = torch.ops.aten.addmm.default(primals_27, view_default_2, t_default);  primals_27 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default, [8, 128, 1024]);  addmm_default = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(view_default_3, 0.125);  view_default_3 = None
        view_default_4 = torch.ops.aten.view.default(getitem, [1024, 1024])
        t_default_1 = torch.ops.aten.t.default(primals_22);  primals_22 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_21, view_default_4, t_default_1);  primals_21 = None
        view_default_5 = torch.ops.aten.view.default(addmm_default_1, [8, 128, 1024]);  addmm_default_1 = None
        view_default_6 = torch.ops.aten.view.default(view_default_5, [8, -1, 16, 64]);  view_default_5 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        clone_default = torch.ops.aten.clone.default(transpose_int, memory_format = torch.contiguous_format);  transpose_int = None
        view_default_7 = torch.ops.aten.view.default(getitem, [1024, 1024])
        t_default_2 = torch.ops.aten.t.default(primals_30);  primals_30 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_29, view_default_7, t_default_2);  primals_29 = None
        view_default_8 = torch.ops.aten.view.default(addmm_default_2, [8, 128, 1024]);  addmm_default_2 = None
        view_default_9 = torch.ops.aten.view.default(view_default_8, [8, -1, 16, 64]);  view_default_8 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_9, 1, 2);  view_default_9 = None
        clone_default_1 = torch.ops.aten.clone.default(transpose_int_1, memory_format = torch.contiguous_format);  transpose_int_1 = None
        view_default_10 = torch.ops.aten.view.default(mul_tensor_1, [8, 128, 16, 64]);  mul_tensor_1 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        clone_default_2 = torch.ops.aten.clone.default(transpose_int_2, memory_format = torch.contiguous_format);  transpose_int_2 = None
        view_default_11 = torch.ops.aten.view.default(clone_default_2, [128, -1, 64]);  clone_default_2 = None
        view_default_12 = torch.ops.aten.view.default(clone_default, [128, -1, 64])
        view_default_13 = torch.ops.aten.view.default(clone_default_1, [128, -1, 64])
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_12, 1, 2);  view_default_12 = None
        bmm_default = torch.ops.aten.bmm.default(view_default_11, transpose_int_3)
        view_default_14 = torch.ops.aten.view.default(bmm_default, [8, 16, 128, 128]);  bmm_default = None
        add_tensor_3 = torch.ops.aten.add.Tensor(view_default_14, _to_copy_default);  view_default_14 = None
        view_default_15 = torch.ops.aten.view.default(add_tensor_3, [128, 128, 128]);  add_tensor_3 = None
        _softmax_default = torch.ops.aten._softmax.default(view_default_15, -1, False);  view_default_15 = None
        bmm_default_1 = torch.ops.aten.bmm.default(_softmax_default, view_default_13)
        view_default_16 = torch.ops.aten.view.default(bmm_default_1, [8, 16, 128, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_3, [8, 128, 1024]);  clone_default_3 = None
        view_default_17 = torch.ops.aten.view.default(_unsafe_view_default, [1024, 1024]);  _unsafe_view_default = None
        t_default_3 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_25, view_default_17, t_default_3);  primals_25 = None
        view_default_18 = torch.ops.aten.view.default(addmm_default_3, [8, 128, 1024]);  addmm_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem, view_default_18);  getitem = view_default_18 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [1024], primals_24, primals_23, 1e-05)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_19 = torch.ops.aten.view.default(getitem_3, [1024, 1024])
        t_default_4 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_11, view_default_19, t_default_4);  primals_11 = None
        view_default_20 = torch.ops.aten.view.default(addmm_default_4, [8, 128, 1024]);  addmm_default_4 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(view_default_20, 0.125);  view_default_20 = None
        view_default_21 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_5 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_5, view_default_21, t_default_5);  primals_5 = None
        view_default_22 = torch.ops.aten.view.default(addmm_default_5, [8, 1024, 1024]);  addmm_default_5 = None
        view_default_23 = torch.ops.aten.view.default(view_default_22, [8, -1, 16, 64]);  view_default_22 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_23, 1, 2);  view_default_23 = None
        clone_default_4 = torch.ops.aten.clone.default(transpose_int_5, memory_format = torch.contiguous_format);  transpose_int_5 = None
        view_default_24 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_6 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_13, view_default_24, t_default_6);  primals_13 = None
        view_default_25 = torch.ops.aten.view.default(addmm_default_6, [8, 1024, 1024]);  addmm_default_6 = None
        view_default_26 = torch.ops.aten.view.default(view_default_25, [8, -1, 16, 64]);  view_default_25 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        clone_default_5 = torch.ops.aten.clone.default(transpose_int_6, memory_format = torch.contiguous_format);  transpose_int_6 = None
        view_default_27 = torch.ops.aten.view.default(mul_tensor_2, [8, 128, 16, 64]);  mul_tensor_2 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_27, 1, 2);  view_default_27 = None
        clone_default_6 = torch.ops.aten.clone.default(transpose_int_7, memory_format = torch.contiguous_format);  transpose_int_7 = None
        view_default_28 = torch.ops.aten.view.default(clone_default_6, [128, -1, 64]);  clone_default_6 = None
        view_default_29 = torch.ops.aten.view.default(clone_default_4, [128, -1, 64])
        view_default_30 = torch.ops.aten.view.default(clone_default_5, [128, -1, 64])
        transpose_int_8 = torch.ops.aten.transpose.int(view_default_29, 1, 2);  view_default_29 = None
        bmm_default_2 = torch.ops.aten.bmm.default(view_default_28, transpose_int_8)
        view_default_31 = torch.ops.aten.view.default(bmm_default_2, [8, 16, 128, 1024]);  bmm_default_2 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(view_default_31, where_scalar_self);  view_default_31 = None
        view_default_32 = torch.ops.aten.view.default(add_tensor_5, [128, 128, 1024]);  add_tensor_5 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(view_default_32, -1, False);  view_default_32 = None
        bmm_default_3 = torch.ops.aten.bmm.default(_softmax_default_1, view_default_30)
        view_default_33 = torch.ops.aten.view.default(bmm_default_3, [8, 16, 128, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(view_default_33, 1, 2);  view_default_33 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_7, [8, 128, 1024]);  clone_default_7 = None
        view_default_34 = torch.ops.aten.view.default(_unsafe_view_default_1, [1024, 1024]);  _unsafe_view_default_1 = None
        t_default_7 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_9, view_default_34, t_default_7);  primals_9 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_7, [8, 128, 1024]);  addmm_default_7 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_3, view_default_35);  getitem_3 = view_default_35 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_6, [1024], primals_8, primals_7, 1e-05)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_36 = torch.ops.aten.view.default(getitem_6, [1024, 1024])
        t_default_8 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_15, view_default_36, t_default_8);  primals_15 = None
        view_default_37 = torch.ops.aten.view.default(addmm_default_8, [8, 128, 4096]);  addmm_default_8 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_37)
        view_default_38 = torch.ops.aten.view.default(gelu_default, [1024, 4096]);  gelu_default = None
        t_default_9 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_17, view_default_38, t_default_9);  primals_17 = None
        view_default_39 = torch.ops.aten.view.default(addmm_default_9, [8, 128, 1024]);  addmm_default_9 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_6, view_default_39);  getitem_6 = view_default_39 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_7, [1024], primals_20, primals_19, 1e-05)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_40 = torch.ops.aten.view.default(getitem_9, [1024, 1024])
        t_default_10 = torch.ops.aten.t.default(primals_106);  primals_106 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_105, view_default_40, t_default_10);  primals_105 = None
        view_default_41 = torch.ops.aten.view.default(addmm_default_10, [8, 128, 1024]);  addmm_default_10 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(view_default_41, 0.125);  view_default_41 = None
        view_default_42 = torch.ops.aten.view.default(getitem_9, [1024, 1024])
        t_default_11 = torch.ops.aten.t.default(primals_100);  primals_100 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_99, view_default_42, t_default_11);  primals_99 = None
        view_default_43 = torch.ops.aten.view.default(addmm_default_11, [8, 128, 1024]);  addmm_default_11 = None
        view_default_44 = torch.ops.aten.view.default(view_default_43, [8, -1, 16, 64]);  view_default_43 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_44, 1, 2);  view_default_44 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_10, memory_format = torch.contiguous_format);  transpose_int_10 = None
        view_default_45 = torch.ops.aten.view.default(getitem_9, [1024, 1024])
        t_default_12 = torch.ops.aten.t.default(primals_108);  primals_108 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_107, view_default_45, t_default_12);  primals_107 = None
        view_default_46 = torch.ops.aten.view.default(addmm_default_12, [8, 128, 1024]);  addmm_default_12 = None
        view_default_47 = torch.ops.aten.view.default(view_default_46, [8, -1, 16, 64]);  view_default_46 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_47, 1, 2);  view_default_47 = None
        clone_default_9 = torch.ops.aten.clone.default(transpose_int_11, memory_format = torch.contiguous_format);  transpose_int_11 = None
        view_default_48 = torch.ops.aten.view.default(mul_tensor_3, [8, 128, 16, 64]);  mul_tensor_3 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_48, 1, 2);  view_default_48 = None
        clone_default_10 = torch.ops.aten.clone.default(transpose_int_12, memory_format = torch.contiguous_format);  transpose_int_12 = None
        view_default_49 = torch.ops.aten.view.default(clone_default_10, [128, -1, 64]);  clone_default_10 = None
        view_default_50 = torch.ops.aten.view.default(clone_default_8, [128, -1, 64])
        view_default_51 = torch.ops.aten.view.default(clone_default_9, [128, -1, 64])
        transpose_int_13 = torch.ops.aten.transpose.int(view_default_50, 1, 2);  view_default_50 = None
        bmm_default_4 = torch.ops.aten.bmm.default(view_default_49, transpose_int_13)
        view_default_52 = torch.ops.aten.view.default(bmm_default_4, [8, 16, 128, 128]);  bmm_default_4 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(view_default_52, _to_copy_default);  view_default_52 = None
        view_default_53 = torch.ops.aten.view.default(add_tensor_8, [128, 128, 128]);  add_tensor_8 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(view_default_53, -1, False);  view_default_53 = None
        bmm_default_5 = torch.ops.aten.bmm.default(_softmax_default_2, view_default_51)
        view_default_54 = torch.ops.aten.view.default(bmm_default_5, [8, 16, 128, 64]);  bmm_default_5 = None
        transpose_int_14 = torch.ops.aten.transpose.int(view_default_54, 1, 2);  view_default_54 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_11, [8, 128, 1024]);  clone_default_11 = None
        view_default_55 = torch.ops.aten.view.default(_unsafe_view_default_2, [1024, 1024]);  _unsafe_view_default_2 = None
        t_default_13 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_103, view_default_55, t_default_13);  primals_103 = None
        view_default_56 = torch.ops.aten.view.default(addmm_default_13, [8, 128, 1024]);  addmm_default_13 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_9, view_default_56);  getitem_9 = view_default_56 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_9, [1024], primals_102, primals_101, 1e-05)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_57 = torch.ops.aten.view.default(getitem_12, [1024, 1024])
        t_default_14 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_89, view_default_57, t_default_14);  primals_89 = None
        view_default_58 = torch.ops.aten.view.default(addmm_default_14, [8, 128, 1024]);  addmm_default_14 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(view_default_58, 0.125);  view_default_58 = None
        view_default_59 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_15 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_83, view_default_59, t_default_15);  primals_83 = None
        view_default_60 = torch.ops.aten.view.default(addmm_default_15, [8, 1024, 1024]);  addmm_default_15 = None
        view_default_61 = torch.ops.aten.view.default(view_default_60, [8, -1, 16, 64]);  view_default_60 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_61, 1, 2);  view_default_61 = None
        clone_default_12 = torch.ops.aten.clone.default(transpose_int_15, memory_format = torch.contiguous_format);  transpose_int_15 = None
        view_default_62 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_16 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_91, view_default_62, t_default_16);  primals_91 = None
        view_default_63 = torch.ops.aten.view.default(addmm_default_16, [8, 1024, 1024]);  addmm_default_16 = None
        view_default_64 = torch.ops.aten.view.default(view_default_63, [8, -1, 16, 64]);  view_default_63 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_64, 1, 2);  view_default_64 = None
        clone_default_13 = torch.ops.aten.clone.default(transpose_int_16, memory_format = torch.contiguous_format);  transpose_int_16 = None
        view_default_65 = torch.ops.aten.view.default(mul_tensor_4, [8, 128, 16, 64]);  mul_tensor_4 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_65, 1, 2);  view_default_65 = None
        clone_default_14 = torch.ops.aten.clone.default(transpose_int_17, memory_format = torch.contiguous_format);  transpose_int_17 = None
        view_default_66 = torch.ops.aten.view.default(clone_default_14, [128, -1, 64]);  clone_default_14 = None
        view_default_67 = torch.ops.aten.view.default(clone_default_12, [128, -1, 64])
        view_default_68 = torch.ops.aten.view.default(clone_default_13, [128, -1, 64])
        transpose_int_18 = torch.ops.aten.transpose.int(view_default_67, 1, 2);  view_default_67 = None
        bmm_default_6 = torch.ops.aten.bmm.default(view_default_66, transpose_int_18)
        view_default_69 = torch.ops.aten.view.default(bmm_default_6, [8, 16, 128, 1024]);  bmm_default_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(view_default_69, where_scalar_self);  view_default_69 = None
        view_default_70 = torch.ops.aten.view.default(add_tensor_10, [128, 128, 1024]);  add_tensor_10 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(view_default_70, -1, False);  view_default_70 = None
        bmm_default_7 = torch.ops.aten.bmm.default(_softmax_default_3, view_default_68)
        view_default_71 = torch.ops.aten.view.default(bmm_default_7, [8, 16, 128, 64]);  bmm_default_7 = None
        transpose_int_19 = torch.ops.aten.transpose.int(view_default_71, 1, 2);  view_default_71 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_15, [8, 128, 1024]);  clone_default_15 = None
        view_default_72 = torch.ops.aten.view.default(_unsafe_view_default_3, [1024, 1024]);  _unsafe_view_default_3 = None
        t_default_17 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_87, view_default_72, t_default_17);  primals_87 = None
        view_default_73 = torch.ops.aten.view.default(addmm_default_17, [8, 128, 1024]);  addmm_default_17 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_12, view_default_73);  getitem_12 = view_default_73 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_11, [1024], primals_86, primals_85, 1e-05)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_74 = torch.ops.aten.view.default(getitem_15, [1024, 1024])
        t_default_18 = torch.ops.aten.t.default(primals_94);  primals_94 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_93, view_default_74, t_default_18);  primals_93 = None
        view_default_75 = torch.ops.aten.view.default(addmm_default_18, [8, 128, 4096]);  addmm_default_18 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_75)
        view_default_76 = torch.ops.aten.view.default(gelu_default_1, [1024, 4096]);  gelu_default_1 = None
        t_default_19 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_95, view_default_76, t_default_19);  primals_95 = None
        view_default_77 = torch.ops.aten.view.default(addmm_default_19, [8, 128, 1024]);  addmm_default_19 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_15, view_default_77);  getitem_15 = view_default_77 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_12, [1024], primals_98, primals_97, 1e-05)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_78 = torch.ops.aten.view.default(getitem_18, [1024, 1024])
        t_default_20 = torch.ops.aten.t.default(primals_132);  primals_132 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_131, view_default_78, t_default_20);  primals_131 = None
        view_default_79 = torch.ops.aten.view.default(addmm_default_20, [8, 128, 1024]);  addmm_default_20 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(view_default_79, 0.125);  view_default_79 = None
        view_default_80 = torch.ops.aten.view.default(getitem_18, [1024, 1024])
        t_default_21 = torch.ops.aten.t.default(primals_126);  primals_126 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_125, view_default_80, t_default_21);  primals_125 = None
        view_default_81 = torch.ops.aten.view.default(addmm_default_21, [8, 128, 1024]);  addmm_default_21 = None
        view_default_82 = torch.ops.aten.view.default(view_default_81, [8, -1, 16, 64]);  view_default_81 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_82, 1, 2);  view_default_82 = None
        clone_default_16 = torch.ops.aten.clone.default(transpose_int_20, memory_format = torch.contiguous_format);  transpose_int_20 = None
        view_default_83 = torch.ops.aten.view.default(getitem_18, [1024, 1024])
        t_default_22 = torch.ops.aten.t.default(primals_134);  primals_134 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_133, view_default_83, t_default_22);  primals_133 = None
        view_default_84 = torch.ops.aten.view.default(addmm_default_22, [8, 128, 1024]);  addmm_default_22 = None
        view_default_85 = torch.ops.aten.view.default(view_default_84, [8, -1, 16, 64]);  view_default_84 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_85, 1, 2);  view_default_85 = None
        clone_default_17 = torch.ops.aten.clone.default(transpose_int_21, memory_format = torch.contiguous_format);  transpose_int_21 = None
        view_default_86 = torch.ops.aten.view.default(mul_tensor_5, [8, 128, 16, 64]);  mul_tensor_5 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_86, 1, 2);  view_default_86 = None
        clone_default_18 = torch.ops.aten.clone.default(transpose_int_22, memory_format = torch.contiguous_format);  transpose_int_22 = None
        view_default_87 = torch.ops.aten.view.default(clone_default_18, [128, -1, 64]);  clone_default_18 = None
        view_default_88 = torch.ops.aten.view.default(clone_default_16, [128, -1, 64])
        view_default_89 = torch.ops.aten.view.default(clone_default_17, [128, -1, 64])
        transpose_int_23 = torch.ops.aten.transpose.int(view_default_88, 1, 2);  view_default_88 = None
        bmm_default_8 = torch.ops.aten.bmm.default(view_default_87, transpose_int_23)
        view_default_90 = torch.ops.aten.view.default(bmm_default_8, [8, 16, 128, 128]);  bmm_default_8 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(view_default_90, _to_copy_default);  view_default_90 = None
        view_default_91 = torch.ops.aten.view.default(add_tensor_13, [128, 128, 128]);  add_tensor_13 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(view_default_91, -1, False);  view_default_91 = None
        bmm_default_9 = torch.ops.aten.bmm.default(_softmax_default_4, view_default_89)
        view_default_92 = torch.ops.aten.view.default(bmm_default_9, [8, 16, 128, 64]);  bmm_default_9 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_92, 1, 2);  view_default_92 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_19, [8, 128, 1024]);  clone_default_19 = None
        view_default_93 = torch.ops.aten.view.default(_unsafe_view_default_4, [1024, 1024]);  _unsafe_view_default_4 = None
        t_default_23 = torch.ops.aten.t.default(primals_130);  primals_130 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_129, view_default_93, t_default_23);  primals_129 = None
        view_default_94 = torch.ops.aten.view.default(addmm_default_23, [8, 128, 1024]);  addmm_default_23 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_18, view_default_94);  getitem_18 = view_default_94 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_14, [1024], primals_128, primals_127, 1e-05)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_95 = torch.ops.aten.view.default(getitem_21, [1024, 1024])
        t_default_24 = torch.ops.aten.t.default(primals_116);  primals_116 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_115, view_default_95, t_default_24);  primals_115 = None
        view_default_96 = torch.ops.aten.view.default(addmm_default_24, [8, 128, 1024]);  addmm_default_24 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(view_default_96, 0.125);  view_default_96 = None
        view_default_97 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_25 = torch.ops.aten.t.default(primals_110);  primals_110 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_109, view_default_97, t_default_25);  primals_109 = None
        view_default_98 = torch.ops.aten.view.default(addmm_default_25, [8, 1024, 1024]);  addmm_default_25 = None
        view_default_99 = torch.ops.aten.view.default(view_default_98, [8, -1, 16, 64]);  view_default_98 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_99, 1, 2);  view_default_99 = None
        clone_default_20 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        view_default_100 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_26 = torch.ops.aten.t.default(primals_118);  primals_118 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_117, view_default_100, t_default_26);  primals_117 = None
        view_default_101 = torch.ops.aten.view.default(addmm_default_26, [8, 1024, 1024]);  addmm_default_26 = None
        view_default_102 = torch.ops.aten.view.default(view_default_101, [8, -1, 16, 64]);  view_default_101 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_102, 1, 2);  view_default_102 = None
        clone_default_21 = torch.ops.aten.clone.default(transpose_int_26, memory_format = torch.contiguous_format);  transpose_int_26 = None
        view_default_103 = torch.ops.aten.view.default(mul_tensor_6, [8, 128, 16, 64]);  mul_tensor_6 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_103, 1, 2);  view_default_103 = None
        clone_default_22 = torch.ops.aten.clone.default(transpose_int_27, memory_format = torch.contiguous_format);  transpose_int_27 = None
        view_default_104 = torch.ops.aten.view.default(clone_default_22, [128, -1, 64]);  clone_default_22 = None
        view_default_105 = torch.ops.aten.view.default(clone_default_20, [128, -1, 64])
        view_default_106 = torch.ops.aten.view.default(clone_default_21, [128, -1, 64])
        transpose_int_28 = torch.ops.aten.transpose.int(view_default_105, 1, 2);  view_default_105 = None
        bmm_default_10 = torch.ops.aten.bmm.default(view_default_104, transpose_int_28)
        view_default_107 = torch.ops.aten.view.default(bmm_default_10, [8, 16, 128, 1024]);  bmm_default_10 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(view_default_107, where_scalar_self);  view_default_107 = None
        view_default_108 = torch.ops.aten.view.default(add_tensor_15, [128, 128, 1024]);  add_tensor_15 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(view_default_108, -1, False);  view_default_108 = None
        bmm_default_11 = torch.ops.aten.bmm.default(_softmax_default_5, view_default_106)
        view_default_109 = torch.ops.aten.view.default(bmm_default_11, [8, 16, 128, 64]);  bmm_default_11 = None
        transpose_int_29 = torch.ops.aten.transpose.int(view_default_109, 1, 2);  view_default_109 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_23, [8, 128, 1024]);  clone_default_23 = None
        view_default_110 = torch.ops.aten.view.default(_unsafe_view_default_5, [1024, 1024]);  _unsafe_view_default_5 = None
        t_default_27 = torch.ops.aten.t.default(primals_114);  primals_114 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_113, view_default_110, t_default_27);  primals_113 = None
        view_default_111 = torch.ops.aten.view.default(addmm_default_27, [8, 128, 1024]);  addmm_default_27 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_21, view_default_111);  getitem_21 = view_default_111 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_16, [1024], primals_112, primals_111, 1e-05)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_112 = torch.ops.aten.view.default(getitem_24, [1024, 1024])
        t_default_28 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_119, view_default_112, t_default_28);  primals_119 = None
        view_default_113 = torch.ops.aten.view.default(addmm_default_28, [8, 128, 4096]);  addmm_default_28 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_113)
        view_default_114 = torch.ops.aten.view.default(gelu_default_2, [1024, 4096]);  gelu_default_2 = None
        t_default_29 = torch.ops.aten.t.default(primals_122);  primals_122 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_121, view_default_114, t_default_29);  primals_121 = None
        view_default_115 = torch.ops.aten.view.default(addmm_default_29, [8, 128, 1024]);  addmm_default_29 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_24, view_default_115);  getitem_24 = view_default_115 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_17, [1024], primals_124, primals_123, 1e-05)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_116 = torch.ops.aten.view.default(getitem_27, [1024, 1024])
        t_default_30 = torch.ops.aten.t.default(primals_158);  primals_158 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_157, view_default_116, t_default_30);  primals_157 = None
        view_default_117 = torch.ops.aten.view.default(addmm_default_30, [8, 128, 1024]);  addmm_default_30 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(view_default_117, 0.125);  view_default_117 = None
        view_default_118 = torch.ops.aten.view.default(getitem_27, [1024, 1024])
        t_default_31 = torch.ops.aten.t.default(primals_152);  primals_152 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_151, view_default_118, t_default_31);  primals_151 = None
        view_default_119 = torch.ops.aten.view.default(addmm_default_31, [8, 128, 1024]);  addmm_default_31 = None
        view_default_120 = torch.ops.aten.view.default(view_default_119, [8, -1, 16, 64]);  view_default_119 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_120, 1, 2);  view_default_120 = None
        clone_default_24 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format);  transpose_int_30 = None
        view_default_121 = torch.ops.aten.view.default(getitem_27, [1024, 1024])
        t_default_32 = torch.ops.aten.t.default(primals_160);  primals_160 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_159, view_default_121, t_default_32);  primals_159 = None
        view_default_122 = torch.ops.aten.view.default(addmm_default_32, [8, 128, 1024]);  addmm_default_32 = None
        view_default_123 = torch.ops.aten.view.default(view_default_122, [8, -1, 16, 64]);  view_default_122 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_123, 1, 2);  view_default_123 = None
        clone_default_25 = torch.ops.aten.clone.default(transpose_int_31, memory_format = torch.contiguous_format);  transpose_int_31 = None
        view_default_124 = torch.ops.aten.view.default(mul_tensor_7, [8, 128, 16, 64]);  mul_tensor_7 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_124, 1, 2);  view_default_124 = None
        clone_default_26 = torch.ops.aten.clone.default(transpose_int_32, memory_format = torch.contiguous_format);  transpose_int_32 = None
        view_default_125 = torch.ops.aten.view.default(clone_default_26, [128, -1, 64]);  clone_default_26 = None
        view_default_126 = torch.ops.aten.view.default(clone_default_24, [128, -1, 64])
        view_default_127 = torch.ops.aten.view.default(clone_default_25, [128, -1, 64])
        transpose_int_33 = torch.ops.aten.transpose.int(view_default_126, 1, 2);  view_default_126 = None
        bmm_default_12 = torch.ops.aten.bmm.default(view_default_125, transpose_int_33)
        view_default_128 = torch.ops.aten.view.default(bmm_default_12, [8, 16, 128, 128]);  bmm_default_12 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(view_default_128, _to_copy_default);  view_default_128 = None
        view_default_129 = torch.ops.aten.view.default(add_tensor_18, [128, 128, 128]);  add_tensor_18 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(view_default_129, -1, False);  view_default_129 = None
        bmm_default_13 = torch.ops.aten.bmm.default(_softmax_default_6, view_default_127)
        view_default_130 = torch.ops.aten.view.default(bmm_default_13, [8, 16, 128, 64]);  bmm_default_13 = None
        transpose_int_34 = torch.ops.aten.transpose.int(view_default_130, 1, 2);  view_default_130 = None
        clone_default_27 = torch.ops.aten.clone.default(transpose_int_34, memory_format = torch.contiguous_format);  transpose_int_34 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_27, [8, 128, 1024]);  clone_default_27 = None
        view_default_131 = torch.ops.aten.view.default(_unsafe_view_default_6, [1024, 1024]);  _unsafe_view_default_6 = None
        t_default_33 = torch.ops.aten.t.default(primals_156);  primals_156 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_155, view_default_131, t_default_33);  primals_155 = None
        view_default_132 = torch.ops.aten.view.default(addmm_default_33, [8, 128, 1024]);  addmm_default_33 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_27, view_default_132);  getitem_27 = view_default_132 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_19, [1024], primals_154, primals_153, 1e-05)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_133 = torch.ops.aten.view.default(getitem_30, [1024, 1024])
        t_default_34 = torch.ops.aten.t.default(primals_142);  primals_142 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_141, view_default_133, t_default_34);  primals_141 = None
        view_default_134 = torch.ops.aten.view.default(addmm_default_34, [8, 128, 1024]);  addmm_default_34 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(view_default_134, 0.125);  view_default_134 = None
        view_default_135 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_35 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_135, view_default_135, t_default_35);  primals_135 = None
        view_default_136 = torch.ops.aten.view.default(addmm_default_35, [8, 1024, 1024]);  addmm_default_35 = None
        view_default_137 = torch.ops.aten.view.default(view_default_136, [8, -1, 16, 64]);  view_default_136 = None
        transpose_int_35 = torch.ops.aten.transpose.int(view_default_137, 1, 2);  view_default_137 = None
        clone_default_28 = torch.ops.aten.clone.default(transpose_int_35, memory_format = torch.contiguous_format);  transpose_int_35 = None
        view_default_138 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_36 = torch.ops.aten.t.default(primals_144);  primals_144 = None
        addmm_default_36 = torch.ops.aten.addmm.default(primals_143, view_default_138, t_default_36);  primals_143 = None
        view_default_139 = torch.ops.aten.view.default(addmm_default_36, [8, 1024, 1024]);  addmm_default_36 = None
        view_default_140 = torch.ops.aten.view.default(view_default_139, [8, -1, 16, 64]);  view_default_139 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_140, 1, 2);  view_default_140 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_36, memory_format = torch.contiguous_format);  transpose_int_36 = None
        view_default_141 = torch.ops.aten.view.default(mul_tensor_8, [8, 128, 16, 64]);  mul_tensor_8 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_141, 1, 2);  view_default_141 = None
        clone_default_30 = torch.ops.aten.clone.default(transpose_int_37, memory_format = torch.contiguous_format);  transpose_int_37 = None
        view_default_142 = torch.ops.aten.view.default(clone_default_30, [128, -1, 64]);  clone_default_30 = None
        view_default_143 = torch.ops.aten.view.default(clone_default_28, [128, -1, 64])
        view_default_144 = torch.ops.aten.view.default(clone_default_29, [128, -1, 64])
        transpose_int_38 = torch.ops.aten.transpose.int(view_default_143, 1, 2);  view_default_143 = None
        bmm_default_14 = torch.ops.aten.bmm.default(view_default_142, transpose_int_38)
        view_default_145 = torch.ops.aten.view.default(bmm_default_14, [8, 16, 128, 1024]);  bmm_default_14 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(view_default_145, where_scalar_self);  view_default_145 = None
        view_default_146 = torch.ops.aten.view.default(add_tensor_20, [128, 128, 1024]);  add_tensor_20 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(view_default_146, -1, False);  view_default_146 = None
        bmm_default_15 = torch.ops.aten.bmm.default(_softmax_default_7, view_default_144)
        view_default_147 = torch.ops.aten.view.default(bmm_default_15, [8, 16, 128, 64]);  bmm_default_15 = None
        transpose_int_39 = torch.ops.aten.transpose.int(view_default_147, 1, 2);  view_default_147 = None
        clone_default_31 = torch.ops.aten.clone.default(transpose_int_39, memory_format = torch.contiguous_format);  transpose_int_39 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_31, [8, 128, 1024]);  clone_default_31 = None
        view_default_148 = torch.ops.aten.view.default(_unsafe_view_default_7, [1024, 1024]);  _unsafe_view_default_7 = None
        t_default_37 = torch.ops.aten.t.default(primals_140);  primals_140 = None
        addmm_default_37 = torch.ops.aten.addmm.default(primals_139, view_default_148, t_default_37);  primals_139 = None
        view_default_149 = torch.ops.aten.view.default(addmm_default_37, [8, 128, 1024]);  addmm_default_37 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_30, view_default_149);  getitem_30 = view_default_149 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_21, [1024], primals_138, primals_137, 1e-05)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_150 = torch.ops.aten.view.default(getitem_33, [1024, 1024])
        t_default_38 = torch.ops.aten.t.default(primals_146);  primals_146 = None
        addmm_default_38 = torch.ops.aten.addmm.default(primals_145, view_default_150, t_default_38);  primals_145 = None
        view_default_151 = torch.ops.aten.view.default(addmm_default_38, [8, 128, 4096]);  addmm_default_38 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_151)
        view_default_152 = torch.ops.aten.view.default(gelu_default_3, [1024, 4096]);  gelu_default_3 = None
        t_default_39 = torch.ops.aten.t.default(primals_148);  primals_148 = None
        addmm_default_39 = torch.ops.aten.addmm.default(primals_147, view_default_152, t_default_39);  primals_147 = None
        view_default_153 = torch.ops.aten.view.default(addmm_default_39, [8, 128, 1024]);  addmm_default_39 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_33, view_default_153);  getitem_33 = view_default_153 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add_tensor_22, [1024], primals_150, primals_149, 1e-05)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        view_default_154 = torch.ops.aten.view.default(getitem_36, [1024, 1024])
        t_default_40 = torch.ops.aten.t.default(primals_184);  primals_184 = None
        addmm_default_40 = torch.ops.aten.addmm.default(primals_183, view_default_154, t_default_40);  primals_183 = None
        view_default_155 = torch.ops.aten.view.default(addmm_default_40, [8, 128, 1024]);  addmm_default_40 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(view_default_155, 0.125);  view_default_155 = None
        view_default_156 = torch.ops.aten.view.default(getitem_36, [1024, 1024])
        t_default_41 = torch.ops.aten.t.default(primals_178);  primals_178 = None
        addmm_default_41 = torch.ops.aten.addmm.default(primals_177, view_default_156, t_default_41);  primals_177 = None
        view_default_157 = torch.ops.aten.view.default(addmm_default_41, [8, 128, 1024]);  addmm_default_41 = None
        view_default_158 = torch.ops.aten.view.default(view_default_157, [8, -1, 16, 64]);  view_default_157 = None
        transpose_int_40 = torch.ops.aten.transpose.int(view_default_158, 1, 2);  view_default_158 = None
        clone_default_32 = torch.ops.aten.clone.default(transpose_int_40, memory_format = torch.contiguous_format);  transpose_int_40 = None
        view_default_159 = torch.ops.aten.view.default(getitem_36, [1024, 1024])
        t_default_42 = torch.ops.aten.t.default(primals_186);  primals_186 = None
        addmm_default_42 = torch.ops.aten.addmm.default(primals_185, view_default_159, t_default_42);  primals_185 = None
        view_default_160 = torch.ops.aten.view.default(addmm_default_42, [8, 128, 1024]);  addmm_default_42 = None
        view_default_161 = torch.ops.aten.view.default(view_default_160, [8, -1, 16, 64]);  view_default_160 = None
        transpose_int_41 = torch.ops.aten.transpose.int(view_default_161, 1, 2);  view_default_161 = None
        clone_default_33 = torch.ops.aten.clone.default(transpose_int_41, memory_format = torch.contiguous_format);  transpose_int_41 = None
        view_default_162 = torch.ops.aten.view.default(mul_tensor_9, [8, 128, 16, 64]);  mul_tensor_9 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_162, 1, 2);  view_default_162 = None
        clone_default_34 = torch.ops.aten.clone.default(transpose_int_42, memory_format = torch.contiguous_format);  transpose_int_42 = None
        view_default_163 = torch.ops.aten.view.default(clone_default_34, [128, -1, 64]);  clone_default_34 = None
        view_default_164 = torch.ops.aten.view.default(clone_default_32, [128, -1, 64])
        view_default_165 = torch.ops.aten.view.default(clone_default_33, [128, -1, 64])
        transpose_int_43 = torch.ops.aten.transpose.int(view_default_164, 1, 2);  view_default_164 = None
        bmm_default_16 = torch.ops.aten.bmm.default(view_default_163, transpose_int_43)
        view_default_166 = torch.ops.aten.view.default(bmm_default_16, [8, 16, 128, 128]);  bmm_default_16 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(view_default_166, _to_copy_default);  view_default_166 = None
        view_default_167 = torch.ops.aten.view.default(add_tensor_23, [128, 128, 128]);  add_tensor_23 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(view_default_167, -1, False);  view_default_167 = None
        bmm_default_17 = torch.ops.aten.bmm.default(_softmax_default_8, view_default_165)
        view_default_168 = torch.ops.aten.view.default(bmm_default_17, [8, 16, 128, 64]);  bmm_default_17 = None
        transpose_int_44 = torch.ops.aten.transpose.int(view_default_168, 1, 2);  view_default_168 = None
        clone_default_35 = torch.ops.aten.clone.default(transpose_int_44, memory_format = torch.contiguous_format);  transpose_int_44 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_35, [8, 128, 1024]);  clone_default_35 = None
        view_default_169 = torch.ops.aten.view.default(_unsafe_view_default_8, [1024, 1024]);  _unsafe_view_default_8 = None
        t_default_43 = torch.ops.aten.t.default(primals_182);  primals_182 = None
        addmm_default_43 = torch.ops.aten.addmm.default(primals_181, view_default_169, t_default_43);  primals_181 = None
        view_default_170 = torch.ops.aten.view.default(addmm_default_43, [8, 128, 1024]);  addmm_default_43 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_36, view_default_170);  getitem_36 = view_default_170 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_24, [1024], primals_180, primals_179, 1e-05)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        view_default_171 = torch.ops.aten.view.default(getitem_39, [1024, 1024])
        t_default_44 = torch.ops.aten.t.default(primals_168);  primals_168 = None
        addmm_default_44 = torch.ops.aten.addmm.default(primals_167, view_default_171, t_default_44);  primals_167 = None
        view_default_172 = torch.ops.aten.view.default(addmm_default_44, [8, 128, 1024]);  addmm_default_44 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(view_default_172, 0.125);  view_default_172 = None
        view_default_173 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_45 = torch.ops.aten.t.default(primals_162);  primals_162 = None
        addmm_default_45 = torch.ops.aten.addmm.default(primals_161, view_default_173, t_default_45);  primals_161 = None
        view_default_174 = torch.ops.aten.view.default(addmm_default_45, [8, 1024, 1024]);  addmm_default_45 = None
        view_default_175 = torch.ops.aten.view.default(view_default_174, [8, -1, 16, 64]);  view_default_174 = None
        transpose_int_45 = torch.ops.aten.transpose.int(view_default_175, 1, 2);  view_default_175 = None
        clone_default_36 = torch.ops.aten.clone.default(transpose_int_45, memory_format = torch.contiguous_format);  transpose_int_45 = None
        view_default_176 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_46 = torch.ops.aten.t.default(primals_170);  primals_170 = None
        addmm_default_46 = torch.ops.aten.addmm.default(primals_169, view_default_176, t_default_46);  primals_169 = None
        view_default_177 = torch.ops.aten.view.default(addmm_default_46, [8, 1024, 1024]);  addmm_default_46 = None
        view_default_178 = torch.ops.aten.view.default(view_default_177, [8, -1, 16, 64]);  view_default_177 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_178, 1, 2);  view_default_178 = None
        clone_default_37 = torch.ops.aten.clone.default(transpose_int_46, memory_format = torch.contiguous_format);  transpose_int_46 = None
        view_default_179 = torch.ops.aten.view.default(mul_tensor_10, [8, 128, 16, 64]);  mul_tensor_10 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_179, 1, 2);  view_default_179 = None
        clone_default_38 = torch.ops.aten.clone.default(transpose_int_47, memory_format = torch.contiguous_format);  transpose_int_47 = None
        view_default_180 = torch.ops.aten.view.default(clone_default_38, [128, -1, 64]);  clone_default_38 = None
        view_default_181 = torch.ops.aten.view.default(clone_default_36, [128, -1, 64])
        view_default_182 = torch.ops.aten.view.default(clone_default_37, [128, -1, 64])
        transpose_int_48 = torch.ops.aten.transpose.int(view_default_181, 1, 2);  view_default_181 = None
        bmm_default_18 = torch.ops.aten.bmm.default(view_default_180, transpose_int_48)
        view_default_183 = torch.ops.aten.view.default(bmm_default_18, [8, 16, 128, 1024]);  bmm_default_18 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(view_default_183, where_scalar_self);  view_default_183 = None
        view_default_184 = torch.ops.aten.view.default(add_tensor_25, [128, 128, 1024]);  add_tensor_25 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(view_default_184, -1, False);  view_default_184 = None
        bmm_default_19 = torch.ops.aten.bmm.default(_softmax_default_9, view_default_182)
        view_default_185 = torch.ops.aten.view.default(bmm_default_19, [8, 16, 128, 64]);  bmm_default_19 = None
        transpose_int_49 = torch.ops.aten.transpose.int(view_default_185, 1, 2);  view_default_185 = None
        clone_default_39 = torch.ops.aten.clone.default(transpose_int_49, memory_format = torch.contiguous_format);  transpose_int_49 = None
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(clone_default_39, [8, 128, 1024]);  clone_default_39 = None
        view_default_186 = torch.ops.aten.view.default(_unsafe_view_default_9, [1024, 1024]);  _unsafe_view_default_9 = None
        t_default_47 = torch.ops.aten.t.default(primals_166);  primals_166 = None
        addmm_default_47 = torch.ops.aten.addmm.default(primals_165, view_default_186, t_default_47);  primals_165 = None
        view_default_187 = torch.ops.aten.view.default(addmm_default_47, [8, 128, 1024]);  addmm_default_47 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_39, view_default_187);  getitem_39 = view_default_187 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add_tensor_26, [1024], primals_164, primals_163, 1e-05)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        view_default_188 = torch.ops.aten.view.default(getitem_42, [1024, 1024])
        t_default_48 = torch.ops.aten.t.default(primals_172);  primals_172 = None
        addmm_default_48 = torch.ops.aten.addmm.default(primals_171, view_default_188, t_default_48);  primals_171 = None
        view_default_189 = torch.ops.aten.view.default(addmm_default_48, [8, 128, 4096]);  addmm_default_48 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_189)
        view_default_190 = torch.ops.aten.view.default(gelu_default_4, [1024, 4096]);  gelu_default_4 = None
        t_default_49 = torch.ops.aten.t.default(primals_174);  primals_174 = None
        addmm_default_49 = torch.ops.aten.addmm.default(primals_173, view_default_190, t_default_49);  primals_173 = None
        view_default_191 = torch.ops.aten.view.default(addmm_default_49, [8, 128, 1024]);  addmm_default_49 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_42, view_default_191);  getitem_42 = view_default_191 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add_tensor_27, [1024], primals_176, primals_175, 1e-05)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        view_default_192 = torch.ops.aten.view.default(getitem_45, [1024, 1024])
        t_default_50 = torch.ops.aten.t.default(primals_210);  primals_210 = None
        addmm_default_50 = torch.ops.aten.addmm.default(primals_209, view_default_192, t_default_50);  primals_209 = None
        view_default_193 = torch.ops.aten.view.default(addmm_default_50, [8, 128, 1024]);  addmm_default_50 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(view_default_193, 0.125);  view_default_193 = None
        view_default_194 = torch.ops.aten.view.default(getitem_45, [1024, 1024])
        t_default_51 = torch.ops.aten.t.default(primals_204);  primals_204 = None
        addmm_default_51 = torch.ops.aten.addmm.default(primals_203, view_default_194, t_default_51);  primals_203 = None
        view_default_195 = torch.ops.aten.view.default(addmm_default_51, [8, 128, 1024]);  addmm_default_51 = None
        view_default_196 = torch.ops.aten.view.default(view_default_195, [8, -1, 16, 64]);  view_default_195 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_196, 1, 2);  view_default_196 = None
        clone_default_40 = torch.ops.aten.clone.default(transpose_int_50, memory_format = torch.contiguous_format);  transpose_int_50 = None
        view_default_197 = torch.ops.aten.view.default(getitem_45, [1024, 1024])
        t_default_52 = torch.ops.aten.t.default(primals_212);  primals_212 = None
        addmm_default_52 = torch.ops.aten.addmm.default(primals_211, view_default_197, t_default_52);  primals_211 = None
        view_default_198 = torch.ops.aten.view.default(addmm_default_52, [8, 128, 1024]);  addmm_default_52 = None
        view_default_199 = torch.ops.aten.view.default(view_default_198, [8, -1, 16, 64]);  view_default_198 = None
        transpose_int_51 = torch.ops.aten.transpose.int(view_default_199, 1, 2);  view_default_199 = None
        clone_default_41 = torch.ops.aten.clone.default(transpose_int_51, memory_format = torch.contiguous_format);  transpose_int_51 = None
        view_default_200 = torch.ops.aten.view.default(mul_tensor_11, [8, 128, 16, 64]);  mul_tensor_11 = None
        transpose_int_52 = torch.ops.aten.transpose.int(view_default_200, 1, 2);  view_default_200 = None
        clone_default_42 = torch.ops.aten.clone.default(transpose_int_52, memory_format = torch.contiguous_format);  transpose_int_52 = None
        view_default_201 = torch.ops.aten.view.default(clone_default_42, [128, -1, 64]);  clone_default_42 = None
        view_default_202 = torch.ops.aten.view.default(clone_default_40, [128, -1, 64])
        view_default_203 = torch.ops.aten.view.default(clone_default_41, [128, -1, 64])
        transpose_int_53 = torch.ops.aten.transpose.int(view_default_202, 1, 2);  view_default_202 = None
        bmm_default_20 = torch.ops.aten.bmm.default(view_default_201, transpose_int_53)
        view_default_204 = torch.ops.aten.view.default(bmm_default_20, [8, 16, 128, 128]);  bmm_default_20 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(view_default_204, _to_copy_default);  view_default_204 = None
        view_default_205 = torch.ops.aten.view.default(add_tensor_28, [128, 128, 128]);  add_tensor_28 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(view_default_205, -1, False);  view_default_205 = None
        bmm_default_21 = torch.ops.aten.bmm.default(_softmax_default_10, view_default_203)
        view_default_206 = torch.ops.aten.view.default(bmm_default_21, [8, 16, 128, 64]);  bmm_default_21 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_206, 1, 2);  view_default_206 = None
        clone_default_43 = torch.ops.aten.clone.default(transpose_int_54, memory_format = torch.contiguous_format);  transpose_int_54 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_43, [8, 128, 1024]);  clone_default_43 = None
        view_default_207 = torch.ops.aten.view.default(_unsafe_view_default_10, [1024, 1024]);  _unsafe_view_default_10 = None
        t_default_53 = torch.ops.aten.t.default(primals_208);  primals_208 = None
        addmm_default_53 = torch.ops.aten.addmm.default(primals_207, view_default_207, t_default_53);  primals_207 = None
        view_default_208 = torch.ops.aten.view.default(addmm_default_53, [8, 128, 1024]);  addmm_default_53 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(getitem_45, view_default_208);  getitem_45 = view_default_208 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add_tensor_29, [1024], primals_206, primals_205, 1e-05)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        view_default_209 = torch.ops.aten.view.default(getitem_48, [1024, 1024])
        t_default_54 = torch.ops.aten.t.default(primals_194);  primals_194 = None
        addmm_default_54 = torch.ops.aten.addmm.default(primals_193, view_default_209, t_default_54);  primals_193 = None
        view_default_210 = torch.ops.aten.view.default(addmm_default_54, [8, 128, 1024]);  addmm_default_54 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(view_default_210, 0.125);  view_default_210 = None
        view_default_211 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_55 = torch.ops.aten.t.default(primals_188);  primals_188 = None
        addmm_default_55 = torch.ops.aten.addmm.default(primals_187, view_default_211, t_default_55);  primals_187 = None
        view_default_212 = torch.ops.aten.view.default(addmm_default_55, [8, 1024, 1024]);  addmm_default_55 = None
        view_default_213 = torch.ops.aten.view.default(view_default_212, [8, -1, 16, 64]);  view_default_212 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_213, 1, 2);  view_default_213 = None
        clone_default_44 = torch.ops.aten.clone.default(transpose_int_55, memory_format = torch.contiguous_format);  transpose_int_55 = None
        view_default_214 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_56 = torch.ops.aten.t.default(primals_196);  primals_196 = None
        addmm_default_56 = torch.ops.aten.addmm.default(primals_195, view_default_214, t_default_56);  primals_195 = None
        view_default_215 = torch.ops.aten.view.default(addmm_default_56, [8, 1024, 1024]);  addmm_default_56 = None
        view_default_216 = torch.ops.aten.view.default(view_default_215, [8, -1, 16, 64]);  view_default_215 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_216, 1, 2);  view_default_216 = None
        clone_default_45 = torch.ops.aten.clone.default(transpose_int_56, memory_format = torch.contiguous_format);  transpose_int_56 = None
        view_default_217 = torch.ops.aten.view.default(mul_tensor_12, [8, 128, 16, 64]);  mul_tensor_12 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_217, 1, 2);  view_default_217 = None
        clone_default_46 = torch.ops.aten.clone.default(transpose_int_57, memory_format = torch.contiguous_format);  transpose_int_57 = None
        view_default_218 = torch.ops.aten.view.default(clone_default_46, [128, -1, 64]);  clone_default_46 = None
        view_default_219 = torch.ops.aten.view.default(clone_default_44, [128, -1, 64])
        view_default_220 = torch.ops.aten.view.default(clone_default_45, [128, -1, 64])
        transpose_int_58 = torch.ops.aten.transpose.int(view_default_219, 1, 2);  view_default_219 = None
        bmm_default_22 = torch.ops.aten.bmm.default(view_default_218, transpose_int_58)
        view_default_221 = torch.ops.aten.view.default(bmm_default_22, [8, 16, 128, 1024]);  bmm_default_22 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(view_default_221, where_scalar_self);  view_default_221 = None
        view_default_222 = torch.ops.aten.view.default(add_tensor_30, [128, 128, 1024]);  add_tensor_30 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(view_default_222, -1, False);  view_default_222 = None
        bmm_default_23 = torch.ops.aten.bmm.default(_softmax_default_11, view_default_220)
        view_default_223 = torch.ops.aten.view.default(bmm_default_23, [8, 16, 128, 64]);  bmm_default_23 = None
        transpose_int_59 = torch.ops.aten.transpose.int(view_default_223, 1, 2);  view_default_223 = None
        clone_default_47 = torch.ops.aten.clone.default(transpose_int_59, memory_format = torch.contiguous_format);  transpose_int_59 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_47, [8, 128, 1024]);  clone_default_47 = None
        view_default_224 = torch.ops.aten.view.default(_unsafe_view_default_11, [1024, 1024]);  _unsafe_view_default_11 = None
        t_default_57 = torch.ops.aten.t.default(primals_192);  primals_192 = None
        addmm_default_57 = torch.ops.aten.addmm.default(primals_191, view_default_224, t_default_57);  primals_191 = None
        view_default_225 = torch.ops.aten.view.default(addmm_default_57, [8, 128, 1024]);  addmm_default_57 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(getitem_48, view_default_225);  getitem_48 = view_default_225 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add_tensor_31, [1024], primals_190, primals_189, 1e-05)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        view_default_226 = torch.ops.aten.view.default(getitem_51, [1024, 1024])
        t_default_58 = torch.ops.aten.t.default(primals_198);  primals_198 = None
        addmm_default_58 = torch.ops.aten.addmm.default(primals_197, view_default_226, t_default_58);  primals_197 = None
        view_default_227 = torch.ops.aten.view.default(addmm_default_58, [8, 128, 4096]);  addmm_default_58 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_227)
        view_default_228 = torch.ops.aten.view.default(gelu_default_5, [1024, 4096]);  gelu_default_5 = None
        t_default_59 = torch.ops.aten.t.default(primals_200);  primals_200 = None
        addmm_default_59 = torch.ops.aten.addmm.default(primals_199, view_default_228, t_default_59);  primals_199 = None
        view_default_229 = torch.ops.aten.view.default(addmm_default_59, [8, 128, 1024]);  addmm_default_59 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_51, view_default_229);  getitem_51 = view_default_229 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add_tensor_32, [1024], primals_202, primals_201, 1e-05)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        view_default_230 = torch.ops.aten.view.default(getitem_54, [1024, 1024])
        t_default_60 = torch.ops.aten.t.default(primals_236);  primals_236 = None
        addmm_default_60 = torch.ops.aten.addmm.default(primals_235, view_default_230, t_default_60);  primals_235 = None
        view_default_231 = torch.ops.aten.view.default(addmm_default_60, [8, 128, 1024]);  addmm_default_60 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(view_default_231, 0.125);  view_default_231 = None
        view_default_232 = torch.ops.aten.view.default(getitem_54, [1024, 1024])
        t_default_61 = torch.ops.aten.t.default(primals_230);  primals_230 = None
        addmm_default_61 = torch.ops.aten.addmm.default(primals_229, view_default_232, t_default_61);  primals_229 = None
        view_default_233 = torch.ops.aten.view.default(addmm_default_61, [8, 128, 1024]);  addmm_default_61 = None
        view_default_234 = torch.ops.aten.view.default(view_default_233, [8, -1, 16, 64]);  view_default_233 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_234, 1, 2);  view_default_234 = None
        clone_default_48 = torch.ops.aten.clone.default(transpose_int_60, memory_format = torch.contiguous_format);  transpose_int_60 = None
        view_default_235 = torch.ops.aten.view.default(getitem_54, [1024, 1024])
        t_default_62 = torch.ops.aten.t.default(primals_238);  primals_238 = None
        addmm_default_62 = torch.ops.aten.addmm.default(primals_237, view_default_235, t_default_62);  primals_237 = None
        view_default_236 = torch.ops.aten.view.default(addmm_default_62, [8, 128, 1024]);  addmm_default_62 = None
        view_default_237 = torch.ops.aten.view.default(view_default_236, [8, -1, 16, 64]);  view_default_236 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_237, 1, 2);  view_default_237 = None
        clone_default_49 = torch.ops.aten.clone.default(transpose_int_61, memory_format = torch.contiguous_format);  transpose_int_61 = None
        view_default_238 = torch.ops.aten.view.default(mul_tensor_13, [8, 128, 16, 64]);  mul_tensor_13 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_238, 1, 2);  view_default_238 = None
        clone_default_50 = torch.ops.aten.clone.default(transpose_int_62, memory_format = torch.contiguous_format);  transpose_int_62 = None
        view_default_239 = torch.ops.aten.view.default(clone_default_50, [128, -1, 64]);  clone_default_50 = None
        view_default_240 = torch.ops.aten.view.default(clone_default_48, [128, -1, 64])
        view_default_241 = torch.ops.aten.view.default(clone_default_49, [128, -1, 64])
        transpose_int_63 = torch.ops.aten.transpose.int(view_default_240, 1, 2);  view_default_240 = None
        bmm_default_24 = torch.ops.aten.bmm.default(view_default_239, transpose_int_63)
        view_default_242 = torch.ops.aten.view.default(bmm_default_24, [8, 16, 128, 128]);  bmm_default_24 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(view_default_242, _to_copy_default);  view_default_242 = None
        view_default_243 = torch.ops.aten.view.default(add_tensor_33, [128, 128, 128]);  add_tensor_33 = None
        _softmax_default_12 = torch.ops.aten._softmax.default(view_default_243, -1, False);  view_default_243 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_softmax_default_12, view_default_241)
        view_default_244 = torch.ops.aten.view.default(bmm_default_25, [8, 16, 128, 64]);  bmm_default_25 = None
        transpose_int_64 = torch.ops.aten.transpose.int(view_default_244, 1, 2);  view_default_244 = None
        clone_default_51 = torch.ops.aten.clone.default(transpose_int_64, memory_format = torch.contiguous_format);  transpose_int_64 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_51, [8, 128, 1024]);  clone_default_51 = None
        view_default_245 = torch.ops.aten.view.default(_unsafe_view_default_12, [1024, 1024]);  _unsafe_view_default_12 = None
        t_default_63 = torch.ops.aten.t.default(primals_234);  primals_234 = None
        addmm_default_63 = torch.ops.aten.addmm.default(primals_233, view_default_245, t_default_63);  primals_233 = None
        view_default_246 = torch.ops.aten.view.default(addmm_default_63, [8, 128, 1024]);  addmm_default_63 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_54, view_default_246);  getitem_54 = view_default_246 = None
        native_layer_norm_default_19 = torch.ops.aten.native_layer_norm.default(add_tensor_34, [1024], primals_232, primals_231, 1e-05)
        getitem_57 = native_layer_norm_default_19[0]
        getitem_58 = native_layer_norm_default_19[1]
        getitem_59 = native_layer_norm_default_19[2];  native_layer_norm_default_19 = None
        view_default_247 = torch.ops.aten.view.default(getitem_57, [1024, 1024])
        t_default_64 = torch.ops.aten.t.default(primals_220);  primals_220 = None
        addmm_default_64 = torch.ops.aten.addmm.default(primals_219, view_default_247, t_default_64);  primals_219 = None
        view_default_248 = torch.ops.aten.view.default(addmm_default_64, [8, 128, 1024]);  addmm_default_64 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(view_default_248, 0.125);  view_default_248 = None
        view_default_249 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_65 = torch.ops.aten.t.default(primals_214);  primals_214 = None
        addmm_default_65 = torch.ops.aten.addmm.default(primals_213, view_default_249, t_default_65);  primals_213 = None
        view_default_250 = torch.ops.aten.view.default(addmm_default_65, [8, 1024, 1024]);  addmm_default_65 = None
        view_default_251 = torch.ops.aten.view.default(view_default_250, [8, -1, 16, 64]);  view_default_250 = None
        transpose_int_65 = torch.ops.aten.transpose.int(view_default_251, 1, 2);  view_default_251 = None
        clone_default_52 = torch.ops.aten.clone.default(transpose_int_65, memory_format = torch.contiguous_format);  transpose_int_65 = None
        view_default_252 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_66 = torch.ops.aten.t.default(primals_222);  primals_222 = None
        addmm_default_66 = torch.ops.aten.addmm.default(primals_221, view_default_252, t_default_66);  primals_221 = None
        view_default_253 = torch.ops.aten.view.default(addmm_default_66, [8, 1024, 1024]);  addmm_default_66 = None
        view_default_254 = torch.ops.aten.view.default(view_default_253, [8, -1, 16, 64]);  view_default_253 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_254, 1, 2);  view_default_254 = None
        clone_default_53 = torch.ops.aten.clone.default(transpose_int_66, memory_format = torch.contiguous_format);  transpose_int_66 = None
        view_default_255 = torch.ops.aten.view.default(mul_tensor_14, [8, 128, 16, 64]);  mul_tensor_14 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_255, 1, 2);  view_default_255 = None
        clone_default_54 = torch.ops.aten.clone.default(transpose_int_67, memory_format = torch.contiguous_format);  transpose_int_67 = None
        view_default_256 = torch.ops.aten.view.default(clone_default_54, [128, -1, 64]);  clone_default_54 = None
        view_default_257 = torch.ops.aten.view.default(clone_default_52, [128, -1, 64])
        view_default_258 = torch.ops.aten.view.default(clone_default_53, [128, -1, 64])
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_257, 1, 2);  view_default_257 = None
        bmm_default_26 = torch.ops.aten.bmm.default(view_default_256, transpose_int_68)
        view_default_259 = torch.ops.aten.view.default(bmm_default_26, [8, 16, 128, 1024]);  bmm_default_26 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(view_default_259, where_scalar_self);  view_default_259 = None
        view_default_260 = torch.ops.aten.view.default(add_tensor_35, [128, 128, 1024]);  add_tensor_35 = None
        _softmax_default_13 = torch.ops.aten._softmax.default(view_default_260, -1, False);  view_default_260 = None
        bmm_default_27 = torch.ops.aten.bmm.default(_softmax_default_13, view_default_258)
        view_default_261 = torch.ops.aten.view.default(bmm_default_27, [8, 16, 128, 64]);  bmm_default_27 = None
        transpose_int_69 = torch.ops.aten.transpose.int(view_default_261, 1, 2);  view_default_261 = None
        clone_default_55 = torch.ops.aten.clone.default(transpose_int_69, memory_format = torch.contiguous_format);  transpose_int_69 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_55, [8, 128, 1024]);  clone_default_55 = None
        view_default_262 = torch.ops.aten.view.default(_unsafe_view_default_13, [1024, 1024]);  _unsafe_view_default_13 = None
        t_default_67 = torch.ops.aten.t.default(primals_218);  primals_218 = None
        addmm_default_67 = torch.ops.aten.addmm.default(primals_217, view_default_262, t_default_67);  primals_217 = None
        view_default_263 = torch.ops.aten.view.default(addmm_default_67, [8, 128, 1024]);  addmm_default_67 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_57, view_default_263);  getitem_57 = view_default_263 = None
        native_layer_norm_default_20 = torch.ops.aten.native_layer_norm.default(add_tensor_36, [1024], primals_216, primals_215, 1e-05)
        getitem_60 = native_layer_norm_default_20[0]
        getitem_61 = native_layer_norm_default_20[1]
        getitem_62 = native_layer_norm_default_20[2];  native_layer_norm_default_20 = None
        view_default_264 = torch.ops.aten.view.default(getitem_60, [1024, 1024])
        t_default_68 = torch.ops.aten.t.default(primals_224);  primals_224 = None
        addmm_default_68 = torch.ops.aten.addmm.default(primals_223, view_default_264, t_default_68);  primals_223 = None
        view_default_265 = torch.ops.aten.view.default(addmm_default_68, [8, 128, 4096]);  addmm_default_68 = None
        gelu_default_6 = torch.ops.aten.gelu.default(view_default_265)
        view_default_266 = torch.ops.aten.view.default(gelu_default_6, [1024, 4096]);  gelu_default_6 = None
        t_default_69 = torch.ops.aten.t.default(primals_226);  primals_226 = None
        addmm_default_69 = torch.ops.aten.addmm.default(primals_225, view_default_266, t_default_69);  primals_225 = None
        view_default_267 = torch.ops.aten.view.default(addmm_default_69, [8, 128, 1024]);  addmm_default_69 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(getitem_60, view_default_267);  getitem_60 = view_default_267 = None
        native_layer_norm_default_21 = torch.ops.aten.native_layer_norm.default(add_tensor_37, [1024], primals_228, primals_227, 1e-05)
        getitem_63 = native_layer_norm_default_21[0]
        getitem_64 = native_layer_norm_default_21[1]
        getitem_65 = native_layer_norm_default_21[2];  native_layer_norm_default_21 = None
        view_default_268 = torch.ops.aten.view.default(getitem_63, [1024, 1024])
        t_default_70 = torch.ops.aten.t.default(primals_262);  primals_262 = None
        addmm_default_70 = torch.ops.aten.addmm.default(primals_261, view_default_268, t_default_70);  primals_261 = None
        view_default_269 = torch.ops.aten.view.default(addmm_default_70, [8, 128, 1024]);  addmm_default_70 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(view_default_269, 0.125);  view_default_269 = None
        view_default_270 = torch.ops.aten.view.default(getitem_63, [1024, 1024])
        t_default_71 = torch.ops.aten.t.default(primals_256);  primals_256 = None
        addmm_default_71 = torch.ops.aten.addmm.default(primals_255, view_default_270, t_default_71);  primals_255 = None
        view_default_271 = torch.ops.aten.view.default(addmm_default_71, [8, 128, 1024]);  addmm_default_71 = None
        view_default_272 = torch.ops.aten.view.default(view_default_271, [8, -1, 16, 64]);  view_default_271 = None
        transpose_int_70 = torch.ops.aten.transpose.int(view_default_272, 1, 2);  view_default_272 = None
        clone_default_56 = torch.ops.aten.clone.default(transpose_int_70, memory_format = torch.contiguous_format);  transpose_int_70 = None
        view_default_273 = torch.ops.aten.view.default(getitem_63, [1024, 1024])
        t_default_72 = torch.ops.aten.t.default(primals_264);  primals_264 = None
        addmm_default_72 = torch.ops.aten.addmm.default(primals_263, view_default_273, t_default_72);  primals_263 = None
        view_default_274 = torch.ops.aten.view.default(addmm_default_72, [8, 128, 1024]);  addmm_default_72 = None
        view_default_275 = torch.ops.aten.view.default(view_default_274, [8, -1, 16, 64]);  view_default_274 = None
        transpose_int_71 = torch.ops.aten.transpose.int(view_default_275, 1, 2);  view_default_275 = None
        clone_default_57 = torch.ops.aten.clone.default(transpose_int_71, memory_format = torch.contiguous_format);  transpose_int_71 = None
        view_default_276 = torch.ops.aten.view.default(mul_tensor_15, [8, 128, 16, 64]);  mul_tensor_15 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_276, 1, 2);  view_default_276 = None
        clone_default_58 = torch.ops.aten.clone.default(transpose_int_72, memory_format = torch.contiguous_format);  transpose_int_72 = None
        view_default_277 = torch.ops.aten.view.default(clone_default_58, [128, -1, 64]);  clone_default_58 = None
        view_default_278 = torch.ops.aten.view.default(clone_default_56, [128, -1, 64])
        view_default_279 = torch.ops.aten.view.default(clone_default_57, [128, -1, 64])
        transpose_int_73 = torch.ops.aten.transpose.int(view_default_278, 1, 2);  view_default_278 = None
        bmm_default_28 = torch.ops.aten.bmm.default(view_default_277, transpose_int_73)
        view_default_280 = torch.ops.aten.view.default(bmm_default_28, [8, 16, 128, 128]);  bmm_default_28 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(view_default_280, _to_copy_default);  view_default_280 = None
        view_default_281 = torch.ops.aten.view.default(add_tensor_38, [128, 128, 128]);  add_tensor_38 = None
        _softmax_default_14 = torch.ops.aten._softmax.default(view_default_281, -1, False);  view_default_281 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_softmax_default_14, view_default_279)
        view_default_282 = torch.ops.aten.view.default(bmm_default_29, [8, 16, 128, 64]);  bmm_default_29 = None
        transpose_int_74 = torch.ops.aten.transpose.int(view_default_282, 1, 2);  view_default_282 = None
        clone_default_59 = torch.ops.aten.clone.default(transpose_int_74, memory_format = torch.contiguous_format);  transpose_int_74 = None
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(clone_default_59, [8, 128, 1024]);  clone_default_59 = None
        view_default_283 = torch.ops.aten.view.default(_unsafe_view_default_14, [1024, 1024]);  _unsafe_view_default_14 = None
        t_default_73 = torch.ops.aten.t.default(primals_260);  primals_260 = None
        addmm_default_73 = torch.ops.aten.addmm.default(primals_259, view_default_283, t_default_73);  primals_259 = None
        view_default_284 = torch.ops.aten.view.default(addmm_default_73, [8, 128, 1024]);  addmm_default_73 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_63, view_default_284);  getitem_63 = view_default_284 = None
        native_layer_norm_default_22 = torch.ops.aten.native_layer_norm.default(add_tensor_39, [1024], primals_258, primals_257, 1e-05)
        getitem_66 = native_layer_norm_default_22[0]
        getitem_67 = native_layer_norm_default_22[1]
        getitem_68 = native_layer_norm_default_22[2];  native_layer_norm_default_22 = None
        view_default_285 = torch.ops.aten.view.default(getitem_66, [1024, 1024])
        t_default_74 = torch.ops.aten.t.default(primals_246);  primals_246 = None
        addmm_default_74 = torch.ops.aten.addmm.default(primals_245, view_default_285, t_default_74);  primals_245 = None
        view_default_286 = torch.ops.aten.view.default(addmm_default_74, [8, 128, 1024]);  addmm_default_74 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(view_default_286, 0.125);  view_default_286 = None
        view_default_287 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_75 = torch.ops.aten.t.default(primals_240);  primals_240 = None
        addmm_default_75 = torch.ops.aten.addmm.default(primals_239, view_default_287, t_default_75);  primals_239 = None
        view_default_288 = torch.ops.aten.view.default(addmm_default_75, [8, 1024, 1024]);  addmm_default_75 = None
        view_default_289 = torch.ops.aten.view.default(view_default_288, [8, -1, 16, 64]);  view_default_288 = None
        transpose_int_75 = torch.ops.aten.transpose.int(view_default_289, 1, 2);  view_default_289 = None
        clone_default_60 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format);  transpose_int_75 = None
        view_default_290 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_76 = torch.ops.aten.t.default(primals_248);  primals_248 = None
        addmm_default_76 = torch.ops.aten.addmm.default(primals_247, view_default_290, t_default_76);  primals_247 = None
        view_default_291 = torch.ops.aten.view.default(addmm_default_76, [8, 1024, 1024]);  addmm_default_76 = None
        view_default_292 = torch.ops.aten.view.default(view_default_291, [8, -1, 16, 64]);  view_default_291 = None
        transpose_int_76 = torch.ops.aten.transpose.int(view_default_292, 1, 2);  view_default_292 = None
        clone_default_61 = torch.ops.aten.clone.default(transpose_int_76, memory_format = torch.contiguous_format);  transpose_int_76 = None
        view_default_293 = torch.ops.aten.view.default(mul_tensor_16, [8, 128, 16, 64]);  mul_tensor_16 = None
        transpose_int_77 = torch.ops.aten.transpose.int(view_default_293, 1, 2);  view_default_293 = None
        clone_default_62 = torch.ops.aten.clone.default(transpose_int_77, memory_format = torch.contiguous_format);  transpose_int_77 = None
        view_default_294 = torch.ops.aten.view.default(clone_default_62, [128, -1, 64]);  clone_default_62 = None
        view_default_295 = torch.ops.aten.view.default(clone_default_60, [128, -1, 64])
        view_default_296 = torch.ops.aten.view.default(clone_default_61, [128, -1, 64])
        transpose_int_78 = torch.ops.aten.transpose.int(view_default_295, 1, 2);  view_default_295 = None
        bmm_default_30 = torch.ops.aten.bmm.default(view_default_294, transpose_int_78)
        view_default_297 = torch.ops.aten.view.default(bmm_default_30, [8, 16, 128, 1024]);  bmm_default_30 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(view_default_297, where_scalar_self);  view_default_297 = None
        view_default_298 = torch.ops.aten.view.default(add_tensor_40, [128, 128, 1024]);  add_tensor_40 = None
        _softmax_default_15 = torch.ops.aten._softmax.default(view_default_298, -1, False);  view_default_298 = None
        bmm_default_31 = torch.ops.aten.bmm.default(_softmax_default_15, view_default_296)
        view_default_299 = torch.ops.aten.view.default(bmm_default_31, [8, 16, 128, 64]);  bmm_default_31 = None
        transpose_int_79 = torch.ops.aten.transpose.int(view_default_299, 1, 2);  view_default_299 = None
        clone_default_63 = torch.ops.aten.clone.default(transpose_int_79, memory_format = torch.contiguous_format);  transpose_int_79 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_63, [8, 128, 1024]);  clone_default_63 = None
        view_default_300 = torch.ops.aten.view.default(_unsafe_view_default_15, [1024, 1024]);  _unsafe_view_default_15 = None
        t_default_77 = torch.ops.aten.t.default(primals_244);  primals_244 = None
        addmm_default_77 = torch.ops.aten.addmm.default(primals_243, view_default_300, t_default_77);  primals_243 = None
        view_default_301 = torch.ops.aten.view.default(addmm_default_77, [8, 128, 1024]);  addmm_default_77 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_66, view_default_301);  getitem_66 = view_default_301 = None
        native_layer_norm_default_23 = torch.ops.aten.native_layer_norm.default(add_tensor_41, [1024], primals_242, primals_241, 1e-05)
        getitem_69 = native_layer_norm_default_23[0]
        getitem_70 = native_layer_norm_default_23[1]
        getitem_71 = native_layer_norm_default_23[2];  native_layer_norm_default_23 = None
        view_default_302 = torch.ops.aten.view.default(getitem_69, [1024, 1024])
        t_default_78 = torch.ops.aten.t.default(primals_250);  primals_250 = None
        addmm_default_78 = torch.ops.aten.addmm.default(primals_249, view_default_302, t_default_78);  primals_249 = None
        view_default_303 = torch.ops.aten.view.default(addmm_default_78, [8, 128, 4096]);  addmm_default_78 = None
        gelu_default_7 = torch.ops.aten.gelu.default(view_default_303)
        view_default_304 = torch.ops.aten.view.default(gelu_default_7, [1024, 4096]);  gelu_default_7 = None
        t_default_79 = torch.ops.aten.t.default(primals_252);  primals_252 = None
        addmm_default_79 = torch.ops.aten.addmm.default(primals_251, view_default_304, t_default_79);  primals_251 = None
        view_default_305 = torch.ops.aten.view.default(addmm_default_79, [8, 128, 1024]);  addmm_default_79 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(getitem_69, view_default_305);  getitem_69 = view_default_305 = None
        native_layer_norm_default_24 = torch.ops.aten.native_layer_norm.default(add_tensor_42, [1024], primals_254, primals_253, 1e-05)
        getitem_72 = native_layer_norm_default_24[0]
        getitem_73 = native_layer_norm_default_24[1]
        getitem_74 = native_layer_norm_default_24[2];  native_layer_norm_default_24 = None
        view_default_306 = torch.ops.aten.view.default(getitem_72, [1024, 1024])
        t_default_80 = torch.ops.aten.t.default(primals_288);  primals_288 = None
        addmm_default_80 = torch.ops.aten.addmm.default(primals_287, view_default_306, t_default_80);  primals_287 = None
        view_default_307 = torch.ops.aten.view.default(addmm_default_80, [8, 128, 1024]);  addmm_default_80 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(view_default_307, 0.125);  view_default_307 = None
        view_default_308 = torch.ops.aten.view.default(getitem_72, [1024, 1024])
        t_default_81 = torch.ops.aten.t.default(primals_282);  primals_282 = None
        addmm_default_81 = torch.ops.aten.addmm.default(primals_281, view_default_308, t_default_81);  primals_281 = None
        view_default_309 = torch.ops.aten.view.default(addmm_default_81, [8, 128, 1024]);  addmm_default_81 = None
        view_default_310 = torch.ops.aten.view.default(view_default_309, [8, -1, 16, 64]);  view_default_309 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_310, 1, 2);  view_default_310 = None
        clone_default_64 = torch.ops.aten.clone.default(transpose_int_80, memory_format = torch.contiguous_format);  transpose_int_80 = None
        view_default_311 = torch.ops.aten.view.default(getitem_72, [1024, 1024])
        t_default_82 = torch.ops.aten.t.default(primals_290);  primals_290 = None
        addmm_default_82 = torch.ops.aten.addmm.default(primals_289, view_default_311, t_default_82);  primals_289 = None
        view_default_312 = torch.ops.aten.view.default(addmm_default_82, [8, 128, 1024]);  addmm_default_82 = None
        view_default_313 = torch.ops.aten.view.default(view_default_312, [8, -1, 16, 64]);  view_default_312 = None
        transpose_int_81 = torch.ops.aten.transpose.int(view_default_313, 1, 2);  view_default_313 = None
        clone_default_65 = torch.ops.aten.clone.default(transpose_int_81, memory_format = torch.contiguous_format);  transpose_int_81 = None
        view_default_314 = torch.ops.aten.view.default(mul_tensor_17, [8, 128, 16, 64]);  mul_tensor_17 = None
        transpose_int_82 = torch.ops.aten.transpose.int(view_default_314, 1, 2);  view_default_314 = None
        clone_default_66 = torch.ops.aten.clone.default(transpose_int_82, memory_format = torch.contiguous_format);  transpose_int_82 = None
        view_default_315 = torch.ops.aten.view.default(clone_default_66, [128, -1, 64]);  clone_default_66 = None
        view_default_316 = torch.ops.aten.view.default(clone_default_64, [128, -1, 64])
        view_default_317 = torch.ops.aten.view.default(clone_default_65, [128, -1, 64])
        transpose_int_83 = torch.ops.aten.transpose.int(view_default_316, 1, 2);  view_default_316 = None
        bmm_default_32 = torch.ops.aten.bmm.default(view_default_315, transpose_int_83)
        view_default_318 = torch.ops.aten.view.default(bmm_default_32, [8, 16, 128, 128]);  bmm_default_32 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(view_default_318, _to_copy_default);  view_default_318 = None
        view_default_319 = torch.ops.aten.view.default(add_tensor_43, [128, 128, 128]);  add_tensor_43 = None
        _softmax_default_16 = torch.ops.aten._softmax.default(view_default_319, -1, False);  view_default_319 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_softmax_default_16, view_default_317)
        view_default_320 = torch.ops.aten.view.default(bmm_default_33, [8, 16, 128, 64]);  bmm_default_33 = None
        transpose_int_84 = torch.ops.aten.transpose.int(view_default_320, 1, 2);  view_default_320 = None
        clone_default_67 = torch.ops.aten.clone.default(transpose_int_84, memory_format = torch.contiguous_format);  transpose_int_84 = None
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(clone_default_67, [8, 128, 1024]);  clone_default_67 = None
        view_default_321 = torch.ops.aten.view.default(_unsafe_view_default_16, [1024, 1024]);  _unsafe_view_default_16 = None
        t_default_83 = torch.ops.aten.t.default(primals_286);  primals_286 = None
        addmm_default_83 = torch.ops.aten.addmm.default(primals_285, view_default_321, t_default_83);  primals_285 = None
        view_default_322 = torch.ops.aten.view.default(addmm_default_83, [8, 128, 1024]);  addmm_default_83 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_72, view_default_322);  getitem_72 = view_default_322 = None
        native_layer_norm_default_25 = torch.ops.aten.native_layer_norm.default(add_tensor_44, [1024], primals_284, primals_283, 1e-05)
        getitem_75 = native_layer_norm_default_25[0]
        getitem_76 = native_layer_norm_default_25[1]
        getitem_77 = native_layer_norm_default_25[2];  native_layer_norm_default_25 = None
        view_default_323 = torch.ops.aten.view.default(getitem_75, [1024, 1024])
        t_default_84 = torch.ops.aten.t.default(primals_272);  primals_272 = None
        addmm_default_84 = torch.ops.aten.addmm.default(primals_271, view_default_323, t_default_84);  primals_271 = None
        view_default_324 = torch.ops.aten.view.default(addmm_default_84, [8, 128, 1024]);  addmm_default_84 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(view_default_324, 0.125);  view_default_324 = None
        view_default_325 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_85 = torch.ops.aten.t.default(primals_266);  primals_266 = None
        addmm_default_85 = torch.ops.aten.addmm.default(primals_265, view_default_325, t_default_85);  primals_265 = None
        view_default_326 = torch.ops.aten.view.default(addmm_default_85, [8, 1024, 1024]);  addmm_default_85 = None
        view_default_327 = torch.ops.aten.view.default(view_default_326, [8, -1, 16, 64]);  view_default_326 = None
        transpose_int_85 = torch.ops.aten.transpose.int(view_default_327, 1, 2);  view_default_327 = None
        clone_default_68 = torch.ops.aten.clone.default(transpose_int_85, memory_format = torch.contiguous_format);  transpose_int_85 = None
        view_default_328 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_86 = torch.ops.aten.t.default(primals_274);  primals_274 = None
        addmm_default_86 = torch.ops.aten.addmm.default(primals_273, view_default_328, t_default_86);  primals_273 = None
        view_default_329 = torch.ops.aten.view.default(addmm_default_86, [8, 1024, 1024]);  addmm_default_86 = None
        view_default_330 = torch.ops.aten.view.default(view_default_329, [8, -1, 16, 64]);  view_default_329 = None
        transpose_int_86 = torch.ops.aten.transpose.int(view_default_330, 1, 2);  view_default_330 = None
        clone_default_69 = torch.ops.aten.clone.default(transpose_int_86, memory_format = torch.contiguous_format);  transpose_int_86 = None
        view_default_331 = torch.ops.aten.view.default(mul_tensor_18, [8, 128, 16, 64]);  mul_tensor_18 = None
        transpose_int_87 = torch.ops.aten.transpose.int(view_default_331, 1, 2);  view_default_331 = None
        clone_default_70 = torch.ops.aten.clone.default(transpose_int_87, memory_format = torch.contiguous_format);  transpose_int_87 = None
        view_default_332 = torch.ops.aten.view.default(clone_default_70, [128, -1, 64]);  clone_default_70 = None
        view_default_333 = torch.ops.aten.view.default(clone_default_68, [128, -1, 64])
        view_default_334 = torch.ops.aten.view.default(clone_default_69, [128, -1, 64])
        transpose_int_88 = torch.ops.aten.transpose.int(view_default_333, 1, 2);  view_default_333 = None
        bmm_default_34 = torch.ops.aten.bmm.default(view_default_332, transpose_int_88)
        view_default_335 = torch.ops.aten.view.default(bmm_default_34, [8, 16, 128, 1024]);  bmm_default_34 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(view_default_335, where_scalar_self);  view_default_335 = None
        view_default_336 = torch.ops.aten.view.default(add_tensor_45, [128, 128, 1024]);  add_tensor_45 = None
        _softmax_default_17 = torch.ops.aten._softmax.default(view_default_336, -1, False);  view_default_336 = None
        bmm_default_35 = torch.ops.aten.bmm.default(_softmax_default_17, view_default_334)
        view_default_337 = torch.ops.aten.view.default(bmm_default_35, [8, 16, 128, 64]);  bmm_default_35 = None
        transpose_int_89 = torch.ops.aten.transpose.int(view_default_337, 1, 2);  view_default_337 = None
        clone_default_71 = torch.ops.aten.clone.default(transpose_int_89, memory_format = torch.contiguous_format);  transpose_int_89 = None
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(clone_default_71, [8, 128, 1024]);  clone_default_71 = None
        view_default_338 = torch.ops.aten.view.default(_unsafe_view_default_17, [1024, 1024]);  _unsafe_view_default_17 = None
        t_default_87 = torch.ops.aten.t.default(primals_270);  primals_270 = None
        addmm_default_87 = torch.ops.aten.addmm.default(primals_269, view_default_338, t_default_87);  primals_269 = None
        view_default_339 = torch.ops.aten.view.default(addmm_default_87, [8, 128, 1024]);  addmm_default_87 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(getitem_75, view_default_339);  getitem_75 = view_default_339 = None
        native_layer_norm_default_26 = torch.ops.aten.native_layer_norm.default(add_tensor_46, [1024], primals_268, primals_267, 1e-05)
        getitem_78 = native_layer_norm_default_26[0]
        getitem_79 = native_layer_norm_default_26[1]
        getitem_80 = native_layer_norm_default_26[2];  native_layer_norm_default_26 = None
        view_default_340 = torch.ops.aten.view.default(getitem_78, [1024, 1024])
        t_default_88 = torch.ops.aten.t.default(primals_276);  primals_276 = None
        addmm_default_88 = torch.ops.aten.addmm.default(primals_275, view_default_340, t_default_88);  primals_275 = None
        view_default_341 = torch.ops.aten.view.default(addmm_default_88, [8, 128, 4096]);  addmm_default_88 = None
        gelu_default_8 = torch.ops.aten.gelu.default(view_default_341)
        view_default_342 = torch.ops.aten.view.default(gelu_default_8, [1024, 4096]);  gelu_default_8 = None
        t_default_89 = torch.ops.aten.t.default(primals_278);  primals_278 = None
        addmm_default_89 = torch.ops.aten.addmm.default(primals_277, view_default_342, t_default_89);  primals_277 = None
        view_default_343 = torch.ops.aten.view.default(addmm_default_89, [8, 128, 1024]);  addmm_default_89 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_78, view_default_343);  getitem_78 = view_default_343 = None
        native_layer_norm_default_27 = torch.ops.aten.native_layer_norm.default(add_tensor_47, [1024], primals_280, primals_279, 1e-05)
        getitem_81 = native_layer_norm_default_27[0]
        getitem_82 = native_layer_norm_default_27[1]
        getitem_83 = native_layer_norm_default_27[2];  native_layer_norm_default_27 = None
        view_default_344 = torch.ops.aten.view.default(getitem_81, [1024, 1024])
        t_default_90 = torch.ops.aten.t.default(primals_314);  primals_314 = None
        addmm_default_90 = torch.ops.aten.addmm.default(primals_313, view_default_344, t_default_90);  primals_313 = None
        view_default_345 = torch.ops.aten.view.default(addmm_default_90, [8, 128, 1024]);  addmm_default_90 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(view_default_345, 0.125);  view_default_345 = None
        view_default_346 = torch.ops.aten.view.default(getitem_81, [1024, 1024])
        t_default_91 = torch.ops.aten.t.default(primals_308);  primals_308 = None
        addmm_default_91 = torch.ops.aten.addmm.default(primals_307, view_default_346, t_default_91);  primals_307 = None
        view_default_347 = torch.ops.aten.view.default(addmm_default_91, [8, 128, 1024]);  addmm_default_91 = None
        view_default_348 = torch.ops.aten.view.default(view_default_347, [8, -1, 16, 64]);  view_default_347 = None
        transpose_int_90 = torch.ops.aten.transpose.int(view_default_348, 1, 2);  view_default_348 = None
        clone_default_72 = torch.ops.aten.clone.default(transpose_int_90, memory_format = torch.contiguous_format);  transpose_int_90 = None
        view_default_349 = torch.ops.aten.view.default(getitem_81, [1024, 1024])
        t_default_92 = torch.ops.aten.t.default(primals_316);  primals_316 = None
        addmm_default_92 = torch.ops.aten.addmm.default(primals_315, view_default_349, t_default_92);  primals_315 = None
        view_default_350 = torch.ops.aten.view.default(addmm_default_92, [8, 128, 1024]);  addmm_default_92 = None
        view_default_351 = torch.ops.aten.view.default(view_default_350, [8, -1, 16, 64]);  view_default_350 = None
        transpose_int_91 = torch.ops.aten.transpose.int(view_default_351, 1, 2);  view_default_351 = None
        clone_default_73 = torch.ops.aten.clone.default(transpose_int_91, memory_format = torch.contiguous_format);  transpose_int_91 = None
        view_default_352 = torch.ops.aten.view.default(mul_tensor_19, [8, 128, 16, 64]);  mul_tensor_19 = None
        transpose_int_92 = torch.ops.aten.transpose.int(view_default_352, 1, 2);  view_default_352 = None
        clone_default_74 = torch.ops.aten.clone.default(transpose_int_92, memory_format = torch.contiguous_format);  transpose_int_92 = None
        view_default_353 = torch.ops.aten.view.default(clone_default_74, [128, -1, 64]);  clone_default_74 = None
        view_default_354 = torch.ops.aten.view.default(clone_default_72, [128, -1, 64])
        view_default_355 = torch.ops.aten.view.default(clone_default_73, [128, -1, 64])
        transpose_int_93 = torch.ops.aten.transpose.int(view_default_354, 1, 2);  view_default_354 = None
        bmm_default_36 = torch.ops.aten.bmm.default(view_default_353, transpose_int_93)
        view_default_356 = torch.ops.aten.view.default(bmm_default_36, [8, 16, 128, 128]);  bmm_default_36 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(view_default_356, _to_copy_default);  view_default_356 = None
        view_default_357 = torch.ops.aten.view.default(add_tensor_48, [128, 128, 128]);  add_tensor_48 = None
        _softmax_default_18 = torch.ops.aten._softmax.default(view_default_357, -1, False);  view_default_357 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_softmax_default_18, view_default_355)
        view_default_358 = torch.ops.aten.view.default(bmm_default_37, [8, 16, 128, 64]);  bmm_default_37 = None
        transpose_int_94 = torch.ops.aten.transpose.int(view_default_358, 1, 2);  view_default_358 = None
        clone_default_75 = torch.ops.aten.clone.default(transpose_int_94, memory_format = torch.contiguous_format);  transpose_int_94 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_75, [8, 128, 1024]);  clone_default_75 = None
        view_default_359 = torch.ops.aten.view.default(_unsafe_view_default_18, [1024, 1024]);  _unsafe_view_default_18 = None
        t_default_93 = torch.ops.aten.t.default(primals_312);  primals_312 = None
        addmm_default_93 = torch.ops.aten.addmm.default(primals_311, view_default_359, t_default_93);  primals_311 = None
        view_default_360 = torch.ops.aten.view.default(addmm_default_93, [8, 128, 1024]);  addmm_default_93 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(getitem_81, view_default_360);  getitem_81 = view_default_360 = None
        native_layer_norm_default_28 = torch.ops.aten.native_layer_norm.default(add_tensor_49, [1024], primals_310, primals_309, 1e-05)
        getitem_84 = native_layer_norm_default_28[0]
        getitem_85 = native_layer_norm_default_28[1]
        getitem_86 = native_layer_norm_default_28[2];  native_layer_norm_default_28 = None
        view_default_361 = torch.ops.aten.view.default(getitem_84, [1024, 1024])
        t_default_94 = torch.ops.aten.t.default(primals_298);  primals_298 = None
        addmm_default_94 = torch.ops.aten.addmm.default(primals_297, view_default_361, t_default_94);  primals_297 = None
        view_default_362 = torch.ops.aten.view.default(addmm_default_94, [8, 128, 1024]);  addmm_default_94 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(view_default_362, 0.125);  view_default_362 = None
        view_default_363 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_95 = torch.ops.aten.t.default(primals_292);  primals_292 = None
        addmm_default_95 = torch.ops.aten.addmm.default(primals_291, view_default_363, t_default_95);  primals_291 = None
        view_default_364 = torch.ops.aten.view.default(addmm_default_95, [8, 1024, 1024]);  addmm_default_95 = None
        view_default_365 = torch.ops.aten.view.default(view_default_364, [8, -1, 16, 64]);  view_default_364 = None
        transpose_int_95 = torch.ops.aten.transpose.int(view_default_365, 1, 2);  view_default_365 = None
        clone_default_76 = torch.ops.aten.clone.default(transpose_int_95, memory_format = torch.contiguous_format);  transpose_int_95 = None
        view_default_366 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_96 = torch.ops.aten.t.default(primals_300);  primals_300 = None
        addmm_default_96 = torch.ops.aten.addmm.default(primals_299, view_default_366, t_default_96);  primals_299 = None
        view_default_367 = torch.ops.aten.view.default(addmm_default_96, [8, 1024, 1024]);  addmm_default_96 = None
        view_default_368 = torch.ops.aten.view.default(view_default_367, [8, -1, 16, 64]);  view_default_367 = None
        transpose_int_96 = torch.ops.aten.transpose.int(view_default_368, 1, 2);  view_default_368 = None
        clone_default_77 = torch.ops.aten.clone.default(transpose_int_96, memory_format = torch.contiguous_format);  transpose_int_96 = None
        view_default_369 = torch.ops.aten.view.default(mul_tensor_20, [8, 128, 16, 64]);  mul_tensor_20 = None
        transpose_int_97 = torch.ops.aten.transpose.int(view_default_369, 1, 2);  view_default_369 = None
        clone_default_78 = torch.ops.aten.clone.default(transpose_int_97, memory_format = torch.contiguous_format);  transpose_int_97 = None
        view_default_370 = torch.ops.aten.view.default(clone_default_78, [128, -1, 64]);  clone_default_78 = None
        view_default_371 = torch.ops.aten.view.default(clone_default_76, [128, -1, 64])
        view_default_372 = torch.ops.aten.view.default(clone_default_77, [128, -1, 64])
        transpose_int_98 = torch.ops.aten.transpose.int(view_default_371, 1, 2);  view_default_371 = None
        bmm_default_38 = torch.ops.aten.bmm.default(view_default_370, transpose_int_98)
        view_default_373 = torch.ops.aten.view.default(bmm_default_38, [8, 16, 128, 1024]);  bmm_default_38 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(view_default_373, where_scalar_self);  view_default_373 = None
        view_default_374 = torch.ops.aten.view.default(add_tensor_50, [128, 128, 1024]);  add_tensor_50 = None
        _softmax_default_19 = torch.ops.aten._softmax.default(view_default_374, -1, False);  view_default_374 = None
        bmm_default_39 = torch.ops.aten.bmm.default(_softmax_default_19, view_default_372)
        view_default_375 = torch.ops.aten.view.default(bmm_default_39, [8, 16, 128, 64]);  bmm_default_39 = None
        transpose_int_99 = torch.ops.aten.transpose.int(view_default_375, 1, 2);  view_default_375 = None
        clone_default_79 = torch.ops.aten.clone.default(transpose_int_99, memory_format = torch.contiguous_format);  transpose_int_99 = None
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(clone_default_79, [8, 128, 1024]);  clone_default_79 = None
        view_default_376 = torch.ops.aten.view.default(_unsafe_view_default_19, [1024, 1024]);  _unsafe_view_default_19 = None
        t_default_97 = torch.ops.aten.t.default(primals_296);  primals_296 = None
        addmm_default_97 = torch.ops.aten.addmm.default(primals_295, view_default_376, t_default_97);  primals_295 = None
        view_default_377 = torch.ops.aten.view.default(addmm_default_97, [8, 128, 1024]);  addmm_default_97 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(getitem_84, view_default_377);  getitem_84 = view_default_377 = None
        native_layer_norm_default_29 = torch.ops.aten.native_layer_norm.default(add_tensor_51, [1024], primals_294, primals_293, 1e-05)
        getitem_87 = native_layer_norm_default_29[0]
        getitem_88 = native_layer_norm_default_29[1]
        getitem_89 = native_layer_norm_default_29[2];  native_layer_norm_default_29 = None
        view_default_378 = torch.ops.aten.view.default(getitem_87, [1024, 1024])
        t_default_98 = torch.ops.aten.t.default(primals_302);  primals_302 = None
        addmm_default_98 = torch.ops.aten.addmm.default(primals_301, view_default_378, t_default_98);  primals_301 = None
        view_default_379 = torch.ops.aten.view.default(addmm_default_98, [8, 128, 4096]);  addmm_default_98 = None
        gelu_default_9 = torch.ops.aten.gelu.default(view_default_379)
        view_default_380 = torch.ops.aten.view.default(gelu_default_9, [1024, 4096]);  gelu_default_9 = None
        t_default_99 = torch.ops.aten.t.default(primals_304);  primals_304 = None
        addmm_default_99 = torch.ops.aten.addmm.default(primals_303, view_default_380, t_default_99);  primals_303 = None
        view_default_381 = torch.ops.aten.view.default(addmm_default_99, [8, 128, 1024]);  addmm_default_99 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_87, view_default_381);  getitem_87 = view_default_381 = None
        native_layer_norm_default_30 = torch.ops.aten.native_layer_norm.default(add_tensor_52, [1024], primals_306, primals_305, 1e-05)
        getitem_90 = native_layer_norm_default_30[0]
        getitem_91 = native_layer_norm_default_30[1]
        getitem_92 = native_layer_norm_default_30[2];  native_layer_norm_default_30 = None
        view_default_382 = torch.ops.aten.view.default(getitem_90, [1024, 1024])
        t_default_100 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        addmm_default_100 = torch.ops.aten.addmm.default(primals_53, view_default_382, t_default_100);  primals_53 = None
        view_default_383 = torch.ops.aten.view.default(addmm_default_100, [8, 128, 1024]);  addmm_default_100 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(view_default_383, 0.125);  view_default_383 = None
        view_default_384 = torch.ops.aten.view.default(getitem_90, [1024, 1024])
        t_default_101 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_101 = torch.ops.aten.addmm.default(primals_47, view_default_384, t_default_101);  primals_47 = None
        view_default_385 = torch.ops.aten.view.default(addmm_default_101, [8, 128, 1024]);  addmm_default_101 = None
        view_default_386 = torch.ops.aten.view.default(view_default_385, [8, -1, 16, 64]);  view_default_385 = None
        transpose_int_100 = torch.ops.aten.transpose.int(view_default_386, 1, 2);  view_default_386 = None
        clone_default_80 = torch.ops.aten.clone.default(transpose_int_100, memory_format = torch.contiguous_format);  transpose_int_100 = None
        view_default_387 = torch.ops.aten.view.default(getitem_90, [1024, 1024])
        t_default_102 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        addmm_default_102 = torch.ops.aten.addmm.default(primals_55, view_default_387, t_default_102);  primals_55 = None
        view_default_388 = torch.ops.aten.view.default(addmm_default_102, [8, 128, 1024]);  addmm_default_102 = None
        view_default_389 = torch.ops.aten.view.default(view_default_388, [8, -1, 16, 64]);  view_default_388 = None
        transpose_int_101 = torch.ops.aten.transpose.int(view_default_389, 1, 2);  view_default_389 = None
        clone_default_81 = torch.ops.aten.clone.default(transpose_int_101, memory_format = torch.contiguous_format);  transpose_int_101 = None
        view_default_390 = torch.ops.aten.view.default(mul_tensor_21, [8, 128, 16, 64]);  mul_tensor_21 = None
        transpose_int_102 = torch.ops.aten.transpose.int(view_default_390, 1, 2);  view_default_390 = None
        clone_default_82 = torch.ops.aten.clone.default(transpose_int_102, memory_format = torch.contiguous_format);  transpose_int_102 = None
        view_default_391 = torch.ops.aten.view.default(clone_default_82, [128, -1, 64]);  clone_default_82 = None
        view_default_392 = torch.ops.aten.view.default(clone_default_80, [128, -1, 64])
        view_default_393 = torch.ops.aten.view.default(clone_default_81, [128, -1, 64])
        transpose_int_103 = torch.ops.aten.transpose.int(view_default_392, 1, 2);  view_default_392 = None
        bmm_default_40 = torch.ops.aten.bmm.default(view_default_391, transpose_int_103)
        view_default_394 = torch.ops.aten.view.default(bmm_default_40, [8, 16, 128, 128]);  bmm_default_40 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(view_default_394, _to_copy_default);  view_default_394 = None
        view_default_395 = torch.ops.aten.view.default(add_tensor_53, [128, 128, 128]);  add_tensor_53 = None
        _softmax_default_20 = torch.ops.aten._softmax.default(view_default_395, -1, False);  view_default_395 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_softmax_default_20, view_default_393)
        view_default_396 = torch.ops.aten.view.default(bmm_default_41, [8, 16, 128, 64]);  bmm_default_41 = None
        transpose_int_104 = torch.ops.aten.transpose.int(view_default_396, 1, 2);  view_default_396 = None
        clone_default_83 = torch.ops.aten.clone.default(transpose_int_104, memory_format = torch.contiguous_format);  transpose_int_104 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_83, [8, 128, 1024]);  clone_default_83 = None
        view_default_397 = torch.ops.aten.view.default(_unsafe_view_default_20, [1024, 1024]);  _unsafe_view_default_20 = None
        t_default_103 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default_103 = torch.ops.aten.addmm.default(primals_51, view_default_397, t_default_103);  primals_51 = None
        view_default_398 = torch.ops.aten.view.default(addmm_default_103, [8, 128, 1024]);  addmm_default_103 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(getitem_90, view_default_398);  getitem_90 = view_default_398 = None
        native_layer_norm_default_31 = torch.ops.aten.native_layer_norm.default(add_tensor_54, [1024], primals_50, primals_49, 1e-05)
        getitem_93 = native_layer_norm_default_31[0]
        getitem_94 = native_layer_norm_default_31[1]
        getitem_95 = native_layer_norm_default_31[2];  native_layer_norm_default_31 = None
        view_default_399 = torch.ops.aten.view.default(getitem_93, [1024, 1024])
        t_default_104 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        addmm_default_104 = torch.ops.aten.addmm.default(primals_37, view_default_399, t_default_104);  primals_37 = None
        view_default_400 = torch.ops.aten.view.default(addmm_default_104, [8, 128, 1024]);  addmm_default_104 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(view_default_400, 0.125);  view_default_400 = None
        view_default_401 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_105 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_105 = torch.ops.aten.addmm.default(primals_31, view_default_401, t_default_105);  primals_31 = None
        view_default_402 = torch.ops.aten.view.default(addmm_default_105, [8, 1024, 1024]);  addmm_default_105 = None
        view_default_403 = torch.ops.aten.view.default(view_default_402, [8, -1, 16, 64]);  view_default_402 = None
        transpose_int_105 = torch.ops.aten.transpose.int(view_default_403, 1, 2);  view_default_403 = None
        clone_default_84 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format);  transpose_int_105 = None
        view_default_404 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_106 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        addmm_default_106 = torch.ops.aten.addmm.default(primals_39, view_default_404, t_default_106);  primals_39 = None
        view_default_405 = torch.ops.aten.view.default(addmm_default_106, [8, 1024, 1024]);  addmm_default_106 = None
        view_default_406 = torch.ops.aten.view.default(view_default_405, [8, -1, 16, 64]);  view_default_405 = None
        transpose_int_106 = torch.ops.aten.transpose.int(view_default_406, 1, 2);  view_default_406 = None
        clone_default_85 = torch.ops.aten.clone.default(transpose_int_106, memory_format = torch.contiguous_format);  transpose_int_106 = None
        view_default_407 = torch.ops.aten.view.default(mul_tensor_22, [8, 128, 16, 64]);  mul_tensor_22 = None
        transpose_int_107 = torch.ops.aten.transpose.int(view_default_407, 1, 2);  view_default_407 = None
        clone_default_86 = torch.ops.aten.clone.default(transpose_int_107, memory_format = torch.contiguous_format);  transpose_int_107 = None
        view_default_408 = torch.ops.aten.view.default(clone_default_86, [128, -1, 64]);  clone_default_86 = None
        view_default_409 = torch.ops.aten.view.default(clone_default_84, [128, -1, 64])
        view_default_410 = torch.ops.aten.view.default(clone_default_85, [128, -1, 64])
        transpose_int_108 = torch.ops.aten.transpose.int(view_default_409, 1, 2);  view_default_409 = None
        bmm_default_42 = torch.ops.aten.bmm.default(view_default_408, transpose_int_108)
        view_default_411 = torch.ops.aten.view.default(bmm_default_42, [8, 16, 128, 1024]);  bmm_default_42 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(view_default_411, where_scalar_self);  view_default_411 = None
        view_default_412 = torch.ops.aten.view.default(add_tensor_55, [128, 128, 1024]);  add_tensor_55 = None
        _softmax_default_21 = torch.ops.aten._softmax.default(view_default_412, -1, False);  view_default_412 = None
        bmm_default_43 = torch.ops.aten.bmm.default(_softmax_default_21, view_default_410)
        view_default_413 = torch.ops.aten.view.default(bmm_default_43, [8, 16, 128, 64]);  bmm_default_43 = None
        transpose_int_109 = torch.ops.aten.transpose.int(view_default_413, 1, 2);  view_default_413 = None
        clone_default_87 = torch.ops.aten.clone.default(transpose_int_109, memory_format = torch.contiguous_format);  transpose_int_109 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_87, [8, 128, 1024]);  clone_default_87 = None
        view_default_414 = torch.ops.aten.view.default(_unsafe_view_default_21, [1024, 1024]);  _unsafe_view_default_21 = None
        t_default_107 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        addmm_default_107 = torch.ops.aten.addmm.default(primals_35, view_default_414, t_default_107);  primals_35 = None
        view_default_415 = torch.ops.aten.view.default(addmm_default_107, [8, 128, 1024]);  addmm_default_107 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_93, view_default_415);  getitem_93 = view_default_415 = None
        native_layer_norm_default_32 = torch.ops.aten.native_layer_norm.default(add_tensor_56, [1024], primals_34, primals_33, 1e-05)
        getitem_96 = native_layer_norm_default_32[0]
        getitem_97 = native_layer_norm_default_32[1]
        getitem_98 = native_layer_norm_default_32[2];  native_layer_norm_default_32 = None
        view_default_416 = torch.ops.aten.view.default(getitem_96, [1024, 1024])
        t_default_108 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        addmm_default_108 = torch.ops.aten.addmm.default(primals_41, view_default_416, t_default_108);  primals_41 = None
        view_default_417 = torch.ops.aten.view.default(addmm_default_108, [8, 128, 4096]);  addmm_default_108 = None
        gelu_default_10 = torch.ops.aten.gelu.default(view_default_417)
        view_default_418 = torch.ops.aten.view.default(gelu_default_10, [1024, 4096]);  gelu_default_10 = None
        t_default_109 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_109 = torch.ops.aten.addmm.default(primals_43, view_default_418, t_default_109);  primals_43 = None
        view_default_419 = torch.ops.aten.view.default(addmm_default_109, [8, 128, 1024]);  addmm_default_109 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_96, view_default_419);  getitem_96 = view_default_419 = None
        native_layer_norm_default_33 = torch.ops.aten.native_layer_norm.default(add_tensor_57, [1024], primals_46, primals_45, 1e-05)
        getitem_99 = native_layer_norm_default_33[0]
        getitem_100 = native_layer_norm_default_33[1]
        getitem_101 = native_layer_norm_default_33[2];  native_layer_norm_default_33 = None
        view_default_420 = torch.ops.aten.view.default(getitem_99, [1024, 1024])
        t_default_110 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        addmm_default_110 = torch.ops.aten.addmm.default(primals_79, view_default_420, t_default_110);  primals_79 = None
        view_default_421 = torch.ops.aten.view.default(addmm_default_110, [8, 128, 1024]);  addmm_default_110 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(view_default_421, 0.125);  view_default_421 = None
        view_default_422 = torch.ops.aten.view.default(getitem_99, [1024, 1024])
        t_default_111 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        addmm_default_111 = torch.ops.aten.addmm.default(primals_73, view_default_422, t_default_111);  primals_73 = None
        view_default_423 = torch.ops.aten.view.default(addmm_default_111, [8, 128, 1024]);  addmm_default_111 = None
        view_default_424 = torch.ops.aten.view.default(view_default_423, [8, -1, 16, 64]);  view_default_423 = None
        transpose_int_110 = torch.ops.aten.transpose.int(view_default_424, 1, 2);  view_default_424 = None
        clone_default_88 = torch.ops.aten.clone.default(transpose_int_110, memory_format = torch.contiguous_format);  transpose_int_110 = None
        view_default_425 = torch.ops.aten.view.default(getitem_99, [1024, 1024])
        t_default_112 = torch.ops.aten.t.default(primals_82);  primals_82 = None
        addmm_default_112 = torch.ops.aten.addmm.default(primals_81, view_default_425, t_default_112);  primals_81 = None
        view_default_426 = torch.ops.aten.view.default(addmm_default_112, [8, 128, 1024]);  addmm_default_112 = None
        view_default_427 = torch.ops.aten.view.default(view_default_426, [8, -1, 16, 64]);  view_default_426 = None
        transpose_int_111 = torch.ops.aten.transpose.int(view_default_427, 1, 2);  view_default_427 = None
        clone_default_89 = torch.ops.aten.clone.default(transpose_int_111, memory_format = torch.contiguous_format);  transpose_int_111 = None
        view_default_428 = torch.ops.aten.view.default(mul_tensor_23, [8, 128, 16, 64]);  mul_tensor_23 = None
        transpose_int_112 = torch.ops.aten.transpose.int(view_default_428, 1, 2);  view_default_428 = None
        clone_default_90 = torch.ops.aten.clone.default(transpose_int_112, memory_format = torch.contiguous_format);  transpose_int_112 = None
        view_default_429 = torch.ops.aten.view.default(clone_default_90, [128, -1, 64]);  clone_default_90 = None
        view_default_430 = torch.ops.aten.view.default(clone_default_88, [128, -1, 64])
        view_default_431 = torch.ops.aten.view.default(clone_default_89, [128, -1, 64])
        transpose_int_113 = torch.ops.aten.transpose.int(view_default_430, 1, 2);  view_default_430 = None
        bmm_default_44 = torch.ops.aten.bmm.default(view_default_429, transpose_int_113)
        view_default_432 = torch.ops.aten.view.default(bmm_default_44, [8, 16, 128, 128]);  bmm_default_44 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(view_default_432, _to_copy_default);  view_default_432 = _to_copy_default = None
        view_default_433 = torch.ops.aten.view.default(add_tensor_58, [128, 128, 128]);  add_tensor_58 = None
        _softmax_default_22 = torch.ops.aten._softmax.default(view_default_433, -1, False);  view_default_433 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_softmax_default_22, view_default_431)
        view_default_434 = torch.ops.aten.view.default(bmm_default_45, [8, 16, 128, 64]);  bmm_default_45 = None
        transpose_int_114 = torch.ops.aten.transpose.int(view_default_434, 1, 2);  view_default_434 = None
        clone_default_91 = torch.ops.aten.clone.default(transpose_int_114, memory_format = torch.contiguous_format);  transpose_int_114 = None
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(clone_default_91, [8, 128, 1024]);  clone_default_91 = None
        view_default_435 = torch.ops.aten.view.default(_unsafe_view_default_22, [1024, 1024]);  _unsafe_view_default_22 = None
        t_default_113 = torch.ops.aten.t.default(primals_78);  primals_78 = None
        addmm_default_113 = torch.ops.aten.addmm.default(primals_77, view_default_435, t_default_113);  primals_77 = None
        view_default_436 = torch.ops.aten.view.default(addmm_default_113, [8, 128, 1024]);  addmm_default_113 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_99, view_default_436);  getitem_99 = view_default_436 = None
        native_layer_norm_default_34 = torch.ops.aten.native_layer_norm.default(add_tensor_59, [1024], primals_76, primals_75, 1e-05)
        getitem_102 = native_layer_norm_default_34[0]
        getitem_103 = native_layer_norm_default_34[1]
        getitem_104 = native_layer_norm_default_34[2];  native_layer_norm_default_34 = None
        view_default_437 = torch.ops.aten.view.default(getitem_102, [1024, 1024])
        t_default_114 = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default_114 = torch.ops.aten.addmm.default(primals_63, view_default_437, t_default_114);  primals_63 = None
        view_default_438 = torch.ops.aten.view.default(addmm_default_114, [8, 128, 1024]);  addmm_default_114 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(view_default_438, 0.125);  view_default_438 = None
        view_default_439 = torch.ops.aten.view.default(primals_318, [8192, 1024])
        t_default_115 = torch.ops.aten.t.default(primals_58);  primals_58 = None
        addmm_default_115 = torch.ops.aten.addmm.default(primals_57, view_default_439, t_default_115);  primals_57 = None
        view_default_440 = torch.ops.aten.view.default(addmm_default_115, [8, 1024, 1024]);  addmm_default_115 = None
        view_default_441 = torch.ops.aten.view.default(view_default_440, [8, -1, 16, 64]);  view_default_440 = None
        transpose_int_115 = torch.ops.aten.transpose.int(view_default_441, 1, 2);  view_default_441 = None
        clone_default_92 = torch.ops.aten.clone.default(transpose_int_115, memory_format = torch.contiguous_format);  transpose_int_115 = None
        view_default_442 = torch.ops.aten.view.default(primals_318, [8192, 1024]);  primals_318 = None
        t_default_116 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        addmm_default_116 = torch.ops.aten.addmm.default(primals_65, view_default_442, t_default_116);  primals_65 = None
        view_default_443 = torch.ops.aten.view.default(addmm_default_116, [8, 1024, 1024]);  addmm_default_116 = None
        view_default_444 = torch.ops.aten.view.default(view_default_443, [8, -1, 16, 64]);  view_default_443 = None
        transpose_int_116 = torch.ops.aten.transpose.int(view_default_444, 1, 2);  view_default_444 = None
        clone_default_93 = torch.ops.aten.clone.default(transpose_int_116, memory_format = torch.contiguous_format);  transpose_int_116 = None
        view_default_445 = torch.ops.aten.view.default(mul_tensor_24, [8, 128, 16, 64]);  mul_tensor_24 = None
        transpose_int_117 = torch.ops.aten.transpose.int(view_default_445, 1, 2);  view_default_445 = None
        clone_default_94 = torch.ops.aten.clone.default(transpose_int_117, memory_format = torch.contiguous_format);  transpose_int_117 = None
        view_default_446 = torch.ops.aten.view.default(clone_default_94, [128, -1, 64]);  clone_default_94 = None
        view_default_447 = torch.ops.aten.view.default(clone_default_92, [128, -1, 64])
        view_default_448 = torch.ops.aten.view.default(clone_default_93, [128, -1, 64])
        transpose_int_118 = torch.ops.aten.transpose.int(view_default_447, 1, 2);  view_default_447 = None
        bmm_default_46 = torch.ops.aten.bmm.default(view_default_446, transpose_int_118)
        view_default_449 = torch.ops.aten.view.default(bmm_default_46, [8, 16, 128, 1024]);  bmm_default_46 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(view_default_449, where_scalar_self);  view_default_449 = where_scalar_self = None
        view_default_450 = torch.ops.aten.view.default(add_tensor_60, [128, 128, 1024]);  add_tensor_60 = None
        _softmax_default_23 = torch.ops.aten._softmax.default(view_default_450, -1, False);  view_default_450 = None
        bmm_default_47 = torch.ops.aten.bmm.default(_softmax_default_23, view_default_448)
        view_default_451 = torch.ops.aten.view.default(bmm_default_47, [8, 16, 128, 64]);  bmm_default_47 = None
        transpose_int_119 = torch.ops.aten.transpose.int(view_default_451, 1, 2);  view_default_451 = None
        clone_default_95 = torch.ops.aten.clone.default(transpose_int_119, memory_format = torch.contiguous_format);  transpose_int_119 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_95, [8, 128, 1024]);  clone_default_95 = None
        view_default_452 = torch.ops.aten.view.default(_unsafe_view_default_23, [1024, 1024]);  _unsafe_view_default_23 = None
        t_default_117 = torch.ops.aten.t.default(primals_62);  primals_62 = None
        addmm_default_117 = torch.ops.aten.addmm.default(primals_61, view_default_452, t_default_117);  primals_61 = None
        view_default_453 = torch.ops.aten.view.default(addmm_default_117, [8, 128, 1024]);  addmm_default_117 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(getitem_102, view_default_453);  getitem_102 = view_default_453 = None
        native_layer_norm_default_35 = torch.ops.aten.native_layer_norm.default(add_tensor_61, [1024], primals_60, primals_59, 1e-05)
        getitem_105 = native_layer_norm_default_35[0]
        getitem_106 = native_layer_norm_default_35[1]
        getitem_107 = native_layer_norm_default_35[2];  native_layer_norm_default_35 = None
        view_default_454 = torch.ops.aten.view.default(getitem_105, [1024, 1024])
        t_default_118 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_118 = torch.ops.aten.addmm.default(primals_67, view_default_454, t_default_118);  primals_67 = None
        view_default_455 = torch.ops.aten.view.default(addmm_default_118, [8, 128, 4096]);  addmm_default_118 = None
        gelu_default_11 = torch.ops.aten.gelu.default(view_default_455)
        view_default_456 = torch.ops.aten.view.default(gelu_default_11, [1024, 4096]);  gelu_default_11 = None
        t_default_119 = torch.ops.aten.t.default(primals_70);  primals_70 = None
        addmm_default_119 = torch.ops.aten.addmm.default(primals_69, view_default_456, t_default_119);  primals_69 = None
        view_default_457 = torch.ops.aten.view.default(addmm_default_119, [8, 128, 1024]);  addmm_default_119 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_105, view_default_457);  getitem_105 = view_default_457 = None
        native_layer_norm_default_36 = torch.ops.aten.native_layer_norm.default(add_tensor_62, [1024], primals_72, primals_71, 1e-05)
        getitem_108 = native_layer_norm_default_36[0]
        getitem_109 = native_layer_norm_default_36[1]
        getitem_110 = native_layer_norm_default_36[2];  native_layer_norm_default_36 = None
        return [getitem_108, clone_default, clone_default_1, clone_default_4, clone_default_5, clone_default_8, clone_default_9, clone_default_12, clone_default_13, clone_default_16, clone_default_17, clone_default_20, clone_default_21, clone_default_24, clone_default_25, clone_default_28, clone_default_29, clone_default_32, clone_default_33, clone_default_36, clone_default_37, clone_default_40, clone_default_41, clone_default_44, clone_default_45, clone_default_48, clone_default_49, clone_default_52, clone_default_53, clone_default_56, clone_default_57, clone_default_60, clone_default_61, clone_default_64, clone_default_65, clone_default_68, clone_default_69, clone_default_72, clone_default_73, clone_default_76, clone_default_77, clone_default_80, clone_default_81, clone_default_84, clone_default_85, clone_default_88, clone_default_89, clone_default_92, clone_default_93, getitem_74, view_default_303, primals_138, view_default_308, t_default_79, t_default_80, view_default_315, view_default_306, t_default_81, getitem_73, primals_137, primals_283, view_default_89, view_default_344, view_default_341, primals_284, getitem_80, view_default_93, getitem_83, view_default_353, view_default_456, transpose_int_23, t_default_23, getitem_82, add_tensor_62, _softmax_default_4, t_default_119, add_tensor_14, primals_279, t_default_88, t_default_89, primals_280, t_default_27, _softmax_default_21, transpose_int_108, add_tensor_16, t_default_19, view_default_110, view_default_410, primals_293, _softmax_default_5, view_default_75, view_default_414, transpose_int_28, t_default_107, view_default_76, add_tensor_12, primals_294, view_default_106, getitem_101, t_default_40, t_default_41, getitem_37, getitem_100, view_default_156, view_default_159, view_default, t_default_42, t_default_111, getitem_38, t_default_110, view_default_180, view_default_256, t_default_46, t_default_25, t_default_61, view_default_97, add_tensor_4, view_default_176, view_default_232, view_default_230, t_default_60, t_default_12, view_default_19, view_default_17, view_default_100, getitem_56, t_default_45, view_default_173, t_default_3, getitem_55, _softmax_default, transpose_int_3, t_default_59, t_default_20, getitem_19, view_default_80, getitem_20, view_default_78, view_default_68, view_default_95, view_default_13, view_default_28, t_default_16, getitem_22, t_default_24, transpose_int_18, getitem_23, getitem_7, view_default_36, getitem_8, t_default_8, primals_123, primals_206, primals_124, primals_127, transpose_int_73, add_tensor_39, primals_128, primals_201, view_default_290, view_default_283, t_default_112, t_default_71, t_default_72, view_default_279, primals_205, primals_112, primals_202, primals_75, primals_76, primals_85, primals_86, primals_72, primals_231, view_default_420, primals_150, getitem_5, primals_267, primals_189, add_tensor_36, primals_241, view_default_376, t_default_4, transpose_int_68, t_default_114, primals_227, view_default_262, t_default_5, getitem_62, t_default_67, primals_149, getitem_85, _softmax_default_18, primals_190, primals_232, view_default_359, getitem_104, primals_268, getitem_61, getitem_4, _softmax_default_13, view_default_361, view_default_264, primals_242, t_default_93, view_default_273, view_default_21, primals_228, view_default_186, _softmax_default_19, primals_19, add_tensor_56, transpose_int_98, view_default_66, add_tensor_52, view_default_37, view_default_188, primals_20, transpose_int_13, view_default_38, _softmax_default_2, _softmax_default_9, getitem_97, t_default_47, view_default_372, view_default_416, add_tensor_51, t_default_108, transpose_int_48, t_default_9, view_default_87, view_default_51, view_default_380, add_tensor_57, t_default_21, view_default_446, add_tensor_7, primals_23, t_default_96, add_tensor_26, view_default_83, getitem_43, getitem_98, t_default_22, primals_24, view_default_118, t_default_26, t_default_31, view_default_437, transpose_int_118, view_default_121, view_default_125, t_default_32, t_default_30, t_default_15, add_tensor_61, view_default_62, view_default_452, view_default_454, view_default_448, _softmax_default_3, view_default_59, t_default_14, _softmax_default_23, t_default_117, transpose_int_63, view_default_245, _softmax_default_12, add_tensor_34, transpose_int_33, view_default_247, view_default_241, getitem_86, view_default_127, t_default_63, view_default_49, view_default_363, view_default_163, t_default_95, t_default_94, getitem_58, view_default_425, t_default_64, t_default_116, view_default_258, getitem_26, view_default_266, add_tensor_37, getitem_25, view_default_112, t_default_65, t_default_66, primals_3, getitem_59, primals_4, primals_7, primals_8, view_default_249, t_default_28, t_default_1, getitem_2, view_default_135, t_default_83, getitem_77, view_default_325, primals_59, view_default_104, view_default_323, primals_60, t_default_84, primals_254, primals_253, t_default_85, view_default_138, t_default, view_default_349, view_default_7, view_default_4, primals_257, t_default_36, t_default_34, getitem_1, primals_258, getitem_76, primals_71, t_default_35, view_default_142, primals_306, getitem_10, t_default_68, getitem_11, view_default_317, view_default_277, view_default_268, t_default_52, view_default_270, primals_305, t_default_10, t_default_82, getitem_64, primals_309, getitem_65, _softmax_default_16, view_default_197, t_default_69, view_default_203, add_tensor_47, t_default_115, add_tensor_29, view_default_328, t_default_2, transpose_int_83, view_default_214, _softmax_default_14, transpose_int_53, view_default_265, t_default_70, add_tensor_44, view_default_391, view_default_182, view_default_40, view_default_342, view_default_370, view_default_455, t_default_86, view_default_55, getitem_14, getitem_13, t_default_13, t_default_97, view_default_379, getitem_88, add_tensor_9, view_default_24, view_default_378, t_default_6, t_default_98, getitem_89, t_default_99, view_default_57, view_default_408, view_default_439, _softmax_default_7, view_default_144, view_default_397, add_tensor_54, view_default_422, _softmax_default_20, t_default_109, view_default_148, add_tensor_21, t_default_103, t_default_37, view_default_393, transpose_int_103, transpose_int_38, t_default_74, view_default_285, primals_33, primals_45, t_default_73, getitem_68, getitem_67, primals_50, primals_46, primals_49, primals_34, view_default_294, primals_175, t_default_56, t_default_118, primals_111, primals_98, primals_97, t_default_7, view_default_220, getitem_106, add_tensor_6, view_default_235, primals_102, transpose_int_58, primals_176, _softmax_default_1, add_tensor_32, add_tensor_31, view_default_228, primals_179, getitem_107, primals_180, view_default_34, primals_310, t_default_55, primals_101, add_tensor_24, getitem_35, getitem_34, t_default_39, add_tensor_2, view_default_169, t_default_43, view_default_151, view_default_165, view_default_45, add_tensor_22, view_default_152, view_default_2, transpose_int_43, view_default_11, _softmax_default_8, view_default_150, t_default_38, add_tensor_1, getitem_103, view_default_332, _softmax_default_10, view_default_300, t_default_49, getitem_70, view_default_194, view_default_302, t_default_50, view_default_418, view_default_321, t_default_51, add_tensor_27, primals_216, view_default_190, getitem_71, getitem_47, _softmax_default_22, view_default_192, t_default_77, getitem_46, primals_215, view_default_201, t_default_78, _softmax_default_15, view_default_211, view_default_218, view_default_72, view_default_171, t_default_75, add_tensor_11, view_default_296, getitem_41, getitem_17, t_default_18, view_default_209, view_default_287, getitem_40, getitem_50, getitem_16, t_default_54, view_default_311, view_default_74, t_default_17, view_default_207, transpose_int_78, t_default_44, t_default_53, getitem_49, add_tensor_42, view_default_304, t_default_76, add_tensor_41, view_default_429, t_default_62, getitem_110, view_default_417, view_default_252, getitem_109, view_default_338, view_default_334, add_tensor_46, getitem_79, transpose_int_88, _softmax_default_17, t_default_87, view_default_340, view_default_114, t_default_11, getitem_29, view_default_116, view_default_42, view_default_113, t_default_29, add_tensor_17, getitem_28, primals_153, t_default_104, primals_164, view_default_442, view_default_404, getitem_94, view_default_224, getitem_52, primals_154, t_default_105, t_default_113, view_default_435, t_default_58, view_default_401, view_default_227, view_default_399, add_tensor_59, t_default_106, getitem_95, _softmax_default_11, primals_163, getitem_53, view_default_226, view_default_239, t_default_57, view_default_384, t_default_102, t_default_101, view_default_387, getitem_91, view_default_382, t_default_100, transpose_int_8, getitem_92, view_default_30, view_default_154, _softmax_default_6, view_default_189, view_default_131, t_default_48, add_tensor_19, view_default_431, getitem_32, t_default_91, transpose_int_113, t_default_92, getitem_31, getitem_44, view_default_133, view_default_355, view_default_346, add_tensor_49, transpose_int_93, t_default_33, view_default_366, t_default_90]
        
