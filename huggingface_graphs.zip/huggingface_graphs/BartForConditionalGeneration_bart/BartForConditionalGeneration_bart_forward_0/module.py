
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/BartForConditionalGeneration_bart/BartForConditionalGeneration_bart_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1):
        new_empty_default = torch.ops.aten.new_empty.default(primals_1, [8, 128], device = device(type='cuda', index=0), dtype = torch.int64, layout = torch.strided, pin_memory = False);  primals_1 = None
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        eq_scalar = torch.ops.aten.eq.Scalar(zero__default, -100)
        masked_fill__scalar = torch.ops.aten.masked_fill_.Scalar(zero__default, eq_scalar, 1);  zero__default = eq_scalar = None
        return [masked_fill__scalar]
        
