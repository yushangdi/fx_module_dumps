
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/GPT2LMHeadModel_gpt2/GPT2LMHeadModel_gpt2_forward_28/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16):
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(primals_15, [1280], primals_8, primals_7, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default = torch.ops.aten.view.default(getitem, [-1, 1280]);  getitem = None
        addmm_default = torch.ops.aten.addmm.default(primals_2, view_default, primals_3);  primals_2 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [1, 1024, 3840]);  addmm_default = None
        split_tensor = torch.ops.aten.split.Tensor(view_default_1, 1280, 2);  view_default_1 = None
        getitem_3 = split_tensor[0]
        getitem_4 = split_tensor[1]
        getitem_5 = split_tensor[2];  split_tensor = None
        view_default_2 = torch.ops.aten.view.default(getitem_3, [1, 1024, 20, 64]);  getitem_3 = None
        permute_default = torch.ops.aten.permute.default(view_default_2, [0, 2, 1, 3]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(getitem_4, [1, 1024, 20, 64]);  getitem_4 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_3, [0, 2, 1, 3]);  view_default_3 = None
        view_default_4 = torch.ops.aten.view.default(getitem_5, [1, 1024, 20, 64]);  getitem_5 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_4, [0, 2, 1, 3]);  view_default_4 = None
        transpose_int = torch.ops.aten.transpose.int(permute_default_1, -1, -2)
        expand_default = torch.ops.aten.expand.default(permute_default, [1, 20, 1024, 64]);  permute_default = None
        view_default_5 = torch.ops.aten.view.default(expand_default, [20, 1024, 64]);  expand_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int, [1, 20, 64, 1024]);  transpose_int = None
        view_default_6 = torch.ops.aten.view.default(expand_default_1, [20, 64, 1024]);  expand_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(view_default_5, view_default_6)
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(bmm_default, [1, 20, 1024, 1024]);  bmm_default = None
        div_tensor = torch.ops.aten.div.Tensor(_unsafe_view_default, 8.0);  _unsafe_view_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 9223372036854775807);  slice_tensor = None
        _to_copy_default = torch.ops.aten._to_copy.default(slice_tensor_1, dtype = torch.bool);  slice_tensor_1 = None
        where_self = torch.ops.aten.where.self(_to_copy_default, div_tensor, primals_6);  div_tensor = primals_6 = None
        add_tensor = torch.ops.aten.add.Tensor(where_self, primals_16);  where_self = primals_16 = None
        _softmax_default = torch.ops.aten._softmax.default(add_tensor, -1, False);  add_tensor = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [1, 20, 1024, 1024])
        view_default_7 = torch.ops.aten.view.default(expand_default_2, [20, 1024, 1024]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(permute_default_2, [1, 20, 1024, 64])
        view_default_8 = torch.ops.aten.view.default(expand_default_3, [20, 1024, 64]);  expand_default_3 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_7, view_default_8)
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(bmm_default_1, [1, 20, 1024, 64]);  bmm_default_1 = None
        permute_default_3 = torch.ops.aten.permute.default(_unsafe_view_default_1, [0, 2, 1, 3]);  _unsafe_view_default_1 = None
        clone_default = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        view_default_9 = torch.ops.aten.view.default(clone_default, [1, 1024, 1280]);  clone_default = None
        view_default_10 = torch.ops.aten.view.default(view_default_9, [-1, 1280]);  view_default_9 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_4, view_default_10, primals_5);  primals_4 = None
        view_default_11 = torch.ops.aten.view.default(addmm_default_1, [1, 1024, 1280]);  addmm_default_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_11, primals_15);  view_default_11 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_1, [1280], primals_10, primals_9, 1e-05)
        getitem_6 = native_layer_norm_default_1[0]
        getitem_7 = native_layer_norm_default_1[1]
        getitem_8 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_12 = torch.ops.aten.view.default(getitem_6, [-1, 1280]);  getitem_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_11, view_default_12, primals_12);  primals_11 = None
        view_default_13 = torch.ops.aten.view.default(addmm_default_2, [1, 1024, 5120]);  addmm_default_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default_13, 0.5)
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(view_default_13, 3.0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(pow_tensor_scalar, 0.044715);  pow_tensor_scalar = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_13, mul_tensor_1);  mul_tensor_1 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(add_tensor_2, 0.7978845608028654);  add_tensor_2 = None
        tanh_default = torch.ops.aten.tanh.default(mul_tensor_2);  mul_tensor_2 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(tanh_default, 1.0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor, add_tensor_3)
        view_default_14 = torch.ops.aten.view.default(mul_tensor_3, [-1, 5120]);  mul_tensor_3 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_13, view_default_14, primals_14);  primals_13 = None
        view_default_15 = torch.ops.aten.view.default(addmm_default_3, [1, 1024, 1280]);  addmm_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_15);  view_default_15 = None
        return [add_tensor_4, permute_default_1, permute_default_2, _softmax_default, primals_8, view_default_7, view_default_5, primals_15, primals_12, mul_tensor, add_tensor_3, view_default_8, view_default, view_default_14, tanh_default, view_default_6, primals_5, getitem_7, view_default_12, getitem_1, primals_10, primals_14, primals_3, add_tensor_1, view_default_13, _to_copy_default, getitem_2, primals_7, view_default_10, getitem_8, primals_9]
        
