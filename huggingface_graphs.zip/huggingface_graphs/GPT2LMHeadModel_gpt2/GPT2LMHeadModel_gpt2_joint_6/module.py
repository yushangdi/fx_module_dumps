
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'huggingface_graphs/GPT2LMHeadModel_gpt2/GPT2LMHeadModel_gpt2_joint_6/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, tangents_1, tangents_2, tangents_3):
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(primals_15, [1280], primals_8, primals_7, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default = torch.ops.aten.view.default(getitem, [-1, 1280]);  getitem = None
        addmm_default = torch.ops.aten.addmm.default(primals_2, view_default, primals_3);  primals_2 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [1, 1024, 3840]);  addmm_default = None
        split_tensor = torch.ops.aten.split.Tensor(view_default_1, 1280, 2);  view_default_1 = None
        getitem_3 = split_tensor[0]
        getitem_4 = split_tensor[1]
        getitem_5 = split_tensor[2];  split_tensor = None
        view_default_2 = torch.ops.aten.view.default(getitem_3, [1, 1024, 20, 64]);  getitem_3 = None
        permute_default = torch.ops.aten.permute.default(view_default_2, [0, 2, 1, 3]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(getitem_4, [1, 1024, 20, 64]);  getitem_4 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_3, [0, 2, 1, 3]);  view_default_3 = None
        view_default_4 = torch.ops.aten.view.default(getitem_5, [1, 1024, 20, 64]);  getitem_5 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_4, [0, 2, 1, 3]);  view_default_4 = None
        transpose_int = torch.ops.aten.transpose.int(permute_default_1, -1, -2)
        expand_default = torch.ops.aten.expand.default(permute_default, [1, 20, 1024, 64]);  permute_default = None
        view_default_5 = torch.ops.aten.view.default(expand_default, [20, 1024, 64]);  expand_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int, [1, 20, 64, 1024]);  transpose_int = None
        view_default_6 = torch.ops.aten.view.default(expand_default_1, [20, 64, 1024]);  expand_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(view_default_5, view_default_6)
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(bmm_default, [1, 20, 1024, 1024]);  bmm_default = None
        div_tensor = torch.ops.aten.div.Tensor(_unsafe_view_default, 8.0);  _unsafe_view_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 9223372036854775807);  slice_tensor = None
        _to_copy_default = torch.ops.aten._to_copy.default(slice_tensor_1, dtype = torch.bool);  slice_tensor_1 = None
        where_self = torch.ops.aten.where.self(_to_copy_default, div_tensor, primals_6);  div_tensor = primals_6 = None
        add_tensor = torch.ops.aten.add.Tensor(where_self, primals_16);  where_self = primals_16 = None
        _softmax_default = torch.ops.aten._softmax.default(add_tensor, -1, False);  add_tensor = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [1, 20, 1024, 1024])
        view_default_7 = torch.ops.aten.view.default(expand_default_2, [20, 1024, 1024]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(permute_default_2, [1, 20, 1024, 64])
        view_default_8 = torch.ops.aten.view.default(expand_default_3, [20, 1024, 64]);  expand_default_3 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_7, view_default_8)
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(bmm_default_1, [1, 20, 1024, 64]);  bmm_default_1 = None
        permute_default_3 = torch.ops.aten.permute.default(_unsafe_view_default_1, [0, 2, 1, 3]);  _unsafe_view_default_1 = None
        clone_default = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        view_default_9 = torch.ops.aten.view.default(clone_default, [1, 1024, 1280]);  clone_default = None
        view_default_10 = torch.ops.aten.view.default(view_default_9, [-1, 1280]);  view_default_9 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_4, view_default_10, primals_5);  primals_4 = None
        view_default_11 = torch.ops.aten.view.default(addmm_default_1, [1, 1024, 1280]);  addmm_default_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_11, primals_15);  view_default_11 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_1, [1280], primals_10, primals_9, 1e-05)
        getitem_6 = native_layer_norm_default_1[0]
        getitem_7 = native_layer_norm_default_1[1]
        getitem_8 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_12 = torch.ops.aten.view.default(getitem_6, [-1, 1280]);  getitem_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_11, view_default_12, primals_12);  primals_11 = None
        view_default_13 = torch.ops.aten.view.default(addmm_default_2, [1, 1024, 5120]);  addmm_default_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default_13, 0.5)
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(view_default_13, 3.0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(pow_tensor_scalar, 0.044715);  pow_tensor_scalar = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_13, mul_tensor_1);  mul_tensor_1 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(add_tensor_2, 0.7978845608028654);  add_tensor_2 = None
        tanh_default = torch.ops.aten.tanh.default(mul_tensor_2);  mul_tensor_2 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(tanh_default, 1.0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor, add_tensor_3)
        view_default_14 = torch.ops.aten.view.default(mul_tensor_3, [-1, 5120]);  mul_tensor_3 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_13, view_default_14, primals_14);  primals_13 = None
        view_default_15 = torch.ops.aten.view.default(addmm_default_3, [1, 1024, 1280]);  addmm_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_15);  view_default_15 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(add_tensor_4, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(permute_default_1, tangents_2)
        is_same_size_default_2 = torch.ops.aten.is_same_size.default(permute_default_2, tangents_3)
        view_default_16 = torch.ops.aten.view.default(tangents_1, [1024, 1280])
        t_default = torch.ops.aten.t.default(primals_14);  primals_14 = None
        mm_default = torch.ops.aten.mm.default(view_default_16, t_default);  t_default = None
        t_default_1 = torch.ops.aten.t.default(view_default_14);  view_default_14 = None
        mm_default_1 = torch.ops.aten.mm.default(t_default_1, view_default_16);  t_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_16, [0], True);  view_default_16 = None
        view_default_17 = torch.ops.aten.view.default(sum_dim_int_list, [1280]);  sum_dim_int_list = None
        view_default_18 = torch.ops.aten.view.default(mm_default, [1, 1024, 5120]);  mm_default = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(view_default_18, mul_tensor);  mul_tensor = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(view_default_18, add_tensor_3);  view_default_18 = add_tensor_3 = None
        to_dtype = torch.ops.aten.to.dtype(mul_tensor_4, torch.float32);  mul_tensor_4 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32);  tanh_default = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_6, 1);  mul_tensor_6 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_7, torch.float32);  mul_tensor_7 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype_2, 0.7978845608028654);  to_dtype_2 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(mul_tensor_8, 0.044715)
        pow_tensor_scalar_1 = torch.ops.aten.pow.Tensor_Scalar(view_default_13, 2.0);  view_default_13 = None
        mul_scalar = torch.ops.aten.mul.Scalar(pow_tensor_scalar_1, 3.0);  pow_tensor_scalar_1 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(mul_tensor_9, mul_scalar);  mul_tensor_9 = mul_scalar = None
        add_tensor_5 = torch.ops.aten.add.Tensor(mul_tensor_8, mul_tensor_10);  mul_tensor_8 = mul_tensor_10 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(mul_tensor_5, 0.5);  mul_tensor_5 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, mul_tensor_11);  add_tensor_5 = mul_tensor_11 = None
        view_default_19 = torch.ops.aten.view.default(add_tensor_6, [1024, 5120]);  add_tensor_6 = None
        t_default_2 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_19, t_default_2);  t_default_2 = None
        t_default_3 = torch.ops.aten.t.default(view_default_12);  view_default_12 = None
        mm_default_3 = torch.ops.aten.mm.default(t_default_3, view_default_19);  t_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_19, [0], True);  view_default_19 = None
        view_default_20 = torch.ops.aten.view.default(sum_dim_int_list_1, [5120]);  sum_dim_int_list_1 = None
        view_default_21 = torch.ops.aten.view.default(mm_default_2, [1, 1024, 1280]);  mm_default_2 = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(view_default_21, add_tensor_1, [1280], getitem_7, getitem_8, primals_10, primals_9, [True, True, True]);  view_default_21 = add_tensor_1 = getitem_7 = getitem_8 = primals_10 = primals_9 = None
        getitem_9 = native_layer_norm_backward_default[0]
        getitem_10 = native_layer_norm_backward_default[1]
        getitem_11 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        add_tensor_7 = torch.ops.aten.add.Tensor(tangents_1, getitem_9);  tangents_1 = getitem_9 = None
        view_default_22 = torch.ops.aten.view.default(add_tensor_7, [1024, 1280])
        t_default_4 = torch.ops.aten.t.default(primals_5);  primals_5 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_22, t_default_4);  t_default_4 = None
        t_default_5 = torch.ops.aten.t.default(view_default_10);  view_default_10 = None
        mm_default_5 = torch.ops.aten.mm.default(t_default_5, view_default_22);  t_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_22, [0], True);  view_default_22 = None
        view_default_23 = torch.ops.aten.view.default(sum_dim_int_list_2, [1280]);  sum_dim_int_list_2 = None
        view_default_24 = torch.ops.aten.view.default(mm_default_4, [1, 1024, 1280]);  mm_default_4 = None
        view_default_25 = torch.ops.aten.view.default(view_default_24, [1, 1024, 20, 64]);  view_default_24 = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_25, [0, 2, 1, 3]);  view_default_25 = None
        view_default_26 = torch.ops.aten.view.default(permute_default_4, [20, 1024, 64]);  permute_default_4 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_7, 1, 2);  view_default_7 = None
        bmm_default_2 = torch.ops.aten.bmm.default(transpose_int_1, view_default_26);  transpose_int_1 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_8, 1, 2);  view_default_8 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_26, transpose_int_2);  view_default_26 = transpose_int_2 = None
        view_default_27 = torch.ops.aten.view.default(bmm_default_2, [1, 20, 1024, 64]);  bmm_default_2 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(tangents_3, view_default_27);  tangents_3 = view_default_27 = None
        view_default_28 = torch.ops.aten.view.default(bmm_default_3, [1, 20, 1024, 1024]);  bmm_default_3 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_28, _softmax_default, -1, torch.float32);  view_default_28 = _softmax_default = None
        empty_like_default = torch.ops.aten.empty_like.default(_softmax_backward_data_default)
        zero__default = torch.ops.aten.zero_.default(empty_like_default);  empty_like_default = None
        where_self_1 = torch.ops.aten.where.self(_to_copy_default, _softmax_backward_data_default, zero__default);  _to_copy_default = _softmax_backward_data_default = zero__default = None
        div_tensor_1 = torch.ops.aten.div.Tensor(where_self_1, 8.0);  where_self_1 = None
        view_default_29 = torch.ops.aten.view.default(div_tensor_1, [20, 1024, 1024]);  div_tensor_1 = None
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        bmm_default_4 = torch.ops.aten.bmm.default(transpose_int_3, view_default_29);  transpose_int_3 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_29, transpose_int_4);  view_default_29 = transpose_int_4 = None
        view_default_30 = torch.ops.aten.view.default(bmm_default_4, [1, 20, 64, 1024]);  bmm_default_4 = None
        view_default_31 = torch.ops.aten.view.default(bmm_default_5, [1, 20, 1024, 64]);  bmm_default_5 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_30, -1, -2);  view_default_30 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(tangents_2, transpose_int_5);  tangents_2 = transpose_int_5 = None
        permute_default_5 = torch.ops.aten.permute.default(add_tensor_8, [0, 2, 1, 3]);  add_tensor_8 = None
        clone_default_1 = torch.ops.aten.clone.default(permute_default_5, memory_format = torch.contiguous_format);  permute_default_5 = None
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_1, [1, 1024, 1280]);  clone_default_1 = None
        permute_default_6 = torch.ops.aten.permute.default(add_tensor_9, [0, 2, 1, 3]);  add_tensor_9 = None
        clone_default_2 = torch.ops.aten.clone.default(permute_default_6, memory_format = torch.contiguous_format);  permute_default_6 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [1, 1024, 1280]);  clone_default_2 = None
        permute_default_7 = torch.ops.aten.permute.default(view_default_31, [0, 2, 1, 3]);  view_default_31 = None
        clone_default_3 = torch.ops.aten.clone.default(permute_default_7, memory_format = torch.contiguous_format);  permute_default_7 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_3, [1, 1024, 1280]);  clone_default_3 = None
        cat_default = torch.ops.aten.cat.default([_unsafe_view_default_4, _unsafe_view_default_3, _unsafe_view_default_2], 2);  _unsafe_view_default_4 = _unsafe_view_default_3 = _unsafe_view_default_2 = None
        view_default_32 = torch.ops.aten.view.default(cat_default, [1024, 3840]);  cat_default = None
        t_default_6 = torch.ops.aten.t.default(primals_3);  primals_3 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_32, t_default_6);  t_default_6 = None
        t_default_7 = torch.ops.aten.t.default(view_default);  view_default = None
        mm_default_7 = torch.ops.aten.mm.default(t_default_7, view_default_32);  t_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_32, [0], True);  view_default_32 = None
        view_default_33 = torch.ops.aten.view.default(sum_dim_int_list_3, [3840]);  sum_dim_int_list_3 = None
        view_default_34 = torch.ops.aten.view.default(mm_default_6, [1, 1024, 1280]);  mm_default_6 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(view_default_34, primals_15, [1280], getitem_1, getitem_2, primals_8, primals_7, [True, True, True]);  view_default_34 = primals_15 = getitem_1 = getitem_2 = primals_8 = primals_7 = None
        getitem_12 = native_layer_norm_backward_default_1[0]
        getitem_13 = native_layer_norm_backward_default_1[1]
        getitem_14 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_7, getitem_12);  add_tensor_7 = getitem_12 = None
        return [add_tensor_4, permute_default_1, permute_default_2, None, view_default_33, mm_default_7, view_default_23, mm_default_5, None, getitem_14, getitem_13, getitem_11, getitem_10, view_default_20, mm_default_3, view_default_17, mm_default_1, add_tensor_10, None]
        
